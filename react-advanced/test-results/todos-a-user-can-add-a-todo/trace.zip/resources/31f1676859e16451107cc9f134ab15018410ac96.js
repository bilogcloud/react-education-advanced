const StrictMode = __vite__cjsImport3_react["StrictMode"];const createRoot = __vite__cjsImport4_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import "/src/index.css";
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=37813280";
import { ReactQueryDevtools } from "/node_modules/.vite/deps/@tanstack_react-query-devtools.js?v=37813280";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=37813280";
import __vite__cjsImport4_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=37813280";
import { BrowserRouter } from "/node_modules/.vite/deps/react-router.js?v=37813280";
import App from "/src/App.tsx";
var _jsxFileName = "/Users/luka/Documents/Work/React Course/React advanced 2026/react-advanced/src/main.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=37813280";
const queryClient = new QueryClient({ defaultOptions: { queries: { staleTime: 3e4 } } });
createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
	client: queryClient,
	children: [/* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 9
	}, this), /* @__PURE__ */ _jsxDEV(ReactQueryDevtools, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 9
	}, this)]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 19,
	columnNumber: 7
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 18,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 17,
	columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUNQLFNBQVMsYUFBYSwyQkFBMkI7QUFDakQsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxxQkFBcUI7QUFFOUIsT0FBTyxTQUFTOzs7QUFFaEIsTUFBTSxjQUFjLElBQUksWUFBWSxFQUNsQyxnQkFBZ0IsRUFDZCxTQUFTLEVBQUUsV0FBVyxJQUFPLEVBQy9CLEVBQ0YsQ0FBQztBQUVELFdBQVcsU0FBUyxlQUFlLE1BQU0sQ0FBRSxDQUFDLENBQUMsT0FDM0Msd0JBQUMsWUFBRCxZQUNFLHdCQUFDLGVBQUQsWUFDRSx3QkFBQyxxQkFBRDtDQUFxQixRQUFRO1dBQTdCLENBQ0Usd0JBQUMsS0FBRCxDQUFNOzs7O1dBQ04sd0JBQUMsb0JBQUQsQ0FBcUI7Ozs7U0FDRjs7Ozs7U0FDUjs7OztTQUNMOzs7O1FBQ2QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuL2luZGV4LmNzcydcbmltcG9ydCB7IFF1ZXJ5Q2xpZW50LCBRdWVyeUNsaWVudFByb3ZpZGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgUmVhY3RRdWVyeURldnRvb2xzIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5LWRldnRvb2xzJ1xuaW1wb3J0IHsgU3RyaWN0TW9kZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnXG5pbXBvcnQgeyBCcm93c2VyUm91dGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyJ1xuXG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwLnRzeCdcblxuY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoe1xuICBkZWZhdWx0T3B0aW9uczoge1xuICAgIHF1ZXJpZXM6IHsgc3RhbGVUaW1lOiAzMF8wMDAgfSwgLy8gZGF0YSBjb3VudHMgYXMgZnJlc2ggZm9yIDMwIHNcbiAgfSxcbn0pXG5cbmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSEpLnJlbmRlcihcbiAgPFN0cmljdE1vZGU+XG4gICAgPEJyb3dzZXJSb3V0ZXI+XG4gICAgICA8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT5cbiAgICAgICAgPEFwcCAvPlxuICAgICAgICA8UmVhY3RRdWVyeURldnRvb2xzIC8+XG4gICAgICA8L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4gICAgPC9Ccm93c2VyUm91dGVyPlxuICA8L1N0cmljdE1vZGU+LFxuKVxuIl19