import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/day3/TodoApp.tsx");const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=37813280";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=37813280";
import { api } from "/src/day2/api.ts";
var _jsxFileName = "/Users/luka/Documents/Work/React Course/React advanced 2026/react-advanced/src/day3/TodoApp.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=37813280";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$();
const todoKeys = { all: ["todos"] };
function useTodos() {
	_s();
	return useQuery({
		queryKey: todoKeys.all,
		queryFn: () => api("/todos")
	});
}
_s(useTodos, "4ZpngI1uv+Uo3WQHEZmTQ5FNM+k=", false, function() {
	return [useQuery];
});
function useAddTodo() {
	_s2();
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (title) => api("/todos", {
			method: "POST",
			body: JSON.stringify({
				title,
				done: false
			})
		}),
		onSuccess: () => queryClient.invalidateQueries({ queryKey: todoKeys.all })
	});
}
_s2(useAddTodo, "i+IOhi4najGoOT2n6g5oPWdxN4s=", false, function() {
	return [useQueryClient, useMutation];
});
function useToggleTodo() {
	_s3();
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (todo) => api(`/todos/${todo.id}`, {
			method: "PATCH",
			body: JSON.stringify({ done: !todo.done })
		}),
		onMutate: async (todo) => {
			await queryClient.cancelQueries({ queryKey: todoKeys.all });
			const previous = queryClient.getQueryData(todoKeys.all);
			queryClient.setQueryData(todoKeys.all, (old) => old?.map((t) => t.id === todo.id ? {
				...t,
				done: !t.done
			} : t));
			return { previous };
		},
		onError: (_error, _todo, result) => {
			queryClient.setQueryData(todoKeys.all, result?.previous);
		},
		onSettled: () => queryClient.invalidateQueries({ queryKey: todoKeys.all })
	});
}
_s3(useToggleTodo, "i+IOhi4najGoOT2n6g5oPWdxN4s=", false, function() {
	return [useQueryClient, useMutation];
});
export function TodoApp() {
	_s4();
	const { data: todos, isPending, isError, error, isFetching } = useTodos();
	const addTodo = useAddTodo();
	const toggleTodo = useToggleTodo();
	const [title, setTitle] = useState("");
	if (isPending) return /* @__PURE__ */ _jsxDEV("p", { children: "Loading todos…" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 58,
		columnNumber: 25
	}, this);
	if (isError) return /* @__PURE__ */ _jsxDEV("p", {
		role: "alert",
		children: ["Error: ", error.message]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 23
	}, this);
	return /* @__PURE__ */ _jsxDEV("section", { children: [
		/* @__PURE__ */ _jsxDEV("form", {
			onSubmit: (e) => {
				e.preventDefault();
				addTodo.mutate(title, { onSuccess: () => setTitle("") });
			},
			children: [/* @__PURE__ */ _jsxDEV("input", {
				value: title,
				onChange: (e) => setTitle(e.target.value),
				"aria-label": "New todo",
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				disabled: addTodo.isPending,
				children: addTodo.isPending ? "Adding…" : "Add"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 7
		}, this),
		isFetching && /* @__PURE__ */ _jsxDEV("small", { children: "Refreshing…" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 22
		}, this),
		/* @__PURE__ */ _jsxDEV("ul", { children: todos.map((todo) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("label", { children: [
			/* @__PURE__ */ _jsxDEV("input", {
				type: "checkbox",
				checked: todo.done,
				onChange: () => toggleTodo.mutate(todo)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 15
			}, this),
			" ",
			todo.title
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 13
		}, this) }, todo.id, false, {
			fileName: _jsxFileName,
			lineNumber: 84,
			columnNumber: 11
		}, this)) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 7
		}, this),
		toggleTodo.isError && /* @__PURE__ */ _jsxDEV("p", {
			role: "alert",
			children: ["Couldn't save: ", toggleTodo.error.message]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 98,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(RemainingCount, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 62,
		columnNumber: 5
	}, this);
}
_s4(TodoApp, "s93chnj9g9/WvpNjRZ6fPZufrJU=", false, function() {
	return [
		useTodos,
		useAddTodo,
		useToggleTodo
	];
});
_c = TodoApp;
function RemainingCount() {
	_s5();
	const { data: todos = [] } = useTodos();
	return /* @__PURE__ */ _jsxDEV("p", { children: ["Remaining: ", todos.filter((t) => !t.done).length] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 108,
		columnNumber: 10
	}, this);
}
_s5(RemainingCount, "II0TEGkllmQ/0pnFzNtYbWUpIr4=", false, function() {
	return [useTodos];
});
_c2 = RemainingCount;
var _c, _c2;
$RefreshReg$(_c, "TodoApp");
$RefreshReg$(_c2, "RemainingCount");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/day3/TodoApp.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/luka/Documents/Work/React Course/React advanced 2026/react-advanced/src/day3/TodoApp.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/luka/Documents/Work/React Course/React advanced 2026/react-advanced/src/day3/TodoApp.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/luka/Documents/Work/React Course/React advanced 2026/react-advanced/src/day3/TodoApp.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFVBQVUsc0JBQXNCO0FBQ3RELFNBQVMsZ0JBQWdCO0FBRXpCLFNBQVMsV0FBVzs7OztBQUdwQixNQUFNLFdBQVcsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFXO0FBRTNDLFNBQVMsV0FBVzs7Q0FDbEIsT0FBTyxTQUFTO0VBQ2QsVUFBVSxTQUFTO0VBQ25CLGVBQWUsSUFBWSxRQUFRO0NBQ3JDLENBQUM7QUFDSDs7OztBQUVBLFNBQVMsYUFBYTs7Q0FDcEIsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsT0FBTyxZQUFZO0VBQ2pCLGFBQWEsVUFDWCxJQUFVLFVBQVU7R0FDbEIsUUFBUTtHQUNSLE1BQU0sS0FBSyxVQUFVO0lBQUU7SUFBTyxNQUFNO0dBQU0sQ0FBQztFQUM3QyxDQUFDO0VBQ0gsaUJBQWlCLFlBQVksa0JBQWtCLEVBQUUsVUFBVSxTQUFTLElBQUksQ0FBQztDQUMzRSxDQUFDO0FBQ0g7Ozs7QUFFQSxTQUFTLGdCQUFnQjs7Q0FDdkIsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsT0FBTyxZQUFZO0VBQ2pCLGFBQWEsU0FDWCxJQUFVLFVBQVUsS0FBSyxNQUFNO0dBQzdCLFFBQVE7R0FDUixNQUFNLEtBQUssVUFBVSxFQUFFLE1BQU0sQ0FBQyxLQUFLLEtBQUssQ0FBQztFQUMzQyxDQUFDO0VBRUgsVUFBVSxPQUFPLFNBQVM7R0FDeEIsTUFBTSxZQUFZLGNBQWMsRUFBRSxVQUFVLFNBQVMsSUFBSSxDQUFDO0dBQzFELE1BQU0sV0FBVyxZQUFZLGFBQXFCLFNBQVMsR0FBRztHQUM5RCxZQUFZLGFBQXFCLFNBQVMsTUFBTSxRQUM5QyxLQUFLLEtBQUssTUFBTyxFQUFFLE9BQU8sS0FBSyxLQUFLO0lBQUUsR0FBRztJQUFHLE1BQU0sQ0FBQyxFQUFFO0dBQUssSUFBSSxDQUFFLENBQ2xFO0dBQ0EsT0FBTyxFQUFFLFNBQVM7RUFDcEI7RUFDQSxVQUFVLFFBQVEsT0FBTyxXQUFXO0dBQ2xDLFlBQVksYUFBYSxTQUFTLEtBQUssUUFBUSxRQUFRO0VBQ3pEO0VBQ0EsaUJBQWlCLFlBQVksa0JBQWtCLEVBQUUsVUFBVSxTQUFTLElBQUksQ0FBQztDQUMzRSxDQUFDO0FBQ0g7Ozs7QUFFQSxPQUFPLFNBQVMsVUFBVTs7Q0FDeEIsTUFBTSxFQUFFLE1BQU0sT0FBTyxXQUFXLFNBQVMsT0FBTyxlQUFlLFNBQVM7Q0FDeEUsTUFBTSxVQUFVLFdBQVc7Q0FDM0IsTUFBTSxhQUFhLGNBQWM7Q0FDakMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FFckMsSUFBSSxXQUFXLE9BQU8sd0JBQUMsS0FBRCxZQUFHLGlCQUFpQjs7Ozs7Q0FDMUMsSUFBSSxTQUFTLE9BQU8sd0JBQUMsS0FBRDtFQUFHLE1BQUs7WUFBUixDQUFnQixXQUFRLE1BQU0sT0FBVzs7Ozs7O0NBRTdELE9BQ0Usd0JBQUMsV0FBRDtFQUNFLHdCQUFDLFFBQUQ7R0FDRSxXQUFXLE1BQU07SUFDZixFQUFFLGVBQWU7SUFDakIsUUFBUSxPQUFPLE9BQU8sRUFBRSxpQkFBaUIsU0FBUyxFQUFFLEVBQUUsQ0FBQztHQUN6RDthQUpGLENBTUUsd0JBQUMsU0FBRDtJQUNFLE9BQU87SUFDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztJQUN4QyxjQUFXO0lBQ1g7R0FDRDs7OzthQUNELHdCQUFDLFVBQUQ7SUFBUSxVQUFVLFFBQVE7Y0FDdkIsUUFBUSxZQUFZLFlBQVk7R0FDM0I7Ozs7V0FDSjs7Ozs7O0VBRUwsY0FBYyx3QkFBQyxTQUFELFlBQU8sY0FBa0I7Ozs7O0VBRXhDLHdCQUFDLE1BQUQsWUFDRyxNQUFNLEtBQUssU0FDVix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsU0FBRDtHQUNFLHdCQUFDLFNBQUQ7SUFDRSxNQUFLO0lBQ0wsU0FBUyxLQUFLO0lBQ2QsZ0JBQWdCLFdBQVcsT0FBTyxJQUFJO0dBQ3ZDOzs7OztHQUFFO0dBQ0YsS0FBSztFQUNEOzs7O1dBQ0wsR0FUSyxLQUFLOzs7O1NBU1YsQ0FDTCxFQUNDOzs7OztFQUVILFdBQVcsV0FDVix3QkFBQyxLQUFEO0dBQUcsTUFBSzthQUFSLENBQWdCLG1CQUFnQixXQUFXLE1BQU0sT0FBVzs7Ozs7O0VBRzlELHdCQUFDLGdCQUFELENBQWlCOzs7OztDQUNWOzs7OztBQUViOzs7Ozs7Ozs7QUFFQSxTQUFTLGlCQUFpQjs7Q0FDeEIsTUFBTSxFQUFFLE1BQU0sUUFBUSxDQUFDLE1BQU0sU0FBUztDQUN0QyxPQUFPLHdCQUFDLEtBQUQsYUFBRyxlQUFZLE1BQU0sUUFBUSxNQUFNLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxNQUFVOzs7OztBQUMvRCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUb2RvQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuaW1wb3J0IHsgYXBpIH0gZnJvbSAnQC9kYXkyL2FwaS50cydcbmltcG9ydCB0eXBlIHsgVG9kbyB9IGZyb20gJ0AvZGF5Mi90eXBlcy50cydcblxuY29uc3QgdG9kb0tleXMgPSB7IGFsbDogWyd0b2RvcyddIGFzIGNvbnN0IH1cblxuZnVuY3Rpb24gdXNlVG9kb3MoKSB7XG4gIHJldHVybiB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IHRvZG9LZXlzLmFsbCxcbiAgICBxdWVyeUZuOiAoKSA9PiBhcGk8VG9kb1tdPignL3RvZG9zJyksXG4gIH0pXG59XG5cbmZ1bmN0aW9uIHVzZUFkZFRvZG8oKSB7XG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuICByZXR1cm4gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46ICh0aXRsZTogc3RyaW5nKSA9PlxuICAgICAgYXBpPFRvZG8+KCcvdG9kb3MnLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHRpdGxlLCBkb25lOiBmYWxzZSB9KSxcbiAgICAgIH0pLFxuICAgIG9uU3VjY2VzczogKCkgPT4gcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogdG9kb0tleXMuYWxsIH0pLFxuICB9KVxufVxuXG5mdW5jdGlvbiB1c2VUb2dnbGVUb2RvKCkge1xuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbiAgcmV0dXJuIHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiAodG9kbzogVG9kbykgPT5cbiAgICAgIGFwaTxUb2RvPihgL3RvZG9zLyR7dG9kby5pZH1gLCB7XG4gICAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBkb25lOiAhdG9kby5kb25lIH0pLFxuICAgICAgfSksXG5cbiAgICBvbk11dGF0ZTogYXN5bmMgKHRvZG8pID0+IHtcbiAgICAgIGF3YWl0IHF1ZXJ5Q2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleTogdG9kb0tleXMuYWxsIH0pXG4gICAgICBjb25zdCBwcmV2aW91cyA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5RGF0YTxUb2RvW10+KHRvZG9LZXlzLmFsbClcbiAgICAgIHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGF0YTxUb2RvW10+KHRvZG9LZXlzLmFsbCwgKG9sZCkgPT5cbiAgICAgICAgb2xkPy5tYXAoKHQpID0+ICh0LmlkID09PSB0b2RvLmlkID8geyAuLi50LCBkb25lOiAhdC5kb25lIH0gOiB0KSksXG4gICAgICApXG4gICAgICByZXR1cm4geyBwcmV2aW91cyB9XG4gICAgfSxcbiAgICBvbkVycm9yOiAoX2Vycm9yLCBfdG9kbywgcmVzdWx0KSA9PiB7XG4gICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEodG9kb0tleXMuYWxsLCByZXN1bHQ/LnByZXZpb3VzKVxuICAgIH0sXG4gICAgb25TZXR0bGVkOiAoKSA9PiBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiB0b2RvS2V5cy5hbGwgfSksXG4gIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBUb2RvQXBwKCkge1xuICBjb25zdCB7IGRhdGE6IHRvZG9zLCBpc1BlbmRpbmcsIGlzRXJyb3IsIGVycm9yLCBpc0ZldGNoaW5nIH0gPSB1c2VUb2RvcygpXG4gIGNvbnN0IGFkZFRvZG8gPSB1c2VBZGRUb2RvKClcbiAgY29uc3QgdG9nZ2xlVG9kbyA9IHVzZVRvZ2dsZVRvZG8oKVxuICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlKCcnKVxuXG4gIGlmIChpc1BlbmRpbmcpIHJldHVybiA8cD5Mb2FkaW5nIHRvZG9z4oCmPC9wPlxuICBpZiAoaXNFcnJvcikgcmV0dXJuIDxwIHJvbGU9XCJhbGVydFwiPkVycm9yOiB7ZXJyb3IubWVzc2FnZX08L3A+XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbj5cbiAgICAgIDxmb3JtXG4gICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICAgIGFkZFRvZG8ubXV0YXRlKHRpdGxlLCB7IG9uU3VjY2VzczogKCkgPT4gc2V0VGl0bGUoJycpIH0pXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHZhbHVlPXt0aXRsZX1cbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRpdGxlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICBhcmlhLWxhYmVsPVwiTmV3IHRvZG9cIlxuICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgIC8+XG4gICAgICAgIDxidXR0b24gZGlzYWJsZWQ9e2FkZFRvZG8uaXNQZW5kaW5nfT5cbiAgICAgICAgICB7YWRkVG9kby5pc1BlbmRpbmcgPyAnQWRkaW5n4oCmJyA6ICdBZGQnfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cblxuICAgICAge2lzRmV0Y2hpbmcgJiYgPHNtYWxsPlJlZnJlc2hpbmfigKY8L3NtYWxsPn1cblxuICAgICAgPHVsPlxuICAgICAgICB7dG9kb3MubWFwKCh0b2RvKSA9PiAoXG4gICAgICAgICAgPGxpIGtleT17dG9kby5pZH0+XG4gICAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17dG9kby5kb25lfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB0b2dnbGVUb2RvLm11dGF0ZSh0b2RvKX1cbiAgICAgICAgICAgICAgLz57JyAnfVxuICAgICAgICAgICAgICB7dG9kby50aXRsZX1cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPC9saT5cbiAgICAgICAgKSl9XG4gICAgICA8L3VsPlxuXG4gICAgICB7dG9nZ2xlVG9kby5pc0Vycm9yICYmIChcbiAgICAgICAgPHAgcm9sZT1cImFsZXJ0XCI+Q291bGRuJ3Qgc2F2ZToge3RvZ2dsZVRvZG8uZXJyb3IubWVzc2FnZX08L3A+XG4gICAgICApfVxuXG4gICAgICA8UmVtYWluaW5nQ291bnQgLz5cbiAgICA8L3NlY3Rpb24+XG4gIClcbn1cblxuZnVuY3Rpb24gUmVtYWluaW5nQ291bnQoKSB7XG4gIGNvbnN0IHsgZGF0YTogdG9kb3MgPSBbXSB9ID0gdXNlVG9kb3MoKVxuICByZXR1cm4gPHA+UmVtYWluaW5nOiB7dG9kb3MuZmlsdGVyKCh0KSA9PiAhdC5kb25lKS5sZW5ndGh9PC9wPlxufVxuIl19