export const API = "http://localhost:3001";
export async function api(path, init) {
	const res = await fetch(`${API}${path}`, {
		headers: { "Content-Type": "application/json" },
		...init
	});
	if (!res.ok) throw new Error(`${init?.method ?? "GET"} ${path} failed: ${res.status}`);
	return res.json();
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxNQUFNLE1BQU07QUFFbkIsT0FBTyxlQUFlLElBQU8sTUFBYyxNQUFnQztDQUN6RSxNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsTUFBTSxRQUFRO0VBQ3ZDLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0VBQzlDLEdBQUc7Q0FDTCxDQUFDO0NBQ0QsSUFBSSxDQUFDLElBQUksSUFDUCxNQUFNLElBQUksTUFBTSxHQUFHLE1BQU0sVUFBVSxNQUFNLEdBQUcsS0FBSyxXQUFXLElBQUksUUFBUTtDQUMxRSxPQUFPLElBQUksS0FBSztBQUNsQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJhcGkudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IEFQSSA9ICdodHRwOi8vbG9jYWxob3N0OjMwMDEnXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcGk8VD4ocGF0aDogc3RyaW5nLCBpbml0PzogUmVxdWVzdEluaXQpOiBQcm9taXNlPFQ+IHtcbiAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJfSR7cGF0aH1gLCB7XG4gICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgLi4uaW5pdCxcbiAgfSlcbiAgaWYgKCFyZXMub2spXG4gICAgdGhyb3cgbmV3IEVycm9yKGAke2luaXQ/Lm1ldGhvZCA/PyAnR0VUJ30gJHtwYXRofSBmYWlsZWQ6ICR7cmVzLnN0YXR1c31gKVxuICByZXR1cm4gcmVzLmpzb24oKVxufVxuIl19