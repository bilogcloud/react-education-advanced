// node_modules/@tanstack/query-devtools/build/web-BZdVkndN.js
var sharedConfig = {
	context: void 0,
	registry: void 0,
	effects: void 0,
	done: false,
	getContextId() {
		return getContextId(this.context.count);
	},
	getNextContextId() {
		return getContextId(this.context.count++);
	}
};
function getContextId(count) {
	const num = String(count), len = num.length - 1;
	return sharedConfig.context.id + (len ? String.fromCharCode(96 + len) : "") + num;
}
function setHydrateContext(context) {
	sharedConfig.context = context;
}
var equalFn = (a, b) => a === b;
var $PROXY = Symbol("solid-proxy");
var SUPPORTS_PROXY = typeof Proxy === "function";
var $TRACK = Symbol("solid-track");
var signalOptions = { equals: equalFn };
var runEffects = runQueue;
var STALE = 1;
var PENDING = 2;
var UNOWNED = {
	owned: null,
	cleanups: null,
	context: null,
	owner: null
};
var NO_INIT = {};
var Owner = null;
var Transition = null;
var Listener = null;
var Updates = null;
var Effects = null;
var ExecCount = 0;
function createRoot(fn, detachedOwner) {
	const listener = Listener, owner = Owner, unowned = fn.length === 0, current = detachedOwner === void 0 ? owner : detachedOwner, root = unowned ? UNOWNED : {
		owned: null,
		cleanups: null,
		context: current ? current.context : null,
		owner: current
	}, updateFn = unowned ? fn : () => fn(createDisposer(root));
	Owner = root;
	Listener = null;
	try {
		return runUpdates(updateFn, true);
	} finally {
		Listener = listener;
		Owner = owner;
	}
}
function createDisposer(root) {
	return () => untrack(() => cleanNode(root));
}
function createSignal(value, options) {
	options = options ? Object.assign({}, signalOptions, options) : signalOptions;
	const s = {
		value,
		observers: null,
		observerSlots: null,
		comparator: options.equals || void 0
	};
	const setter = (value) => {
		if (typeof value === "function") {
			if (Transition && Transition.running && Transition.sources.has(s)) value = value(s.tValue);
			else value = value(s.value);
		}
		return writeSignal(s, value);
	};
	return [readSignal.bind(s), setter];
}
function createComputed(fn, value, options) {
	updateComputation(createComputation(fn, value, true, STALE));
}
function createRenderEffect(fn, value, options) {
	updateComputation(createComputation(fn, value, false, STALE));
}
function createEffect(fn, value, options) {
	runEffects = runUserEffects;
	const c = createComputation(fn, value, false, STALE), s = SuspenseContext && useContext(SuspenseContext);
	if (s) c.suspense = s;
	if (!options || !options.render) c.user = true;
	Effects ? Effects.push(c) : updateComputation(c);
}
function createMemo(fn, value, options) {
	options = options ? Object.assign({}, signalOptions, options) : signalOptions;
	const c = createComputation(fn, value, true, 0);
	c.observers = null;
	c.observerSlots = null;
	c.comparator = options.equals || void 0;
	updateComputation(c);
	return readSignal.bind(c);
}
function isPromise(v) {
	return v && typeof v === "object" && "then" in v;
}
function createResource(pSource, pFetcher, pOptions) {
	let source;
	let fetcher;
	let options;
	if (typeof pFetcher === "function") {
		source = pSource;
		fetcher = pFetcher;
		options = pOptions || {};
	} else {
		source = true;
		fetcher = pSource;
		options = pFetcher || {};
	}
	let pr = null, initP = NO_INIT, id = null, loadedUnderTransition = false, scheduled = false, resolved = "initialValue" in options, dynamic = typeof source === "function" && createMemo(source);
	const contexts = /* @__PURE__ */ new Set(), [value, setValue] = (options.storage || createSignal)(options.initialValue), [error, setError] = createSignal(void 0), [track, trigger] = createSignal(void 0, { equals: false }), [state, setState] = createSignal(resolved ? "ready" : "unresolved");
	if (Owner) onCleanup(() => {
		for (const c of contexts.keys()) c.decrement();
		contexts.clear();
		if (Transition && pr) Transition.promises.delete(pr);
		pr = null;
	});
	if (sharedConfig.context) {
		id = sharedConfig.getNextContextId();
		if (options.ssrLoadFrom === "initial") initP = options.initialValue;
		else if (sharedConfig.load && sharedConfig.has(id)) initP = sharedConfig.load(id);
	}
	function loadEnd(p, v, error, key) {
		if (pr === p) {
			pr = null;
			key !== void 0 && (resolved = true);
			if ((p === initP || v === initP) && options.onHydrated) queueMicrotask(() => options.onHydrated(key, { value: v }));
			initP = NO_INIT;
			if (Transition && p && loadedUnderTransition) {
				Transition.promises.delete(p);
				loadedUnderTransition = false;
				runUpdates(() => {
					Transition.running = true;
					completeLoad(v, error);
				}, false);
			} else completeLoad(v, error);
		}
		return v;
	}
	function completeLoad(v, err) {
		runUpdates(() => {
			if (err === void 0) setValue(() => v);
			setState(err !== void 0 ? "errored" : resolved ? "ready" : "unresolved");
			setError(err);
			for (const c of contexts.keys()) c.decrement();
			contexts.clear();
		}, false);
	}
	function read() {
		const c = SuspenseContext && useContext(SuspenseContext), v = value(), err = error();
		if (err !== void 0 && !pr) throw err;
		if (Listener && !Listener.user && c) createComputed(() => {
			track();
			if (pr) {
				if (c.resolved && Transition && loadedUnderTransition) Transition.promises.add(pr);
				else if (!contexts.has(c)) {
					c.increment();
					contexts.add(c);
				}
			}
		});
		return v;
	}
	function load(refetching = true) {
		if (refetching !== false && scheduled) return;
		scheduled = false;
		const lookup = dynamic ? dynamic() : source;
		loadedUnderTransition = Transition && Transition.running;
		if (lookup == null || lookup === false) {
			loadEnd(pr, untrack(value));
			return;
		}
		if (Transition && pr) Transition.promises.delete(pr);
		let error;
		const p = initP !== NO_INIT ? initP : untrack(() => {
			try {
				return fetcher(lookup, {
					value: value(),
					refetching
				});
			} catch (fetcherError) {
				error = fetcherError;
			}
		});
		if (error !== void 0) {
			loadEnd(pr, void 0, castError(error), lookup);
			return;
		} else if (!isPromise(p)) {
			loadEnd(pr, p, void 0, lookup);
			return p;
		}
		pr = p;
		if ("v" in p) {
			if (p.s === 1) loadEnd(pr, p.v, void 0, lookup);
			else loadEnd(pr, void 0, castError(p.v), lookup);
			return p;
		}
		scheduled = true;
		queueMicrotask(() => scheduled = false);
		runUpdates(() => {
			setState(resolved ? "refreshing" : "pending");
			trigger();
		}, false);
		return p.then((v) => loadEnd(p, v, void 0, lookup), (e) => loadEnd(p, void 0, castError(e), lookup));
	}
	Object.defineProperties(read, {
		state: { get: () => state() },
		error: { get: () => error() },
		loading: { get() {
			const s = state();
			return s === "pending" || s === "refreshing";
		} },
		latest: { get() {
			if (!resolved) return read();
			const err = error();
			if (err && !pr) throw err;
			return value();
		} }
	});
	let owner = Owner;
	if (dynamic) createComputed(() => (owner = Owner, load(false)));
	else load(false);
	return [read, {
		refetch: (info) => runWithOwner(owner, () => load(info)),
		mutate: setValue
	}];
}
function batch(fn) {
	return runUpdates(fn, false);
}
function untrack(fn) {
	if (Listener === null) return fn();
	const listener = Listener;
	Listener = null;
	try {
		return fn();
	} finally {
		Listener = listener;
	}
}
function on(deps, fn, options) {
	const isArray = Array.isArray(deps);
	let prevInput;
	let defer = options && options.defer;
	return (prevValue) => {
		let input;
		if (isArray) {
			input = Array(deps.length);
			for (let i = 0; i < deps.length; i++) input[i] = deps[i]();
		} else input = deps();
		if (defer) {
			defer = false;
			return prevValue;
		}
		const result = untrack(() => fn(input, prevInput, prevValue));
		prevInput = input;
		return result;
	};
}
function onMount(fn) {
	createEffect(() => untrack(fn));
}
function onCleanup(fn) {
	if (Owner === null);
	else if (Owner.cleanups === null) Owner.cleanups = [fn];
	else Owner.cleanups.push(fn);
	return fn;
}
function getListener() {
	return Listener;
}
function getOwner() {
	return Owner;
}
function runWithOwner(o, fn) {
	const prev = Owner;
	const prevListener = Listener;
	Owner = o;
	Listener = null;
	try {
		return runUpdates(fn, true);
	} catch (err) {
		handleError(err);
	} finally {
		Owner = prev;
		Listener = prevListener;
	}
}
function startTransition(fn) {
	if (Transition && Transition.running) {
		fn();
		return Transition.done;
	}
	const l = Listener;
	const o = Owner;
	return Promise.resolve().then(() => {
		Listener = l;
		Owner = o;
		let t;
		if (SuspenseContext) {
			t = Transition || (Transition = {
				sources: /* @__PURE__ */ new Set(),
				effects: [],
				promises: /* @__PURE__ */ new Set(),
				disposed: /* @__PURE__ */ new Set(),
				queue: /* @__PURE__ */ new Set(),
				running: true
			});
			t.done || (t.done = new Promise((res) => t.resolve = res));
			t.running = true;
		}
		runUpdates(fn, false);
		Listener = Owner = null;
		return t ? t.done : void 0;
	});
}
var [transPending, setTransPending] = /*@__PURE__*/ createSignal(false);
function useTransition() {
	return [transPending, startTransition];
}
function createContext(defaultValue, options) {
	const id = Symbol("context");
	return {
		id,
		Provider: createProvider(id),
		defaultValue
	};
}
function useContext(context) {
	let value;
	return Owner && Owner.context && (value = Owner.context[context.id]) !== void 0 ? value : context.defaultValue;
}
function children(fn) {
	const children = createMemo(fn);
	const memo = createMemo(() => resolveChildren(children()));
	memo.toArray = () => {
		const c = memo();
		return Array.isArray(c) ? c : c != null ? [c] : [];
	};
	return memo;
}
var SuspenseContext;
function repairObserverSlots(source) {
	source.observerSlots = source.observers.map((observer, slot) => {
		const sources = observer.sources;
		if (!sources) return -1;
		for (let i = sources.length - 1; i >= 0; i--) if (sources[i] === source && observer.sourceSlots && observer.sourceSlots[i] === slot) return i;
		return sources.lastIndexOf(source);
	});
}
function readSignal() {
	const runningTransition = Transition && Transition.running;
	if (this.sources && (runningTransition ? this.tState : this.state)) {
		if ((runningTransition ? this.tState : this.state) === STALE) updateComputation(this);
		else {
			const updates = Updates;
			Updates = null;
			runUpdates(() => lookUpstream(this), false);
			Updates = updates;
		}
	}
	if (Listener) {
		const observers = this.observers;
		if (!observers || observers[observers.length - 1] !== Listener) {
			const sSlot = observers ? observers.length : 0;
			if (!Listener.sources) {
				const sources = [this];
				const sourceSlots = [sSlot];
				Listener.sources = sources;
				Listener.sourceSlots = sourceSlots;
			} else {
				Listener.sources.push(this);
				Listener.sourceSlots.push(sSlot);
			}
			if (!observers) {
				const newObservers = [Listener];
				const newObserverSlots = [Listener.sources.length - 1];
				this.observers = newObservers;
				this.observerSlots = newObserverSlots;
			} else {
				if (!this.observerSlots || this.observerSlots.length !== observers.length) repairObserverSlots(this);
				observers.push(Listener);
				this.observerSlots.push(Listener.sources.length - 1);
			}
		}
	}
	if (runningTransition && Transition.sources.has(this)) return this.tValue;
	return this.value;
}
function writeSignal(node, value, isComp) {
	let current = Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value;
	if (!node.comparator || !node.comparator(current, value)) {
		if (Transition) {
			const TransitionRunning = Transition.running;
			if (TransitionRunning || !isComp && Transition.sources.has(node)) {
				Transition.sources.add(node);
				node.tValue = value;
			}
			if (!TransitionRunning) node.value = value;
		} else node.value = value;
		if (node.observers && node.observers.length) runUpdates(() => {
			for (let i = 0; i < node.observers.length; i += 1) {
				const o = node.observers[i];
				const TransitionRunning = Transition && Transition.running;
				if (TransitionRunning && Transition.disposed.has(o)) continue;
				if (TransitionRunning ? !o.tState : !o.state) {
					if (o.pure) Updates.push(o);
					else Effects.push(o);
					if (o.observers) markDownstream(o);
				}
				if (!TransitionRunning) o.state = STALE;
				else o.tState = STALE;
			}
			if (Updates.length > 1e6) {
				Updates = [];
				throw new Error();
			}
		}, false);
	}
	return value;
}
function updateComputation(node) {
	if (!node.fn) return;
	cleanNode(node, true);
	const time = ExecCount;
	runComputation(node, Transition && Transition.running && Transition.sources.has(node) ? node.tValue : node.value, time);
	if (Transition && !Transition.running && Transition.sources.has(node)) queueMicrotask(() => {
		runUpdates(() => {
			Transition && (Transition.running = true);
			Listener = Owner = node;
			runComputation(node, node.tValue, time);
			Listener = Owner = null;
		}, false);
	});
}
function runComputation(node, value, time) {
	let nextValue;
	const owner = Owner, listener = Listener;
	Listener = Owner = node;
	try {
		nextValue = node.fn(value);
	} catch (err) {
		if (node.pure) {
			if (Transition && Transition.running) {
				node.tState = STALE;
				node.tOwned && node.tOwned.forEach((n) => cleanNode(n));
				node.tOwned = void 0;
			} else {
				node.state = STALE;
				node.owned && node.owned.forEach((n) => cleanNode(n));
				node.owned = null;
			}
		}
		node.updatedAt = time + 1;
		return handleError(err);
	} finally {
		Listener = listener;
		Owner = owner;
	}
	if (!node.updatedAt || node.updatedAt <= time) {
		if (node.updatedAt != null && "observers" in node) writeSignal(node, nextValue, true);
		else if (Transition && Transition.running && node.pure) {
			if (!Transition.sources.has(node)) node.value = nextValue;
			Transition.sources.add(node);
			node.tValue = nextValue;
		} else node.value = nextValue;
		node.updatedAt = time;
	}
}
function createComputation(fn, init, pure, state = STALE, options) {
	const c = {
		fn,
		state,
		updatedAt: null,
		owned: null,
		sources: null,
		sourceSlots: null,
		cleanups: null,
		value: init,
		owner: Owner,
		context: Owner ? Owner.context : null,
		pure
	};
	if (Transition && Transition.running) {
		c.state = 0;
		c.tState = state;
	}
	if (Owner === null);
	else if (Owner !== UNOWNED) {
		if (Transition && Transition.running && Owner.pure) {
			if (!Owner.tOwned) Owner.tOwned = [c];
			else Owner.tOwned.push(c);
		} else if (!Owner.owned) Owner.owned = [c];
		else Owner.owned.push(c);
	}
	return c;
}
function runTop(node) {
	const runningTransition = Transition && Transition.running;
	if ((runningTransition ? node.tState : node.state) === 0) return;
	if ((runningTransition ? node.tState : node.state) === PENDING) return lookUpstream(node);
	if (node.suspense && untrack(node.suspense.inFallback)) return node.suspense.effects.push(node);
	const ancestors = [node];
	while ((node = node.owner) && (!node.updatedAt || node.updatedAt < ExecCount)) {
		if (runningTransition && Transition.disposed.has(node)) return;
		if (runningTransition ? node.tState : node.state) ancestors.push(node);
	}
	for (let i = ancestors.length - 1; i >= 0; i--) {
		node = ancestors[i];
		if (runningTransition) {
			let top = node, prev = ancestors[i + 1];
			while ((top = top.owner) && top !== prev) if (Transition.disposed.has(top)) return;
		}
		if ((runningTransition ? node.tState : node.state) === STALE) updateComputation(node);
		else if ((runningTransition ? node.tState : node.state) === PENDING) {
			const updates = Updates;
			Updates = null;
			runUpdates(() => lookUpstream(node, ancestors[0]), false);
			Updates = updates;
		}
	}
}
function runUpdates(fn, init) {
	if (Updates) return fn();
	let wait = false;
	if (!init) Updates = [];
	if (Effects) wait = true;
	else Effects = [];
	ExecCount++;
	try {
		const res = fn();
		completeUpdates(wait);
		return res;
	} catch (err) {
		if (!wait) Effects = null;
		Updates = null;
		handleError(err);
	}
}
function completeUpdates(wait) {
	if (Updates) {
		runQueue(Updates);
		Updates = null;
	}
	if (wait) return;
	let res;
	if (Transition) {
		if (!Transition.promises.size && !Transition.queue.size) {
			const sources = Transition.sources;
			const disposed = Transition.disposed;
			Effects.push.apply(Effects, Transition.effects);
			res = Transition.resolve;
			for (const e of Effects) {
				"tState" in e && (e.state = e.tState);
				delete e.tState;
			}
			Transition = null;
			runUpdates(() => {
				for (const d of disposed) cleanNode(d);
				for (const v of sources) {
					v.value = v.tValue;
					if (v.owned) for (let i = 0, len = v.owned.length; i < len; i++) cleanNode(v.owned[i]);
					if (v.tOwned) v.owned = v.tOwned;
					delete v.tValue;
					delete v.tOwned;
					v.tState = 0;
				}
				setTransPending(false);
			}, false);
		} else if (Transition.running) {
			Transition.running = false;
			Transition.effects.push.apply(Transition.effects, Effects);
			Effects = null;
			setTransPending(true);
			return;
		}
	}
	const e = Effects;
	Effects = null;
	if (e.length) runUpdates(() => runEffects(e), false);
	if (res) res();
}
function runQueue(queue) {
	for (let i = 0; i < queue.length; i++) runTop(queue[i]);
}
function runUserEffects(queue) {
	let i, userLength = 0;
	for (i = 0; i < queue.length; i++) {
		const e = queue[i];
		if (!e.user) runTop(e);
		else queue[userLength++] = e;
	}
	if (sharedConfig.context) {
		if (sharedConfig.count) {
			sharedConfig.effects || (sharedConfig.effects = []);
			sharedConfig.effects.push(...queue.slice(0, userLength));
			return;
		}
		setHydrateContext();
	}
	if (sharedConfig.effects && (sharedConfig.done || !sharedConfig.count)) {
		queue = [...sharedConfig.effects, ...queue];
		userLength += sharedConfig.effects.length;
		delete sharedConfig.effects;
	}
	for (i = 0; i < userLength; i++) runTop(queue[i]);
}
function lookUpstream(node, ignore) {
	const runningTransition = Transition && Transition.running;
	if (runningTransition) node.tState = 0;
	else node.state = 0;
	for (let i = 0; i < node.sources.length; i += 1) {
		const source = node.sources[i];
		if (source.sources) {
			const state = runningTransition ? source.tState : source.state;
			if (state === STALE) {
				if (source !== ignore && (!source.updatedAt || source.updatedAt < ExecCount)) runTop(source);
			} else if (state === PENDING) lookUpstream(source, ignore);
		}
	}
}
function markDownstream(node) {
	const runningTransition = Transition && Transition.running;
	for (let i = 0; i < node.observers.length; i += 1) {
		const o = node.observers[i];
		if (runningTransition ? !o.tState : !o.state) {
			if (runningTransition) o.tState = PENDING;
			else o.state = PENDING;
			if (o.pure) Updates.push(o);
			else Effects.push(o);
			o.observers && markDownstream(o);
		}
	}
}
function releaseTransitionSource(node) {
	if (Transition && Transition.sources.has(node)) {
		Transition.sources.delete(node);
		delete node.tValue;
	}
}
function cleanNode(node, recompute) {
	let i;
	if (node.sources) while (node.sources.length) {
		const source = node.sources.pop(), index = node.sourceSlots.pop(), obs = source.observers;
		if (obs && obs.length) {
			if (!source.observerSlots || source.observerSlots.length !== obs.length) repairObserverSlots(source);
			const n = obs.pop(), s = source.observerSlots.pop();
			if (index < obs.length) {
				n.sourceSlots[s] = index;
				obs[index] = n;
				source.observerSlots[index] = s;
			}
		}
		if (!recompute && (!obs || !obs.length) && Transition) releaseTransitionSource(source);
	}
	if (node.tOwned) {
		for (i = node.tOwned.length - 1; i >= 0; i--) cleanNode(node.tOwned[i]);
		delete node.tOwned;
	}
	if (Transition && Transition.running && node.pure) reset(node, true);
	else if (node.owned) {
		for (i = node.owned.length - 1; i >= 0; i--) cleanNode(node.owned[i]);
		node.owned = null;
	}
	if (!recompute) releaseTransitionSource(node);
	if (node.cleanups) {
		for (i = node.cleanups.length - 1; i >= 0; i--) node.cleanups[i]();
		node.cleanups = null;
	}
	if (Transition && Transition.running) node.tState = 0;
	else node.state = 0;
}
function reset(node, top) {
	if (!top) {
		node.tState = 0;
		Transition.disposed.add(node);
		releaseTransitionSource(node);
	}
	if (node.owned) for (let i = 0; i < node.owned.length; i++) reset(node.owned[i]);
}
function castError(err) {
	if (err instanceof Error) return err;
	return new Error(typeof err === "string" ? err : "Unknown error", { cause: err });
}
function handleError(err, owner = Owner) {
	throw castError(err);
}
function resolveChildren(children) {
	if (typeof children === "function" && !children.length) return resolveChildren(children());
	if (Array.isArray(children)) {
		const results = [];
		for (let i = 0; i < children.length; i++) {
			const result = resolveChildren(children[i]);
			if (Array.isArray(result)) {
				if (result.length < 32768) results.push.apply(results, result);
				else for (let j = 0; j < result.length; j++) results.push(result[j]);
			} else results.push(result);
		}
		return results;
	}
	return children;
}
function createProvider(id, options) {
	return function provider(props) {
		let res;
		createRenderEffect(() => res = untrack(() => {
			Owner.context = {
				...Owner.context,
				[id]: props.value
			};
			return children(() => props.children);
		}), void 0);
		return res;
	};
}
var FALLBACK = Symbol("fallback");
function dispose(d) {
	for (let i = 0; i < d.length; i++) d[i]();
}
function mapArray(list, mapFn, options = {}) {
	let items = [], mapped = [], disposers = [], len = 0, indexes = mapFn.length > 1 ? [] : null;
	onCleanup(() => dispose(disposers));
	return () => {
		let newItems = list() || [], newLen = newItems.length, i, j;
		newItems[$TRACK];
		return untrack(() => {
			let newIndices, newIndicesNext, temp, tempdisposers, tempIndexes, start, end, newEnd, item;
			if (newLen === 0) {
				if (len !== 0) {
					dispose(disposers);
					disposers = [];
					items = [];
					mapped = [];
					len = 0;
					indexes && (indexes = []);
				}
				if (options.fallback) {
					items = [FALLBACK];
					mapped[0] = createRoot((disposer) => {
						disposers[0] = disposer;
						return options.fallback();
					});
					len = 1;
				}
			} else if (len === 0) {
				mapped = new Array(newLen);
				for (j = 0; j < newLen; j++) {
					items[j] = newItems[j];
					mapped[j] = createRoot(mapper);
				}
				len = newLen;
			} else {
				temp = new Array(newLen);
				tempdisposers = new Array(newLen);
				indexes && (tempIndexes = new Array(newLen));
				for (start = 0, end = Math.min(len, newLen); start < end && items[start] === newItems[start]; start++);
				for (end = len - 1, newEnd = newLen - 1; end >= start && newEnd >= start && items[end] === newItems[newEnd]; end--, newEnd--) {
					temp[newEnd] = mapped[end];
					tempdisposers[newEnd] = disposers[end];
					indexes && (tempIndexes[newEnd] = indexes[end]);
				}
				newIndices = /* @__PURE__ */ new Map();
				newIndicesNext = new Array(newEnd + 1);
				for (j = newEnd; j >= start; j--) {
					item = newItems[j];
					i = newIndices.get(item);
					newIndicesNext[j] = i === void 0 ? -1 : i;
					newIndices.set(item, j);
				}
				for (i = start; i <= end; i++) {
					item = items[i];
					j = newIndices.get(item);
					if (j !== void 0 && j !== -1) {
						temp[j] = mapped[i];
						tempdisposers[j] = disposers[i];
						indexes && (tempIndexes[j] = indexes[i]);
						j = newIndicesNext[j];
						newIndices.set(item, j);
					} else disposers[i]();
				}
				for (j = start; j < newLen; j++) if (j in temp) {
					mapped[j] = temp[j];
					disposers[j] = tempdisposers[j];
					if (indexes) {
						indexes[j] = tempIndexes[j];
						indexes[j](j);
					}
				} else mapped[j] = createRoot(mapper);
				mapped = mapped.slice(0, len = newLen);
				items = newItems.slice(0);
			}
			return mapped;
		});
		function mapper(disposer) {
			disposers[j] = disposer;
			if (indexes) {
				const [s, set] = createSignal(j);
				indexes[j] = set;
				return mapFn(newItems[j], s);
			}
			return mapFn(newItems[j]);
		}
	};
}
function indexArray(list, mapFn, options = {}) {
	let items = [], mapped = [], disposers = [], signals = [], len = 0, i;
	onCleanup(() => dispose(disposers));
	return () => {
		const newItems = list() || [], newLen = newItems.length;
		newItems[$TRACK];
		return untrack(() => {
			if (newLen === 0) {
				if (len !== 0) {
					dispose(disposers);
					disposers = [];
					items = [];
					mapped = [];
					len = 0;
					signals = [];
				}
				if (options.fallback) {
					items = [FALLBACK];
					mapped[0] = createRoot((disposer) => {
						disposers[0] = disposer;
						return options.fallback();
					});
					len = 1;
				}
				return mapped;
			}
			if (items[0] === FALLBACK) {
				disposers[0]();
				disposers = [];
				items = [];
				mapped = [];
				len = 0;
			}
			for (i = 0; i < newLen; i++) if (i < items.length && items[i] !== newItems[i]) signals[i](() => newItems[i]);
			else if (i >= items.length) mapped[i] = createRoot(mapper);
			for (; i < items.length; i++) disposers[i]();
			len = signals.length = disposers.length = newLen;
			items = newItems.slice(0);
			return mapped = mapped.slice(0, len);
		});
		function mapper(disposer) {
			disposers[i] = disposer;
			const [s, set] = createSignal(newItems[i]);
			signals[i] = set;
			return mapFn(s, i);
		}
	};
}
function createComponent(Comp, props) {
	return untrack(() => Comp(props || {}));
}
function trueFn() {
	return true;
}
var propTraps = {
	get(_, property, receiver) {
		if (property === $PROXY) return receiver;
		return _.get(property);
	},
	has(_, property) {
		if (property === $PROXY) return true;
		return _.has(property);
	},
	set: trueFn,
	deleteProperty: trueFn,
	getOwnPropertyDescriptor(_, property) {
		return {
			configurable: true,
			enumerable: true,
			get() {
				return _.get(property);
			},
			set: trueFn,
			deleteProperty: trueFn
		};
	},
	ownKeys(_) {
		return _.keys();
	}
};
function resolveSource(s) {
	return !(s = typeof s === "function" ? s() : s) ? {} : s;
}
function resolveSources() {
	for (let i = 0, length = this.length; i < length; ++i) {
		const v = this[i]();
		if (v !== void 0) return v;
	}
}
function mergeProps(...sources) {
	let proxy = false;
	for (let i = 0; i < sources.length; i++) {
		const s = sources[i];
		proxy = proxy || !!s && $PROXY in s;
		sources[i] = typeof s === "function" ? (proxy = true, createMemo(s)) : s;
	}
	if (SUPPORTS_PROXY && proxy) return new Proxy({
		get(property) {
			for (let i = sources.length - 1; i >= 0; i--) {
				const v = resolveSource(sources[i])[property];
				if (v !== void 0) return v;
			}
		},
		has(property) {
			for (let i = sources.length - 1; i >= 0; i--) if (property in resolveSource(sources[i])) return true;
			return false;
		},
		keys() {
			const keys = [];
			for (let i = 0; i < sources.length; i++) keys.push(...Object.keys(resolveSource(sources[i])));
			return [...new Set(keys)];
		}
	}, propTraps);
	const sourcesMap = {};
	const defined = Object.create(null);
	for (let i = sources.length - 1; i >= 0; i--) {
		const source = sources[i];
		if (!source) continue;
		const sourceKeys = Object.getOwnPropertyNames(source);
		for (let i = sourceKeys.length - 1; i >= 0; i--) {
			const key = sourceKeys[i];
			if (key === "__proto__" || key === "constructor") continue;
			const desc = Object.getOwnPropertyDescriptor(source, key);
			if (!defined[key]) defined[key] = desc.get ? {
				enumerable: true,
				configurable: true,
				get: resolveSources.bind(sourcesMap[key] = [desc.get.bind(source)])
			} : desc.value !== void 0 ? desc : void 0;
			else {
				const sources = sourcesMap[key];
				if (sources) {
					if (desc.get) sources.push(desc.get.bind(source));
					else if (desc.value !== void 0) sources.push(() => desc.value);
				}
			}
		}
	}
	const target = {};
	const definedKeys = Object.keys(defined);
	for (let i = definedKeys.length - 1; i >= 0; i--) {
		const key = definedKeys[i], desc = defined[key];
		if (desc && desc.get) Object.defineProperty(target, key, desc);
		else target[key] = desc ? desc.value : void 0;
	}
	return target;
}
function splitProps(props, ...keys) {
	const len = keys.length;
	if (SUPPORTS_PROXY && $PROXY in props) {
		const blocked = len > 1 ? keys.flat() : keys[0];
		const claimed = /* @__PURE__ */ new Set();
		const res = keys.map((k) => {
			const owned = k.filter((property) => !claimed.has(property) && (claimed.add(property), true));
			return new Proxy({
				get(property) {
					return owned.includes(property) ? props[property] : void 0;
				},
				has(property) {
					return owned.includes(property) && property in props;
				},
				keys() {
					return owned.filter((property) => property in props);
				}
			}, propTraps);
		});
		res.push(new Proxy({
			get(property) {
				return blocked.includes(property) ? void 0 : props[property];
			},
			has(property) {
				return blocked.includes(property) ? false : property in props;
			},
			keys() {
				return Object.keys(props).filter((k) => !blocked.includes(k));
			}
		}, propTraps));
		return res;
	}
	const objects = [];
	for (let i = 0; i <= len; i++) objects[i] = {};
	for (const propName of Object.getOwnPropertyNames(props)) {
		let keyIndex = len;
		for (let i = 0; i < keys.length; i++) if (keys[i].includes(propName)) {
			keyIndex = i;
			break;
		}
		const desc = Object.getOwnPropertyDescriptor(props, propName);
		!desc.get && !desc.set && desc.enumerable && desc.writable && desc.configurable ? objects[keyIndex][propName] = desc.value : Object.defineProperty(objects[keyIndex], propName, desc);
	}
	return objects;
}
function lazy(fn) {
	let comp;
	let p;
	const load = () => {
		if (!p) {
			const cur = p = fn();
			cur.then((mod) => {
				comp = () => mod.default;
			}, () => {
				if (p === cur) p = void 0;
			});
		}
		return p;
	};
	const wrap = (props) => {
		const ctx = sharedConfig.context;
		if (ctx) {
			const [s, set] = createSignal();
			sharedConfig.count || (sharedConfig.count = 0);
			sharedConfig.count++;
			load().then((mod) => {
				!sharedConfig.done && setHydrateContext(ctx);
				sharedConfig.count--;
				set(() => mod.default);
				setHydrateContext();
			}, (err) => {
				!sharedConfig.done && setHydrateContext(ctx);
				sharedConfig.count--;
				set(() => () => {
					throw err;
				});
				setHydrateContext();
			});
			comp = s;
		} else if (!comp) {
			const [s] = createResource(() => load().then((mod) => mod.default));
			comp = s;
			onCleanup(() => {
				if (comp === s) comp = void 0;
			});
		}
		let Comp;
		return createMemo(() => (Comp = comp?.()) ? untrack(() => {
			if (!ctx || sharedConfig.done) return Comp(props);
			const c = sharedConfig.context;
			setHydrateContext(ctx);
			const r = Comp(props);
			setHydrateContext(c);
			return r;
		}) : "");
	};
	wrap.preload = () => load();
	return wrap;
}
var counter = 0;
function createUniqueId() {
	return sharedConfig.context ? sharedConfig.getNextContextId() : `cl-${counter++}`;
}
var narrowedError = (name) => `Stale read from <${name}>.`;
function For(props) {
	const fallback = "fallback" in props && { fallback: () => props.fallback };
	return createMemo(mapArray(() => props.each, props.children, fallback || void 0));
}
function Index(props) {
	const fallback = "fallback" in props && { fallback: () => props.fallback };
	return createMemo(indexArray(() => props.each, props.children, fallback || void 0));
}
function Show(props) {
	const keyed = props.keyed;
	const conditionValue = createMemo(() => props.when, void 0, void 0);
	const condition = keyed ? conditionValue : createMemo(conditionValue, void 0, { equals: (a, b) => !a === !b });
	return createMemo(() => {
		const c = condition();
		if (c) {
			const child = props.children;
			return typeof child === "function" && child.length > 0 ? untrack(() => child(keyed ? c : () => {
				if (!untrack(condition)) throw narrowedError("Show");
				return conditionValue();
			})) : child;
		}
		return props.fallback;
	}, void 0, void 0);
}
function Switch(props) {
	const chs = children(() => props.children);
	const switchFunc = createMemo(() => {
		const ch = chs();
		const mps = Array.isArray(ch) ? ch : [ch];
		let func = () => void 0;
		for (let i = 0; i < mps.length; i++) {
			const index = i;
			const mp = mps[i];
			const prevFunc = func;
			const conditionValue = createMemo(() => prevFunc() ? void 0 : mp.when, void 0, void 0);
			const condition = mp.keyed ? conditionValue : createMemo(conditionValue, void 0, { equals: (a, b) => !a === !b });
			func = () => prevFunc() || (condition() ? [
				index,
				conditionValue,
				mp
			] : void 0);
		}
		return func;
	});
	return createMemo(() => {
		const sel = switchFunc()();
		if (!sel) return props.fallback;
		const [index, conditionValue, mp] = sel;
		const child = mp.children;
		return typeof child === "function" && child.length > 0 ? untrack(() => child(mp.keyed ? conditionValue() : () => {
			if (untrack(switchFunc)()?.[0] !== index) throw narrowedError("Match");
			return conditionValue();
		})) : child;
	}, void 0, void 0);
}
function Match(props) {
	return props;
}
var Properties = /*#__PURE__*/ new Set([
	"className",
	"value",
	"readOnly",
	"noValidate",
	"formNoValidate",
	"isMap",
	"noModule",
	"playsInline",
	"adAuctionHeaders",
	"allowFullscreen",
	"browsingTopics",
	"defaultChecked",
	"defaultMuted",
	"defaultSelected",
	"disablePictureInPicture",
	"disableRemotePlayback",
	"preservesPitch",
	"shadowRootClonable",
	"shadowRootCustomElementRegistry",
	"shadowRootDelegatesFocus",
	"shadowRootSerializable",
	"sharedStorageWritable",
	...[
		"allowfullscreen",
		"async",
		"alpha",
		"autofocus",
		"autoplay",
		"checked",
		"controls",
		"default",
		"disabled",
		"formnovalidate",
		"hidden",
		"indeterminate",
		"inert",
		"ismap",
		"loop",
		"multiple",
		"muted",
		"nomodule",
		"novalidate",
		"open",
		"playsinline",
		"readonly",
		"required",
		"reversed",
		"seamless",
		"selected",
		"adauctionheaders",
		"browsingtopics",
		"credentialless",
		"defaultchecked",
		"defaultmuted",
		"defaultselected",
		"defer",
		"disablepictureinpicture",
		"disableremoteplayback",
		"preservespitch",
		"shadowrootclonable",
		"shadowrootcustomelementregistry",
		"shadowrootdelegatesfocus",
		"shadowrootserializable",
		"sharedstoragewritable"
	]
]);
var ChildProperties = /*#__PURE__*/ new Set([
	"innerHTML",
	"textContent",
	"innerText",
	"children"
]);
var Aliases = /*#__PURE__*/ Object.assign(Object.create(null), {
	className: "class",
	htmlFor: "for"
});
var PropAliases = /*#__PURE__*/ Object.assign(Object.create(null), {
	class: "className",
	novalidate: {
		$: "noValidate",
		FORM: 1
	},
	formnovalidate: {
		$: "formNoValidate",
		BUTTON: 1,
		INPUT: 1
	},
	ismap: {
		$: "isMap",
		IMG: 1
	},
	nomodule: {
		$: "noModule",
		SCRIPT: 1
	},
	playsinline: {
		$: "playsInline",
		VIDEO: 1
	},
	readonly: {
		$: "readOnly",
		INPUT: 1,
		TEXTAREA: 1
	},
	adauctionheaders: {
		$: "adAuctionHeaders",
		IFRAME: 1
	},
	allowfullscreen: {
		$: "allowFullscreen",
		IFRAME: 1
	},
	browsingtopics: {
		$: "browsingTopics",
		IMG: 1
	},
	defaultchecked: {
		$: "defaultChecked",
		INPUT: 1
	},
	defaultmuted: {
		$: "defaultMuted",
		AUDIO: 1,
		VIDEO: 1
	},
	defaultselected: {
		$: "defaultSelected",
		OPTION: 1
	},
	disablepictureinpicture: {
		$: "disablePictureInPicture",
		VIDEO: 1
	},
	disableremoteplayback: {
		$: "disableRemotePlayback",
		AUDIO: 1,
		VIDEO: 1
	},
	preservespitch: {
		$: "preservesPitch",
		AUDIO: 1,
		VIDEO: 1
	},
	shadowrootclonable: {
		$: "shadowRootClonable",
		TEMPLATE: 1
	},
	shadowrootdelegatesfocus: {
		$: "shadowRootDelegatesFocus",
		TEMPLATE: 1
	},
	shadowrootserializable: {
		$: "shadowRootSerializable",
		TEMPLATE: 1
	},
	sharedstoragewritable: {
		$: "sharedStorageWritable",
		IFRAME: 1,
		IMG: 1
	}
});
function getPropAlias(prop, tagName) {
	const a = PropAliases[prop];
	return typeof a === "object" ? a[tagName] ? a["$"] : void 0 : a;
}
var DelegatedEvents = /*#__PURE__*/ new Set([
	"beforeinput",
	"click",
	"dblclick",
	"contextmenu",
	"focusin",
	"focusout",
	"input",
	"keydown",
	"keyup",
	"mousedown",
	"mousemove",
	"mouseout",
	"mouseover",
	"mouseup",
	"pointerdown",
	"pointermove",
	"pointerout",
	"pointerover",
	"pointerup",
	"touchend",
	"touchmove",
	"touchstart"
]);
var SVGElements = /*#__PURE__*/ new Set([
	"altGlyph",
	"altGlyphDef",
	"altGlyphItem",
	"animate",
	"animateColor",
	"animateMotion",
	"animateTransform",
	"circle",
	"clipPath",
	"color-profile",
	"cursor",
	"defs",
	"desc",
	"ellipse",
	"feBlend",
	"feColorMatrix",
	"feComponentTransfer",
	"feComposite",
	"feConvolveMatrix",
	"feDiffuseLighting",
	"feDisplacementMap",
	"feDistantLight",
	"feDropShadow",
	"feFlood",
	"feFuncA",
	"feFuncB",
	"feFuncG",
	"feFuncR",
	"feGaussianBlur",
	"feImage",
	"feMerge",
	"feMergeNode",
	"feMorphology",
	"feOffset",
	"fePointLight",
	"feSpecularLighting",
	"feSpotLight",
	"feTile",
	"feTurbulence",
	"filter",
	"font",
	"font-face",
	"font-face-format",
	"font-face-name",
	"font-face-src",
	"font-face-uri",
	"foreignObject",
	"g",
	"glyph",
	"glyphRef",
	"hkern",
	"image",
	"line",
	"linearGradient",
	"marker",
	"mask",
	"metadata",
	"missing-glyph",
	"mpath",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"radialGradient",
	"rect",
	"set",
	"stop",
	"svg",
	"switch",
	"symbol",
	"text",
	"textPath",
	"tref",
	"tspan",
	"use",
	"view",
	"vkern"
]);
var SVGNamespace = {
	xlink: "http://www.w3.org/1999/xlink",
	xml: "http://www.w3.org/XML/1998/namespace"
};
var memo = (fn) => createMemo(() => fn());
function reconcileArrays(parentNode, a, b) {
	let bLength = b.length, aEnd = a.length, bEnd = bLength, aStart = 0, bStart = 0, after = a[aEnd - 1].nextSibling, map = null;
	while (aStart < aEnd || bStart < bEnd) {
		if (a[aStart] === b[bStart]) {
			aStart++;
			bStart++;
			continue;
		}
		while (a[aEnd - 1] === b[bEnd - 1]) {
			aEnd--;
			bEnd--;
		}
		if (aEnd === aStart) {
			const node = bEnd < bLength ? bStart ? b[bStart - 1].nextSibling : b[bEnd - bStart] : after;
			while (bStart < bEnd) parentNode.insertBefore(b[bStart++], node);
		} else if (bEnd === bStart) while (aStart < aEnd) {
			if (!map || !map.has(a[aStart])) a[aStart].remove();
			aStart++;
		}
		else if (a[aStart] === b[bEnd - 1] && b[bStart] === a[aEnd - 1]) {
			const node = a[--aEnd].nextSibling;
			parentNode.insertBefore(b[bStart++], a[aStart++].nextSibling);
			parentNode.insertBefore(b[--bEnd], node);
			a[aEnd] = b[bEnd];
		} else {
			if (!map) {
				map = /* @__PURE__ */ new Map();
				let i = bStart;
				while (i < bEnd) map.set(b[i], i++);
			}
			const index = map.get(a[aStart]);
			if (index != null) {
				if (bStart < index && index < bEnd) {
					let i = aStart, sequence = 1, t;
					while (++i < aEnd && i < bEnd) {
						if ((t = map.get(a[i])) == null || t !== index + sequence) break;
						sequence++;
					}
					if (sequence > index - bStart) {
						const node = a[aStart];
						while (bStart < index) parentNode.insertBefore(b[bStart++], node);
					} else parentNode.replaceChild(b[bStart++], a[aStart++]);
				} else aStart++;
			} else a[aStart++].remove();
		}
	}
}
var $$EVENTS = "_$DX_DELEGATE";
function render(code, element, init, options = {}) {
	let disposer;
	createRoot((dispose) => {
		disposer = dispose;
		element === document ? code() : insert(element, code(), !init && element.firstChild ? null : void 0, init);
	}, options.owner);
	return () => {
		disposer();
		element.textContent = "";
	};
}
var policy;
function setTrustedTypesPolicy(value) {
	policy = value;
}
function template(html, isImportNode, isSVG, isMathML) {
	let node;
	const create = () => {
		const t = isMathML ? document.createElementNS("http://www.w3.org/1998/Math/MathML", "template") : document.createElement("template");
		t.innerHTML = policy ? policy.createHTML(html) : html;
		return isSVG ? t.content.firstChild.firstChild : isMathML ? t.firstChild : t.content.firstChild;
	};
	const fn = isImportNode ? () => untrack(() => document.importNode(node || (node = create()), true)) : () => (node || (node = create())).cloneNode(true);
	fn.cloneNode = fn;
	return fn;
}
function delegateEvents(eventNames, document = window.document) {
	const e = document[$$EVENTS] || (document[$$EVENTS] = /* @__PURE__ */ new Set());
	for (let i = 0, l = eventNames.length; i < l; i++) {
		const name = eventNames[i];
		if (!e.has(name)) {
			e.add(name);
			document.addEventListener(name, eventHandler);
		}
	}
}
function clearDelegatedEvents(document = window.document) {
	if (document[$$EVENTS]) {
		for (let name of document[$$EVENTS].keys()) document.removeEventListener(name, eventHandler);
		delete document[$$EVENTS];
	}
}
function setAttribute(node, name, value) {
	if (isHydrating(node)) return;
	if (value == null) node.removeAttribute(name);
	else node.setAttribute(name, value);
}
function setAttributeNS(node, namespace, name, value) {
	if (isHydrating(node)) return;
	if (value == null) node.removeAttributeNS(namespace, name);
	else node.setAttributeNS(namespace, name, value);
}
function setBoolAttribute(node, name, value) {
	if (isHydrating(node)) return;
	value ? node.setAttribute(name, "") : node.removeAttribute(name);
}
function className(node, value) {
	if (isHydrating(node)) return;
	if (value == null) node.removeAttribute("class");
	else node.className = value;
}
function addEventListener(node, name, handler, delegate) {
	if (delegate) {
		if (Array.isArray(handler)) {
			node[`$$${name}`] = handler[0];
			node[`$$${name}Data`] = handler[1];
		} else node[`$$${name}`] = handler;
	} else if (Array.isArray(handler)) {
		const handlerFn = handler[0];
		node.addEventListener(name, handler[0] = (e) => handlerFn.call(node, handler[1], e));
	} else node.addEventListener(name, handler, typeof handler !== "function" && handler);
}
function classList(node, value, prev = {}) {
	const classKeys = Object.keys(value || {}), prevKeys = Object.keys(prev);
	let i, len;
	for (i = 0, len = prevKeys.length; i < len; i++) {
		const key = prevKeys[i];
		if (!key || key === "undefined" || value[key]) continue;
		toggleClassKey(node, key, false);
		delete prev[key];
	}
	for (i = 0, len = classKeys.length; i < len; i++) {
		const key = classKeys[i], classValue = !!value[key];
		if (!key || key === "undefined" || prev[key] === classValue || !classValue) continue;
		toggleClassKey(node, key, true);
		prev[key] = classValue;
	}
	return prev;
}
function style(node, value, prev) {
	if (!value) return prev ? setAttribute(node, "style") : value;
	const nodeStyle = node.style;
	if (typeof value === "string") return nodeStyle.cssText = value;
	typeof prev === "string" && (nodeStyle.cssText = prev = void 0);
	prev || (prev = {});
	value || (value = {});
	let v, s;
	for (s in prev) {
		value[s] ?? nodeStyle.removeProperty(s);
		delete prev[s];
	}
	for (s in value) {
		v = value[s];
		if (v !== prev[s]) {
			nodeStyle.setProperty(s, v);
			prev[s] = v;
		}
	}
	return prev;
}
function setStyleProperty(node, name, value) {
	value != null ? node.style.setProperty(name, value) : node.style.removeProperty(name);
}
function spread(node, props = {}, isSVG, skipChildren) {
	const prevProps = {};
	if (!skipChildren) createRenderEffect(() => prevProps.children = insertExpression(node, props.children, prevProps.children));
	createRenderEffect(() => typeof props.ref === "function" && use(props.ref, node));
	createRenderEffect(() => assign(node, props, isSVG, true, prevProps, true));
	return prevProps;
}
function use(fn, element, arg) {
	return untrack(() => fn(element, arg));
}
function insert(parent, accessor, marker, initial) {
	if (marker !== void 0 && !initial) initial = [];
	if (typeof accessor !== "function") return insertExpression(parent, accessor, initial, marker);
	createRenderEffect((current) => insertExpression(parent, accessor(), current, marker), initial);
}
function assign(node, props, isSVG, skipChildren, prevProps = {}, skipRef = false) {
	props || (props = {});
	for (const prop in prevProps) if (!(prop in props)) {
		if (prop === "children") continue;
		prevProps[prop] = assignProp(node, prop, null, prevProps[prop], isSVG, skipRef, props);
	}
	for (const prop in props) {
		if (prop === "children") {
			if (!skipChildren) insertExpression(node, props.children);
			continue;
		}
		prevProps[prop] = assignProp(node, prop, props[prop], prevProps[prop], isSVG, skipRef, props);
	}
}
function getNextElement(template) {
	let node, key;
	if (!isHydrating() || !(node = sharedConfig.registry.get(key = getHydrationKey()))) return template();
	if (sharedConfig.completed) sharedConfig.completed.add(node);
	sharedConfig.registry.delete(key);
	return node;
}
function isHydrating(node) {
	return !!sharedConfig.context && !sharedConfig.done && (!node || node.isConnected);
}
function toPropertyName(name) {
	return name.toLowerCase().replace(/-([a-z])/g, (_, w) => w.toUpperCase());
}
function toggleClassKey(node, key, value) {
	const classNames = key.trim().split(/\s+/);
	for (let i = 0, nameLen = classNames.length; i < nameLen; i++) node.classList.toggle(classNames[i], value);
}
function assignProp(node, prop, value, prev, isSVG, skipRef, props) {
	let isCE, isProp, isChildProp, propAlias, forceProp;
	if (prop === "style") return style(node, value, prev);
	if (prop === "classList") return classList(node, value, prev);
	if (value === prev) return prev;
	if (prop === "ref") {
		if (!skipRef) value(node);
	} else if (prop.slice(0, 3) === "on:") {
		const e = prop.slice(3);
		prev && node.removeEventListener(e, prev, typeof prev !== "function" && prev);
		value && node.addEventListener(e, value, typeof value !== "function" && value);
	} else if (prop.slice(0, 10) === "oncapture:") {
		const e = prop.slice(10);
		prev && node.removeEventListener(e, prev, true);
		value && node.addEventListener(e, value, true);
	} else if (prop.slice(0, 2) === "on") {
		const name = prop.slice(2).toLowerCase();
		const delegate = DelegatedEvents.has(name);
		if (!delegate && prev) {
			const h = Array.isArray(prev) ? prev[0] : prev;
			node.removeEventListener(name, h);
		}
		if (delegate || value) {
			addEventListener(node, name, value, delegate);
			delegate && delegateEvents([name]);
		}
	} else if (prop.slice(0, 5) === "attr:") setAttribute(node, prop.slice(5), value);
	else if (prop.slice(0, 5) === "bool:") setBoolAttribute(node, prop.slice(5), value);
	else if ((forceProp = prop.slice(0, 5) === "prop:") || (isChildProp = ChildProperties.has(prop)) || !isSVG && ((propAlias = getPropAlias(prop, node.tagName)) || (isProp = Properties.has(prop))) || (isCE = node.nodeName.includes("-") || "is" in props)) {
		if (forceProp) {
			prop = prop.slice(5);
			isProp = true;
		} else if (isHydrating(node)) return value;
		if (prop === "class" || prop === "className") className(node, value);
		else if (isCE && !isProp && !isChildProp) node[toPropertyName(prop)] = value;
		else if ((prop === "value" || prop === "defaultValue") && (node.nodeName === "INPUT" || node.nodeName === "TEXTAREA")) node[propAlias || prop] = value ?? "";
		else node[propAlias || prop] = value;
	} else {
		const ns = isSVG && prop.indexOf(":") > -1 && SVGNamespace[prop.split(":")[0]];
		if (ns) setAttributeNS(node, ns, prop, value);
		else setAttribute(node, Aliases[prop] || prop, value);
	}
	return value;
}
function eventHandler(e) {
	if (sharedConfig.registry && sharedConfig.events) {
		if (sharedConfig.events.find(([el, ev]) => ev === e)) return;
	}
	let node = e.target;
	const key = `$$${e.type}`;
	const oriTarget = e.target;
	const oriCurrentTarget = e.currentTarget;
	const retarget = (value) => Object.defineProperty(e, "target", {
		configurable: true,
		value
	});
	const handleNode = () => {
		const handler = node[key];
		if (handler && !node.disabled) {
			const data = node[`${key}Data`];
			data !== void 0 ? handler.call(node, data, e) : handler.call(node, e);
			if (e.cancelBubble) return;
		}
		node.host && typeof node.host !== "string" && !node.host._$host && node.contains(e.target) && retarget(node.host);
		return true;
	};
	const walkUpTree = () => {
		while (handleNode() && (node = node._$host || node.parentNode || node.host));
	};
	Object.defineProperty(e, "currentTarget", {
		configurable: true,
		get() {
			return node || document;
		}
	});
	if (sharedConfig.registry && !sharedConfig.done) sharedConfig.done = _$HY.done = true;
	try {
		if (e.composedPath) {
			const path = e.composedPath();
			retarget(path[0]);
			for (let i = 0; i < path.length - 2; i++) {
				node = path[i];
				if (!handleNode()) break;
				if (node._$host) {
					node = node._$host;
					walkUpTree();
					break;
				}
				if (node.parentNode === oriCurrentTarget) break;
			}
		} else walkUpTree();
		retarget(oriTarget);
	} finally {
		e = node = null;
	}
}
function insertExpression(parent, value, current, marker, unwrapArray) {
	const hydrating = isHydrating(parent);
	if (hydrating) {
		!current && (current = [...parent.childNodes]);
		let cleaned = [];
		for (let i = 0; i < current.length; i++) {
			const node = current[i];
			if (node.nodeType === 8 && node.data.slice(0, 2) === "!$") node.remove();
			else cleaned.push(node);
		}
		current = cleaned;
	}
	while (typeof current === "function") current = current();
	if (value === current) return current;
	const t = typeof value, multi = marker !== void 0;
	parent = multi && current[0] && current[0].parentNode || parent;
	if (t === "string" || t === "number") {
		if (hydrating) return current;
		if (t === "number") {
			value = value.toString();
			if (value === current) return current;
		}
		if (multi) {
			let node = current[0];
			if (node && node.nodeType === 3) node.data !== value && (node.data = value);
			else node = document.createTextNode(value);
			current = cleanChildren(parent, current, marker, node);
		} else if (current !== "" && typeof current === "string") current = parent.firstChild.data = value;
		else current = parent.textContent = value;
	} else if (value == null || t === "boolean") {
		if (hydrating) return current;
		current = cleanChildren(parent, current, marker);
	} else if (t === "function") {
		createRenderEffect(() => {
			let v = value();
			while (typeof v === "function") v = v();
			current = insertExpression(parent, v, current, marker);
		});
		return () => current;
	} else if (Array.isArray(value)) {
		const array = [];
		const currentArray = current && Array.isArray(current);
		if (normalizeIncomingArray(array, value, current, unwrapArray)) {
			createRenderEffect(() => current = insertExpression(parent, array, current, marker, true));
			return () => current;
		}
		if (hydrating) {
			if (!array.length) return current;
			if (marker === void 0) return current = [...parent.childNodes];
			let node = array[0];
			if (node.parentNode !== parent) return current;
			const nodes = [node];
			while ((node = node.nextSibling) !== marker) nodes.push(node);
			return current = nodes;
		}
		if (array.length === 0) {
			current = cleanChildren(parent, current, marker);
			if (multi) return current;
		} else if (currentArray) {
			if (current.length === 0) appendNodes(parent, array, marker);
			else reconcileArrays(parent, current, array);
		} else {
			current && cleanChildren(parent);
			appendNodes(parent, array);
		}
		current = array;
	} else if (value.nodeType) {
		if (hydrating && value.parentNode) return current = multi ? [value] : value;
		if (Array.isArray(current)) {
			if (multi) return current = cleanChildren(parent, current, marker, value);
			cleanChildren(parent, current, null, value);
		} else if (current == null || current === "" || !parent.firstChild) parent.appendChild(value);
		else parent.replaceChild(value, parent.firstChild);
		current = value;
	}
	return current;
}
function normalizeIncomingArray(normalized, array, current, unwrap) {
	let dynamic = false;
	for (let i = 0, len = array.length; i < len; i++) {
		let item = array[i], prev = current && current[normalized.length], t;
		if (item == null || item === true || item === false);
		else if ((t = typeof item) === "object" && item.nodeType) normalized.push(item);
		else if (Array.isArray(item)) dynamic = normalizeIncomingArray(normalized, item, prev) || dynamic;
		else if (t === "function") {
			if (unwrap) {
				while (typeof item === "function") item = item();
				dynamic = normalizeIncomingArray(normalized, Array.isArray(item) ? item : [item], Array.isArray(prev) ? prev : [prev]) || dynamic;
			} else {
				normalized.push(item);
				dynamic = true;
			}
		} else {
			const value = String(item);
			if (prev && prev.nodeType === 3 && prev.data === value) normalized.push(prev);
			else normalized.push(document.createTextNode(value));
		}
	}
	return dynamic;
}
function appendNodes(parent, array, marker = null) {
	for (let i = 0, len = array.length; i < len; i++) parent.insertBefore(array[i], marker);
}
function cleanChildren(parent, current, marker, replacement) {
	if (marker === void 0) return parent.textContent = "";
	const node = replacement || document.createTextNode("");
	if (current.length) {
		let inserted = false;
		for (let i = current.length - 1; i >= 0; i--) {
			const el = current[i];
			if (node !== el) {
				const isParent = el.parentNode === parent;
				if (!inserted && !i) isParent ? parent.replaceChild(node, el) : parent.insertBefore(node, marker);
				else isParent && el.remove();
			} else inserted = true;
		}
	} else parent.insertBefore(node, marker);
	return [node];
}
function getHydrationKey() {
	return sharedConfig.getNextContextId();
}
var SVG_NAMESPACE = "http://www.w3.org/2000/svg";
function createElement(tagName, isSVG = false, is = void 0) {
	return isSVG ? document.createElementNS(SVG_NAMESPACE, tagName) : document.createElement(tagName, { is });
}
function Portal(props) {
	const { useShadow } = props, marker = document.createTextNode(""), mount = () => props.mount || document.body, owner = getOwner();
	let content;
	let hydrating = !!sharedConfig.context;
	createEffect(() => {
		if (hydrating) getOwner().user = hydrating = false;
		content || (content = runWithOwner(owner, () => createMemo(() => props.children)));
		const el = mount();
		if (el instanceof HTMLHeadElement) {
			const [clean, setClean] = createSignal(false);
			const cleanup = () => setClean(true);
			createRoot((dispose) => insert(el, () => !clean() ? content() : dispose(), null));
			onCleanup(cleanup);
		} else {
			const container = createElement(props.isSVG ? "g" : "div", props.isSVG), renderRoot = useShadow && container.attachShadow ? container.attachShadow({ mode: "open" }) : container;
			Object.defineProperty(container, "_$host", {
				get() {
					return marker.parentNode;
				},
				configurable: true
			});
			insert(renderRoot, content);
			el.appendChild(container);
			props.ref && props.ref(container);
			onCleanup(() => el.contains(container) && el.removeChild(container));
		}
	}, void 0, { render: !hydrating });
	return marker;
}
function createDynamic(component, props) {
	const cached = createMemo(component);
	return createMemo(() => {
		const component = cached();
		switch (typeof component) {
			case "function": return untrack(() => component(props));
			case "string":
				const isSvg = SVGElements.has(component);
				const el = sharedConfig.context ? getNextElement() : createElement(component, isSvg, untrack(() => props.is));
				spread(el, props, isSvg);
				return el;
		}
	});
}
function Dynamic(props) {
	const [, others] = splitProps(props, ["component"]);
	return createDynamic(() => props.component, others);
}
export { onCleanup as A, use as B, delegateEvents as C, memo as D, lazy as E, setTrustedTypesPolicy as F, useTransition as H, splitProps as I, spread as L, render as M, setAttribute as N, mergeProps as O, setStyleProperty as P, template as R, createUniqueId as S, insert as T, useContext as V, createEffect as _, Index as a, createRoot as b, Show as c, batch as d, className as f, createContext as g, createComputed as h, For as i, onMount as j, on as k, Switch as l, createComponent as m, $TRACK as n, Match as o, clearDelegatedEvents as p, Dynamic as r, Portal as s, $PROXY as t, addEventListener as u, createMemo as v, getListener as w, createSignal as x, createRenderEffect as y, untrack as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2ViLUJaZFZrbmROLUQ5eW56aExxLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1kZXZ0b29scy9idWlsZC93ZWItQlpkVmtuZE4uanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogQHJlZnJlc2ggc2tpcCAqL1xuLy8gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NvbGlkLWpzQDEuOS4yMC9ub2RlX21vZHVsZXMvc29saWQtanMvZGlzdC9zb2xpZC5qc1xuY29uc3Qgc2hhcmVkQ29uZmlnID0ge1xuXHRjb250ZXh0OiB2b2lkIDAsXG5cdHJlZ2lzdHJ5OiB2b2lkIDAsXG5cdGVmZmVjdHM6IHZvaWQgMCxcblx0ZG9uZTogZmFsc2UsXG5cdGdldENvbnRleHRJZCgpIHtcblx0XHRyZXR1cm4gZ2V0Q29udGV4dElkKHRoaXMuY29udGV4dC5jb3VudCk7XG5cdH0sXG5cdGdldE5leHRDb250ZXh0SWQoKSB7XG5cdFx0cmV0dXJuIGdldENvbnRleHRJZCh0aGlzLmNvbnRleHQuY291bnQrKyk7XG5cdH1cbn07XG5mdW5jdGlvbiBnZXRDb250ZXh0SWQoY291bnQpIHtcblx0Y29uc3QgbnVtID0gU3RyaW5nKGNvdW50KSwgbGVuID0gbnVtLmxlbmd0aCAtIDE7XG5cdHJldHVybiBzaGFyZWRDb25maWcuY29udGV4dC5pZCArIChsZW4gPyBTdHJpbmcuZnJvbUNoYXJDb2RlKDk2ICsgbGVuKSA6IFwiXCIpICsgbnVtO1xufVxuZnVuY3Rpb24gc2V0SHlkcmF0ZUNvbnRleHQoY29udGV4dCkge1xuXHRzaGFyZWRDb25maWcuY29udGV4dCA9IGNvbnRleHQ7XG59XG5jb25zdCBlcXVhbEZuID0gKGEsIGIpID0+IGEgPT09IGI7XG5jb25zdCAkUFJPWFkgPSBTeW1ib2woXCJzb2xpZC1wcm94eVwiKTtcbmNvbnN0IFNVUFBPUlRTX1BST1hZID0gdHlwZW9mIFByb3h5ID09PSBcImZ1bmN0aW9uXCI7XG5jb25zdCAkVFJBQ0sgPSBTeW1ib2woXCJzb2xpZC10cmFja1wiKTtcbmNvbnN0IHNpZ25hbE9wdGlvbnMgPSB7IGVxdWFsczogZXF1YWxGbiB9O1xubGV0IHJ1bkVmZmVjdHMgPSBydW5RdWV1ZTtcbmNvbnN0IFNUQUxFID0gMTtcbmNvbnN0IFBFTkRJTkcgPSAyO1xuY29uc3QgVU5PV05FRCA9IHtcblx0b3duZWQ6IG51bGwsXG5cdGNsZWFudXBzOiBudWxsLFxuXHRjb250ZXh0OiBudWxsLFxuXHRvd25lcjogbnVsbFxufTtcbmNvbnN0IE5PX0lOSVQgPSB7fTtcbnZhciBPd25lciA9IG51bGw7XG5sZXQgVHJhbnNpdGlvbiA9IG51bGw7XG5sZXQgTGlzdGVuZXIgPSBudWxsO1xubGV0IFVwZGF0ZXMgPSBudWxsO1xubGV0IEVmZmVjdHMgPSBudWxsO1xubGV0IEV4ZWNDb3VudCA9IDA7XG5mdW5jdGlvbiBjcmVhdGVSb290KGZuLCBkZXRhY2hlZE93bmVyKSB7XG5cdGNvbnN0IGxpc3RlbmVyID0gTGlzdGVuZXIsIG93bmVyID0gT3duZXIsIHVub3duZWQgPSBmbi5sZW5ndGggPT09IDAsIGN1cnJlbnQgPSBkZXRhY2hlZE93bmVyID09PSB2b2lkIDAgPyBvd25lciA6IGRldGFjaGVkT3duZXIsIHJvb3QgPSB1bm93bmVkID8gVU5PV05FRCA6IHtcblx0XHRvd25lZDogbnVsbCxcblx0XHRjbGVhbnVwczogbnVsbCxcblx0XHRjb250ZXh0OiBjdXJyZW50ID8gY3VycmVudC5jb250ZXh0IDogbnVsbCxcblx0XHRvd25lcjogY3VycmVudFxuXHR9LCB1cGRhdGVGbiA9IHVub3duZWQgPyBmbiA6ICgpID0+IGZuKGNyZWF0ZURpc3Bvc2VyKHJvb3QpKTtcblx0T3duZXIgPSByb290O1xuXHRMaXN0ZW5lciA9IG51bGw7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHJ1blVwZGF0ZXModXBkYXRlRm4sIHRydWUpO1xuXHR9IGZpbmFsbHkge1xuXHRcdExpc3RlbmVyID0gbGlzdGVuZXI7XG5cdFx0T3duZXIgPSBvd25lcjtcblx0fVxufVxuZnVuY3Rpb24gY3JlYXRlRGlzcG9zZXIocm9vdCkge1xuXHRyZXR1cm4gKCkgPT4gdW50cmFjaygoKSA9PiBjbGVhbk5vZGUocm9vdCkpO1xufVxuZnVuY3Rpb24gY3JlYXRlU2lnbmFsKHZhbHVlLCBvcHRpb25zKSB7XG5cdG9wdGlvbnMgPSBvcHRpb25zID8gT2JqZWN0LmFzc2lnbih7fSwgc2lnbmFsT3B0aW9ucywgb3B0aW9ucykgOiBzaWduYWxPcHRpb25zO1xuXHRjb25zdCBzID0ge1xuXHRcdHZhbHVlLFxuXHRcdG9ic2VydmVyczogbnVsbCxcblx0XHRvYnNlcnZlclNsb3RzOiBudWxsLFxuXHRcdGNvbXBhcmF0b3I6IG9wdGlvbnMuZXF1YWxzIHx8IHZvaWQgMFxuXHR9O1xuXHRjb25zdCBzZXR0ZXIgPSAodmFsdWUpID0+IHtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdGlmIChUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZyAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKHMpKSB2YWx1ZSA9IHZhbHVlKHMudFZhbHVlKTtcblx0XHRcdGVsc2UgdmFsdWUgPSB2YWx1ZShzLnZhbHVlKTtcblx0XHR9XG5cdFx0cmV0dXJuIHdyaXRlU2lnbmFsKHMsIHZhbHVlKTtcblx0fTtcblx0cmV0dXJuIFtyZWFkU2lnbmFsLmJpbmQocyksIHNldHRlcl07XG59XG5mdW5jdGlvbiBjcmVhdGVDb21wdXRlZChmbiwgdmFsdWUsIG9wdGlvbnMpIHtcblx0dXBkYXRlQ29tcHV0YXRpb24oY3JlYXRlQ29tcHV0YXRpb24oZm4sIHZhbHVlLCB0cnVlLCBTVEFMRSkpO1xufVxuZnVuY3Rpb24gY3JlYXRlUmVuZGVyRWZmZWN0KGZuLCB2YWx1ZSwgb3B0aW9ucykge1xuXHR1cGRhdGVDb21wdXRhdGlvbihjcmVhdGVDb21wdXRhdGlvbihmbiwgdmFsdWUsIGZhbHNlLCBTVEFMRSkpO1xufVxuZnVuY3Rpb24gY3JlYXRlRWZmZWN0KGZuLCB2YWx1ZSwgb3B0aW9ucykge1xuXHRydW5FZmZlY3RzID0gcnVuVXNlckVmZmVjdHM7XG5cdGNvbnN0IGMgPSBjcmVhdGVDb21wdXRhdGlvbihmbiwgdmFsdWUsIGZhbHNlLCBTVEFMRSksIHMgPSBTdXNwZW5zZUNvbnRleHQgJiYgdXNlQ29udGV4dChTdXNwZW5zZUNvbnRleHQpO1xuXHRpZiAocykgYy5zdXNwZW5zZSA9IHM7XG5cdGlmICghb3B0aW9ucyB8fCAhb3B0aW9ucy5yZW5kZXIpIGMudXNlciA9IHRydWU7XG5cdEVmZmVjdHMgPyBFZmZlY3RzLnB1c2goYykgOiB1cGRhdGVDb21wdXRhdGlvbihjKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZU1lbW8oZm4sIHZhbHVlLCBvcHRpb25zKSB7XG5cdG9wdGlvbnMgPSBvcHRpb25zID8gT2JqZWN0LmFzc2lnbih7fSwgc2lnbmFsT3B0aW9ucywgb3B0aW9ucykgOiBzaWduYWxPcHRpb25zO1xuXHRjb25zdCBjID0gY3JlYXRlQ29tcHV0YXRpb24oZm4sIHZhbHVlLCB0cnVlLCAwKTtcblx0Yy5vYnNlcnZlcnMgPSBudWxsO1xuXHRjLm9ic2VydmVyU2xvdHMgPSBudWxsO1xuXHRjLmNvbXBhcmF0b3IgPSBvcHRpb25zLmVxdWFscyB8fCB2b2lkIDA7XG5cdHVwZGF0ZUNvbXB1dGF0aW9uKGMpO1xuXHRyZXR1cm4gcmVhZFNpZ25hbC5iaW5kKGMpO1xufVxuZnVuY3Rpb24gaXNQcm9taXNlKHYpIHtcblx0cmV0dXJuIHYgJiYgdHlwZW9mIHYgPT09IFwib2JqZWN0XCIgJiYgXCJ0aGVuXCIgaW4gdjtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJlc291cmNlKHBTb3VyY2UsIHBGZXRjaGVyLCBwT3B0aW9ucykge1xuXHRsZXQgc291cmNlO1xuXHRsZXQgZmV0Y2hlcjtcblx0bGV0IG9wdGlvbnM7XG5cdGlmICh0eXBlb2YgcEZldGNoZXIgPT09IFwiZnVuY3Rpb25cIikge1xuXHRcdHNvdXJjZSA9IHBTb3VyY2U7XG5cdFx0ZmV0Y2hlciA9IHBGZXRjaGVyO1xuXHRcdG9wdGlvbnMgPSBwT3B0aW9ucyB8fCB7fTtcblx0fSBlbHNlIHtcblx0XHRzb3VyY2UgPSB0cnVlO1xuXHRcdGZldGNoZXIgPSBwU291cmNlO1xuXHRcdG9wdGlvbnMgPSBwRmV0Y2hlciB8fCB7fTtcblx0fVxuXHRsZXQgcHIgPSBudWxsLCBpbml0UCA9IE5PX0lOSVQsIGlkID0gbnVsbCwgbG9hZGVkVW5kZXJUcmFuc2l0aW9uID0gZmFsc2UsIHNjaGVkdWxlZCA9IGZhbHNlLCByZXNvbHZlZCA9IFwiaW5pdGlhbFZhbHVlXCIgaW4gb3B0aW9ucywgZHluYW1pYyA9IHR5cGVvZiBzb3VyY2UgPT09IFwiZnVuY3Rpb25cIiAmJiBjcmVhdGVNZW1vKHNvdXJjZSk7XG5cdGNvbnN0IGNvbnRleHRzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSwgW3ZhbHVlLCBzZXRWYWx1ZV0gPSAob3B0aW9ucy5zdG9yYWdlIHx8IGNyZWF0ZVNpZ25hbCkob3B0aW9ucy5pbml0aWFsVmFsdWUpLCBbZXJyb3IsIHNldEVycm9yXSA9IGNyZWF0ZVNpZ25hbCh2b2lkIDApLCBbdHJhY2ssIHRyaWdnZXJdID0gY3JlYXRlU2lnbmFsKHZvaWQgMCwgeyBlcXVhbHM6IGZhbHNlIH0pLCBbc3RhdGUsIHNldFN0YXRlXSA9IGNyZWF0ZVNpZ25hbChyZXNvbHZlZCA/IFwicmVhZHlcIiA6IFwidW5yZXNvbHZlZFwiKTtcblx0aWYgKE93bmVyKSBvbkNsZWFudXAoKCkgPT4ge1xuXHRcdGZvciAoY29uc3QgYyBvZiBjb250ZXh0cy5rZXlzKCkpIGMuZGVjcmVtZW50KCk7XG5cdFx0Y29udGV4dHMuY2xlYXIoKTtcblx0XHRpZiAoVHJhbnNpdGlvbiAmJiBwcikgVHJhbnNpdGlvbi5wcm9taXNlcy5kZWxldGUocHIpO1xuXHRcdHByID0gbnVsbDtcblx0fSk7XG5cdGlmIChzaGFyZWRDb25maWcuY29udGV4dCkge1xuXHRcdGlkID0gc2hhcmVkQ29uZmlnLmdldE5leHRDb250ZXh0SWQoKTtcblx0XHRpZiAob3B0aW9ucy5zc3JMb2FkRnJvbSA9PT0gXCJpbml0aWFsXCIpIGluaXRQID0gb3B0aW9ucy5pbml0aWFsVmFsdWU7XG5cdFx0ZWxzZSBpZiAoc2hhcmVkQ29uZmlnLmxvYWQgJiYgc2hhcmVkQ29uZmlnLmhhcyhpZCkpIGluaXRQID0gc2hhcmVkQ29uZmlnLmxvYWQoaWQpO1xuXHR9XG5cdGZ1bmN0aW9uIGxvYWRFbmQocCwgdiwgZXJyb3IsIGtleSkge1xuXHRcdGlmIChwciA9PT0gcCkge1xuXHRcdFx0cHIgPSBudWxsO1xuXHRcdFx0a2V5ICE9PSB2b2lkIDAgJiYgKHJlc29sdmVkID0gdHJ1ZSk7XG5cdFx0XHRpZiAoKHAgPT09IGluaXRQIHx8IHYgPT09IGluaXRQKSAmJiBvcHRpb25zLm9uSHlkcmF0ZWQpIHF1ZXVlTWljcm90YXNrKCgpID0+IG9wdGlvbnMub25IeWRyYXRlZChrZXksIHsgdmFsdWU6IHYgfSkpO1xuXHRcdFx0aW5pdFAgPSBOT19JTklUO1xuXHRcdFx0aWYgKFRyYW5zaXRpb24gJiYgcCAmJiBsb2FkZWRVbmRlclRyYW5zaXRpb24pIHtcblx0XHRcdFx0VHJhbnNpdGlvbi5wcm9taXNlcy5kZWxldGUocCk7XG5cdFx0XHRcdGxvYWRlZFVuZGVyVHJhbnNpdGlvbiA9IGZhbHNlO1xuXHRcdFx0XHRydW5VcGRhdGVzKCgpID0+IHtcblx0XHRcdFx0XHRUcmFuc2l0aW9uLnJ1bm5pbmcgPSB0cnVlO1xuXHRcdFx0XHRcdGNvbXBsZXRlTG9hZCh2LCBlcnJvcik7XG5cdFx0XHRcdH0sIGZhbHNlKTtcblx0XHRcdH0gZWxzZSBjb21wbGV0ZUxvYWQodiwgZXJyb3IpO1xuXHRcdH1cblx0XHRyZXR1cm4gdjtcblx0fVxuXHRmdW5jdGlvbiBjb21wbGV0ZUxvYWQodiwgZXJyKSB7XG5cdFx0cnVuVXBkYXRlcygoKSA9PiB7XG5cdFx0XHRpZiAoZXJyID09PSB2b2lkIDApIHNldFZhbHVlKCgpID0+IHYpO1xuXHRcdFx0c2V0U3RhdGUoZXJyICE9PSB2b2lkIDAgPyBcImVycm9yZWRcIiA6IHJlc29sdmVkID8gXCJyZWFkeVwiIDogXCJ1bnJlc29sdmVkXCIpO1xuXHRcdFx0c2V0RXJyb3IoZXJyKTtcblx0XHRcdGZvciAoY29uc3QgYyBvZiBjb250ZXh0cy5rZXlzKCkpIGMuZGVjcmVtZW50KCk7XG5cdFx0XHRjb250ZXh0cy5jbGVhcigpO1xuXHRcdH0sIGZhbHNlKTtcblx0fVxuXHRmdW5jdGlvbiByZWFkKCkge1xuXHRcdGNvbnN0IGMgPSBTdXNwZW5zZUNvbnRleHQgJiYgdXNlQ29udGV4dChTdXNwZW5zZUNvbnRleHQpLCB2ID0gdmFsdWUoKSwgZXJyID0gZXJyb3IoKTtcblx0XHRpZiAoZXJyICE9PSB2b2lkIDAgJiYgIXByKSB0aHJvdyBlcnI7XG5cdFx0aWYgKExpc3RlbmVyICYmICFMaXN0ZW5lci51c2VyICYmIGMpIGNyZWF0ZUNvbXB1dGVkKCgpID0+IHtcblx0XHRcdHRyYWNrKCk7XG5cdFx0XHRpZiAocHIpIHtcblx0XHRcdFx0aWYgKGMucmVzb2x2ZWQgJiYgVHJhbnNpdGlvbiAmJiBsb2FkZWRVbmRlclRyYW5zaXRpb24pIFRyYW5zaXRpb24ucHJvbWlzZXMuYWRkKHByKTtcblx0XHRcdFx0ZWxzZSBpZiAoIWNvbnRleHRzLmhhcyhjKSkge1xuXHRcdFx0XHRcdGMuaW5jcmVtZW50KCk7XG5cdFx0XHRcdFx0Y29udGV4dHMuYWRkKGMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0cmV0dXJuIHY7XG5cdH1cblx0ZnVuY3Rpb24gbG9hZChyZWZldGNoaW5nID0gdHJ1ZSkge1xuXHRcdGlmIChyZWZldGNoaW5nICE9PSBmYWxzZSAmJiBzY2hlZHVsZWQpIHJldHVybjtcblx0XHRzY2hlZHVsZWQgPSBmYWxzZTtcblx0XHRjb25zdCBsb29rdXAgPSBkeW5hbWljID8gZHluYW1pYygpIDogc291cmNlO1xuXHRcdGxvYWRlZFVuZGVyVHJhbnNpdGlvbiA9IFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nO1xuXHRcdGlmIChsb29rdXAgPT0gbnVsbCB8fCBsb29rdXAgPT09IGZhbHNlKSB7XG5cdFx0XHRsb2FkRW5kKHByLCB1bnRyYWNrKHZhbHVlKSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChUcmFuc2l0aW9uICYmIHByKSBUcmFuc2l0aW9uLnByb21pc2VzLmRlbGV0ZShwcik7XG5cdFx0bGV0IGVycm9yO1xuXHRcdGNvbnN0IHAgPSBpbml0UCAhPT0gTk9fSU5JVCA/IGluaXRQIDogdW50cmFjaygoKSA9PiB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRyZXR1cm4gZmV0Y2hlcihsb29rdXAsIHtcblx0XHRcdFx0XHR2YWx1ZTogdmFsdWUoKSxcblx0XHRcdFx0XHRyZWZldGNoaW5nXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSBjYXRjaCAoZmV0Y2hlckVycm9yKSB7XG5cdFx0XHRcdGVycm9yID0gZmV0Y2hlckVycm9yO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGlmIChlcnJvciAhPT0gdm9pZCAwKSB7XG5cdFx0XHRsb2FkRW5kKHByLCB2b2lkIDAsIGNhc3RFcnJvcihlcnJvciksIGxvb2t1cCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fSBlbHNlIGlmICghaXNQcm9taXNlKHApKSB7XG5cdFx0XHRsb2FkRW5kKHByLCBwLCB2b2lkIDAsIGxvb2t1cCk7XG5cdFx0XHRyZXR1cm4gcDtcblx0XHR9XG5cdFx0cHIgPSBwO1xuXHRcdGlmIChcInZcIiBpbiBwKSB7XG5cdFx0XHRpZiAocC5zID09PSAxKSBsb2FkRW5kKHByLCBwLnYsIHZvaWQgMCwgbG9va3VwKTtcblx0XHRcdGVsc2UgbG9hZEVuZChwciwgdm9pZCAwLCBjYXN0RXJyb3IocC52KSwgbG9va3VwKTtcblx0XHRcdHJldHVybiBwO1xuXHRcdH1cblx0XHRzY2hlZHVsZWQgPSB0cnVlO1xuXHRcdHF1ZXVlTWljcm90YXNrKCgpID0+IHNjaGVkdWxlZCA9IGZhbHNlKTtcblx0XHRydW5VcGRhdGVzKCgpID0+IHtcblx0XHRcdHNldFN0YXRlKHJlc29sdmVkID8gXCJyZWZyZXNoaW5nXCIgOiBcInBlbmRpbmdcIik7XG5cdFx0XHR0cmlnZ2VyKCk7XG5cdFx0fSwgZmFsc2UpO1xuXHRcdHJldHVybiBwLnRoZW4oKHYpID0+IGxvYWRFbmQocCwgdiwgdm9pZCAwLCBsb29rdXApLCAoZSkgPT4gbG9hZEVuZChwLCB2b2lkIDAsIGNhc3RFcnJvcihlKSwgbG9va3VwKSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnRpZXMocmVhZCwge1xuXHRcdHN0YXRlOiB7IGdldDogKCkgPT4gc3RhdGUoKSB9LFxuXHRcdGVycm9yOiB7IGdldDogKCkgPT4gZXJyb3IoKSB9LFxuXHRcdGxvYWRpbmc6IHsgZ2V0KCkge1xuXHRcdFx0Y29uc3QgcyA9IHN0YXRlKCk7XG5cdFx0XHRyZXR1cm4gcyA9PT0gXCJwZW5kaW5nXCIgfHwgcyA9PT0gXCJyZWZyZXNoaW5nXCI7XG5cdFx0fSB9LFxuXHRcdGxhdGVzdDogeyBnZXQoKSB7XG5cdFx0XHRpZiAoIXJlc29sdmVkKSByZXR1cm4gcmVhZCgpO1xuXHRcdFx0Y29uc3QgZXJyID0gZXJyb3IoKTtcblx0XHRcdGlmIChlcnIgJiYgIXByKSB0aHJvdyBlcnI7XG5cdFx0XHRyZXR1cm4gdmFsdWUoKTtcblx0XHR9IH1cblx0fSk7XG5cdGxldCBvd25lciA9IE93bmVyO1xuXHRpZiAoZHluYW1pYykgY3JlYXRlQ29tcHV0ZWQoKCkgPT4gKG93bmVyID0gT3duZXIsIGxvYWQoZmFsc2UpKSk7XG5cdGVsc2UgbG9hZChmYWxzZSk7XG5cdHJldHVybiBbcmVhZCwge1xuXHRcdHJlZmV0Y2g6IChpbmZvKSA9PiBydW5XaXRoT3duZXIob3duZXIsICgpID0+IGxvYWQoaW5mbykpLFxuXHRcdG11dGF0ZTogc2V0VmFsdWVcblx0fV07XG59XG5mdW5jdGlvbiBiYXRjaChmbikge1xuXHRyZXR1cm4gcnVuVXBkYXRlcyhmbiwgZmFsc2UpO1xufVxuZnVuY3Rpb24gdW50cmFjayhmbikge1xuXHRpZiAoTGlzdGVuZXIgPT09IG51bGwpIHJldHVybiBmbigpO1xuXHRjb25zdCBsaXN0ZW5lciA9IExpc3RlbmVyO1xuXHRMaXN0ZW5lciA9IG51bGw7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIGZuKCk7XG5cdH0gZmluYWxseSB7XG5cdFx0TGlzdGVuZXIgPSBsaXN0ZW5lcjtcblx0fVxufVxuZnVuY3Rpb24gb24oZGVwcywgZm4sIG9wdGlvbnMpIHtcblx0Y29uc3QgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkoZGVwcyk7XG5cdGxldCBwcmV2SW5wdXQ7XG5cdGxldCBkZWZlciA9IG9wdGlvbnMgJiYgb3B0aW9ucy5kZWZlcjtcblx0cmV0dXJuIChwcmV2VmFsdWUpID0+IHtcblx0XHRsZXQgaW5wdXQ7XG5cdFx0aWYgKGlzQXJyYXkpIHtcblx0XHRcdGlucHV0ID0gQXJyYXkoZGVwcy5sZW5ndGgpO1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBkZXBzLmxlbmd0aDsgaSsrKSBpbnB1dFtpXSA9IGRlcHNbaV0oKTtcblx0XHR9IGVsc2UgaW5wdXQgPSBkZXBzKCk7XG5cdFx0aWYgKGRlZmVyKSB7XG5cdFx0XHRkZWZlciA9IGZhbHNlO1xuXHRcdFx0cmV0dXJuIHByZXZWYWx1ZTtcblx0XHR9XG5cdFx0Y29uc3QgcmVzdWx0ID0gdW50cmFjaygoKSA9PiBmbihpbnB1dCwgcHJldklucHV0LCBwcmV2VmFsdWUpKTtcblx0XHRwcmV2SW5wdXQgPSBpbnB1dDtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9O1xufVxuZnVuY3Rpb24gb25Nb3VudChmbikge1xuXHRjcmVhdGVFZmZlY3QoKCkgPT4gdW50cmFjayhmbikpO1xufVxuZnVuY3Rpb24gb25DbGVhbnVwKGZuKSB7XG5cdGlmIChPd25lciA9PT0gbnVsbCk7XG5cdGVsc2UgaWYgKE93bmVyLmNsZWFudXBzID09PSBudWxsKSBPd25lci5jbGVhbnVwcyA9IFtmbl07XG5cdGVsc2UgT3duZXIuY2xlYW51cHMucHVzaChmbik7XG5cdHJldHVybiBmbjtcbn1cbmZ1bmN0aW9uIGdldExpc3RlbmVyKCkge1xuXHRyZXR1cm4gTGlzdGVuZXI7XG59XG5mdW5jdGlvbiBnZXRPd25lcigpIHtcblx0cmV0dXJuIE93bmVyO1xufVxuZnVuY3Rpb24gcnVuV2l0aE93bmVyKG8sIGZuKSB7XG5cdGNvbnN0IHByZXYgPSBPd25lcjtcblx0Y29uc3QgcHJldkxpc3RlbmVyID0gTGlzdGVuZXI7XG5cdE93bmVyID0gbztcblx0TGlzdGVuZXIgPSBudWxsO1xuXHR0cnkge1xuXHRcdHJldHVybiBydW5VcGRhdGVzKGZuLCB0cnVlKTtcblx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0aGFuZGxlRXJyb3IoZXJyKTtcblx0fSBmaW5hbGx5IHtcblx0XHRPd25lciA9IHByZXY7XG5cdFx0TGlzdGVuZXIgPSBwcmV2TGlzdGVuZXI7XG5cdH1cbn1cbmZ1bmN0aW9uIHN0YXJ0VHJhbnNpdGlvbihmbikge1xuXHRpZiAoVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcpIHtcblx0XHRmbigpO1xuXHRcdHJldHVybiBUcmFuc2l0aW9uLmRvbmU7XG5cdH1cblx0Y29uc3QgbCA9IExpc3RlbmVyO1xuXHRjb25zdCBvID0gT3duZXI7XG5cdHJldHVybiBQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IHtcblx0XHRMaXN0ZW5lciA9IGw7XG5cdFx0T3duZXIgPSBvO1xuXHRcdGxldCB0O1xuXHRcdGlmIChTdXNwZW5zZUNvbnRleHQpIHtcblx0XHRcdHQgPSBUcmFuc2l0aW9uIHx8IChUcmFuc2l0aW9uID0ge1xuXHRcdFx0XHRzb3VyY2VzOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpLFxuXHRcdFx0XHRlZmZlY3RzOiBbXSxcblx0XHRcdFx0cHJvbWlzZXM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG5cdFx0XHRcdGRpc3Bvc2VkOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpLFxuXHRcdFx0XHRxdWV1ZTogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcblx0XHRcdFx0cnVubmluZzogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHR0LmRvbmUgfHwgKHQuZG9uZSA9IG5ldyBQcm9taXNlKChyZXMpID0+IHQucmVzb2x2ZSA9IHJlcykpO1xuXHRcdFx0dC5ydW5uaW5nID0gdHJ1ZTtcblx0XHR9XG5cdFx0cnVuVXBkYXRlcyhmbiwgZmFsc2UpO1xuXHRcdExpc3RlbmVyID0gT3duZXIgPSBudWxsO1xuXHRcdHJldHVybiB0ID8gdC5kb25lIDogdm9pZCAwO1xuXHR9KTtcbn1cbmNvbnN0IFt0cmFuc1BlbmRpbmcsIHNldFRyYW5zUGVuZGluZ10gPSAvKkBfX1BVUkVfXyovIGNyZWF0ZVNpZ25hbChmYWxzZSk7XG5mdW5jdGlvbiB1c2VUcmFuc2l0aW9uKCkge1xuXHRyZXR1cm4gW3RyYW5zUGVuZGluZywgc3RhcnRUcmFuc2l0aW9uXTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUNvbnRleHQoZGVmYXVsdFZhbHVlLCBvcHRpb25zKSB7XG5cdGNvbnN0IGlkID0gU3ltYm9sKFwiY29udGV4dFwiKTtcblx0cmV0dXJuIHtcblx0XHRpZCxcblx0XHRQcm92aWRlcjogY3JlYXRlUHJvdmlkZXIoaWQpLFxuXHRcdGRlZmF1bHRWYWx1ZVxuXHR9O1xufVxuZnVuY3Rpb24gdXNlQ29udGV4dChjb250ZXh0KSB7XG5cdGxldCB2YWx1ZTtcblx0cmV0dXJuIE93bmVyICYmIE93bmVyLmNvbnRleHQgJiYgKHZhbHVlID0gT3duZXIuY29udGV4dFtjb250ZXh0LmlkXSkgIT09IHZvaWQgMCA/IHZhbHVlIDogY29udGV4dC5kZWZhdWx0VmFsdWU7XG59XG5mdW5jdGlvbiBjaGlsZHJlbihmbikge1xuXHRjb25zdCBjaGlsZHJlbiA9IGNyZWF0ZU1lbW8oZm4pO1xuXHRjb25zdCBtZW1vID0gY3JlYXRlTWVtbygoKSA9PiByZXNvbHZlQ2hpbGRyZW4oY2hpbGRyZW4oKSkpO1xuXHRtZW1vLnRvQXJyYXkgPSAoKSA9PiB7XG5cdFx0Y29uc3QgYyA9IG1lbW8oKTtcblx0XHRyZXR1cm4gQXJyYXkuaXNBcnJheShjKSA/IGMgOiBjICE9IG51bGwgPyBbY10gOiBbXTtcblx0fTtcblx0cmV0dXJuIG1lbW87XG59XG5sZXQgU3VzcGVuc2VDb250ZXh0O1xuZnVuY3Rpb24gcmVwYWlyT2JzZXJ2ZXJTbG90cyhzb3VyY2UpIHtcblx0c291cmNlLm9ic2VydmVyU2xvdHMgPSBzb3VyY2Uub2JzZXJ2ZXJzLm1hcCgob2JzZXJ2ZXIsIHNsb3QpID0+IHtcblx0XHRjb25zdCBzb3VyY2VzID0gb2JzZXJ2ZXIuc291cmNlcztcblx0XHRpZiAoIXNvdXJjZXMpIHJldHVybiAtMTtcblx0XHRmb3IgKGxldCBpID0gc291cmNlcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgaWYgKHNvdXJjZXNbaV0gPT09IHNvdXJjZSAmJiBvYnNlcnZlci5zb3VyY2VTbG90cyAmJiBvYnNlcnZlci5zb3VyY2VTbG90c1tpXSA9PT0gc2xvdCkgcmV0dXJuIGk7XG5cdFx0cmV0dXJuIHNvdXJjZXMubGFzdEluZGV4T2Yoc291cmNlKTtcblx0fSk7XG59XG5mdW5jdGlvbiByZWFkU2lnbmFsKCkge1xuXHRjb25zdCBydW5uaW5nVHJhbnNpdGlvbiA9IFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nO1xuXHRpZiAodGhpcy5zb3VyY2VzICYmIChydW5uaW5nVHJhbnNpdGlvbiA/IHRoaXMudFN0YXRlIDogdGhpcy5zdGF0ZSkpIHtcblx0XHRpZiAoKHJ1bm5pbmdUcmFuc2l0aW9uID8gdGhpcy50U3RhdGUgOiB0aGlzLnN0YXRlKSA9PT0gU1RBTEUpIHVwZGF0ZUNvbXB1dGF0aW9uKHRoaXMpO1xuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3QgdXBkYXRlcyA9IFVwZGF0ZXM7XG5cdFx0XHRVcGRhdGVzID0gbnVsbDtcblx0XHRcdHJ1blVwZGF0ZXMoKCkgPT4gbG9va1Vwc3RyZWFtKHRoaXMpLCBmYWxzZSk7XG5cdFx0XHRVcGRhdGVzID0gdXBkYXRlcztcblx0XHR9XG5cdH1cblx0aWYgKExpc3RlbmVyKSB7XG5cdFx0Y29uc3Qgb2JzZXJ2ZXJzID0gdGhpcy5vYnNlcnZlcnM7XG5cdFx0aWYgKCFvYnNlcnZlcnMgfHwgb2JzZXJ2ZXJzW29ic2VydmVycy5sZW5ndGggLSAxXSAhPT0gTGlzdGVuZXIpIHtcblx0XHRcdGNvbnN0IHNTbG90ID0gb2JzZXJ2ZXJzID8gb2JzZXJ2ZXJzLmxlbmd0aCA6IDA7XG5cdFx0XHRpZiAoIUxpc3RlbmVyLnNvdXJjZXMpIHtcblx0XHRcdFx0Y29uc3Qgc291cmNlcyA9IFt0aGlzXTtcblx0XHRcdFx0Y29uc3Qgc291cmNlU2xvdHMgPSBbc1Nsb3RdO1xuXHRcdFx0XHRMaXN0ZW5lci5zb3VyY2VzID0gc291cmNlcztcblx0XHRcdFx0TGlzdGVuZXIuc291cmNlU2xvdHMgPSBzb3VyY2VTbG90cztcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdExpc3RlbmVyLnNvdXJjZXMucHVzaCh0aGlzKTtcblx0XHRcdFx0TGlzdGVuZXIuc291cmNlU2xvdHMucHVzaChzU2xvdCk7XG5cdFx0XHR9XG5cdFx0XHRpZiAoIW9ic2VydmVycykge1xuXHRcdFx0XHRjb25zdCBuZXdPYnNlcnZlcnMgPSBbTGlzdGVuZXJdO1xuXHRcdFx0XHRjb25zdCBuZXdPYnNlcnZlclNsb3RzID0gW0xpc3RlbmVyLnNvdXJjZXMubGVuZ3RoIC0gMV07XG5cdFx0XHRcdHRoaXMub2JzZXJ2ZXJzID0gbmV3T2JzZXJ2ZXJzO1xuXHRcdFx0XHR0aGlzLm9ic2VydmVyU2xvdHMgPSBuZXdPYnNlcnZlclNsb3RzO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0aWYgKCF0aGlzLm9ic2VydmVyU2xvdHMgfHwgdGhpcy5vYnNlcnZlclNsb3RzLmxlbmd0aCAhPT0gb2JzZXJ2ZXJzLmxlbmd0aCkgcmVwYWlyT2JzZXJ2ZXJTbG90cyh0aGlzKTtcblx0XHRcdFx0b2JzZXJ2ZXJzLnB1c2goTGlzdGVuZXIpO1xuXHRcdFx0XHR0aGlzLm9ic2VydmVyU2xvdHMucHVzaChMaXN0ZW5lci5zb3VyY2VzLmxlbmd0aCAtIDEpO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRpZiAocnVubmluZ1RyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5zb3VyY2VzLmhhcyh0aGlzKSkgcmV0dXJuIHRoaXMudFZhbHVlO1xuXHRyZXR1cm4gdGhpcy52YWx1ZTtcbn1cbmZ1bmN0aW9uIHdyaXRlU2lnbmFsKG5vZGUsIHZhbHVlLCBpc0NvbXApIHtcblx0bGV0IGN1cnJlbnQgPSBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZyAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKG5vZGUpID8gbm9kZS50VmFsdWUgOiBub2RlLnZhbHVlO1xuXHRpZiAoIW5vZGUuY29tcGFyYXRvciB8fCAhbm9kZS5jb21wYXJhdG9yKGN1cnJlbnQsIHZhbHVlKSkge1xuXHRcdGlmIChUcmFuc2l0aW9uKSB7XG5cdFx0XHRjb25zdCBUcmFuc2l0aW9uUnVubmluZyA9IFRyYW5zaXRpb24ucnVubmluZztcblx0XHRcdGlmIChUcmFuc2l0aW9uUnVubmluZyB8fCAhaXNDb21wICYmIFRyYW5zaXRpb24uc291cmNlcy5oYXMobm9kZSkpIHtcblx0XHRcdFx0VHJhbnNpdGlvbi5zb3VyY2VzLmFkZChub2RlKTtcblx0XHRcdFx0bm9kZS50VmFsdWUgPSB2YWx1ZTtcblx0XHRcdH1cblx0XHRcdGlmICghVHJhbnNpdGlvblJ1bm5pbmcpIG5vZGUudmFsdWUgPSB2YWx1ZTtcblx0XHR9IGVsc2Ugbm9kZS52YWx1ZSA9IHZhbHVlO1xuXHRcdGlmIChub2RlLm9ic2VydmVycyAmJiBub2RlLm9ic2VydmVycy5sZW5ndGgpIHJ1blVwZGF0ZXMoKCkgPT4ge1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBub2RlLm9ic2VydmVycy5sZW5ndGg7IGkgKz0gMSkge1xuXHRcdFx0XHRjb25zdCBvID0gbm9kZS5vYnNlcnZlcnNbaV07XG5cdFx0XHRcdGNvbnN0IFRyYW5zaXRpb25SdW5uaW5nID0gVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmc7XG5cdFx0XHRcdGlmIChUcmFuc2l0aW9uUnVubmluZyAmJiBUcmFuc2l0aW9uLmRpc3Bvc2VkLmhhcyhvKSkgY29udGludWU7XG5cdFx0XHRcdGlmIChUcmFuc2l0aW9uUnVubmluZyA/ICFvLnRTdGF0ZSA6ICFvLnN0YXRlKSB7XG5cdFx0XHRcdFx0aWYgKG8ucHVyZSkgVXBkYXRlcy5wdXNoKG8pO1xuXHRcdFx0XHRcdGVsc2UgRWZmZWN0cy5wdXNoKG8pO1xuXHRcdFx0XHRcdGlmIChvLm9ic2VydmVycykgbWFya0Rvd25zdHJlYW0obyk7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKCFUcmFuc2l0aW9uUnVubmluZykgby5zdGF0ZSA9IFNUQUxFO1xuXHRcdFx0XHRlbHNlIG8udFN0YXRlID0gU1RBTEU7XG5cdFx0XHR9XG5cdFx0XHRpZiAoVXBkYXRlcy5sZW5ndGggPiAxZTYpIHtcblx0XHRcdFx0VXBkYXRlcyA9IFtdO1xuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoKTtcblx0XHRcdH1cblx0XHR9LCBmYWxzZSk7XG5cdH1cblx0cmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gdXBkYXRlQ29tcHV0YXRpb24obm9kZSkge1xuXHRpZiAoIW5vZGUuZm4pIHJldHVybjtcblx0Y2xlYW5Ob2RlKG5vZGUsIHRydWUpO1xuXHRjb25zdCB0aW1lID0gRXhlY0NvdW50O1xuXHRydW5Db21wdXRhdGlvbihub2RlLCBUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZyAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKG5vZGUpID8gbm9kZS50VmFsdWUgOiBub2RlLnZhbHVlLCB0aW1lKTtcblx0aWYgKFRyYW5zaXRpb24gJiYgIVRyYW5zaXRpb24ucnVubmluZyAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKG5vZGUpKSBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG5cdFx0cnVuVXBkYXRlcygoKSA9PiB7XG5cdFx0XHRUcmFuc2l0aW9uICYmIChUcmFuc2l0aW9uLnJ1bm5pbmcgPSB0cnVlKTtcblx0XHRcdExpc3RlbmVyID0gT3duZXIgPSBub2RlO1xuXHRcdFx0cnVuQ29tcHV0YXRpb24obm9kZSwgbm9kZS50VmFsdWUsIHRpbWUpO1xuXHRcdFx0TGlzdGVuZXIgPSBPd25lciA9IG51bGw7XG5cdFx0fSwgZmFsc2UpO1xuXHR9KTtcbn1cbmZ1bmN0aW9uIHJ1bkNvbXB1dGF0aW9uKG5vZGUsIHZhbHVlLCB0aW1lKSB7XG5cdGxldCBuZXh0VmFsdWU7XG5cdGNvbnN0IG93bmVyID0gT3duZXIsIGxpc3RlbmVyID0gTGlzdGVuZXI7XG5cdExpc3RlbmVyID0gT3duZXIgPSBub2RlO1xuXHR0cnkge1xuXHRcdG5leHRWYWx1ZSA9IG5vZGUuZm4odmFsdWUpO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRpZiAobm9kZS5wdXJlKSB7XG5cdFx0XHRpZiAoVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcpIHtcblx0XHRcdFx0bm9kZS50U3RhdGUgPSBTVEFMRTtcblx0XHRcdFx0bm9kZS50T3duZWQgJiYgbm9kZS50T3duZWQuZm9yRWFjaCgobikgPT4gY2xlYW5Ob2RlKG4pKTtcblx0XHRcdFx0bm9kZS50T3duZWQgPSB2b2lkIDA7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRub2RlLnN0YXRlID0gU1RBTEU7XG5cdFx0XHRcdG5vZGUub3duZWQgJiYgbm9kZS5vd25lZC5mb3JFYWNoKChuKSA9PiBjbGVhbk5vZGUobikpO1xuXHRcdFx0XHRub2RlLm93bmVkID0gbnVsbDtcblx0XHRcdH1cblx0XHR9XG5cdFx0bm9kZS51cGRhdGVkQXQgPSB0aW1lICsgMTtcblx0XHRyZXR1cm4gaGFuZGxlRXJyb3IoZXJyKTtcblx0fSBmaW5hbGx5IHtcblx0XHRMaXN0ZW5lciA9IGxpc3RlbmVyO1xuXHRcdE93bmVyID0gb3duZXI7XG5cdH1cblx0aWYgKCFub2RlLnVwZGF0ZWRBdCB8fCBub2RlLnVwZGF0ZWRBdCA8PSB0aW1lKSB7XG5cdFx0aWYgKG5vZGUudXBkYXRlZEF0ICE9IG51bGwgJiYgXCJvYnNlcnZlcnNcIiBpbiBub2RlKSB3cml0ZVNpZ25hbChub2RlLCBuZXh0VmFsdWUsIHRydWUpO1xuXHRcdGVsc2UgaWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nICYmIG5vZGUucHVyZSkge1xuXHRcdFx0aWYgKCFUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKG5vZGUpKSBub2RlLnZhbHVlID0gbmV4dFZhbHVlO1xuXHRcdFx0VHJhbnNpdGlvbi5zb3VyY2VzLmFkZChub2RlKTtcblx0XHRcdG5vZGUudFZhbHVlID0gbmV4dFZhbHVlO1xuXHRcdH0gZWxzZSBub2RlLnZhbHVlID0gbmV4dFZhbHVlO1xuXHRcdG5vZGUudXBkYXRlZEF0ID0gdGltZTtcblx0fVxufVxuZnVuY3Rpb24gY3JlYXRlQ29tcHV0YXRpb24oZm4sIGluaXQsIHB1cmUsIHN0YXRlID0gU1RBTEUsIG9wdGlvbnMpIHtcblx0Y29uc3QgYyA9IHtcblx0XHRmbixcblx0XHRzdGF0ZSxcblx0XHR1cGRhdGVkQXQ6IG51bGwsXG5cdFx0b3duZWQ6IG51bGwsXG5cdFx0c291cmNlczogbnVsbCxcblx0XHRzb3VyY2VTbG90czogbnVsbCxcblx0XHRjbGVhbnVwczogbnVsbCxcblx0XHR2YWx1ZTogaW5pdCxcblx0XHRvd25lcjogT3duZXIsXG5cdFx0Y29udGV4dDogT3duZXIgPyBPd25lci5jb250ZXh0IDogbnVsbCxcblx0XHRwdXJlXG5cdH07XG5cdGlmIChUcmFuc2l0aW9uICYmIFRyYW5zaXRpb24ucnVubmluZykge1xuXHRcdGMuc3RhdGUgPSAwO1xuXHRcdGMudFN0YXRlID0gc3RhdGU7XG5cdH1cblx0aWYgKE93bmVyID09PSBudWxsKTtcblx0ZWxzZSBpZiAoT3duZXIgIT09IFVOT1dORUQpIHtcblx0XHRpZiAoVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcgJiYgT3duZXIucHVyZSkge1xuXHRcdFx0aWYgKCFPd25lci50T3duZWQpIE93bmVyLnRPd25lZCA9IFtjXTtcblx0XHRcdGVsc2UgT3duZXIudE93bmVkLnB1c2goYyk7XG5cdFx0fSBlbHNlIGlmICghT3duZXIub3duZWQpIE93bmVyLm93bmVkID0gW2NdO1xuXHRcdGVsc2UgT3duZXIub3duZWQucHVzaChjKTtcblx0fVxuXHRyZXR1cm4gYztcbn1cbmZ1bmN0aW9uIHJ1blRvcChub2RlKSB7XG5cdGNvbnN0IHJ1bm5pbmdUcmFuc2l0aW9uID0gVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmc7XG5cdGlmICgocnVubmluZ1RyYW5zaXRpb24gPyBub2RlLnRTdGF0ZSA6IG5vZGUuc3RhdGUpID09PSAwKSByZXR1cm47XG5cdGlmICgocnVubmluZ1RyYW5zaXRpb24gPyBub2RlLnRTdGF0ZSA6IG5vZGUuc3RhdGUpID09PSBQRU5ESU5HKSByZXR1cm4gbG9va1Vwc3RyZWFtKG5vZGUpO1xuXHRpZiAobm9kZS5zdXNwZW5zZSAmJiB1bnRyYWNrKG5vZGUuc3VzcGVuc2UuaW5GYWxsYmFjaykpIHJldHVybiBub2RlLnN1c3BlbnNlLmVmZmVjdHMucHVzaChub2RlKTtcblx0Y29uc3QgYW5jZXN0b3JzID0gW25vZGVdO1xuXHR3aGlsZSAoKG5vZGUgPSBub2RlLm93bmVyKSAmJiAoIW5vZGUudXBkYXRlZEF0IHx8IG5vZGUudXBkYXRlZEF0IDwgRXhlY0NvdW50KSkge1xuXHRcdGlmIChydW5uaW5nVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLmRpc3Bvc2VkLmhhcyhub2RlKSkgcmV0dXJuO1xuXHRcdGlmIChydW5uaW5nVHJhbnNpdGlvbiA/IG5vZGUudFN0YXRlIDogbm9kZS5zdGF0ZSkgYW5jZXN0b3JzLnB1c2gobm9kZSk7XG5cdH1cblx0Zm9yIChsZXQgaSA9IGFuY2VzdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdG5vZGUgPSBhbmNlc3RvcnNbaV07XG5cdFx0aWYgKHJ1bm5pbmdUcmFuc2l0aW9uKSB7XG5cdFx0XHRsZXQgdG9wID0gbm9kZSwgcHJldiA9IGFuY2VzdG9yc1tpICsgMV07XG5cdFx0XHR3aGlsZSAoKHRvcCA9IHRvcC5vd25lcikgJiYgdG9wICE9PSBwcmV2KSBpZiAoVHJhbnNpdGlvbi5kaXNwb3NlZC5oYXModG9wKSkgcmV0dXJuO1xuXHRcdH1cblx0XHRpZiAoKHJ1bm5pbmdUcmFuc2l0aW9uID8gbm9kZS50U3RhdGUgOiBub2RlLnN0YXRlKSA9PT0gU1RBTEUpIHVwZGF0ZUNvbXB1dGF0aW9uKG5vZGUpO1xuXHRcdGVsc2UgaWYgKChydW5uaW5nVHJhbnNpdGlvbiA/IG5vZGUudFN0YXRlIDogbm9kZS5zdGF0ZSkgPT09IFBFTkRJTkcpIHtcblx0XHRcdGNvbnN0IHVwZGF0ZXMgPSBVcGRhdGVzO1xuXHRcdFx0VXBkYXRlcyA9IG51bGw7XG5cdFx0XHRydW5VcGRhdGVzKCgpID0+IGxvb2tVcHN0cmVhbShub2RlLCBhbmNlc3RvcnNbMF0pLCBmYWxzZSk7XG5cdFx0XHRVcGRhdGVzID0gdXBkYXRlcztcblx0XHR9XG5cdH1cbn1cbmZ1bmN0aW9uIHJ1blVwZGF0ZXMoZm4sIGluaXQpIHtcblx0aWYgKFVwZGF0ZXMpIHJldHVybiBmbigpO1xuXHRsZXQgd2FpdCA9IGZhbHNlO1xuXHRpZiAoIWluaXQpIFVwZGF0ZXMgPSBbXTtcblx0aWYgKEVmZmVjdHMpIHdhaXQgPSB0cnVlO1xuXHRlbHNlIEVmZmVjdHMgPSBbXTtcblx0RXhlY0NvdW50Kys7XG5cdHRyeSB7XG5cdFx0Y29uc3QgcmVzID0gZm4oKTtcblx0XHRjb21wbGV0ZVVwZGF0ZXMod2FpdCk7XG5cdFx0cmV0dXJuIHJlcztcblx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0aWYgKCF3YWl0KSBFZmZlY3RzID0gbnVsbDtcblx0XHRVcGRhdGVzID0gbnVsbDtcblx0XHRoYW5kbGVFcnJvcihlcnIpO1xuXHR9XG59XG5mdW5jdGlvbiBjb21wbGV0ZVVwZGF0ZXMod2FpdCkge1xuXHRpZiAoVXBkYXRlcykge1xuXHRcdHJ1blF1ZXVlKFVwZGF0ZXMpO1xuXHRcdFVwZGF0ZXMgPSBudWxsO1xuXHR9XG5cdGlmICh3YWl0KSByZXR1cm47XG5cdGxldCByZXM7XG5cdGlmIChUcmFuc2l0aW9uKSB7XG5cdFx0aWYgKCFUcmFuc2l0aW9uLnByb21pc2VzLnNpemUgJiYgIVRyYW5zaXRpb24ucXVldWUuc2l6ZSkge1xuXHRcdFx0Y29uc3Qgc291cmNlcyA9IFRyYW5zaXRpb24uc291cmNlcztcblx0XHRcdGNvbnN0IGRpc3Bvc2VkID0gVHJhbnNpdGlvbi5kaXNwb3NlZDtcblx0XHRcdEVmZmVjdHMucHVzaC5hcHBseShFZmZlY3RzLCBUcmFuc2l0aW9uLmVmZmVjdHMpO1xuXHRcdFx0cmVzID0gVHJhbnNpdGlvbi5yZXNvbHZlO1xuXHRcdFx0Zm9yIChjb25zdCBlIG9mIEVmZmVjdHMpIHtcblx0XHRcdFx0XCJ0U3RhdGVcIiBpbiBlICYmIChlLnN0YXRlID0gZS50U3RhdGUpO1xuXHRcdFx0XHRkZWxldGUgZS50U3RhdGU7XG5cdFx0XHR9XG5cdFx0XHRUcmFuc2l0aW9uID0gbnVsbDtcblx0XHRcdHJ1blVwZGF0ZXMoKCkgPT4ge1xuXHRcdFx0XHRmb3IgKGNvbnN0IGQgb2YgZGlzcG9zZWQpIGNsZWFuTm9kZShkKTtcblx0XHRcdFx0Zm9yIChjb25zdCB2IG9mIHNvdXJjZXMpIHtcblx0XHRcdFx0XHR2LnZhbHVlID0gdi50VmFsdWU7XG5cdFx0XHRcdFx0aWYgKHYub3duZWQpIGZvciAobGV0IGkgPSAwLCBsZW4gPSB2Lm93bmVkLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSBjbGVhbk5vZGUodi5vd25lZFtpXSk7XG5cdFx0XHRcdFx0aWYgKHYudE93bmVkKSB2Lm93bmVkID0gdi50T3duZWQ7XG5cdFx0XHRcdFx0ZGVsZXRlIHYudFZhbHVlO1xuXHRcdFx0XHRcdGRlbGV0ZSB2LnRPd25lZDtcblx0XHRcdFx0XHR2LnRTdGF0ZSA9IDA7XG5cdFx0XHRcdH1cblx0XHRcdFx0c2V0VHJhbnNQZW5kaW5nKGZhbHNlKTtcblx0XHRcdH0sIGZhbHNlKTtcblx0XHR9IGVsc2UgaWYgKFRyYW5zaXRpb24ucnVubmluZykge1xuXHRcdFx0VHJhbnNpdGlvbi5ydW5uaW5nID0gZmFsc2U7XG5cdFx0XHRUcmFuc2l0aW9uLmVmZmVjdHMucHVzaC5hcHBseShUcmFuc2l0aW9uLmVmZmVjdHMsIEVmZmVjdHMpO1xuXHRcdFx0RWZmZWN0cyA9IG51bGw7XG5cdFx0XHRzZXRUcmFuc1BlbmRpbmcodHJ1ZSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHR9XG5cdGNvbnN0IGUgPSBFZmZlY3RzO1xuXHRFZmZlY3RzID0gbnVsbDtcblx0aWYgKGUubGVuZ3RoKSBydW5VcGRhdGVzKCgpID0+IHJ1bkVmZmVjdHMoZSksIGZhbHNlKTtcblx0aWYgKHJlcykgcmVzKCk7XG59XG5mdW5jdGlvbiBydW5RdWV1ZShxdWV1ZSkge1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHF1ZXVlLmxlbmd0aDsgaSsrKSBydW5Ub3AocXVldWVbaV0pO1xufVxuZnVuY3Rpb24gcnVuVXNlckVmZmVjdHMocXVldWUpIHtcblx0bGV0IGksIHVzZXJMZW5ndGggPSAwO1xuXHRmb3IgKGkgPSAwOyBpIDwgcXVldWUubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCBlID0gcXVldWVbaV07XG5cdFx0aWYgKCFlLnVzZXIpIHJ1blRvcChlKTtcblx0XHRlbHNlIHF1ZXVlW3VzZXJMZW5ndGgrK10gPSBlO1xuXHR9XG5cdGlmIChzaGFyZWRDb25maWcuY29udGV4dCkge1xuXHRcdGlmIChzaGFyZWRDb25maWcuY291bnQpIHtcblx0XHRcdHNoYXJlZENvbmZpZy5lZmZlY3RzIHx8IChzaGFyZWRDb25maWcuZWZmZWN0cyA9IFtdKTtcblx0XHRcdHNoYXJlZENvbmZpZy5lZmZlY3RzLnB1c2goLi4ucXVldWUuc2xpY2UoMCwgdXNlckxlbmd0aCkpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRzZXRIeWRyYXRlQ29udGV4dCgpO1xuXHR9XG5cdGlmIChzaGFyZWRDb25maWcuZWZmZWN0cyAmJiAoc2hhcmVkQ29uZmlnLmRvbmUgfHwgIXNoYXJlZENvbmZpZy5jb3VudCkpIHtcblx0XHRxdWV1ZSA9IFsuLi5zaGFyZWRDb25maWcuZWZmZWN0cywgLi4ucXVldWVdO1xuXHRcdHVzZXJMZW5ndGggKz0gc2hhcmVkQ29uZmlnLmVmZmVjdHMubGVuZ3RoO1xuXHRcdGRlbGV0ZSBzaGFyZWRDb25maWcuZWZmZWN0cztcblx0fVxuXHRmb3IgKGkgPSAwOyBpIDwgdXNlckxlbmd0aDsgaSsrKSBydW5Ub3AocXVldWVbaV0pO1xufVxuZnVuY3Rpb24gbG9va1Vwc3RyZWFtKG5vZGUsIGlnbm9yZSkge1xuXHRjb25zdCBydW5uaW5nVHJhbnNpdGlvbiA9IFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nO1xuXHRpZiAocnVubmluZ1RyYW5zaXRpb24pIG5vZGUudFN0YXRlID0gMDtcblx0ZWxzZSBub2RlLnN0YXRlID0gMDtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBub2RlLnNvdXJjZXMubGVuZ3RoOyBpICs9IDEpIHtcblx0XHRjb25zdCBzb3VyY2UgPSBub2RlLnNvdXJjZXNbaV07XG5cdFx0aWYgKHNvdXJjZS5zb3VyY2VzKSB7XG5cdFx0XHRjb25zdCBzdGF0ZSA9IHJ1bm5pbmdUcmFuc2l0aW9uID8gc291cmNlLnRTdGF0ZSA6IHNvdXJjZS5zdGF0ZTtcblx0XHRcdGlmIChzdGF0ZSA9PT0gU1RBTEUpIHtcblx0XHRcdFx0aWYgKHNvdXJjZSAhPT0gaWdub3JlICYmICghc291cmNlLnVwZGF0ZWRBdCB8fCBzb3VyY2UudXBkYXRlZEF0IDwgRXhlY0NvdW50KSkgcnVuVG9wKHNvdXJjZSk7XG5cdFx0XHR9IGVsc2UgaWYgKHN0YXRlID09PSBQRU5ESU5HKSBsb29rVXBzdHJlYW0oc291cmNlLCBpZ25vcmUpO1xuXHRcdH1cblx0fVxufVxuZnVuY3Rpb24gbWFya0Rvd25zdHJlYW0obm9kZSkge1xuXHRjb25zdCBydW5uaW5nVHJhbnNpdGlvbiA9IFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IG5vZGUub2JzZXJ2ZXJzLmxlbmd0aDsgaSArPSAxKSB7XG5cdFx0Y29uc3QgbyA9IG5vZGUub2JzZXJ2ZXJzW2ldO1xuXHRcdGlmIChydW5uaW5nVHJhbnNpdGlvbiA/ICFvLnRTdGF0ZSA6ICFvLnN0YXRlKSB7XG5cdFx0XHRpZiAocnVubmluZ1RyYW5zaXRpb24pIG8udFN0YXRlID0gUEVORElORztcblx0XHRcdGVsc2Ugby5zdGF0ZSA9IFBFTkRJTkc7XG5cdFx0XHRpZiAoby5wdXJlKSBVcGRhdGVzLnB1c2gobyk7XG5cdFx0XHRlbHNlIEVmZmVjdHMucHVzaChvKTtcblx0XHRcdG8ub2JzZXJ2ZXJzICYmIG1hcmtEb3duc3RyZWFtKG8pO1xuXHRcdH1cblx0fVxufVxuZnVuY3Rpb24gcmVsZWFzZVRyYW5zaXRpb25Tb3VyY2Uobm9kZSkge1xuXHRpZiAoVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnNvdXJjZXMuaGFzKG5vZGUpKSB7XG5cdFx0VHJhbnNpdGlvbi5zb3VyY2VzLmRlbGV0ZShub2RlKTtcblx0XHRkZWxldGUgbm9kZS50VmFsdWU7XG5cdH1cbn1cbmZ1bmN0aW9uIGNsZWFuTm9kZShub2RlLCByZWNvbXB1dGUpIHtcblx0bGV0IGk7XG5cdGlmIChub2RlLnNvdXJjZXMpIHdoaWxlIChub2RlLnNvdXJjZXMubGVuZ3RoKSB7XG5cdFx0Y29uc3Qgc291cmNlID0gbm9kZS5zb3VyY2VzLnBvcCgpLCBpbmRleCA9IG5vZGUuc291cmNlU2xvdHMucG9wKCksIG9icyA9IHNvdXJjZS5vYnNlcnZlcnM7XG5cdFx0aWYgKG9icyAmJiBvYnMubGVuZ3RoKSB7XG5cdFx0XHRpZiAoIXNvdXJjZS5vYnNlcnZlclNsb3RzIHx8IHNvdXJjZS5vYnNlcnZlclNsb3RzLmxlbmd0aCAhPT0gb2JzLmxlbmd0aCkgcmVwYWlyT2JzZXJ2ZXJTbG90cyhzb3VyY2UpO1xuXHRcdFx0Y29uc3QgbiA9IG9icy5wb3AoKSwgcyA9IHNvdXJjZS5vYnNlcnZlclNsb3RzLnBvcCgpO1xuXHRcdFx0aWYgKGluZGV4IDwgb2JzLmxlbmd0aCkge1xuXHRcdFx0XHRuLnNvdXJjZVNsb3RzW3NdID0gaW5kZXg7XG5cdFx0XHRcdG9ic1tpbmRleF0gPSBuO1xuXHRcdFx0XHRzb3VyY2Uub2JzZXJ2ZXJTbG90c1tpbmRleF0gPSBzO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZiAoIXJlY29tcHV0ZSAmJiAoIW9icyB8fCAhb2JzLmxlbmd0aCkgJiYgVHJhbnNpdGlvbikgcmVsZWFzZVRyYW5zaXRpb25Tb3VyY2Uoc291cmNlKTtcblx0fVxuXHRpZiAobm9kZS50T3duZWQpIHtcblx0XHRmb3IgKGkgPSBub2RlLnRPd25lZC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgY2xlYW5Ob2RlKG5vZGUudE93bmVkW2ldKTtcblx0XHRkZWxldGUgbm9kZS50T3duZWQ7XG5cdH1cblx0aWYgKFRyYW5zaXRpb24gJiYgVHJhbnNpdGlvbi5ydW5uaW5nICYmIG5vZGUucHVyZSkgcmVzZXQobm9kZSwgdHJ1ZSk7XG5cdGVsc2UgaWYgKG5vZGUub3duZWQpIHtcblx0XHRmb3IgKGkgPSBub2RlLm93bmVkLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBjbGVhbk5vZGUobm9kZS5vd25lZFtpXSk7XG5cdFx0bm9kZS5vd25lZCA9IG51bGw7XG5cdH1cblx0aWYgKCFyZWNvbXB1dGUpIHJlbGVhc2VUcmFuc2l0aW9uU291cmNlKG5vZGUpO1xuXHRpZiAobm9kZS5jbGVhbnVwcykge1xuXHRcdGZvciAoaSA9IG5vZGUuY2xlYW51cHMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIG5vZGUuY2xlYW51cHNbaV0oKTtcblx0XHRub2RlLmNsZWFudXBzID0gbnVsbDtcblx0fVxuXHRpZiAoVHJhbnNpdGlvbiAmJiBUcmFuc2l0aW9uLnJ1bm5pbmcpIG5vZGUudFN0YXRlID0gMDtcblx0ZWxzZSBub2RlLnN0YXRlID0gMDtcbn1cbmZ1bmN0aW9uIHJlc2V0KG5vZGUsIHRvcCkge1xuXHRpZiAoIXRvcCkge1xuXHRcdG5vZGUudFN0YXRlID0gMDtcblx0XHRUcmFuc2l0aW9uLmRpc3Bvc2VkLmFkZChub2RlKTtcblx0XHRyZWxlYXNlVHJhbnNpdGlvblNvdXJjZShub2RlKTtcblx0fVxuXHRpZiAobm9kZS5vd25lZCkgZm9yIChsZXQgaSA9IDA7IGkgPCBub2RlLm93bmVkLmxlbmd0aDsgaSsrKSByZXNldChub2RlLm93bmVkW2ldKTtcbn1cbmZ1bmN0aW9uIGNhc3RFcnJvcihlcnIpIHtcblx0aWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSByZXR1cm4gZXJyO1xuXHRyZXR1cm4gbmV3IEVycm9yKHR5cGVvZiBlcnIgPT09IFwic3RyaW5nXCIgPyBlcnIgOiBcIlVua25vd24gZXJyb3JcIiwgeyBjYXVzZTogZXJyIH0pO1xufVxuZnVuY3Rpb24gaGFuZGxlRXJyb3IoZXJyLCBvd25lciA9IE93bmVyKSB7XG5cdHRocm93IGNhc3RFcnJvcihlcnIpO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUNoaWxkcmVuKGNoaWxkcmVuKSB7XG5cdGlmICh0eXBlb2YgY2hpbGRyZW4gPT09IFwiZnVuY3Rpb25cIiAmJiAhY2hpbGRyZW4ubGVuZ3RoKSByZXR1cm4gcmVzb2x2ZUNoaWxkcmVuKGNoaWxkcmVuKCkpO1xuXHRpZiAoQXJyYXkuaXNBcnJheShjaGlsZHJlbikpIHtcblx0XHRjb25zdCByZXN1bHRzID0gW107XG5cdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuXHRcdFx0Y29uc3QgcmVzdWx0ID0gcmVzb2x2ZUNoaWxkcmVuKGNoaWxkcmVuW2ldKTtcblx0XHRcdGlmIChBcnJheS5pc0FycmF5KHJlc3VsdCkpIHtcblx0XHRcdFx0aWYgKHJlc3VsdC5sZW5ndGggPCAzMjc2OCkgcmVzdWx0cy5wdXNoLmFwcGx5KHJlc3VsdHMsIHJlc3VsdCk7XG5cdFx0XHRcdGVsc2UgZm9yIChsZXQgaiA9IDA7IGogPCByZXN1bHQubGVuZ3RoOyBqKyspIHJlc3VsdHMucHVzaChyZXN1bHRbal0pO1xuXHRcdFx0fSBlbHNlIHJlc3VsdHMucHVzaChyZXN1bHQpO1xuXHRcdH1cblx0XHRyZXR1cm4gcmVzdWx0cztcblx0fVxuXHRyZXR1cm4gY2hpbGRyZW47XG59XG5mdW5jdGlvbiBjcmVhdGVQcm92aWRlcihpZCwgb3B0aW9ucykge1xuXHRyZXR1cm4gZnVuY3Rpb24gcHJvdmlkZXIocHJvcHMpIHtcblx0XHRsZXQgcmVzO1xuXHRcdGNyZWF0ZVJlbmRlckVmZmVjdCgoKSA9PiByZXMgPSB1bnRyYWNrKCgpID0+IHtcblx0XHRcdE93bmVyLmNvbnRleHQgPSB7XG5cdFx0XHRcdC4uLk93bmVyLmNvbnRleHQsXG5cdFx0XHRcdFtpZF06IHByb3BzLnZhbHVlXG5cdFx0XHR9O1xuXHRcdFx0cmV0dXJuIGNoaWxkcmVuKCgpID0+IHByb3BzLmNoaWxkcmVuKTtcblx0XHR9KSwgdm9pZCAwKTtcblx0XHRyZXR1cm4gcmVzO1xuXHR9O1xufVxuY29uc3QgRkFMTEJBQ0sgPSBTeW1ib2woXCJmYWxsYmFja1wiKTtcbmZ1bmN0aW9uIGRpc3Bvc2UoZCkge1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGQubGVuZ3RoOyBpKyspIGRbaV0oKTtcbn1cbmZ1bmN0aW9uIG1hcEFycmF5KGxpc3QsIG1hcEZuLCBvcHRpb25zID0ge30pIHtcblx0bGV0IGl0ZW1zID0gW10sIG1hcHBlZCA9IFtdLCBkaXNwb3NlcnMgPSBbXSwgbGVuID0gMCwgaW5kZXhlcyA9IG1hcEZuLmxlbmd0aCA+IDEgPyBbXSA6IG51bGw7XG5cdG9uQ2xlYW51cCgoKSA9PiBkaXNwb3NlKGRpc3Bvc2VycykpO1xuXHRyZXR1cm4gKCkgPT4ge1xuXHRcdGxldCBuZXdJdGVtcyA9IGxpc3QoKSB8fCBbXSwgbmV3TGVuID0gbmV3SXRlbXMubGVuZ3RoLCBpLCBqO1xuXHRcdG5ld0l0ZW1zWyRUUkFDS107XG5cdFx0cmV0dXJuIHVudHJhY2soKCkgPT4ge1xuXHRcdFx0bGV0IG5ld0luZGljZXMsIG5ld0luZGljZXNOZXh0LCB0ZW1wLCB0ZW1wZGlzcG9zZXJzLCB0ZW1wSW5kZXhlcywgc3RhcnQsIGVuZCwgbmV3RW5kLCBpdGVtO1xuXHRcdFx0aWYgKG5ld0xlbiA9PT0gMCkge1xuXHRcdFx0XHRpZiAobGVuICE9PSAwKSB7XG5cdFx0XHRcdFx0ZGlzcG9zZShkaXNwb3NlcnMpO1xuXHRcdFx0XHRcdGRpc3Bvc2VycyA9IFtdO1xuXHRcdFx0XHRcdGl0ZW1zID0gW107XG5cdFx0XHRcdFx0bWFwcGVkID0gW107XG5cdFx0XHRcdFx0bGVuID0gMDtcblx0XHRcdFx0XHRpbmRleGVzICYmIChpbmRleGVzID0gW10pO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChvcHRpb25zLmZhbGxiYWNrKSB7XG5cdFx0XHRcdFx0aXRlbXMgPSBbRkFMTEJBQ0tdO1xuXHRcdFx0XHRcdG1hcHBlZFswXSA9IGNyZWF0ZVJvb3QoKGRpc3Bvc2VyKSA9PiB7XG5cdFx0XHRcdFx0XHRkaXNwb3NlcnNbMF0gPSBkaXNwb3Nlcjtcblx0XHRcdFx0XHRcdHJldHVybiBvcHRpb25zLmZhbGxiYWNrKCk7XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0bGVuID0gMTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIGlmIChsZW4gPT09IDApIHtcblx0XHRcdFx0bWFwcGVkID0gbmV3IEFycmF5KG5ld0xlbik7XG5cdFx0XHRcdGZvciAoaiA9IDA7IGogPCBuZXdMZW47IGorKykge1xuXHRcdFx0XHRcdGl0ZW1zW2pdID0gbmV3SXRlbXNbal07XG5cdFx0XHRcdFx0bWFwcGVkW2pdID0gY3JlYXRlUm9vdChtYXBwZXIpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGxlbiA9IG5ld0xlbjtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHRlbXAgPSBuZXcgQXJyYXkobmV3TGVuKTtcblx0XHRcdFx0dGVtcGRpc3Bvc2VycyA9IG5ldyBBcnJheShuZXdMZW4pO1xuXHRcdFx0XHRpbmRleGVzICYmICh0ZW1wSW5kZXhlcyA9IG5ldyBBcnJheShuZXdMZW4pKTtcblx0XHRcdFx0Zm9yIChzdGFydCA9IDAsIGVuZCA9IE1hdGgubWluKGxlbiwgbmV3TGVuKTsgc3RhcnQgPCBlbmQgJiYgaXRlbXNbc3RhcnRdID09PSBuZXdJdGVtc1tzdGFydF07IHN0YXJ0KyspO1xuXHRcdFx0XHRmb3IgKGVuZCA9IGxlbiAtIDEsIG5ld0VuZCA9IG5ld0xlbiAtIDE7IGVuZCA+PSBzdGFydCAmJiBuZXdFbmQgPj0gc3RhcnQgJiYgaXRlbXNbZW5kXSA9PT0gbmV3SXRlbXNbbmV3RW5kXTsgZW5kLS0sIG5ld0VuZC0tKSB7XG5cdFx0XHRcdFx0dGVtcFtuZXdFbmRdID0gbWFwcGVkW2VuZF07XG5cdFx0XHRcdFx0dGVtcGRpc3Bvc2Vyc1tuZXdFbmRdID0gZGlzcG9zZXJzW2VuZF07XG5cdFx0XHRcdFx0aW5kZXhlcyAmJiAodGVtcEluZGV4ZXNbbmV3RW5kXSA9IGluZGV4ZXNbZW5kXSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0bmV3SW5kaWNlcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0XHRcdG5ld0luZGljZXNOZXh0ID0gbmV3IEFycmF5KG5ld0VuZCArIDEpO1xuXHRcdFx0XHRmb3IgKGogPSBuZXdFbmQ7IGogPj0gc3RhcnQ7IGotLSkge1xuXHRcdFx0XHRcdGl0ZW0gPSBuZXdJdGVtc1tqXTtcblx0XHRcdFx0XHRpID0gbmV3SW5kaWNlcy5nZXQoaXRlbSk7XG5cdFx0XHRcdFx0bmV3SW5kaWNlc05leHRbal0gPSBpID09PSB2b2lkIDAgPyAtMSA6IGk7XG5cdFx0XHRcdFx0bmV3SW5kaWNlcy5zZXQoaXRlbSwgaik7XG5cdFx0XHRcdH1cblx0XHRcdFx0Zm9yIChpID0gc3RhcnQ7IGkgPD0gZW5kOyBpKyspIHtcblx0XHRcdFx0XHRpdGVtID0gaXRlbXNbaV07XG5cdFx0XHRcdFx0aiA9IG5ld0luZGljZXMuZ2V0KGl0ZW0pO1xuXHRcdFx0XHRcdGlmIChqICE9PSB2b2lkIDAgJiYgaiAhPT0gLTEpIHtcblx0XHRcdFx0XHRcdHRlbXBbal0gPSBtYXBwZWRbaV07XG5cdFx0XHRcdFx0XHR0ZW1wZGlzcG9zZXJzW2pdID0gZGlzcG9zZXJzW2ldO1xuXHRcdFx0XHRcdFx0aW5kZXhlcyAmJiAodGVtcEluZGV4ZXNbal0gPSBpbmRleGVzW2ldKTtcblx0XHRcdFx0XHRcdGogPSBuZXdJbmRpY2VzTmV4dFtqXTtcblx0XHRcdFx0XHRcdG5ld0luZGljZXMuc2V0KGl0ZW0sIGopO1xuXHRcdFx0XHRcdH0gZWxzZSBkaXNwb3NlcnNbaV0oKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRmb3IgKGogPSBzdGFydDsgaiA8IG5ld0xlbjsgaisrKSBpZiAoaiBpbiB0ZW1wKSB7XG5cdFx0XHRcdFx0bWFwcGVkW2pdID0gdGVtcFtqXTtcblx0XHRcdFx0XHRkaXNwb3NlcnNbal0gPSB0ZW1wZGlzcG9zZXJzW2pdO1xuXHRcdFx0XHRcdGlmIChpbmRleGVzKSB7XG5cdFx0XHRcdFx0XHRpbmRleGVzW2pdID0gdGVtcEluZGV4ZXNbal07XG5cdFx0XHRcdFx0XHRpbmRleGVzW2pdKGopO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIG1hcHBlZFtqXSA9IGNyZWF0ZVJvb3QobWFwcGVyKTtcblx0XHRcdFx0bWFwcGVkID0gbWFwcGVkLnNsaWNlKDAsIGxlbiA9IG5ld0xlbik7XG5cdFx0XHRcdGl0ZW1zID0gbmV3SXRlbXMuc2xpY2UoMCk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gbWFwcGVkO1xuXHRcdH0pO1xuXHRcdGZ1bmN0aW9uIG1hcHBlcihkaXNwb3Nlcikge1xuXHRcdFx0ZGlzcG9zZXJzW2pdID0gZGlzcG9zZXI7XG5cdFx0XHRpZiAoaW5kZXhlcykge1xuXHRcdFx0XHRjb25zdCBbcywgc2V0XSA9IGNyZWF0ZVNpZ25hbChqKTtcblx0XHRcdFx0aW5kZXhlc1tqXSA9IHNldDtcblx0XHRcdFx0cmV0dXJuIG1hcEZuKG5ld0l0ZW1zW2pdLCBzKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBtYXBGbihuZXdJdGVtc1tqXSk7XG5cdFx0fVxuXHR9O1xufVxuZnVuY3Rpb24gaW5kZXhBcnJheShsaXN0LCBtYXBGbiwgb3B0aW9ucyA9IHt9KSB7XG5cdGxldCBpdGVtcyA9IFtdLCBtYXBwZWQgPSBbXSwgZGlzcG9zZXJzID0gW10sIHNpZ25hbHMgPSBbXSwgbGVuID0gMCwgaTtcblx0b25DbGVhbnVwKCgpID0+IGRpc3Bvc2UoZGlzcG9zZXJzKSk7XG5cdHJldHVybiAoKSA9PiB7XG5cdFx0Y29uc3QgbmV3SXRlbXMgPSBsaXN0KCkgfHwgW10sIG5ld0xlbiA9IG5ld0l0ZW1zLmxlbmd0aDtcblx0XHRuZXdJdGVtc1skVFJBQ0tdO1xuXHRcdHJldHVybiB1bnRyYWNrKCgpID0+IHtcblx0XHRcdGlmIChuZXdMZW4gPT09IDApIHtcblx0XHRcdFx0aWYgKGxlbiAhPT0gMCkge1xuXHRcdFx0XHRcdGRpc3Bvc2UoZGlzcG9zZXJzKTtcblx0XHRcdFx0XHRkaXNwb3NlcnMgPSBbXTtcblx0XHRcdFx0XHRpdGVtcyA9IFtdO1xuXHRcdFx0XHRcdG1hcHBlZCA9IFtdO1xuXHRcdFx0XHRcdGxlbiA9IDA7XG5cdFx0XHRcdFx0c2lnbmFscyA9IFtdO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChvcHRpb25zLmZhbGxiYWNrKSB7XG5cdFx0XHRcdFx0aXRlbXMgPSBbRkFMTEJBQ0tdO1xuXHRcdFx0XHRcdG1hcHBlZFswXSA9IGNyZWF0ZVJvb3QoKGRpc3Bvc2VyKSA9PiB7XG5cdFx0XHRcdFx0XHRkaXNwb3NlcnNbMF0gPSBkaXNwb3Nlcjtcblx0XHRcdFx0XHRcdHJldHVybiBvcHRpb25zLmZhbGxiYWNrKCk7XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0bGVuID0gMTtcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gbWFwcGVkO1xuXHRcdFx0fVxuXHRcdFx0aWYgKGl0ZW1zWzBdID09PSBGQUxMQkFDSykge1xuXHRcdFx0XHRkaXNwb3NlcnNbMF0oKTtcblx0XHRcdFx0ZGlzcG9zZXJzID0gW107XG5cdFx0XHRcdGl0ZW1zID0gW107XG5cdFx0XHRcdG1hcHBlZCA9IFtdO1xuXHRcdFx0XHRsZW4gPSAwO1xuXHRcdFx0fVxuXHRcdFx0Zm9yIChpID0gMDsgaSA8IG5ld0xlbjsgaSsrKSBpZiAoaSA8IGl0ZW1zLmxlbmd0aCAmJiBpdGVtc1tpXSAhPT0gbmV3SXRlbXNbaV0pIHNpZ25hbHNbaV0oKCkgPT4gbmV3SXRlbXNbaV0pO1xuXHRcdFx0ZWxzZSBpZiAoaSA+PSBpdGVtcy5sZW5ndGgpIG1hcHBlZFtpXSA9IGNyZWF0ZVJvb3QobWFwcGVyKTtcblx0XHRcdGZvciAoOyBpIDwgaXRlbXMubGVuZ3RoOyBpKyspIGRpc3Bvc2Vyc1tpXSgpO1xuXHRcdFx0bGVuID0gc2lnbmFscy5sZW5ndGggPSBkaXNwb3NlcnMubGVuZ3RoID0gbmV3TGVuO1xuXHRcdFx0aXRlbXMgPSBuZXdJdGVtcy5zbGljZSgwKTtcblx0XHRcdHJldHVybiBtYXBwZWQgPSBtYXBwZWQuc2xpY2UoMCwgbGVuKTtcblx0XHR9KTtcblx0XHRmdW5jdGlvbiBtYXBwZXIoZGlzcG9zZXIpIHtcblx0XHRcdGRpc3Bvc2Vyc1tpXSA9IGRpc3Bvc2VyO1xuXHRcdFx0Y29uc3QgW3MsIHNldF0gPSBjcmVhdGVTaWduYWwobmV3SXRlbXNbaV0pO1xuXHRcdFx0c2lnbmFsc1tpXSA9IHNldDtcblx0XHRcdHJldHVybiBtYXBGbihzLCBpKTtcblx0XHR9XG5cdH07XG59XG5mdW5jdGlvbiBjcmVhdGVDb21wb25lbnQoQ29tcCwgcHJvcHMpIHtcblx0cmV0dXJuIHVudHJhY2soKCkgPT4gQ29tcChwcm9wcyB8fCB7fSkpO1xufVxuZnVuY3Rpb24gdHJ1ZUZuKCkge1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbmNvbnN0IHByb3BUcmFwcyA9IHtcblx0Z2V0KF8sIHByb3BlcnR5LCByZWNlaXZlcikge1xuXHRcdGlmIChwcm9wZXJ0eSA9PT0gJFBST1hZKSByZXR1cm4gcmVjZWl2ZXI7XG5cdFx0cmV0dXJuIF8uZ2V0KHByb3BlcnR5KTtcblx0fSxcblx0aGFzKF8sIHByb3BlcnR5KSB7XG5cdFx0aWYgKHByb3BlcnR5ID09PSAkUFJPWFkpIHJldHVybiB0cnVlO1xuXHRcdHJldHVybiBfLmhhcyhwcm9wZXJ0eSk7XG5cdH0sXG5cdHNldDogdHJ1ZUZuLFxuXHRkZWxldGVQcm9wZXJ0eTogdHJ1ZUZuLFxuXHRnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoXywgcHJvcGVydHkpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0Y29uZmlndXJhYmxlOiB0cnVlLFxuXHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdGdldCgpIHtcblx0XHRcdFx0cmV0dXJuIF8uZ2V0KHByb3BlcnR5KTtcblx0XHRcdH0sXG5cdFx0XHRzZXQ6IHRydWVGbixcblx0XHRcdGRlbGV0ZVByb3BlcnR5OiB0cnVlRm5cblx0XHR9O1xuXHR9LFxuXHRvd25LZXlzKF8pIHtcblx0XHRyZXR1cm4gXy5rZXlzKCk7XG5cdH1cbn07XG5mdW5jdGlvbiByZXNvbHZlU291cmNlKHMpIHtcblx0cmV0dXJuICEocyA9IHR5cGVvZiBzID09PSBcImZ1bmN0aW9uXCIgPyBzKCkgOiBzKSA/IHt9IDogcztcbn1cbmZ1bmN0aW9uIHJlc29sdmVTb3VyY2VzKCkge1xuXHRmb3IgKGxldCBpID0gMCwgbGVuZ3RoID0gdGhpcy5sZW5ndGg7IGkgPCBsZW5ndGg7ICsraSkge1xuXHRcdGNvbnN0IHYgPSB0aGlzW2ldKCk7XG5cdFx0aWYgKHYgIT09IHZvaWQgMCkgcmV0dXJuIHY7XG5cdH1cbn1cbmZ1bmN0aW9uIG1lcmdlUHJvcHMoLi4uc291cmNlcykge1xuXHRsZXQgcHJveHkgPSBmYWxzZTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBzb3VyY2VzLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3QgcyA9IHNvdXJjZXNbaV07XG5cdFx0cHJveHkgPSBwcm94eSB8fCAhIXMgJiYgJFBST1hZIGluIHM7XG5cdFx0c291cmNlc1tpXSA9IHR5cGVvZiBzID09PSBcImZ1bmN0aW9uXCIgPyAocHJveHkgPSB0cnVlLCBjcmVhdGVNZW1vKHMpKSA6IHM7XG5cdH1cblx0aWYgKFNVUFBPUlRTX1BST1hZICYmIHByb3h5KSByZXR1cm4gbmV3IFByb3h5KHtcblx0XHRnZXQocHJvcGVydHkpIHtcblx0XHRcdGZvciAobGV0IGkgPSBzb3VyY2VzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRcdGNvbnN0IHYgPSByZXNvbHZlU291cmNlKHNvdXJjZXNbaV0pW3Byb3BlcnR5XTtcblx0XHRcdFx0aWYgKHYgIT09IHZvaWQgMCkgcmV0dXJuIHY7XG5cdFx0XHR9XG5cdFx0fSxcblx0XHRoYXMocHJvcGVydHkpIHtcblx0XHRcdGZvciAobGV0IGkgPSBzb3VyY2VzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBpZiAocHJvcGVydHkgaW4gcmVzb2x2ZVNvdXJjZShzb3VyY2VzW2ldKSkgcmV0dXJuIHRydWU7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fSxcblx0XHRrZXlzKCkge1xuXHRcdFx0Y29uc3Qga2V5cyA9IFtdO1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBzb3VyY2VzLmxlbmd0aDsgaSsrKSBrZXlzLnB1c2goLi4uT2JqZWN0LmtleXMocmVzb2x2ZVNvdXJjZShzb3VyY2VzW2ldKSkpO1xuXHRcdFx0cmV0dXJuIFsuLi5uZXcgU2V0KGtleXMpXTtcblx0XHR9XG5cdH0sIHByb3BUcmFwcyk7XG5cdGNvbnN0IHNvdXJjZXNNYXAgPSB7fTtcblx0Y29uc3QgZGVmaW5lZCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cdGZvciAobGV0IGkgPSBzb3VyY2VzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0Y29uc3Qgc291cmNlID0gc291cmNlc1tpXTtcblx0XHRpZiAoIXNvdXJjZSkgY29udGludWU7XG5cdFx0Y29uc3Qgc291cmNlS2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHNvdXJjZSk7XG5cdFx0Zm9yIChsZXQgaSA9IHNvdXJjZUtleXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcblx0XHRcdGNvbnN0IGtleSA9IHNvdXJjZUtleXNbaV07XG5cdFx0XHRpZiAoa2V5ID09PSBcIl9fcHJvdG9fX1wiIHx8IGtleSA9PT0gXCJjb25zdHJ1Y3RvclwiKSBjb250aW51ZTtcblx0XHRcdGNvbnN0IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHNvdXJjZSwga2V5KTtcblx0XHRcdGlmICghZGVmaW5lZFtrZXldKSBkZWZpbmVkW2tleV0gPSBkZXNjLmdldCA/IHtcblx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdFx0Y29uZmlndXJhYmxlOiB0cnVlLFxuXHRcdFx0XHRnZXQ6IHJlc29sdmVTb3VyY2VzLmJpbmQoc291cmNlc01hcFtrZXldID0gW2Rlc2MuZ2V0LmJpbmQoc291cmNlKV0pXG5cdFx0XHR9IDogZGVzYy52YWx1ZSAhPT0gdm9pZCAwID8gZGVzYyA6IHZvaWQgMDtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRjb25zdCBzb3VyY2VzID0gc291cmNlc01hcFtrZXldO1xuXHRcdFx0XHRpZiAoc291cmNlcykge1xuXHRcdFx0XHRcdGlmIChkZXNjLmdldCkgc291cmNlcy5wdXNoKGRlc2MuZ2V0LmJpbmQoc291cmNlKSk7XG5cdFx0XHRcdFx0ZWxzZSBpZiAoZGVzYy52YWx1ZSAhPT0gdm9pZCAwKSBzb3VyY2VzLnB1c2goKCkgPT4gZGVzYy52YWx1ZSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH1cblx0Y29uc3QgdGFyZ2V0ID0ge307XG5cdGNvbnN0IGRlZmluZWRLZXlzID0gT2JqZWN0LmtleXMoZGVmaW5lZCk7XG5cdGZvciAobGV0IGkgPSBkZWZpbmVkS2V5cy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdGNvbnN0IGtleSA9IGRlZmluZWRLZXlzW2ldLCBkZXNjID0gZGVmaW5lZFtrZXldO1xuXHRcdGlmIChkZXNjICYmIGRlc2MuZ2V0KSBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIGRlc2MpO1xuXHRcdGVsc2UgdGFyZ2V0W2tleV0gPSBkZXNjID8gZGVzYy52YWx1ZSA6IHZvaWQgMDtcblx0fVxuXHRyZXR1cm4gdGFyZ2V0O1xufVxuZnVuY3Rpb24gc3BsaXRQcm9wcyhwcm9wcywgLi4ua2V5cykge1xuXHRjb25zdCBsZW4gPSBrZXlzLmxlbmd0aDtcblx0aWYgKFNVUFBPUlRTX1BST1hZICYmICRQUk9YWSBpbiBwcm9wcykge1xuXHRcdGNvbnN0IGJsb2NrZWQgPSBsZW4gPiAxID8ga2V5cy5mbGF0KCkgOiBrZXlzWzBdO1xuXHRcdGNvbnN0IGNsYWltZWQgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdGNvbnN0IHJlcyA9IGtleXMubWFwKChrKSA9PiB7XG5cdFx0XHRjb25zdCBvd25lZCA9IGsuZmlsdGVyKChwcm9wZXJ0eSkgPT4gIWNsYWltZWQuaGFzKHByb3BlcnR5KSAmJiAoY2xhaW1lZC5hZGQocHJvcGVydHkpLCB0cnVlKSk7XG5cdFx0XHRyZXR1cm4gbmV3IFByb3h5KHtcblx0XHRcdFx0Z2V0KHByb3BlcnR5KSB7XG5cdFx0XHRcdFx0cmV0dXJuIG93bmVkLmluY2x1ZGVzKHByb3BlcnR5KSA/IHByb3BzW3Byb3BlcnR5XSA6IHZvaWQgMDtcblx0XHRcdFx0fSxcblx0XHRcdFx0aGFzKHByb3BlcnR5KSB7XG5cdFx0XHRcdFx0cmV0dXJuIG93bmVkLmluY2x1ZGVzKHByb3BlcnR5KSAmJiBwcm9wZXJ0eSBpbiBwcm9wcztcblx0XHRcdFx0fSxcblx0XHRcdFx0a2V5cygpIHtcblx0XHRcdFx0XHRyZXR1cm4gb3duZWQuZmlsdGVyKChwcm9wZXJ0eSkgPT4gcHJvcGVydHkgaW4gcHJvcHMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9LCBwcm9wVHJhcHMpO1xuXHRcdH0pO1xuXHRcdHJlcy5wdXNoKG5ldyBQcm94eSh7XG5cdFx0XHRnZXQocHJvcGVydHkpIHtcblx0XHRcdFx0cmV0dXJuIGJsb2NrZWQuaW5jbHVkZXMocHJvcGVydHkpID8gdm9pZCAwIDogcHJvcHNbcHJvcGVydHldO1xuXHRcdFx0fSxcblx0XHRcdGhhcyhwcm9wZXJ0eSkge1xuXHRcdFx0XHRyZXR1cm4gYmxvY2tlZC5pbmNsdWRlcyhwcm9wZXJ0eSkgPyBmYWxzZSA6IHByb3BlcnR5IGluIHByb3BzO1xuXHRcdFx0fSxcblx0XHRcdGtleXMoKSB7XG5cdFx0XHRcdHJldHVybiBPYmplY3Qua2V5cyhwcm9wcykuZmlsdGVyKChrKSA9PiAhYmxvY2tlZC5pbmNsdWRlcyhrKSk7XG5cdFx0XHR9XG5cdFx0fSwgcHJvcFRyYXBzKSk7XG5cdFx0cmV0dXJuIHJlcztcblx0fVxuXHRjb25zdCBvYmplY3RzID0gW107XG5cdGZvciAobGV0IGkgPSAwOyBpIDw9IGxlbjsgaSsrKSBvYmplY3RzW2ldID0ge307XG5cdGZvciAoY29uc3QgcHJvcE5hbWUgb2YgT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMocHJvcHMpKSB7XG5cdFx0bGV0IGtleUluZGV4ID0gbGVuO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7IGkrKykgaWYgKGtleXNbaV0uaW5jbHVkZXMocHJvcE5hbWUpKSB7XG5cdFx0XHRrZXlJbmRleCA9IGk7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cdFx0Y29uc3QgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IocHJvcHMsIHByb3BOYW1lKTtcblx0XHQhZGVzYy5nZXQgJiYgIWRlc2Muc2V0ICYmIGRlc2MuZW51bWVyYWJsZSAmJiBkZXNjLndyaXRhYmxlICYmIGRlc2MuY29uZmlndXJhYmxlID8gb2JqZWN0c1trZXlJbmRleF1bcHJvcE5hbWVdID0gZGVzYy52YWx1ZSA6IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmplY3RzW2tleUluZGV4XSwgcHJvcE5hbWUsIGRlc2MpO1xuXHR9XG5cdHJldHVybiBvYmplY3RzO1xufVxuZnVuY3Rpb24gbGF6eShmbikge1xuXHRsZXQgY29tcDtcblx0bGV0IHA7XG5cdGNvbnN0IGxvYWQgPSAoKSA9PiB7XG5cdFx0aWYgKCFwKSB7XG5cdFx0XHRjb25zdCBjdXIgPSBwID0gZm4oKTtcblx0XHRcdGN1ci50aGVuKChtb2QpID0+IHtcblx0XHRcdFx0Y29tcCA9ICgpID0+IG1vZC5kZWZhdWx0O1xuXHRcdFx0fSwgKCkgPT4ge1xuXHRcdFx0XHRpZiAocCA9PT0gY3VyKSBwID0gdm9pZCAwO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdHJldHVybiBwO1xuXHR9O1xuXHRjb25zdCB3cmFwID0gKHByb3BzKSA9PiB7XG5cdFx0Y29uc3QgY3R4ID0gc2hhcmVkQ29uZmlnLmNvbnRleHQ7XG5cdFx0aWYgKGN0eCkge1xuXHRcdFx0Y29uc3QgW3MsIHNldF0gPSBjcmVhdGVTaWduYWwoKTtcblx0XHRcdHNoYXJlZENvbmZpZy5jb3VudCB8fCAoc2hhcmVkQ29uZmlnLmNvdW50ID0gMCk7XG5cdFx0XHRzaGFyZWRDb25maWcuY291bnQrKztcblx0XHRcdGxvYWQoKS50aGVuKChtb2QpID0+IHtcblx0XHRcdFx0IXNoYXJlZENvbmZpZy5kb25lICYmIHNldEh5ZHJhdGVDb250ZXh0KGN0eCk7XG5cdFx0XHRcdHNoYXJlZENvbmZpZy5jb3VudC0tO1xuXHRcdFx0XHRzZXQoKCkgPT4gbW9kLmRlZmF1bHQpO1xuXHRcdFx0XHRzZXRIeWRyYXRlQ29udGV4dCgpO1xuXHRcdFx0fSwgKGVycikgPT4ge1xuXHRcdFx0XHQhc2hhcmVkQ29uZmlnLmRvbmUgJiYgc2V0SHlkcmF0ZUNvbnRleHQoY3R4KTtcblx0XHRcdFx0c2hhcmVkQ29uZmlnLmNvdW50LS07XG5cdFx0XHRcdHNldCgoKSA9PiAoKSA9PiB7XG5cdFx0XHRcdFx0dGhyb3cgZXJyO1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0c2V0SHlkcmF0ZUNvbnRleHQoKTtcblx0XHRcdH0pO1xuXHRcdFx0Y29tcCA9IHM7XG5cdFx0fSBlbHNlIGlmICghY29tcCkge1xuXHRcdFx0Y29uc3QgW3NdID0gY3JlYXRlUmVzb3VyY2UoKCkgPT4gbG9hZCgpLnRoZW4oKG1vZCkgPT4gbW9kLmRlZmF1bHQpKTtcblx0XHRcdGNvbXAgPSBzO1xuXHRcdFx0b25DbGVhbnVwKCgpID0+IHtcblx0XHRcdFx0aWYgKGNvbXAgPT09IHMpIGNvbXAgPSB2b2lkIDA7XG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0bGV0IENvbXA7XG5cdFx0cmV0dXJuIGNyZWF0ZU1lbW8oKCkgPT4gKENvbXAgPSBjb21wPy4oKSkgPyB1bnRyYWNrKCgpID0+IHtcblx0XHRcdGlmICghY3R4IHx8IHNoYXJlZENvbmZpZy5kb25lKSByZXR1cm4gQ29tcChwcm9wcyk7XG5cdFx0XHRjb25zdCBjID0gc2hhcmVkQ29uZmlnLmNvbnRleHQ7XG5cdFx0XHRzZXRIeWRyYXRlQ29udGV4dChjdHgpO1xuXHRcdFx0Y29uc3QgciA9IENvbXAocHJvcHMpO1xuXHRcdFx0c2V0SHlkcmF0ZUNvbnRleHQoYyk7XG5cdFx0XHRyZXR1cm4gcjtcblx0XHR9KSA6IFwiXCIpO1xuXHR9O1xuXHR3cmFwLnByZWxvYWQgPSAoKSA9PiBsb2FkKCk7XG5cdHJldHVybiB3cmFwO1xufVxubGV0IGNvdW50ZXIgPSAwO1xuZnVuY3Rpb24gY3JlYXRlVW5pcXVlSWQoKSB7XG5cdHJldHVybiBzaGFyZWRDb25maWcuY29udGV4dCA/IHNoYXJlZENvbmZpZy5nZXROZXh0Q29udGV4dElkKCkgOiBgY2wtJHtjb3VudGVyKyt9YDtcbn1cbmNvbnN0IG5hcnJvd2VkRXJyb3IgPSAobmFtZSkgPT4gYFN0YWxlIHJlYWQgZnJvbSA8JHtuYW1lfT4uYDtcbmZ1bmN0aW9uIEZvcihwcm9wcykge1xuXHRjb25zdCBmYWxsYmFjayA9IFwiZmFsbGJhY2tcIiBpbiBwcm9wcyAmJiB7IGZhbGxiYWNrOiAoKSA9PiBwcm9wcy5mYWxsYmFjayB9O1xuXHRyZXR1cm4gY3JlYXRlTWVtbyhtYXBBcnJheSgoKSA9PiBwcm9wcy5lYWNoLCBwcm9wcy5jaGlsZHJlbiwgZmFsbGJhY2sgfHwgdm9pZCAwKSk7XG59XG5mdW5jdGlvbiBJbmRleChwcm9wcykge1xuXHRjb25zdCBmYWxsYmFjayA9IFwiZmFsbGJhY2tcIiBpbiBwcm9wcyAmJiB7IGZhbGxiYWNrOiAoKSA9PiBwcm9wcy5mYWxsYmFjayB9O1xuXHRyZXR1cm4gY3JlYXRlTWVtbyhpbmRleEFycmF5KCgpID0+IHByb3BzLmVhY2gsIHByb3BzLmNoaWxkcmVuLCBmYWxsYmFjayB8fCB2b2lkIDApKTtcbn1cbmZ1bmN0aW9uIFNob3cocHJvcHMpIHtcblx0Y29uc3Qga2V5ZWQgPSBwcm9wcy5rZXllZDtcblx0Y29uc3QgY29uZGl0aW9uVmFsdWUgPSBjcmVhdGVNZW1vKCgpID0+IHByb3BzLndoZW4sIHZvaWQgMCwgdm9pZCAwKTtcblx0Y29uc3QgY29uZGl0aW9uID0ga2V5ZWQgPyBjb25kaXRpb25WYWx1ZSA6IGNyZWF0ZU1lbW8oY29uZGl0aW9uVmFsdWUsIHZvaWQgMCwgeyBlcXVhbHM6IChhLCBiKSA9PiAhYSA9PT0gIWIgfSk7XG5cdHJldHVybiBjcmVhdGVNZW1vKCgpID0+IHtcblx0XHRjb25zdCBjID0gY29uZGl0aW9uKCk7XG5cdFx0aWYgKGMpIHtcblx0XHRcdGNvbnN0IGNoaWxkID0gcHJvcHMuY2hpbGRyZW47XG5cdFx0XHRyZXR1cm4gdHlwZW9mIGNoaWxkID09PSBcImZ1bmN0aW9uXCIgJiYgY2hpbGQubGVuZ3RoID4gMCA/IHVudHJhY2soKCkgPT4gY2hpbGQoa2V5ZWQgPyBjIDogKCkgPT4ge1xuXHRcdFx0XHRpZiAoIXVudHJhY2soY29uZGl0aW9uKSkgdGhyb3cgbmFycm93ZWRFcnJvcihcIlNob3dcIik7XG5cdFx0XHRcdHJldHVybiBjb25kaXRpb25WYWx1ZSgpO1xuXHRcdFx0fSkpIDogY2hpbGQ7XG5cdFx0fVxuXHRcdHJldHVybiBwcm9wcy5mYWxsYmFjaztcblx0fSwgdm9pZCAwLCB2b2lkIDApO1xufVxuZnVuY3Rpb24gU3dpdGNoKHByb3BzKSB7XG5cdGNvbnN0IGNocyA9IGNoaWxkcmVuKCgpID0+IHByb3BzLmNoaWxkcmVuKTtcblx0Y29uc3Qgc3dpdGNoRnVuYyA9IGNyZWF0ZU1lbW8oKCkgPT4ge1xuXHRcdGNvbnN0IGNoID0gY2hzKCk7XG5cdFx0Y29uc3QgbXBzID0gQXJyYXkuaXNBcnJheShjaCkgPyBjaCA6IFtjaF07XG5cdFx0bGV0IGZ1bmMgPSAoKSA9PiB2b2lkIDA7XG5cdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBtcHMubGVuZ3RoOyBpKyspIHtcblx0XHRcdGNvbnN0IGluZGV4ID0gaTtcblx0XHRcdGNvbnN0IG1wID0gbXBzW2ldO1xuXHRcdFx0Y29uc3QgcHJldkZ1bmMgPSBmdW5jO1xuXHRcdFx0Y29uc3QgY29uZGl0aW9uVmFsdWUgPSBjcmVhdGVNZW1vKCgpID0+IHByZXZGdW5jKCkgPyB2b2lkIDAgOiBtcC53aGVuLCB2b2lkIDAsIHZvaWQgMCk7XG5cdFx0XHRjb25zdCBjb25kaXRpb24gPSBtcC5rZXllZCA/IGNvbmRpdGlvblZhbHVlIDogY3JlYXRlTWVtbyhjb25kaXRpb25WYWx1ZSwgdm9pZCAwLCB7IGVxdWFsczogKGEsIGIpID0+ICFhID09PSAhYiB9KTtcblx0XHRcdGZ1bmMgPSAoKSA9PiBwcmV2RnVuYygpIHx8IChjb25kaXRpb24oKSA/IFtcblx0XHRcdFx0aW5kZXgsXG5cdFx0XHRcdGNvbmRpdGlvblZhbHVlLFxuXHRcdFx0XHRtcFxuXHRcdFx0XSA6IHZvaWQgMCk7XG5cdFx0fVxuXHRcdHJldHVybiBmdW5jO1xuXHR9KTtcblx0cmV0dXJuIGNyZWF0ZU1lbW8oKCkgPT4ge1xuXHRcdGNvbnN0IHNlbCA9IHN3aXRjaEZ1bmMoKSgpO1xuXHRcdGlmICghc2VsKSByZXR1cm4gcHJvcHMuZmFsbGJhY2s7XG5cdFx0Y29uc3QgW2luZGV4LCBjb25kaXRpb25WYWx1ZSwgbXBdID0gc2VsO1xuXHRcdGNvbnN0IGNoaWxkID0gbXAuY2hpbGRyZW47XG5cdFx0cmV0dXJuIHR5cGVvZiBjaGlsZCA9PT0gXCJmdW5jdGlvblwiICYmIGNoaWxkLmxlbmd0aCA+IDAgPyB1bnRyYWNrKCgpID0+IGNoaWxkKG1wLmtleWVkID8gY29uZGl0aW9uVmFsdWUoKSA6ICgpID0+IHtcblx0XHRcdGlmICh1bnRyYWNrKHN3aXRjaEZ1bmMpKCk/LlswXSAhPT0gaW5kZXgpIHRocm93IG5hcnJvd2VkRXJyb3IoXCJNYXRjaFwiKTtcblx0XHRcdHJldHVybiBjb25kaXRpb25WYWx1ZSgpO1xuXHRcdH0pKSA6IGNoaWxkO1xuXHR9LCB2b2lkIDAsIHZvaWQgMCk7XG59XG5mdW5jdGlvbiBNYXRjaChwcm9wcykge1xuXHRyZXR1cm4gcHJvcHM7XG59XG4vLyAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc29saWQtanNAMS45LjIwL25vZGVfbW9kdWxlcy9zb2xpZC1qcy93ZWIvZGlzdC93ZWIuanNcbmNvbnN0IFByb3BlcnRpZXMgPSAvKiNfX1BVUkVfXyovIG5ldyBTZXQoW1xuXHRcImNsYXNzTmFtZVwiLFxuXHRcInZhbHVlXCIsXG5cdFwicmVhZE9ubHlcIixcblx0XCJub1ZhbGlkYXRlXCIsXG5cdFwiZm9ybU5vVmFsaWRhdGVcIixcblx0XCJpc01hcFwiLFxuXHRcIm5vTW9kdWxlXCIsXG5cdFwicGxheXNJbmxpbmVcIixcblx0XCJhZEF1Y3Rpb25IZWFkZXJzXCIsXG5cdFwiYWxsb3dGdWxsc2NyZWVuXCIsXG5cdFwiYnJvd3NpbmdUb3BpY3NcIixcblx0XCJkZWZhdWx0Q2hlY2tlZFwiLFxuXHRcImRlZmF1bHRNdXRlZFwiLFxuXHRcImRlZmF1bHRTZWxlY3RlZFwiLFxuXHRcImRpc2FibGVQaWN0dXJlSW5QaWN0dXJlXCIsXG5cdFwiZGlzYWJsZVJlbW90ZVBsYXliYWNrXCIsXG5cdFwicHJlc2VydmVzUGl0Y2hcIixcblx0XCJzaGFkb3dSb290Q2xvbmFibGVcIixcblx0XCJzaGFkb3dSb290Q3VzdG9tRWxlbWVudFJlZ2lzdHJ5XCIsXG5cdFwic2hhZG93Um9vdERlbGVnYXRlc0ZvY3VzXCIsXG5cdFwic2hhZG93Um9vdFNlcmlhbGl6YWJsZVwiLFxuXHRcInNoYXJlZFN0b3JhZ2VXcml0YWJsZVwiLFxuXHQuLi5bXG5cdFx0XCJhbGxvd2Z1bGxzY3JlZW5cIixcblx0XHRcImFzeW5jXCIsXG5cdFx0XCJhbHBoYVwiLFxuXHRcdFwiYXV0b2ZvY3VzXCIsXG5cdFx0XCJhdXRvcGxheVwiLFxuXHRcdFwiY2hlY2tlZFwiLFxuXHRcdFwiY29udHJvbHNcIixcblx0XHRcImRlZmF1bHRcIixcblx0XHRcImRpc2FibGVkXCIsXG5cdFx0XCJmb3Jtbm92YWxpZGF0ZVwiLFxuXHRcdFwiaGlkZGVuXCIsXG5cdFx0XCJpbmRldGVybWluYXRlXCIsXG5cdFx0XCJpbmVydFwiLFxuXHRcdFwiaXNtYXBcIixcblx0XHRcImxvb3BcIixcblx0XHRcIm11bHRpcGxlXCIsXG5cdFx0XCJtdXRlZFwiLFxuXHRcdFwibm9tb2R1bGVcIixcblx0XHRcIm5vdmFsaWRhdGVcIixcblx0XHRcIm9wZW5cIixcblx0XHRcInBsYXlzaW5saW5lXCIsXG5cdFx0XCJyZWFkb25seVwiLFxuXHRcdFwicmVxdWlyZWRcIixcblx0XHRcInJldmVyc2VkXCIsXG5cdFx0XCJzZWFtbGVzc1wiLFxuXHRcdFwic2VsZWN0ZWRcIixcblx0XHRcImFkYXVjdGlvbmhlYWRlcnNcIixcblx0XHRcImJyb3dzaW5ndG9waWNzXCIsXG5cdFx0XCJjcmVkZW50aWFsbGVzc1wiLFxuXHRcdFwiZGVmYXVsdGNoZWNrZWRcIixcblx0XHRcImRlZmF1bHRtdXRlZFwiLFxuXHRcdFwiZGVmYXVsdHNlbGVjdGVkXCIsXG5cdFx0XCJkZWZlclwiLFxuXHRcdFwiZGlzYWJsZXBpY3R1cmVpbnBpY3R1cmVcIixcblx0XHRcImRpc2FibGVyZW1vdGVwbGF5YmFja1wiLFxuXHRcdFwicHJlc2VydmVzcGl0Y2hcIixcblx0XHRcInNoYWRvd3Jvb3RjbG9uYWJsZVwiLFxuXHRcdFwic2hhZG93cm9vdGN1c3RvbWVsZW1lbnRyZWdpc3RyeVwiLFxuXHRcdFwic2hhZG93cm9vdGRlbGVnYXRlc2ZvY3VzXCIsXG5cdFx0XCJzaGFkb3dyb290c2VyaWFsaXphYmxlXCIsXG5cdFx0XCJzaGFyZWRzdG9yYWdld3JpdGFibGVcIlxuXHRdXG5dKTtcbmNvbnN0IENoaWxkUHJvcGVydGllcyA9IC8qI19fUFVSRV9fKi8gbmV3IFNldChbXG5cdFwiaW5uZXJIVE1MXCIsXG5cdFwidGV4dENvbnRlbnRcIixcblx0XCJpbm5lclRleHRcIixcblx0XCJjaGlsZHJlblwiXG5dKTtcbmNvbnN0IEFsaWFzZXMgPSAvKiNfX1BVUkVfXyovIE9iamVjdC5hc3NpZ24oT2JqZWN0LmNyZWF0ZShudWxsKSwge1xuXHRjbGFzc05hbWU6IFwiY2xhc3NcIixcblx0aHRtbEZvcjogXCJmb3JcIlxufSk7XG5jb25zdCBQcm9wQWxpYXNlcyA9IC8qI19fUFVSRV9fKi8gT2JqZWN0LmFzc2lnbihPYmplY3QuY3JlYXRlKG51bGwpLCB7XG5cdGNsYXNzOiBcImNsYXNzTmFtZVwiLFxuXHRub3ZhbGlkYXRlOiB7XG5cdFx0JDogXCJub1ZhbGlkYXRlXCIsXG5cdFx0Rk9STTogMVxuXHR9LFxuXHRmb3Jtbm92YWxpZGF0ZToge1xuXHRcdCQ6IFwiZm9ybU5vVmFsaWRhdGVcIixcblx0XHRCVVRUT046IDEsXG5cdFx0SU5QVVQ6IDFcblx0fSxcblx0aXNtYXA6IHtcblx0XHQkOiBcImlzTWFwXCIsXG5cdFx0SU1HOiAxXG5cdH0sXG5cdG5vbW9kdWxlOiB7XG5cdFx0JDogXCJub01vZHVsZVwiLFxuXHRcdFNDUklQVDogMVxuXHR9LFxuXHRwbGF5c2lubGluZToge1xuXHRcdCQ6IFwicGxheXNJbmxpbmVcIixcblx0XHRWSURFTzogMVxuXHR9LFxuXHRyZWFkb25seToge1xuXHRcdCQ6IFwicmVhZE9ubHlcIixcblx0XHRJTlBVVDogMSxcblx0XHRURVhUQVJFQTogMVxuXHR9LFxuXHRhZGF1Y3Rpb25oZWFkZXJzOiB7XG5cdFx0JDogXCJhZEF1Y3Rpb25IZWFkZXJzXCIsXG5cdFx0SUZSQU1FOiAxXG5cdH0sXG5cdGFsbG93ZnVsbHNjcmVlbjoge1xuXHRcdCQ6IFwiYWxsb3dGdWxsc2NyZWVuXCIsXG5cdFx0SUZSQU1FOiAxXG5cdH0sXG5cdGJyb3dzaW5ndG9waWNzOiB7XG5cdFx0JDogXCJicm93c2luZ1RvcGljc1wiLFxuXHRcdElNRzogMVxuXHR9LFxuXHRkZWZhdWx0Y2hlY2tlZDoge1xuXHRcdCQ6IFwiZGVmYXVsdENoZWNrZWRcIixcblx0XHRJTlBVVDogMVxuXHR9LFxuXHRkZWZhdWx0bXV0ZWQ6IHtcblx0XHQkOiBcImRlZmF1bHRNdXRlZFwiLFxuXHRcdEFVRElPOiAxLFxuXHRcdFZJREVPOiAxXG5cdH0sXG5cdGRlZmF1bHRzZWxlY3RlZDoge1xuXHRcdCQ6IFwiZGVmYXVsdFNlbGVjdGVkXCIsXG5cdFx0T1BUSU9OOiAxXG5cdH0sXG5cdGRpc2FibGVwaWN0dXJlaW5waWN0dXJlOiB7XG5cdFx0JDogXCJkaXNhYmxlUGljdHVyZUluUGljdHVyZVwiLFxuXHRcdFZJREVPOiAxXG5cdH0sXG5cdGRpc2FibGVyZW1vdGVwbGF5YmFjazoge1xuXHRcdCQ6IFwiZGlzYWJsZVJlbW90ZVBsYXliYWNrXCIsXG5cdFx0QVVESU86IDEsXG5cdFx0VklERU86IDFcblx0fSxcblx0cHJlc2VydmVzcGl0Y2g6IHtcblx0XHQkOiBcInByZXNlcnZlc1BpdGNoXCIsXG5cdFx0QVVESU86IDEsXG5cdFx0VklERU86IDFcblx0fSxcblx0c2hhZG93cm9vdGNsb25hYmxlOiB7XG5cdFx0JDogXCJzaGFkb3dSb290Q2xvbmFibGVcIixcblx0XHRURU1QTEFURTogMVxuXHR9LFxuXHRzaGFkb3dyb290ZGVsZWdhdGVzZm9jdXM6IHtcblx0XHQkOiBcInNoYWRvd1Jvb3REZWxlZ2F0ZXNGb2N1c1wiLFxuXHRcdFRFTVBMQVRFOiAxXG5cdH0sXG5cdHNoYWRvd3Jvb3RzZXJpYWxpemFibGU6IHtcblx0XHQkOiBcInNoYWRvd1Jvb3RTZXJpYWxpemFibGVcIixcblx0XHRURU1QTEFURTogMVxuXHR9LFxuXHRzaGFyZWRzdG9yYWdld3JpdGFibGU6IHtcblx0XHQkOiBcInNoYXJlZFN0b3JhZ2VXcml0YWJsZVwiLFxuXHRcdElGUkFNRTogMSxcblx0XHRJTUc6IDFcblx0fVxufSk7XG5mdW5jdGlvbiBnZXRQcm9wQWxpYXMocHJvcCwgdGFnTmFtZSkge1xuXHRjb25zdCBhID0gUHJvcEFsaWFzZXNbcHJvcF07XG5cdHJldHVybiB0eXBlb2YgYSA9PT0gXCJvYmplY3RcIiA/IGFbdGFnTmFtZV0gPyBhW1wiJFwiXSA6IHZvaWQgMCA6IGE7XG59XG5jb25zdCBEZWxlZ2F0ZWRFdmVudHMgPSAvKiNfX1BVUkVfXyovIG5ldyBTZXQoW1xuXHRcImJlZm9yZWlucHV0XCIsXG5cdFwiY2xpY2tcIixcblx0XCJkYmxjbGlja1wiLFxuXHRcImNvbnRleHRtZW51XCIsXG5cdFwiZm9jdXNpblwiLFxuXHRcImZvY3Vzb3V0XCIsXG5cdFwiaW5wdXRcIixcblx0XCJrZXlkb3duXCIsXG5cdFwia2V5dXBcIixcblx0XCJtb3VzZWRvd25cIixcblx0XCJtb3VzZW1vdmVcIixcblx0XCJtb3VzZW91dFwiLFxuXHRcIm1vdXNlb3ZlclwiLFxuXHRcIm1vdXNldXBcIixcblx0XCJwb2ludGVyZG93blwiLFxuXHRcInBvaW50ZXJtb3ZlXCIsXG5cdFwicG9pbnRlcm91dFwiLFxuXHRcInBvaW50ZXJvdmVyXCIsXG5cdFwicG9pbnRlcnVwXCIsXG5cdFwidG91Y2hlbmRcIixcblx0XCJ0b3VjaG1vdmVcIixcblx0XCJ0b3VjaHN0YXJ0XCJcbl0pO1xuY29uc3QgU1ZHRWxlbWVudHMgPSAvKiNfX1BVUkVfXyovIG5ldyBTZXQoW1xuXHRcImFsdEdseXBoXCIsXG5cdFwiYWx0R2x5cGhEZWZcIixcblx0XCJhbHRHbHlwaEl0ZW1cIixcblx0XCJhbmltYXRlXCIsXG5cdFwiYW5pbWF0ZUNvbG9yXCIsXG5cdFwiYW5pbWF0ZU1vdGlvblwiLFxuXHRcImFuaW1hdGVUcmFuc2Zvcm1cIixcblx0XCJjaXJjbGVcIixcblx0XCJjbGlwUGF0aFwiLFxuXHRcImNvbG9yLXByb2ZpbGVcIixcblx0XCJjdXJzb3JcIixcblx0XCJkZWZzXCIsXG5cdFwiZGVzY1wiLFxuXHRcImVsbGlwc2VcIixcblx0XCJmZUJsZW5kXCIsXG5cdFwiZmVDb2xvck1hdHJpeFwiLFxuXHRcImZlQ29tcG9uZW50VHJhbnNmZXJcIixcblx0XCJmZUNvbXBvc2l0ZVwiLFxuXHRcImZlQ29udm9sdmVNYXRyaXhcIixcblx0XCJmZURpZmZ1c2VMaWdodGluZ1wiLFxuXHRcImZlRGlzcGxhY2VtZW50TWFwXCIsXG5cdFwiZmVEaXN0YW50TGlnaHRcIixcblx0XCJmZURyb3BTaGFkb3dcIixcblx0XCJmZUZsb29kXCIsXG5cdFwiZmVGdW5jQVwiLFxuXHRcImZlRnVuY0JcIixcblx0XCJmZUZ1bmNHXCIsXG5cdFwiZmVGdW5jUlwiLFxuXHRcImZlR2F1c3NpYW5CbHVyXCIsXG5cdFwiZmVJbWFnZVwiLFxuXHRcImZlTWVyZ2VcIixcblx0XCJmZU1lcmdlTm9kZVwiLFxuXHRcImZlTW9ycGhvbG9neVwiLFxuXHRcImZlT2Zmc2V0XCIsXG5cdFwiZmVQb2ludExpZ2h0XCIsXG5cdFwiZmVTcGVjdWxhckxpZ2h0aW5nXCIsXG5cdFwiZmVTcG90TGlnaHRcIixcblx0XCJmZVRpbGVcIixcblx0XCJmZVR1cmJ1bGVuY2VcIixcblx0XCJmaWx0ZXJcIixcblx0XCJmb250XCIsXG5cdFwiZm9udC1mYWNlXCIsXG5cdFwiZm9udC1mYWNlLWZvcm1hdFwiLFxuXHRcImZvbnQtZmFjZS1uYW1lXCIsXG5cdFwiZm9udC1mYWNlLXNyY1wiLFxuXHRcImZvbnQtZmFjZS11cmlcIixcblx0XCJmb3JlaWduT2JqZWN0XCIsXG5cdFwiZ1wiLFxuXHRcImdseXBoXCIsXG5cdFwiZ2x5cGhSZWZcIixcblx0XCJoa2VyblwiLFxuXHRcImltYWdlXCIsXG5cdFwibGluZVwiLFxuXHRcImxpbmVhckdyYWRpZW50XCIsXG5cdFwibWFya2VyXCIsXG5cdFwibWFza1wiLFxuXHRcIm1ldGFkYXRhXCIsXG5cdFwibWlzc2luZy1nbHlwaFwiLFxuXHRcIm1wYXRoXCIsXG5cdFwicGF0aFwiLFxuXHRcInBhdHRlcm5cIixcblx0XCJwb2x5Z29uXCIsXG5cdFwicG9seWxpbmVcIixcblx0XCJyYWRpYWxHcmFkaWVudFwiLFxuXHRcInJlY3RcIixcblx0XCJzZXRcIixcblx0XCJzdG9wXCIsXG5cdFwic3ZnXCIsXG5cdFwic3dpdGNoXCIsXG5cdFwic3ltYm9sXCIsXG5cdFwidGV4dFwiLFxuXHRcInRleHRQYXRoXCIsXG5cdFwidHJlZlwiLFxuXHRcInRzcGFuXCIsXG5cdFwidXNlXCIsXG5cdFwidmlld1wiLFxuXHRcInZrZXJuXCJcbl0pO1xuY29uc3QgU1ZHTmFtZXNwYWNlID0ge1xuXHR4bGluazogXCJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rXCIsXG5cdHhtbDogXCJodHRwOi8vd3d3LnczLm9yZy9YTUwvMTk5OC9uYW1lc3BhY2VcIlxufTtcbmNvbnN0IG1lbW8gPSAoZm4pID0+IGNyZWF0ZU1lbW8oKCkgPT4gZm4oKSk7XG5mdW5jdGlvbiByZWNvbmNpbGVBcnJheXMocGFyZW50Tm9kZSwgYSwgYikge1xuXHRsZXQgYkxlbmd0aCA9IGIubGVuZ3RoLCBhRW5kID0gYS5sZW5ndGgsIGJFbmQgPSBiTGVuZ3RoLCBhU3RhcnQgPSAwLCBiU3RhcnQgPSAwLCBhZnRlciA9IGFbYUVuZCAtIDFdLm5leHRTaWJsaW5nLCBtYXAgPSBudWxsO1xuXHR3aGlsZSAoYVN0YXJ0IDwgYUVuZCB8fCBiU3RhcnQgPCBiRW5kKSB7XG5cdFx0aWYgKGFbYVN0YXJ0XSA9PT0gYltiU3RhcnRdKSB7XG5cdFx0XHRhU3RhcnQrKztcblx0XHRcdGJTdGFydCsrO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdHdoaWxlIChhW2FFbmQgLSAxXSA9PT0gYltiRW5kIC0gMV0pIHtcblx0XHRcdGFFbmQtLTtcblx0XHRcdGJFbmQtLTtcblx0XHR9XG5cdFx0aWYgKGFFbmQgPT09IGFTdGFydCkge1xuXHRcdFx0Y29uc3Qgbm9kZSA9IGJFbmQgPCBiTGVuZ3RoID8gYlN0YXJ0ID8gYltiU3RhcnQgLSAxXS5uZXh0U2libGluZyA6IGJbYkVuZCAtIGJTdGFydF0gOiBhZnRlcjtcblx0XHRcdHdoaWxlIChiU3RhcnQgPCBiRW5kKSBwYXJlbnROb2RlLmluc2VydEJlZm9yZShiW2JTdGFydCsrXSwgbm9kZSk7XG5cdFx0fSBlbHNlIGlmIChiRW5kID09PSBiU3RhcnQpIHdoaWxlIChhU3RhcnQgPCBhRW5kKSB7XG5cdFx0XHRpZiAoIW1hcCB8fCAhbWFwLmhhcyhhW2FTdGFydF0pKSBhW2FTdGFydF0ucmVtb3ZlKCk7XG5cdFx0XHRhU3RhcnQrKztcblx0XHR9XG5cdFx0ZWxzZSBpZiAoYVthU3RhcnRdID09PSBiW2JFbmQgLSAxXSAmJiBiW2JTdGFydF0gPT09IGFbYUVuZCAtIDFdKSB7XG5cdFx0XHRjb25zdCBub2RlID0gYVstLWFFbmRdLm5leHRTaWJsaW5nO1xuXHRcdFx0cGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoYltiU3RhcnQrK10sIGFbYVN0YXJ0KytdLm5leHRTaWJsaW5nKTtcblx0XHRcdHBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKGJbLS1iRW5kXSwgbm9kZSk7XG5cdFx0XHRhW2FFbmRdID0gYltiRW5kXTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0aWYgKCFtYXApIHtcblx0XHRcdFx0bWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRcdFx0bGV0IGkgPSBiU3RhcnQ7XG5cdFx0XHRcdHdoaWxlIChpIDwgYkVuZCkgbWFwLnNldChiW2ldLCBpKyspO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgaW5kZXggPSBtYXAuZ2V0KGFbYVN0YXJ0XSk7XG5cdFx0XHRpZiAoaW5kZXggIT0gbnVsbCkge1xuXHRcdFx0XHRpZiAoYlN0YXJ0IDwgaW5kZXggJiYgaW5kZXggPCBiRW5kKSB7XG5cdFx0XHRcdFx0bGV0IGkgPSBhU3RhcnQsIHNlcXVlbmNlID0gMSwgdDtcblx0XHRcdFx0XHR3aGlsZSAoKytpIDwgYUVuZCAmJiBpIDwgYkVuZCkge1xuXHRcdFx0XHRcdFx0aWYgKCh0ID0gbWFwLmdldChhW2ldKSkgPT0gbnVsbCB8fCB0ICE9PSBpbmRleCArIHNlcXVlbmNlKSBicmVhaztcblx0XHRcdFx0XHRcdHNlcXVlbmNlKys7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmIChzZXF1ZW5jZSA+IGluZGV4IC0gYlN0YXJ0KSB7XG5cdFx0XHRcdFx0XHRjb25zdCBub2RlID0gYVthU3RhcnRdO1xuXHRcdFx0XHRcdFx0d2hpbGUgKGJTdGFydCA8IGluZGV4KSBwYXJlbnROb2RlLmluc2VydEJlZm9yZShiW2JTdGFydCsrXSwgbm9kZSk7XG5cdFx0XHRcdFx0fSBlbHNlIHBhcmVudE5vZGUucmVwbGFjZUNoaWxkKGJbYlN0YXJ0KytdLCBhW2FTdGFydCsrXSk7XG5cdFx0XHRcdH0gZWxzZSBhU3RhcnQrKztcblx0XHRcdH0gZWxzZSBhW2FTdGFydCsrXS5yZW1vdmUoKTtcblx0XHR9XG5cdH1cbn1cbmNvbnN0ICQkRVZFTlRTID0gXCJfJERYX0RFTEVHQVRFXCI7XG5mdW5jdGlvbiByZW5kZXIoY29kZSwgZWxlbWVudCwgaW5pdCwgb3B0aW9ucyA9IHt9KSB7XG5cdGxldCBkaXNwb3Nlcjtcblx0Y3JlYXRlUm9vdCgoZGlzcG9zZSkgPT4ge1xuXHRcdGRpc3Bvc2VyID0gZGlzcG9zZTtcblx0XHRlbGVtZW50ID09PSBkb2N1bWVudCA/IGNvZGUoKSA6IGluc2VydChlbGVtZW50LCBjb2RlKCksICFpbml0ICYmIGVsZW1lbnQuZmlyc3RDaGlsZCA/IG51bGwgOiB2b2lkIDAsIGluaXQpO1xuXHR9LCBvcHRpb25zLm93bmVyKTtcblx0cmV0dXJuICgpID0+IHtcblx0XHRkaXNwb3NlcigpO1xuXHRcdGVsZW1lbnQudGV4dENvbnRlbnQgPSBcIlwiO1xuXHR9O1xufVxubGV0IHBvbGljeTtcbmZ1bmN0aW9uIHNldFRydXN0ZWRUeXBlc1BvbGljeSh2YWx1ZSkge1xuXHRwb2xpY3kgPSB2YWx1ZTtcbn1cbmZ1bmN0aW9uIHRlbXBsYXRlKGh0bWwsIGlzSW1wb3J0Tm9kZSwgaXNTVkcsIGlzTWF0aE1MKSB7XG5cdGxldCBub2RlO1xuXHRjb25zdCBjcmVhdGUgPSAoKSA9PiB7XG5cdFx0Y29uc3QgdCA9IGlzTWF0aE1MID8gZG9jdW1lbnQuY3JlYXRlRWxlbWVudE5TKFwiaHR0cDovL3d3dy53My5vcmcvMTk5OC9NYXRoL01hdGhNTFwiLCBcInRlbXBsYXRlXCIpIDogZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInRlbXBsYXRlXCIpO1xuXHRcdHQuaW5uZXJIVE1MID0gcG9saWN5ID8gcG9saWN5LmNyZWF0ZUhUTUwoaHRtbCkgOiBodG1sO1xuXHRcdHJldHVybiBpc1NWRyA/IHQuY29udGVudC5maXJzdENoaWxkLmZpcnN0Q2hpbGQgOiBpc01hdGhNTCA/IHQuZmlyc3RDaGlsZCA6IHQuY29udGVudC5maXJzdENoaWxkO1xuXHR9O1xuXHRjb25zdCBmbiA9IGlzSW1wb3J0Tm9kZSA/ICgpID0+IHVudHJhY2soKCkgPT4gZG9jdW1lbnQuaW1wb3J0Tm9kZShub2RlIHx8IChub2RlID0gY3JlYXRlKCkpLCB0cnVlKSkgOiAoKSA9PiAobm9kZSB8fCAobm9kZSA9IGNyZWF0ZSgpKSkuY2xvbmVOb2RlKHRydWUpO1xuXHRmbi5jbG9uZU5vZGUgPSBmbjtcblx0cmV0dXJuIGZuO1xufVxuZnVuY3Rpb24gZGVsZWdhdGVFdmVudHMoZXZlbnROYW1lcywgZG9jdW1lbnQgPSB3aW5kb3cuZG9jdW1lbnQpIHtcblx0Y29uc3QgZSA9IGRvY3VtZW50WyQkRVZFTlRTXSB8fCAoZG9jdW1lbnRbJCRFVkVOVFNdID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSk7XG5cdGZvciAobGV0IGkgPSAwLCBsID0gZXZlbnROYW1lcy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcblx0XHRjb25zdCBuYW1lID0gZXZlbnROYW1lc1tpXTtcblx0XHRpZiAoIWUuaGFzKG5hbWUpKSB7XG5cdFx0XHRlLmFkZChuYW1lKTtcblx0XHRcdGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIobmFtZSwgZXZlbnRIYW5kbGVyKTtcblx0XHR9XG5cdH1cbn1cbmZ1bmN0aW9uIGNsZWFyRGVsZWdhdGVkRXZlbnRzKGRvY3VtZW50ID0gd2luZG93LmRvY3VtZW50KSB7XG5cdGlmIChkb2N1bWVudFskJEVWRU5UU10pIHtcblx0XHRmb3IgKGxldCBuYW1lIG9mIGRvY3VtZW50WyQkRVZFTlRTXS5rZXlzKCkpIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIobmFtZSwgZXZlbnRIYW5kbGVyKTtcblx0XHRkZWxldGUgZG9jdW1lbnRbJCRFVkVOVFNdO1xuXHR9XG59XG5mdW5jdGlvbiBzZXRBdHRyaWJ1dGUobm9kZSwgbmFtZSwgdmFsdWUpIHtcblx0aWYgKGlzSHlkcmF0aW5nKG5vZGUpKSByZXR1cm47XG5cdGlmICh2YWx1ZSA9PSBudWxsKSBub2RlLnJlbW92ZUF0dHJpYnV0ZShuYW1lKTtcblx0ZWxzZSBub2RlLnNldEF0dHJpYnV0ZShuYW1lLCB2YWx1ZSk7XG59XG5mdW5jdGlvbiBzZXRBdHRyaWJ1dGVOUyhub2RlLCBuYW1lc3BhY2UsIG5hbWUsIHZhbHVlKSB7XG5cdGlmIChpc0h5ZHJhdGluZyhub2RlKSkgcmV0dXJuO1xuXHRpZiAodmFsdWUgPT0gbnVsbCkgbm9kZS5yZW1vdmVBdHRyaWJ1dGVOUyhuYW1lc3BhY2UsIG5hbWUpO1xuXHRlbHNlIG5vZGUuc2V0QXR0cmlidXRlTlMobmFtZXNwYWNlLCBuYW1lLCB2YWx1ZSk7XG59XG5mdW5jdGlvbiBzZXRCb29sQXR0cmlidXRlKG5vZGUsIG5hbWUsIHZhbHVlKSB7XG5cdGlmIChpc0h5ZHJhdGluZyhub2RlKSkgcmV0dXJuO1xuXHR2YWx1ZSA/IG5vZGUuc2V0QXR0cmlidXRlKG5hbWUsIFwiXCIpIDogbm9kZS5yZW1vdmVBdHRyaWJ1dGUobmFtZSk7XG59XG5mdW5jdGlvbiBjbGFzc05hbWUobm9kZSwgdmFsdWUpIHtcblx0aWYgKGlzSHlkcmF0aW5nKG5vZGUpKSByZXR1cm47XG5cdGlmICh2YWx1ZSA9PSBudWxsKSBub2RlLnJlbW92ZUF0dHJpYnV0ZShcImNsYXNzXCIpO1xuXHRlbHNlIG5vZGUuY2xhc3NOYW1lID0gdmFsdWU7XG59XG5mdW5jdGlvbiBhZGRFdmVudExpc3RlbmVyKG5vZGUsIG5hbWUsIGhhbmRsZXIsIGRlbGVnYXRlKSB7XG5cdGlmIChkZWxlZ2F0ZSkge1xuXHRcdGlmIChBcnJheS5pc0FycmF5KGhhbmRsZXIpKSB7XG5cdFx0XHRub2RlW2AkJCR7bmFtZX1gXSA9IGhhbmRsZXJbMF07XG5cdFx0XHRub2RlW2AkJCR7bmFtZX1EYXRhYF0gPSBoYW5kbGVyWzFdO1xuXHRcdH0gZWxzZSBub2RlW2AkJCR7bmFtZX1gXSA9IGhhbmRsZXI7XG5cdH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShoYW5kbGVyKSkge1xuXHRcdGNvbnN0IGhhbmRsZXJGbiA9IGhhbmRsZXJbMF07XG5cdFx0bm9kZS5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGhhbmRsZXJbMF0gPSAoZSkgPT4gaGFuZGxlckZuLmNhbGwobm9kZSwgaGFuZGxlclsxXSwgZSkpO1xuXHR9IGVsc2Ugbm9kZS5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGhhbmRsZXIsIHR5cGVvZiBoYW5kbGVyICE9PSBcImZ1bmN0aW9uXCIgJiYgaGFuZGxlcik7XG59XG5mdW5jdGlvbiBjbGFzc0xpc3Qobm9kZSwgdmFsdWUsIHByZXYgPSB7fSkge1xuXHRjb25zdCBjbGFzc0tleXMgPSBPYmplY3Qua2V5cyh2YWx1ZSB8fCB7fSksIHByZXZLZXlzID0gT2JqZWN0LmtleXMocHJldik7XG5cdGxldCBpLCBsZW47XG5cdGZvciAoaSA9IDAsIGxlbiA9IHByZXZLZXlzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gcHJldktleXNbaV07XG5cdFx0aWYgKCFrZXkgfHwga2V5ID09PSBcInVuZGVmaW5lZFwiIHx8IHZhbHVlW2tleV0pIGNvbnRpbnVlO1xuXHRcdHRvZ2dsZUNsYXNzS2V5KG5vZGUsIGtleSwgZmFsc2UpO1xuXHRcdGRlbGV0ZSBwcmV2W2tleV07XG5cdH1cblx0Zm9yIChpID0gMCwgbGVuID0gY2xhc3NLZXlzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gY2xhc3NLZXlzW2ldLCBjbGFzc1ZhbHVlID0gISF2YWx1ZVtrZXldO1xuXHRcdGlmICgha2V5IHx8IGtleSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBwcmV2W2tleV0gPT09IGNsYXNzVmFsdWUgfHwgIWNsYXNzVmFsdWUpIGNvbnRpbnVlO1xuXHRcdHRvZ2dsZUNsYXNzS2V5KG5vZGUsIGtleSwgdHJ1ZSk7XG5cdFx0cHJldltrZXldID0gY2xhc3NWYWx1ZTtcblx0fVxuXHRyZXR1cm4gcHJldjtcbn1cbmZ1bmN0aW9uIHN0eWxlKG5vZGUsIHZhbHVlLCBwcmV2KSB7XG5cdGlmICghdmFsdWUpIHJldHVybiBwcmV2ID8gc2V0QXR0cmlidXRlKG5vZGUsIFwic3R5bGVcIikgOiB2YWx1ZTtcblx0Y29uc3Qgbm9kZVN0eWxlID0gbm9kZS5zdHlsZTtcblx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIG5vZGVTdHlsZS5jc3NUZXh0ID0gdmFsdWU7XG5cdHR5cGVvZiBwcmV2ID09PSBcInN0cmluZ1wiICYmIChub2RlU3R5bGUuY3NzVGV4dCA9IHByZXYgPSB2b2lkIDApO1xuXHRwcmV2IHx8IChwcmV2ID0ge30pO1xuXHR2YWx1ZSB8fCAodmFsdWUgPSB7fSk7XG5cdGxldCB2LCBzO1xuXHRmb3IgKHMgaW4gcHJldikge1xuXHRcdHZhbHVlW3NdID8/IG5vZGVTdHlsZS5yZW1vdmVQcm9wZXJ0eShzKTtcblx0XHRkZWxldGUgcHJldltzXTtcblx0fVxuXHRmb3IgKHMgaW4gdmFsdWUpIHtcblx0XHR2ID0gdmFsdWVbc107XG5cdFx0aWYgKHYgIT09IHByZXZbc10pIHtcblx0XHRcdG5vZGVTdHlsZS5zZXRQcm9wZXJ0eShzLCB2KTtcblx0XHRcdHByZXZbc10gPSB2O1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gcHJldjtcbn1cbmZ1bmN0aW9uIHNldFN0eWxlUHJvcGVydHkobm9kZSwgbmFtZSwgdmFsdWUpIHtcblx0dmFsdWUgIT0gbnVsbCA/IG5vZGUuc3R5bGUuc2V0UHJvcGVydHkobmFtZSwgdmFsdWUpIDogbm9kZS5zdHlsZS5yZW1vdmVQcm9wZXJ0eShuYW1lKTtcbn1cbmZ1bmN0aW9uIHNwcmVhZChub2RlLCBwcm9wcyA9IHt9LCBpc1NWRywgc2tpcENoaWxkcmVuKSB7XG5cdGNvbnN0IHByZXZQcm9wcyA9IHt9O1xuXHRpZiAoIXNraXBDaGlsZHJlbikgY3JlYXRlUmVuZGVyRWZmZWN0KCgpID0+IHByZXZQcm9wcy5jaGlsZHJlbiA9IGluc2VydEV4cHJlc3Npb24obm9kZSwgcHJvcHMuY2hpbGRyZW4sIHByZXZQcm9wcy5jaGlsZHJlbikpO1xuXHRjcmVhdGVSZW5kZXJFZmZlY3QoKCkgPT4gdHlwZW9mIHByb3BzLnJlZiA9PT0gXCJmdW5jdGlvblwiICYmIHVzZShwcm9wcy5yZWYsIG5vZGUpKTtcblx0Y3JlYXRlUmVuZGVyRWZmZWN0KCgpID0+IGFzc2lnbihub2RlLCBwcm9wcywgaXNTVkcsIHRydWUsIHByZXZQcm9wcywgdHJ1ZSkpO1xuXHRyZXR1cm4gcHJldlByb3BzO1xufVxuZnVuY3Rpb24gdXNlKGZuLCBlbGVtZW50LCBhcmcpIHtcblx0cmV0dXJuIHVudHJhY2soKCkgPT4gZm4oZWxlbWVudCwgYXJnKSk7XG59XG5mdW5jdGlvbiBpbnNlcnQocGFyZW50LCBhY2Nlc3NvciwgbWFya2VyLCBpbml0aWFsKSB7XG5cdGlmIChtYXJrZXIgIT09IHZvaWQgMCAmJiAhaW5pdGlhbCkgaW5pdGlhbCA9IFtdO1xuXHRpZiAodHlwZW9mIGFjY2Vzc29yICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBpbnNlcnRFeHByZXNzaW9uKHBhcmVudCwgYWNjZXNzb3IsIGluaXRpYWwsIG1hcmtlcik7XG5cdGNyZWF0ZVJlbmRlckVmZmVjdCgoY3VycmVudCkgPT4gaW5zZXJ0RXhwcmVzc2lvbihwYXJlbnQsIGFjY2Vzc29yKCksIGN1cnJlbnQsIG1hcmtlciksIGluaXRpYWwpO1xufVxuZnVuY3Rpb24gYXNzaWduKG5vZGUsIHByb3BzLCBpc1NWRywgc2tpcENoaWxkcmVuLCBwcmV2UHJvcHMgPSB7fSwgc2tpcFJlZiA9IGZhbHNlKSB7XG5cdHByb3BzIHx8IChwcm9wcyA9IHt9KTtcblx0Zm9yIChjb25zdCBwcm9wIGluIHByZXZQcm9wcykgaWYgKCEocHJvcCBpbiBwcm9wcykpIHtcblx0XHRpZiAocHJvcCA9PT0gXCJjaGlsZHJlblwiKSBjb250aW51ZTtcblx0XHRwcmV2UHJvcHNbcHJvcF0gPSBhc3NpZ25Qcm9wKG5vZGUsIHByb3AsIG51bGwsIHByZXZQcm9wc1twcm9wXSwgaXNTVkcsIHNraXBSZWYsIHByb3BzKTtcblx0fVxuXHRmb3IgKGNvbnN0IHByb3AgaW4gcHJvcHMpIHtcblx0XHRpZiAocHJvcCA9PT0gXCJjaGlsZHJlblwiKSB7XG5cdFx0XHRpZiAoIXNraXBDaGlsZHJlbikgaW5zZXJ0RXhwcmVzc2lvbihub2RlLCBwcm9wcy5jaGlsZHJlbik7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0Y29uc3QgdmFsdWUgPSBwcm9wc1twcm9wXTtcblx0XHRwcmV2UHJvcHNbcHJvcF0gPSBhc3NpZ25Qcm9wKG5vZGUsIHByb3AsIHZhbHVlLCBwcmV2UHJvcHNbcHJvcF0sIGlzU1ZHLCBza2lwUmVmLCBwcm9wcyk7XG5cdH1cbn1cbmZ1bmN0aW9uIGdldE5leHRFbGVtZW50KHRlbXBsYXRlKSB7XG5cdGxldCBub2RlLCBrZXk7XG5cdGlmICghaXNIeWRyYXRpbmcoKSB8fCAhKG5vZGUgPSBzaGFyZWRDb25maWcucmVnaXN0cnkuZ2V0KGtleSA9IGdldEh5ZHJhdGlvbktleSgpKSkpIHJldHVybiB0ZW1wbGF0ZSgpO1xuXHRpZiAoc2hhcmVkQ29uZmlnLmNvbXBsZXRlZCkgc2hhcmVkQ29uZmlnLmNvbXBsZXRlZC5hZGQobm9kZSk7XG5cdHNoYXJlZENvbmZpZy5yZWdpc3RyeS5kZWxldGUoa2V5KTtcblx0cmV0dXJuIG5vZGU7XG59XG5mdW5jdGlvbiBpc0h5ZHJhdGluZyhub2RlKSB7XG5cdHJldHVybiAhIXNoYXJlZENvbmZpZy5jb250ZXh0ICYmICFzaGFyZWRDb25maWcuZG9uZSAmJiAoIW5vZGUgfHwgbm9kZS5pc0Nvbm5lY3RlZCk7XG59XG5mdW5jdGlvbiB0b1Byb3BlcnR5TmFtZShuYW1lKSB7XG5cdHJldHVybiBuYW1lLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvLShbYS16XSkvZywgKF8sIHcpID0+IHcudG9VcHBlckNhc2UoKSk7XG59XG5mdW5jdGlvbiB0b2dnbGVDbGFzc0tleShub2RlLCBrZXksIHZhbHVlKSB7XG5cdGNvbnN0IGNsYXNzTmFtZXMgPSBrZXkudHJpbSgpLnNwbGl0KC9cXHMrLyk7XG5cdGZvciAobGV0IGkgPSAwLCBuYW1lTGVuID0gY2xhc3NOYW1lcy5sZW5ndGg7IGkgPCBuYW1lTGVuOyBpKyspIG5vZGUuY2xhc3NMaXN0LnRvZ2dsZShjbGFzc05hbWVzW2ldLCB2YWx1ZSk7XG59XG5mdW5jdGlvbiBhc3NpZ25Qcm9wKG5vZGUsIHByb3AsIHZhbHVlLCBwcmV2LCBpc1NWRywgc2tpcFJlZiwgcHJvcHMpIHtcblx0bGV0IGlzQ0UsIGlzUHJvcCwgaXNDaGlsZFByb3AsIHByb3BBbGlhcywgZm9yY2VQcm9wO1xuXHRpZiAocHJvcCA9PT0gXCJzdHlsZVwiKSByZXR1cm4gc3R5bGUobm9kZSwgdmFsdWUsIHByZXYpO1xuXHRpZiAocHJvcCA9PT0gXCJjbGFzc0xpc3RcIikgcmV0dXJuIGNsYXNzTGlzdChub2RlLCB2YWx1ZSwgcHJldik7XG5cdGlmICh2YWx1ZSA9PT0gcHJldikgcmV0dXJuIHByZXY7XG5cdGlmIChwcm9wID09PSBcInJlZlwiKSB7XG5cdFx0aWYgKCFza2lwUmVmKSB2YWx1ZShub2RlKTtcblx0fSBlbHNlIGlmIChwcm9wLnNsaWNlKDAsIDMpID09PSBcIm9uOlwiKSB7XG5cdFx0Y29uc3QgZSA9IHByb3Auc2xpY2UoMyk7XG5cdFx0cHJldiAmJiBub2RlLnJlbW92ZUV2ZW50TGlzdGVuZXIoZSwgcHJldiwgdHlwZW9mIHByZXYgIT09IFwiZnVuY3Rpb25cIiAmJiBwcmV2KTtcblx0XHR2YWx1ZSAmJiBub2RlLmFkZEV2ZW50TGlzdGVuZXIoZSwgdmFsdWUsIHR5cGVvZiB2YWx1ZSAhPT0gXCJmdW5jdGlvblwiICYmIHZhbHVlKTtcblx0fSBlbHNlIGlmIChwcm9wLnNsaWNlKDAsIDEwKSA9PT0gXCJvbmNhcHR1cmU6XCIpIHtcblx0XHRjb25zdCBlID0gcHJvcC5zbGljZSgxMCk7XG5cdFx0cHJldiAmJiBub2RlLnJlbW92ZUV2ZW50TGlzdGVuZXIoZSwgcHJldiwgdHJ1ZSk7XG5cdFx0dmFsdWUgJiYgbm9kZS5hZGRFdmVudExpc3RlbmVyKGUsIHZhbHVlLCB0cnVlKTtcblx0fSBlbHNlIGlmIChwcm9wLnNsaWNlKDAsIDIpID09PSBcIm9uXCIpIHtcblx0XHRjb25zdCBuYW1lID0gcHJvcC5zbGljZSgyKS50b0xvd2VyQ2FzZSgpO1xuXHRcdGNvbnN0IGRlbGVnYXRlID0gRGVsZWdhdGVkRXZlbnRzLmhhcyhuYW1lKTtcblx0XHRpZiAoIWRlbGVnYXRlICYmIHByZXYpIHtcblx0XHRcdGNvbnN0IGggPSBBcnJheS5pc0FycmF5KHByZXYpID8gcHJldlswXSA6IHByZXY7XG5cdFx0XHRub2RlLnJlbW92ZUV2ZW50TGlzdGVuZXIobmFtZSwgaCk7XG5cdFx0fVxuXHRcdGlmIChkZWxlZ2F0ZSB8fCB2YWx1ZSkge1xuXHRcdFx0YWRkRXZlbnRMaXN0ZW5lcihub2RlLCBuYW1lLCB2YWx1ZSwgZGVsZWdhdGUpO1xuXHRcdFx0ZGVsZWdhdGUgJiYgZGVsZWdhdGVFdmVudHMoW25hbWVdKTtcblx0XHR9XG5cdH0gZWxzZSBpZiAocHJvcC5zbGljZSgwLCA1KSA9PT0gXCJhdHRyOlwiKSBzZXRBdHRyaWJ1dGUobm9kZSwgcHJvcC5zbGljZSg1KSwgdmFsdWUpO1xuXHRlbHNlIGlmIChwcm9wLnNsaWNlKDAsIDUpID09PSBcImJvb2w6XCIpIHNldEJvb2xBdHRyaWJ1dGUobm9kZSwgcHJvcC5zbGljZSg1KSwgdmFsdWUpO1xuXHRlbHNlIGlmICgoZm9yY2VQcm9wID0gcHJvcC5zbGljZSgwLCA1KSA9PT0gXCJwcm9wOlwiKSB8fCAoaXNDaGlsZFByb3AgPSBDaGlsZFByb3BlcnRpZXMuaGFzKHByb3ApKSB8fCAhaXNTVkcgJiYgKChwcm9wQWxpYXMgPSBnZXRQcm9wQWxpYXMocHJvcCwgbm9kZS50YWdOYW1lKSkgfHwgKGlzUHJvcCA9IFByb3BlcnRpZXMuaGFzKHByb3ApKSkgfHwgKGlzQ0UgPSBub2RlLm5vZGVOYW1lLmluY2x1ZGVzKFwiLVwiKSB8fCBcImlzXCIgaW4gcHJvcHMpKSB7XG5cdFx0aWYgKGZvcmNlUHJvcCkge1xuXHRcdFx0cHJvcCA9IHByb3Auc2xpY2UoNSk7XG5cdFx0XHRpc1Byb3AgPSB0cnVlO1xuXHRcdH0gZWxzZSBpZiAoaXNIeWRyYXRpbmcobm9kZSkpIHJldHVybiB2YWx1ZTtcblx0XHRpZiAocHJvcCA9PT0gXCJjbGFzc1wiIHx8IHByb3AgPT09IFwiY2xhc3NOYW1lXCIpIGNsYXNzTmFtZShub2RlLCB2YWx1ZSk7XG5cdFx0ZWxzZSBpZiAoaXNDRSAmJiAhaXNQcm9wICYmICFpc0NoaWxkUHJvcCkgbm9kZVt0b1Byb3BlcnR5TmFtZShwcm9wKV0gPSB2YWx1ZTtcblx0XHRlbHNlIGlmICgocHJvcCA9PT0gXCJ2YWx1ZVwiIHx8IHByb3AgPT09IFwiZGVmYXVsdFZhbHVlXCIpICYmIChub2RlLm5vZGVOYW1lID09PSBcIklOUFVUXCIgfHwgbm9kZS5ub2RlTmFtZSA9PT0gXCJURVhUQVJFQVwiKSkgbm9kZVtwcm9wQWxpYXMgfHwgcHJvcF0gPSB2YWx1ZSA/PyBcIlwiO1xuXHRcdGVsc2Ugbm9kZVtwcm9wQWxpYXMgfHwgcHJvcF0gPSB2YWx1ZTtcblx0fSBlbHNlIHtcblx0XHRjb25zdCBucyA9IGlzU1ZHICYmIHByb3AuaW5kZXhPZihcIjpcIikgPiAtMSAmJiBTVkdOYW1lc3BhY2VbcHJvcC5zcGxpdChcIjpcIilbMF1dO1xuXHRcdGlmIChucykgc2V0QXR0cmlidXRlTlMobm9kZSwgbnMsIHByb3AsIHZhbHVlKTtcblx0XHRlbHNlIHNldEF0dHJpYnV0ZShub2RlLCBBbGlhc2VzW3Byb3BdIHx8IHByb3AsIHZhbHVlKTtcblx0fVxuXHRyZXR1cm4gdmFsdWU7XG59XG5mdW5jdGlvbiBldmVudEhhbmRsZXIoZSkge1xuXHRpZiAoc2hhcmVkQ29uZmlnLnJlZ2lzdHJ5ICYmIHNoYXJlZENvbmZpZy5ldmVudHMpIHtcblx0XHRpZiAoc2hhcmVkQ29uZmlnLmV2ZW50cy5maW5kKChbZWwsIGV2XSkgPT4gZXYgPT09IGUpKSByZXR1cm47XG5cdH1cblx0bGV0IG5vZGUgPSBlLnRhcmdldDtcblx0Y29uc3Qga2V5ID0gYCQkJHtlLnR5cGV9YDtcblx0Y29uc3Qgb3JpVGFyZ2V0ID0gZS50YXJnZXQ7XG5cdGNvbnN0IG9yaUN1cnJlbnRUYXJnZXQgPSBlLmN1cnJlbnRUYXJnZXQ7XG5cdGNvbnN0IHJldGFyZ2V0ID0gKHZhbHVlKSA9PiBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgXCJ0YXJnZXRcIiwge1xuXHRcdGNvbmZpZ3VyYWJsZTogdHJ1ZSxcblx0XHR2YWx1ZVxuXHR9KTtcblx0Y29uc3QgaGFuZGxlTm9kZSA9ICgpID0+IHtcblx0XHRjb25zdCBoYW5kbGVyID0gbm9kZVtrZXldO1xuXHRcdGlmIChoYW5kbGVyICYmICFub2RlLmRpc2FibGVkKSB7XG5cdFx0XHRjb25zdCBkYXRhID0gbm9kZVtgJHtrZXl9RGF0YWBdO1xuXHRcdFx0ZGF0YSAhPT0gdm9pZCAwID8gaGFuZGxlci5jYWxsKG5vZGUsIGRhdGEsIGUpIDogaGFuZGxlci5jYWxsKG5vZGUsIGUpO1xuXHRcdFx0aWYgKGUuY2FuY2VsQnViYmxlKSByZXR1cm47XG5cdFx0fVxuXHRcdG5vZGUuaG9zdCAmJiB0eXBlb2Ygbm9kZS5ob3N0ICE9PSBcInN0cmluZ1wiICYmICFub2RlLmhvc3QuXyRob3N0ICYmIG5vZGUuY29udGFpbnMoZS50YXJnZXQpICYmIHJldGFyZ2V0KG5vZGUuaG9zdCk7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH07XG5cdGNvbnN0IHdhbGtVcFRyZWUgPSAoKSA9PiB7XG5cdFx0d2hpbGUgKGhhbmRsZU5vZGUoKSAmJiAobm9kZSA9IG5vZGUuXyRob3N0IHx8IG5vZGUucGFyZW50Tm9kZSB8fCBub2RlLmhvc3QpKTtcblx0fTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIFwiY3VycmVudFRhcmdldFwiLCB7XG5cdFx0Y29uZmlndXJhYmxlOiB0cnVlLFxuXHRcdGdldCgpIHtcblx0XHRcdHJldHVybiBub2RlIHx8IGRvY3VtZW50O1xuXHRcdH1cblx0fSk7XG5cdGlmIChzaGFyZWRDb25maWcucmVnaXN0cnkgJiYgIXNoYXJlZENvbmZpZy5kb25lKSBzaGFyZWRDb25maWcuZG9uZSA9IF8kSFkuZG9uZSA9IHRydWU7XG5cdHRyeSB7XG5cdFx0aWYgKGUuY29tcG9zZWRQYXRoKSB7XG5cdFx0XHRjb25zdCBwYXRoID0gZS5jb21wb3NlZFBhdGgoKTtcblx0XHRcdHJldGFyZ2V0KHBhdGhbMF0pO1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBwYXRoLmxlbmd0aCAtIDI7IGkrKykge1xuXHRcdFx0XHRub2RlID0gcGF0aFtpXTtcblx0XHRcdFx0aWYgKCFoYW5kbGVOb2RlKCkpIGJyZWFrO1xuXHRcdFx0XHRpZiAobm9kZS5fJGhvc3QpIHtcblx0XHRcdFx0XHRub2RlID0gbm9kZS5fJGhvc3Q7XG5cdFx0XHRcdFx0d2Fsa1VwVHJlZSgpO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGlmIChub2RlLnBhcmVudE5vZGUgPT09IG9yaUN1cnJlbnRUYXJnZXQpIGJyZWFrO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSB3YWxrVXBUcmVlKCk7XG5cdFx0cmV0YXJnZXQob3JpVGFyZ2V0KTtcblx0fSBmaW5hbGx5IHtcblx0XHRlID0gbm9kZSA9IG51bGw7XG5cdH1cbn1cbmZ1bmN0aW9uIGluc2VydEV4cHJlc3Npb24ocGFyZW50LCB2YWx1ZSwgY3VycmVudCwgbWFya2VyLCB1bndyYXBBcnJheSkge1xuXHRjb25zdCBoeWRyYXRpbmcgPSBpc0h5ZHJhdGluZyhwYXJlbnQpO1xuXHRpZiAoaHlkcmF0aW5nKSB7XG5cdFx0IWN1cnJlbnQgJiYgKGN1cnJlbnQgPSBbLi4ucGFyZW50LmNoaWxkTm9kZXNdKTtcblx0XHRsZXQgY2xlYW5lZCA9IFtdO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgY3VycmVudC5sZW5ndGg7IGkrKykge1xuXHRcdFx0Y29uc3Qgbm9kZSA9IGN1cnJlbnRbaV07XG5cdFx0XHRpZiAobm9kZS5ub2RlVHlwZSA9PT0gOCAmJiBub2RlLmRhdGEuc2xpY2UoMCwgMikgPT09IFwiISRcIikgbm9kZS5yZW1vdmUoKTtcblx0XHRcdGVsc2UgY2xlYW5lZC5wdXNoKG5vZGUpO1xuXHRcdH1cblx0XHRjdXJyZW50ID0gY2xlYW5lZDtcblx0fVxuXHR3aGlsZSAodHlwZW9mIGN1cnJlbnQgPT09IFwiZnVuY3Rpb25cIikgY3VycmVudCA9IGN1cnJlbnQoKTtcblx0aWYgKHZhbHVlID09PSBjdXJyZW50KSByZXR1cm4gY3VycmVudDtcblx0Y29uc3QgdCA9IHR5cGVvZiB2YWx1ZSwgbXVsdGkgPSBtYXJrZXIgIT09IHZvaWQgMDtcblx0cGFyZW50ID0gbXVsdGkgJiYgY3VycmVudFswXSAmJiBjdXJyZW50WzBdLnBhcmVudE5vZGUgfHwgcGFyZW50O1xuXHRpZiAodCA9PT0gXCJzdHJpbmdcIiB8fCB0ID09PSBcIm51bWJlclwiKSB7XG5cdFx0aWYgKGh5ZHJhdGluZykgcmV0dXJuIGN1cnJlbnQ7XG5cdFx0aWYgKHQgPT09IFwibnVtYmVyXCIpIHtcblx0XHRcdHZhbHVlID0gdmFsdWUudG9TdHJpbmcoKTtcblx0XHRcdGlmICh2YWx1ZSA9PT0gY3VycmVudCkgcmV0dXJuIGN1cnJlbnQ7XG5cdFx0fVxuXHRcdGlmIChtdWx0aSkge1xuXHRcdFx0bGV0IG5vZGUgPSBjdXJyZW50WzBdO1xuXHRcdFx0aWYgKG5vZGUgJiYgbm9kZS5ub2RlVHlwZSA9PT0gMykgbm9kZS5kYXRhICE9PSB2YWx1ZSAmJiAobm9kZS5kYXRhID0gdmFsdWUpO1xuXHRcdFx0ZWxzZSBub2RlID0gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUodmFsdWUpO1xuXHRcdFx0Y3VycmVudCA9IGNsZWFuQ2hpbGRyZW4ocGFyZW50LCBjdXJyZW50LCBtYXJrZXIsIG5vZGUpO1xuXHRcdH0gZWxzZSBpZiAoY3VycmVudCAhPT0gXCJcIiAmJiB0eXBlb2YgY3VycmVudCA9PT0gXCJzdHJpbmdcIikgY3VycmVudCA9IHBhcmVudC5maXJzdENoaWxkLmRhdGEgPSB2YWx1ZTtcblx0XHRlbHNlIGN1cnJlbnQgPSBwYXJlbnQudGV4dENvbnRlbnQgPSB2YWx1ZTtcblx0fSBlbHNlIGlmICh2YWx1ZSA9PSBudWxsIHx8IHQgPT09IFwiYm9vbGVhblwiKSB7XG5cdFx0aWYgKGh5ZHJhdGluZykgcmV0dXJuIGN1cnJlbnQ7XG5cdFx0Y3VycmVudCA9IGNsZWFuQ2hpbGRyZW4ocGFyZW50LCBjdXJyZW50LCBtYXJrZXIpO1xuXHR9IGVsc2UgaWYgKHQgPT09IFwiZnVuY3Rpb25cIikge1xuXHRcdGNyZWF0ZVJlbmRlckVmZmVjdCgoKSA9PiB7XG5cdFx0XHRsZXQgdiA9IHZhbHVlKCk7XG5cdFx0XHR3aGlsZSAodHlwZW9mIHYgPT09IFwiZnVuY3Rpb25cIikgdiA9IHYoKTtcblx0XHRcdGN1cnJlbnQgPSBpbnNlcnRFeHByZXNzaW9uKHBhcmVudCwgdiwgY3VycmVudCwgbWFya2VyKTtcblx0XHR9KTtcblx0XHRyZXR1cm4gKCkgPT4gY3VycmVudDtcblx0fSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuXHRcdGNvbnN0IGFycmF5ID0gW107XG5cdFx0Y29uc3QgY3VycmVudEFycmF5ID0gY3VycmVudCAmJiBBcnJheS5pc0FycmF5KGN1cnJlbnQpO1xuXHRcdGlmIChub3JtYWxpemVJbmNvbWluZ0FycmF5KGFycmF5LCB2YWx1ZSwgY3VycmVudCwgdW53cmFwQXJyYXkpKSB7XG5cdFx0XHRjcmVhdGVSZW5kZXJFZmZlY3QoKCkgPT4gY3VycmVudCA9IGluc2VydEV4cHJlc3Npb24ocGFyZW50LCBhcnJheSwgY3VycmVudCwgbWFya2VyLCB0cnVlKSk7XG5cdFx0XHRyZXR1cm4gKCkgPT4gY3VycmVudDtcblx0XHR9XG5cdFx0aWYgKGh5ZHJhdGluZykge1xuXHRcdFx0aWYgKCFhcnJheS5sZW5ndGgpIHJldHVybiBjdXJyZW50O1xuXHRcdFx0aWYgKG1hcmtlciA9PT0gdm9pZCAwKSByZXR1cm4gY3VycmVudCA9IFsuLi5wYXJlbnQuY2hpbGROb2Rlc107XG5cdFx0XHRsZXQgbm9kZSA9IGFycmF5WzBdO1xuXHRcdFx0aWYgKG5vZGUucGFyZW50Tm9kZSAhPT0gcGFyZW50KSByZXR1cm4gY3VycmVudDtcblx0XHRcdGNvbnN0IG5vZGVzID0gW25vZGVdO1xuXHRcdFx0d2hpbGUgKChub2RlID0gbm9kZS5uZXh0U2libGluZykgIT09IG1hcmtlcikgbm9kZXMucHVzaChub2RlKTtcblx0XHRcdHJldHVybiBjdXJyZW50ID0gbm9kZXM7XG5cdFx0fVxuXHRcdGlmIChhcnJheS5sZW5ndGggPT09IDApIHtcblx0XHRcdGN1cnJlbnQgPSBjbGVhbkNoaWxkcmVuKHBhcmVudCwgY3VycmVudCwgbWFya2VyKTtcblx0XHRcdGlmIChtdWx0aSkgcmV0dXJuIGN1cnJlbnQ7XG5cdFx0fSBlbHNlIGlmIChjdXJyZW50QXJyYXkpIHtcblx0XHRcdGlmIChjdXJyZW50Lmxlbmd0aCA9PT0gMCkgYXBwZW5kTm9kZXMocGFyZW50LCBhcnJheSwgbWFya2VyKTtcblx0XHRcdGVsc2UgcmVjb25jaWxlQXJyYXlzKHBhcmVudCwgY3VycmVudCwgYXJyYXkpO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRjdXJyZW50ICYmIGNsZWFuQ2hpbGRyZW4ocGFyZW50KTtcblx0XHRcdGFwcGVuZE5vZGVzKHBhcmVudCwgYXJyYXkpO1xuXHRcdH1cblx0XHRjdXJyZW50ID0gYXJyYXk7XG5cdH0gZWxzZSBpZiAodmFsdWUubm9kZVR5cGUpIHtcblx0XHRpZiAoaHlkcmF0aW5nICYmIHZhbHVlLnBhcmVudE5vZGUpIHJldHVybiBjdXJyZW50ID0gbXVsdGkgPyBbdmFsdWVdIDogdmFsdWU7XG5cdFx0aWYgKEFycmF5LmlzQXJyYXkoY3VycmVudCkpIHtcblx0XHRcdGlmIChtdWx0aSkgcmV0dXJuIGN1cnJlbnQgPSBjbGVhbkNoaWxkcmVuKHBhcmVudCwgY3VycmVudCwgbWFya2VyLCB2YWx1ZSk7XG5cdFx0XHRjbGVhbkNoaWxkcmVuKHBhcmVudCwgY3VycmVudCwgbnVsbCwgdmFsdWUpO1xuXHRcdH0gZWxzZSBpZiAoY3VycmVudCA9PSBudWxsIHx8IGN1cnJlbnQgPT09IFwiXCIgfHwgIXBhcmVudC5maXJzdENoaWxkKSBwYXJlbnQuYXBwZW5kQ2hpbGQodmFsdWUpO1xuXHRcdGVsc2UgcGFyZW50LnJlcGxhY2VDaGlsZCh2YWx1ZSwgcGFyZW50LmZpcnN0Q2hpbGQpO1xuXHRcdGN1cnJlbnQgPSB2YWx1ZTtcblx0fVxuXHRyZXR1cm4gY3VycmVudDtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZUluY29taW5nQXJyYXkobm9ybWFsaXplZCwgYXJyYXksIGN1cnJlbnQsIHVud3JhcCkge1xuXHRsZXQgZHluYW1pYyA9IGZhbHNlO1xuXHRmb3IgKGxldCBpID0gMCwgbGVuID0gYXJyYXkubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcblx0XHRsZXQgaXRlbSA9IGFycmF5W2ldLCBwcmV2ID0gY3VycmVudCAmJiBjdXJyZW50W25vcm1hbGl6ZWQubGVuZ3RoXSwgdDtcblx0XHRpZiAoaXRlbSA9PSBudWxsIHx8IGl0ZW0gPT09IHRydWUgfHwgaXRlbSA9PT0gZmFsc2UpO1xuXHRcdGVsc2UgaWYgKCh0ID0gdHlwZW9mIGl0ZW0pID09PSBcIm9iamVjdFwiICYmIGl0ZW0ubm9kZVR5cGUpIG5vcm1hbGl6ZWQucHVzaChpdGVtKTtcblx0XHRlbHNlIGlmIChBcnJheS5pc0FycmF5KGl0ZW0pKSBkeW5hbWljID0gbm9ybWFsaXplSW5jb21pbmdBcnJheShub3JtYWxpemVkLCBpdGVtLCBwcmV2KSB8fCBkeW5hbWljO1xuXHRcdGVsc2UgaWYgKHQgPT09IFwiZnVuY3Rpb25cIikge1xuXHRcdFx0aWYgKHVud3JhcCkge1xuXHRcdFx0XHR3aGlsZSAodHlwZW9mIGl0ZW0gPT09IFwiZnVuY3Rpb25cIikgaXRlbSA9IGl0ZW0oKTtcblx0XHRcdFx0ZHluYW1pYyA9IG5vcm1hbGl6ZUluY29taW5nQXJyYXkobm9ybWFsaXplZCwgQXJyYXkuaXNBcnJheShpdGVtKSA/IGl0ZW0gOiBbaXRlbV0sIEFycmF5LmlzQXJyYXkocHJldikgPyBwcmV2IDogW3ByZXZdKSB8fCBkeW5hbWljO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0bm9ybWFsaXplZC5wdXNoKGl0ZW0pO1xuXHRcdFx0XHRkeW5hbWljID0gdHJ1ZTtcblx0XHRcdH1cblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3QgdmFsdWUgPSBTdHJpbmcoaXRlbSk7XG5cdFx0XHRpZiAocHJldiAmJiBwcmV2Lm5vZGVUeXBlID09PSAzICYmIHByZXYuZGF0YSA9PT0gdmFsdWUpIG5vcm1hbGl6ZWQucHVzaChwcmV2KTtcblx0XHRcdGVsc2Ugbm9ybWFsaXplZC5wdXNoKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKHZhbHVlKSk7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBkeW5hbWljO1xufVxuZnVuY3Rpb24gYXBwZW5kTm9kZXMocGFyZW50LCBhcnJheSwgbWFya2VyID0gbnVsbCkge1xuXHRmb3IgKGxldCBpID0gMCwgbGVuID0gYXJyYXkubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHBhcmVudC5pbnNlcnRCZWZvcmUoYXJyYXlbaV0sIG1hcmtlcik7XG59XG5mdW5jdGlvbiBjbGVhbkNoaWxkcmVuKHBhcmVudCwgY3VycmVudCwgbWFya2VyLCByZXBsYWNlbWVudCkge1xuXHRpZiAobWFya2VyID09PSB2b2lkIDApIHJldHVybiBwYXJlbnQudGV4dENvbnRlbnQgPSBcIlwiO1xuXHRjb25zdCBub2RlID0gcmVwbGFjZW1lbnQgfHwgZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoXCJcIik7XG5cdGlmIChjdXJyZW50Lmxlbmd0aCkge1xuXHRcdGxldCBpbnNlcnRlZCA9IGZhbHNlO1xuXHRcdGZvciAobGV0IGkgPSBjdXJyZW50Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRjb25zdCBlbCA9IGN1cnJlbnRbaV07XG5cdFx0XHRpZiAobm9kZSAhPT0gZWwpIHtcblx0XHRcdFx0Y29uc3QgaXNQYXJlbnQgPSBlbC5wYXJlbnROb2RlID09PSBwYXJlbnQ7XG5cdFx0XHRcdGlmICghaW5zZXJ0ZWQgJiYgIWkpIGlzUGFyZW50ID8gcGFyZW50LnJlcGxhY2VDaGlsZChub2RlLCBlbCkgOiBwYXJlbnQuaW5zZXJ0QmVmb3JlKG5vZGUsIG1hcmtlcik7XG5cdFx0XHRcdGVsc2UgaXNQYXJlbnQgJiYgZWwucmVtb3ZlKCk7XG5cdFx0XHR9IGVsc2UgaW5zZXJ0ZWQgPSB0cnVlO1xuXHRcdH1cblx0fSBlbHNlIHBhcmVudC5pbnNlcnRCZWZvcmUobm9kZSwgbWFya2VyKTtcblx0cmV0dXJuIFtub2RlXTtcbn1cbmZ1bmN0aW9uIGdldEh5ZHJhdGlvbktleSgpIHtcblx0cmV0dXJuIHNoYXJlZENvbmZpZy5nZXROZXh0Q29udGV4dElkKCk7XG59XG5jb25zdCBTVkdfTkFNRVNQQUNFID0gXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiO1xuZnVuY3Rpb24gY3JlYXRlRWxlbWVudCh0YWdOYW1lLCBpc1NWRyA9IGZhbHNlLCBpcyA9IHZvaWQgMCkge1xuXHRyZXR1cm4gaXNTVkcgPyBkb2N1bWVudC5jcmVhdGVFbGVtZW50TlMoU1ZHX05BTUVTUEFDRSwgdGFnTmFtZSkgOiBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRhZ05hbWUsIHsgaXMgfSk7XG59XG5mdW5jdGlvbiBQb3J0YWwocHJvcHMpIHtcblx0Y29uc3QgeyB1c2VTaGFkb3cgfSA9IHByb3BzLCBtYXJrZXIgPSBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShcIlwiKSwgbW91bnQgPSAoKSA9PiBwcm9wcy5tb3VudCB8fCBkb2N1bWVudC5ib2R5LCBvd25lciA9IGdldE93bmVyKCk7XG5cdGxldCBjb250ZW50O1xuXHRsZXQgaHlkcmF0aW5nID0gISFzaGFyZWRDb25maWcuY29udGV4dDtcblx0Y3JlYXRlRWZmZWN0KCgpID0+IHtcblx0XHRpZiAoaHlkcmF0aW5nKSBnZXRPd25lcigpLnVzZXIgPSBoeWRyYXRpbmcgPSBmYWxzZTtcblx0XHRjb250ZW50IHx8IChjb250ZW50ID0gcnVuV2l0aE93bmVyKG93bmVyLCAoKSA9PiBjcmVhdGVNZW1vKCgpID0+IHByb3BzLmNoaWxkcmVuKSkpO1xuXHRcdGNvbnN0IGVsID0gbW91bnQoKTtcblx0XHRpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSGVhZEVsZW1lbnQpIHtcblx0XHRcdGNvbnN0IFtjbGVhbiwgc2V0Q2xlYW5dID0gY3JlYXRlU2lnbmFsKGZhbHNlKTtcblx0XHRcdGNvbnN0IGNsZWFudXAgPSAoKSA9PiBzZXRDbGVhbih0cnVlKTtcblx0XHRcdGNyZWF0ZVJvb3QoKGRpc3Bvc2UpID0+IGluc2VydChlbCwgKCkgPT4gIWNsZWFuKCkgPyBjb250ZW50KCkgOiBkaXNwb3NlKCksIG51bGwpKTtcblx0XHRcdG9uQ2xlYW51cChjbGVhbnVwKTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3QgY29udGFpbmVyID0gY3JlYXRlRWxlbWVudChwcm9wcy5pc1NWRyA/IFwiZ1wiIDogXCJkaXZcIiwgcHJvcHMuaXNTVkcpLCByZW5kZXJSb290ID0gdXNlU2hhZG93ICYmIGNvbnRhaW5lci5hdHRhY2hTaGFkb3cgPyBjb250YWluZXIuYXR0YWNoU2hhZG93KHsgbW9kZTogXCJvcGVuXCIgfSkgOiBjb250YWluZXI7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoY29udGFpbmVyLCBcIl8kaG9zdFwiLCB7XG5cdFx0XHRcdGdldCgpIHtcblx0XHRcdFx0XHRyZXR1cm4gbWFya2VyLnBhcmVudE5vZGU7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdGNvbmZpZ3VyYWJsZTogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHRpbnNlcnQocmVuZGVyUm9vdCwgY29udGVudCk7XG5cdFx0XHRlbC5hcHBlbmRDaGlsZChjb250YWluZXIpO1xuXHRcdFx0cHJvcHMucmVmICYmIHByb3BzLnJlZihjb250YWluZXIpO1xuXHRcdFx0b25DbGVhbnVwKCgpID0+IGVsLmNvbnRhaW5zKGNvbnRhaW5lcikgJiYgZWwucmVtb3ZlQ2hpbGQoY29udGFpbmVyKSk7XG5cdFx0fVxuXHR9LCB2b2lkIDAsIHsgcmVuZGVyOiAhaHlkcmF0aW5nIH0pO1xuXHRyZXR1cm4gbWFya2VyO1xufVxuZnVuY3Rpb24gY3JlYXRlRHluYW1pYyhjb21wb25lbnQsIHByb3BzKSB7XG5cdGNvbnN0IGNhY2hlZCA9IGNyZWF0ZU1lbW8oY29tcG9uZW50KTtcblx0cmV0dXJuIGNyZWF0ZU1lbW8oKCkgPT4ge1xuXHRcdGNvbnN0IGNvbXBvbmVudCA9IGNhY2hlZCgpO1xuXHRcdHN3aXRjaCAodHlwZW9mIGNvbXBvbmVudCkge1xuXHRcdFx0Y2FzZSBcImZ1bmN0aW9uXCI6IHJldHVybiB1bnRyYWNrKCgpID0+IGNvbXBvbmVudChwcm9wcykpO1xuXHRcdFx0Y2FzZSBcInN0cmluZ1wiOlxuXHRcdFx0XHRjb25zdCBpc1N2ZyA9IFNWR0VsZW1lbnRzLmhhcyhjb21wb25lbnQpO1xuXHRcdFx0XHRjb25zdCBlbCA9IHNoYXJlZENvbmZpZy5jb250ZXh0ID8gZ2V0TmV4dEVsZW1lbnQoKSA6IGNyZWF0ZUVsZW1lbnQoY29tcG9uZW50LCBpc1N2ZywgdW50cmFjaygoKSA9PiBwcm9wcy5pcykpO1xuXHRcdFx0XHRzcHJlYWQoZWwsIHByb3BzLCBpc1N2Zyk7XG5cdFx0XHRcdHJldHVybiBlbDtcblx0XHR9XG5cdH0pO1xufVxuZnVuY3Rpb24gRHluYW1pYyhwcm9wcykge1xuXHRjb25zdCBbLCBvdGhlcnNdID0gc3BsaXRQcm9wcyhwcm9wcywgW1wiY29tcG9uZW50XCJdKTtcblx0cmV0dXJuIGNyZWF0ZUR5bmFtaWMoKCkgPT4gcHJvcHMuY29tcG9uZW50LCBvdGhlcnMpO1xufVxuZXhwb3J0IHsgY3JlYXRlUm9vdCBhcyBBLCBzcGxpdFByb3BzIGFzIEIsIGJhdGNoIGFzIEMsIGNyZWF0ZUVmZmVjdCBhcyBELCBjcmVhdGVDb250ZXh0IGFzIEUsIGxhenkgYXMgRiwgdXNlQ29udGV4dCBhcyBILCBtZXJnZVByb3BzIGFzIEksIG9uIGFzIEwsIGNyZWF0ZVVuaXF1ZUlkIGFzIE0sIGdldExpc3RlbmVyIGFzIE4sIGNyZWF0ZU1lbW8gYXMgTywgZ2V0T3duZXIgYXMgUCwgb25DbGVhbnVwIGFzIFIsIFN3aXRjaCBhcyBTLCBjcmVhdGVDb21wdXRlZCBhcyBULCB1c2VUcmFuc2l0aW9uIGFzIFUsIHVudHJhY2sgYXMgViwgJFRSQUNLIGFzIF8sIGNsZWFyRGVsZWdhdGVkRXZlbnRzIGFzIGEsIE1hdGNoIGFzIGIsIG1lbW8gYXMgYywgc2V0U3R5bGVQcm9wZXJ0eSBhcyBkLCBzZXRUcnVzdGVkVHlwZXNQb2xpY3kgYXMgZiwgJFBST1hZIGFzIGcsIHVzZSBhcyBoLCBjbGFzc05hbWUgYXMgaSwgY3JlYXRlU2lnbmFsIGFzIGosIGNyZWF0ZVJlbmRlckVmZmVjdCBhcyBrLCByZW5kZXIgYXMgbCwgdGVtcGxhdGUgYXMgbSwgUG9ydGFsIGFzIG4sIGRlbGVnYXRlRXZlbnRzIGFzIG8sIHNwcmVhZCBhcyBwLCBhZGRFdmVudExpc3RlbmVyIGFzIHIsIGluc2VydCBhcyBzLCBEeW5hbWljIGFzIHQsIHNldEF0dHJpYnV0ZSBhcyB1LCBGb3IgYXMgdiwgY3JlYXRlQ29tcG9uZW50IGFzIHcsIFNob3cgYXMgeCwgSW5kZXggYXMgeSwgb25Nb3VudCBhcyB6IH07XG4iXSwibWFwcGluZ3MiOiI7QUFFQSxJQUFNLGVBQWU7Q0FDcEIsU0FBUyxLQUFLO0NBQ2QsVUFBVSxLQUFLO0NBQ2YsU0FBUyxLQUFLO0NBQ2QsTUFBTTtDQUNOLGVBQWU7RUFDZCxPQUFPLGFBQWEsS0FBSyxRQUFRLEtBQUs7Q0FDdkM7Q0FDQSxtQkFBbUI7RUFDbEIsT0FBTyxhQUFhLEtBQUssUUFBUSxPQUFPO0NBQ3pDO0FBQ0Q7QUFDQSxTQUFTLGFBQWEsT0FBTztDQUM1QixNQUFNLE1BQU0sT0FBTyxLQUFLLEdBQUcsTUFBTSxJQUFJLFNBQVM7Q0FDOUMsT0FBTyxhQUFhLFFBQVEsTUFBTSxNQUFNLE9BQU8sYUFBYSxLQUFLLEdBQUcsSUFBSSxNQUFNO0FBQy9FO0FBQ0EsU0FBUyxrQkFBa0IsU0FBUztDQUNuQyxhQUFhLFVBQVU7QUFDeEI7QUFDQSxJQUFNLFdBQVcsR0FBRyxNQUFNLE1BQU07QUFDaEMsSUFBTSxTQUFTLE9BQU8sYUFBYTtBQUNuQyxJQUFNLGlCQUFpQixPQUFPLFVBQVU7QUFDeEMsSUFBTSxTQUFTLE9BQU8sYUFBYTtBQUNuQyxJQUFNLGdCQUFnQixFQUFFLFFBQVEsUUFBUTtBQUN4QyxJQUFJLGFBQWE7QUFDakIsSUFBTSxRQUFRO0FBQ2QsSUFBTSxVQUFVO0FBQ2hCLElBQU0sVUFBVTtDQUNmLE9BQU87Q0FDUCxVQUFVO0NBQ1YsU0FBUztDQUNULE9BQU87QUFDUjtBQUNBLElBQU0sVUFBVSxDQUFDO0FBQ2pCLElBQUksUUFBUTtBQUNaLElBQUksYUFBYTtBQUNqQixJQUFJLFdBQVc7QUFDZixJQUFJLFVBQVU7QUFDZCxJQUFJLFVBQVU7QUFDZCxJQUFJLFlBQVk7QUFDaEIsU0FBUyxXQUFXLElBQUksZUFBZTtDQUN0QyxNQUFNLFdBQVcsVUFBVSxRQUFRLE9BQU8sVUFBVSxHQUFHLFdBQVcsR0FBRyxVQUFVLGtCQUFrQixLQUFLLElBQUksUUFBUSxlQUFlLE9BQU8sVUFBVSxVQUFVO0VBQzNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsU0FBUyxVQUFVLFFBQVEsVUFBVTtFQUNyQyxPQUFPO0NBQ1IsR0FBRyxXQUFXLFVBQVUsV0FBVyxHQUFHLGVBQWUsSUFBSSxDQUFDO0NBQzFELFFBQVE7Q0FDUixXQUFXO0NBQ1gsSUFBSTtFQUNILE9BQU8sV0FBVyxVQUFVLElBQUk7Q0FDakMsVUFBVTtFQUNULFdBQVc7RUFDWCxRQUFRO0NBQ1Q7QUFDRDtBQUNBLFNBQVMsZUFBZSxNQUFNO0NBQzdCLGFBQWEsY0FBYyxVQUFVLElBQUksQ0FBQztBQUMzQztBQUNBLFNBQVMsYUFBYSxPQUFPLFNBQVM7Q0FDckMsVUFBVSxVQUFVLE9BQU8sT0FBTyxDQUFDLEdBQUcsZUFBZSxPQUFPLElBQUk7Q0FDaEUsTUFBTSxJQUFJO0VBQ1Q7RUFDQSxXQUFXO0VBQ1gsZUFBZTtFQUNmLFlBQVksUUFBUSxVQUFVLEtBQUs7Q0FDcEM7Q0FDQSxNQUFNLFVBQVUsVUFBVTtFQUN6QixJQUFJLE9BQU8sVUFBVSxZQUFZO0dBQ2hDLElBQUksY0FBYyxXQUFXLFdBQVcsV0FBVyxRQUFRLElBQUksQ0FBQyxHQUFHLFFBQVEsTUFBTSxFQUFFLE1BQU07UUFDcEYsUUFBUSxNQUFNLEVBQUUsS0FBSztFQUMzQjtFQUNBLE9BQU8sWUFBWSxHQUFHLEtBQUs7Q0FDNUI7Q0FDQSxPQUFPLENBQUMsV0FBVyxLQUFLLENBQUMsR0FBRyxNQUFNO0FBQ25DO0FBQ0EsU0FBUyxlQUFlLElBQUksT0FBTyxTQUFTO0NBQzNDLGtCQUFrQixrQkFBa0IsSUFBSSxPQUFPLE1BQU0sS0FBSyxDQUFDO0FBQzVEO0FBQ0EsU0FBUyxtQkFBbUIsSUFBSSxPQUFPLFNBQVM7Q0FDL0Msa0JBQWtCLGtCQUFrQixJQUFJLE9BQU8sT0FBTyxLQUFLLENBQUM7QUFDN0Q7QUFDQSxTQUFTLGFBQWEsSUFBSSxPQUFPLFNBQVM7Q0FDekMsYUFBYTtDQUNiLE1BQU0sSUFBSSxrQkFBa0IsSUFBSSxPQUFPLE9BQU8sS0FBSyxHQUFHLElBQUksbUJBQW1CLFdBQVcsZUFBZTtDQUN2RyxJQUFJLEdBQUcsRUFBRSxXQUFXO0NBQ3BCLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxRQUFRLEVBQUUsT0FBTztDQUMxQyxVQUFVLFFBQVEsS0FBSyxDQUFDLElBQUksa0JBQWtCLENBQUM7QUFDaEQ7QUFDQSxTQUFTLFdBQVcsSUFBSSxPQUFPLFNBQVM7Q0FDdkMsVUFBVSxVQUFVLE9BQU8sT0FBTyxDQUFDLEdBQUcsZUFBZSxPQUFPLElBQUk7Q0FDaEUsTUFBTSxJQUFJLGtCQUFrQixJQUFJLE9BQU8sTUFBTSxDQUFDO0NBQzlDLEVBQUUsWUFBWTtDQUNkLEVBQUUsZ0JBQWdCO0NBQ2xCLEVBQUUsYUFBYSxRQUFRLFVBQVUsS0FBSztDQUN0QyxrQkFBa0IsQ0FBQztDQUNuQixPQUFPLFdBQVcsS0FBSyxDQUFDO0FBQ3pCO0FBQ0EsU0FBUyxVQUFVLEdBQUc7Q0FDckIsT0FBTyxLQUFLLE9BQU8sTUFBTSxZQUFZLFVBQVU7QUFDaEQ7QUFDQSxTQUFTLGVBQWUsU0FBUyxVQUFVLFVBQVU7Q0FDcEQsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxPQUFPLGFBQWEsWUFBWTtFQUNuQyxTQUFTO0VBQ1QsVUFBVTtFQUNWLFVBQVUsWUFBWSxDQUFDO0NBQ3hCLE9BQU87RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLFVBQVUsWUFBWSxDQUFDO0NBQ3hCO0NBQ0EsSUFBSSxLQUFLLE1BQU0sUUFBUSxTQUFTLEtBQUssTUFBTSx3QkFBd0IsT0FBTyxZQUFZLE9BQU8sV0FBVyxrQkFBa0IsU0FBUyxVQUFVLE9BQU8sV0FBVyxjQUFjLFdBQVcsTUFBTTtDQUM5TCxNQUFNLDJCQUEyQixJQUFJLElBQUksR0FBRyxDQUFDLE9BQU8sYUFBYSxRQUFRLFdBQVcsYUFBQSxDQUFjLFFBQVEsWUFBWSxHQUFHLENBQUMsT0FBTyxZQUFZLGFBQWEsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLFdBQVcsYUFBYSxLQUFLLEdBQUcsRUFBRSxRQUFRLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxZQUFZLGFBQWEsV0FBVyxVQUFVLFlBQVk7Q0FDalMsSUFBSSxPQUFPLGdCQUFnQjtFQUMxQixLQUFLLE1BQU0sS0FBSyxTQUFTLEtBQUssR0FBRyxFQUFFLFVBQVU7RUFDN0MsU0FBUyxNQUFNO0VBQ2YsSUFBSSxjQUFjLElBQUksV0FBVyxTQUFTLE9BQU8sRUFBRTtFQUNuRCxLQUFLO0NBQ04sQ0FBQztDQUNELElBQUksYUFBYSxTQUFTO0VBQ3pCLEtBQUssYUFBYSxpQkFBaUI7RUFDbkMsSUFBSSxRQUFRLGdCQUFnQixXQUFXLFFBQVEsUUFBUTtPQUNsRCxJQUFJLGFBQWEsUUFBUSxhQUFhLElBQUksRUFBRSxHQUFHLFFBQVEsYUFBYSxLQUFLLEVBQUU7Q0FDakY7Q0FDQSxTQUFTLFFBQVEsR0FBRyxHQUFHLE9BQU8sS0FBSztFQUNsQyxJQUFJLE9BQU8sR0FBRztHQUNiLEtBQUs7R0FDTCxRQUFRLEtBQUssTUFBTSxXQUFXO0dBQzlCLEtBQUssTUFBTSxTQUFTLE1BQU0sVUFBVSxRQUFRLFlBQVkscUJBQXFCLFFBQVEsV0FBVyxLQUFLLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQztHQUNsSCxRQUFRO0dBQ1IsSUFBSSxjQUFjLEtBQUssdUJBQXVCO0lBQzdDLFdBQVcsU0FBUyxPQUFPLENBQUM7SUFDNUIsd0JBQXdCO0lBQ3hCLGlCQUFpQjtLQUNoQixXQUFXLFVBQVU7S0FDckIsYUFBYSxHQUFHLEtBQUs7SUFDdEIsR0FBRyxLQUFLO0dBQ1QsT0FBTyxhQUFhLEdBQUcsS0FBSztFQUM3QjtFQUNBLE9BQU87Q0FDUjtDQUNBLFNBQVMsYUFBYSxHQUFHLEtBQUs7RUFDN0IsaUJBQWlCO0dBQ2hCLElBQUksUUFBUSxLQUFLLEdBQUcsZUFBZSxDQUFDO0dBQ3BDLFNBQVMsUUFBUSxLQUFLLElBQUksWUFBWSxXQUFXLFVBQVUsWUFBWTtHQUN2RSxTQUFTLEdBQUc7R0FDWixLQUFLLE1BQU0sS0FBSyxTQUFTLEtBQUssR0FBRyxFQUFFLFVBQVU7R0FDN0MsU0FBUyxNQUFNO0VBQ2hCLEdBQUcsS0FBSztDQUNUO0NBQ0EsU0FBUyxPQUFPO0VBQ2YsTUFBTSxJQUFJLG1CQUFtQixXQUFXLGVBQWUsR0FBRyxJQUFJLE1BQU0sR0FBRyxNQUFNLE1BQU07RUFDbkYsSUFBSSxRQUFRLEtBQUssS0FBSyxDQUFDLElBQUksTUFBTTtFQUNqQyxJQUFJLFlBQVksQ0FBQyxTQUFTLFFBQVEsR0FBRyxxQkFBcUI7R0FDekQsTUFBTTtHQUNOLElBQUksSUFBSTtJQUNQLElBQUksRUFBRSxZQUFZLGNBQWMsdUJBQXVCLFdBQVcsU0FBUyxJQUFJLEVBQUU7U0FDNUUsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLEdBQUc7S0FDMUIsRUFBRSxVQUFVO0tBQ1osU0FBUyxJQUFJLENBQUM7SUFDZjtHQUNEO0VBQ0QsQ0FBQztFQUNELE9BQU87Q0FDUjtDQUNBLFNBQVMsS0FBSyxhQUFhLE1BQU07RUFDaEMsSUFBSSxlQUFlLFNBQVMsV0FBVztFQUN2QyxZQUFZO0VBQ1osTUFBTSxTQUFTLFVBQVUsUUFBUSxJQUFJO0VBQ3JDLHdCQUF3QixjQUFjLFdBQVc7RUFDakQsSUFBSSxVQUFVLFFBQVEsV0FBVyxPQUFPO0dBQ3ZDLFFBQVEsSUFBSSxRQUFRLEtBQUssQ0FBQztHQUMxQjtFQUNEO0VBQ0EsSUFBSSxjQUFjLElBQUksV0FBVyxTQUFTLE9BQU8sRUFBRTtFQUNuRCxJQUFJO0VBQ0osTUFBTSxJQUFJLFVBQVUsVUFBVSxRQUFRLGNBQWM7R0FDbkQsSUFBSTtJQUNILE9BQU8sUUFBUSxRQUFRO0tBQ3RCLE9BQU8sTUFBTTtLQUNiO0lBQ0QsQ0FBQztHQUNGLFNBQVMsY0FBYztJQUN0QixRQUFRO0dBQ1Q7RUFDRCxDQUFDO0VBQ0QsSUFBSSxVQUFVLEtBQUssR0FBRztHQUNyQixRQUFRLElBQUksS0FBSyxHQUFHLFVBQVUsS0FBSyxHQUFHLE1BQU07R0FDNUM7RUFDRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRztHQUN6QixRQUFRLElBQUksR0FBRyxLQUFLLEdBQUcsTUFBTTtHQUM3QixPQUFPO0VBQ1I7RUFDQSxLQUFLO0VBQ0wsSUFBSSxPQUFPLEdBQUc7R0FDYixJQUFJLEVBQUUsTUFBTSxHQUFHLFFBQVEsSUFBSSxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07UUFDekMsUUFBUSxJQUFJLEtBQUssR0FBRyxVQUFVLEVBQUUsQ0FBQyxHQUFHLE1BQU07R0FDL0MsT0FBTztFQUNSO0VBQ0EsWUFBWTtFQUNaLHFCQUFxQixZQUFZLEtBQUs7RUFDdEMsaUJBQWlCO0dBQ2hCLFNBQVMsV0FBVyxlQUFlLFNBQVM7R0FDNUMsUUFBUTtFQUNULEdBQUcsS0FBSztFQUNSLE9BQU8sRUFBRSxNQUFNLE1BQU0sUUFBUSxHQUFHLEdBQUcsS0FBSyxHQUFHLE1BQU0sSUFBSSxNQUFNLFFBQVEsR0FBRyxLQUFLLEdBQUcsVUFBVSxDQUFDLEdBQUcsTUFBTSxDQUFDO0NBQ3BHO0NBQ0EsT0FBTyxpQkFBaUIsTUFBTTtFQUM3QixPQUFPLEVBQUUsV0FBVyxNQUFNLEVBQUU7RUFDNUIsT0FBTyxFQUFFLFdBQVcsTUFBTSxFQUFFO0VBQzVCLFNBQVMsRUFBRSxNQUFNO0dBQ2hCLE1BQU0sSUFBSSxNQUFNO0dBQ2hCLE9BQU8sTUFBTSxhQUFhLE1BQU07RUFDakMsRUFBRTtFQUNGLFFBQVEsRUFBRSxNQUFNO0dBQ2YsSUFBSSxDQUFDLFVBQVUsT0FBTyxLQUFLO0dBQzNCLE1BQU0sTUFBTSxNQUFNO0dBQ2xCLElBQUksT0FBTyxDQUFDLElBQUksTUFBTTtHQUN0QixPQUFPLE1BQU07RUFDZCxFQUFFO0NBQ0gsQ0FBQztDQUNELElBQUksUUFBUTtDQUNaLElBQUksU0FBUyxzQkFBc0IsUUFBUSxPQUFPLEtBQUssS0FBSyxFQUFFO01BQ3pELEtBQUssS0FBSztDQUNmLE9BQU8sQ0FBQyxNQUFNO0VBQ2IsVUFBVSxTQUFTLGFBQWEsYUFBYSxLQUFLLElBQUksQ0FBQztFQUN2RCxRQUFRO0NBQ1QsQ0FBQztBQUNGO0FBQ0EsU0FBUyxNQUFNLElBQUk7Q0FDbEIsT0FBTyxXQUFXLElBQUksS0FBSztBQUM1QjtBQUNBLFNBQVMsUUFBUSxJQUFJO0NBQ3BCLElBQUksYUFBYSxNQUFNLE9BQU8sR0FBRztDQUNqQyxNQUFNLFdBQVc7Q0FDakIsV0FBVztDQUNYLElBQUk7RUFDSCxPQUFPLEdBQUc7Q0FDWCxVQUFVO0VBQ1QsV0FBVztDQUNaO0FBQ0Q7QUFDQSxTQUFTLEdBQUcsTUFBTSxJQUFJLFNBQVM7Q0FDOUIsTUFBTSxVQUFVLE1BQU0sUUFBUSxJQUFJO0NBQ2xDLElBQUk7Q0FDSixJQUFJLFFBQVEsV0FBVyxRQUFRO0NBQy9CLFFBQVEsY0FBYztFQUNyQixJQUFJO0VBQ0osSUFBSSxTQUFTO0dBQ1osUUFBUSxNQUFNLEtBQUssTUFBTTtHQUN6QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUssTUFBTSxLQUFLLEtBQUssRUFBRSxDQUFDO0VBQzFELE9BQU8sUUFBUSxLQUFLO0VBQ3BCLElBQUksT0FBTztHQUNWLFFBQVE7R0FDUixPQUFPO0VBQ1I7RUFDQSxNQUFNLFNBQVMsY0FBYyxHQUFHLE9BQU8sV0FBVyxTQUFTLENBQUM7RUFDNUQsWUFBWTtFQUNaLE9BQU87Q0FDUjtBQUNEO0FBQ0EsU0FBUyxRQUFRLElBQUk7Q0FDcEIsbUJBQW1CLFFBQVEsRUFBRSxDQUFDO0FBQy9CO0FBQ0EsU0FBUyxVQUFVLElBQUk7Q0FDdEIsSUFBSSxVQUFVO01BQ1QsSUFBSSxNQUFNLGFBQWEsTUFBTSxNQUFNLFdBQVcsQ0FBQyxFQUFFO01BQ2pELE1BQU0sU0FBUyxLQUFLLEVBQUU7Q0FDM0IsT0FBTztBQUNSO0FBQ0EsU0FBUyxjQUFjO0NBQ3RCLE9BQU87QUFDUjtBQUNBLFNBQVMsV0FBVztDQUNuQixPQUFPO0FBQ1I7QUFDQSxTQUFTLGFBQWEsR0FBRyxJQUFJO0NBQzVCLE1BQU0sT0FBTztDQUNiLE1BQU0sZUFBZTtDQUNyQixRQUFRO0NBQ1IsV0FBVztDQUNYLElBQUk7RUFDSCxPQUFPLFdBQVcsSUFBSSxJQUFJO0NBQzNCLFNBQVMsS0FBSztFQUNiLFlBQVksR0FBRztDQUNoQixVQUFVO0VBQ1QsUUFBUTtFQUNSLFdBQVc7Q0FDWjtBQUNEO0FBQ0EsU0FBUyxnQkFBZ0IsSUFBSTtDQUM1QixJQUFJLGNBQWMsV0FBVyxTQUFTO0VBQ3JDLEdBQUc7RUFDSCxPQUFPLFdBQVc7Q0FDbkI7Q0FDQSxNQUFNLElBQUk7Q0FDVixNQUFNLElBQUk7Q0FDVixPQUFPLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVztFQUNuQyxXQUFXO0VBQ1gsUUFBUTtFQUNSLElBQUk7RUFDSixJQUFJLGlCQUFpQjtHQUNwQixJQUFJLGVBQWUsYUFBYTtJQUMvQix5QkFBeUIsSUFBSSxJQUFJO0lBQ2pDLFNBQVMsQ0FBQztJQUNWLDBCQUEwQixJQUFJLElBQUk7SUFDbEMsMEJBQTBCLElBQUksSUFBSTtJQUNsQyx1QkFBdUIsSUFBSSxJQUFJO0lBQy9CLFNBQVM7R0FDVjtHQUNBLEVBQUUsU0FBUyxFQUFFLE9BQU8sSUFBSSxTQUFTLFFBQVEsRUFBRSxVQUFVLEdBQUc7R0FDeEQsRUFBRSxVQUFVO0VBQ2I7RUFDQSxXQUFXLElBQUksS0FBSztFQUNwQixXQUFXLFFBQVE7RUFDbkIsT0FBTyxJQUFJLEVBQUUsT0FBTyxLQUFLO0NBQzFCLENBQUM7QUFDRjtBQUNBLElBQU0sQ0FBQyxjQUFjLG1CQUFpQywyQkFBYSxLQUFLO0FBQ3hFLFNBQVMsZ0JBQWdCO0NBQ3hCLE9BQU8sQ0FBQyxjQUFjLGVBQWU7QUFDdEM7QUFDQSxTQUFTLGNBQWMsY0FBYyxTQUFTO0NBQzdDLE1BQU0sS0FBSyxPQUFPLFNBQVM7Q0FDM0IsT0FBTztFQUNOO0VBQ0EsVUFBVSxlQUFlLEVBQUU7RUFDM0I7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxXQUFXLFNBQVM7Q0FDNUIsSUFBSTtDQUNKLE9BQU8sU0FBUyxNQUFNLFlBQVksUUFBUSxNQUFNLFFBQVEsUUFBUSxTQUFTLEtBQUssSUFBSSxRQUFRLFFBQVE7QUFDbkc7QUFDQSxTQUFTLFNBQVMsSUFBSTtDQUNyQixNQUFNLFdBQVcsV0FBVyxFQUFFO0NBQzlCLE1BQU0sT0FBTyxpQkFBaUIsZ0JBQWdCLFNBQVMsQ0FBQyxDQUFDO0NBQ3pELEtBQUssZ0JBQWdCO0VBQ3BCLE1BQU0sSUFBSSxLQUFLO0VBQ2YsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUM7Q0FDbEQ7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxJQUFJO0FBQ0osU0FBUyxvQkFBb0IsUUFBUTtDQUNwQyxPQUFPLGdCQUFnQixPQUFPLFVBQVUsS0FBSyxVQUFVLFNBQVM7RUFDL0QsTUFBTSxVQUFVLFNBQVM7RUFDekIsSUFBSSxDQUFDLFNBQVMsT0FBTztFQUNyQixLQUFLLElBQUksSUFBSSxRQUFRLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSyxJQUFJLFFBQVEsT0FBTyxVQUFVLFNBQVMsZUFBZSxTQUFTLFlBQVksT0FBTyxNQUFNLE9BQU87RUFDNUksT0FBTyxRQUFRLFlBQVksTUFBTTtDQUNsQyxDQUFDO0FBQ0Y7QUFDQSxTQUFTLGFBQWE7Q0FDckIsTUFBTSxvQkFBb0IsY0FBYyxXQUFXO0NBQ25ELElBQUksS0FBSyxZQUFZLG9CQUFvQixLQUFLLFNBQVMsS0FBSyxRQUFRO0VBQ25FLEtBQUssb0JBQW9CLEtBQUssU0FBUyxLQUFLLFdBQVcsT0FBTyxrQkFBa0IsSUFBSTtPQUMvRTtHQUNKLE1BQU0sVUFBVTtHQUNoQixVQUFVO0dBQ1YsaUJBQWlCLGFBQWEsSUFBSSxHQUFHLEtBQUs7R0FDMUMsVUFBVTtFQUNYO0NBQ0Q7Q0FDQSxJQUFJLFVBQVU7RUFDYixNQUFNLFlBQVksS0FBSztFQUN2QixJQUFJLENBQUMsYUFBYSxVQUFVLFVBQVUsU0FBUyxPQUFPLFVBQVU7R0FDL0QsTUFBTSxRQUFRLFlBQVksVUFBVSxTQUFTO0dBQzdDLElBQUksQ0FBQyxTQUFTLFNBQVM7SUFDdEIsTUFBTSxVQUFVLENBQUMsSUFBSTtJQUNyQixNQUFNLGNBQWMsQ0FBQyxLQUFLO0lBQzFCLFNBQVMsVUFBVTtJQUNuQixTQUFTLGNBQWM7R0FDeEIsT0FBTztJQUNOLFNBQVMsUUFBUSxLQUFLLElBQUk7SUFDMUIsU0FBUyxZQUFZLEtBQUssS0FBSztHQUNoQztHQUNBLElBQUksQ0FBQyxXQUFXO0lBQ2YsTUFBTSxlQUFlLENBQUMsUUFBUTtJQUM5QixNQUFNLG1CQUFtQixDQUFDLFNBQVMsUUFBUSxTQUFTLENBQUM7SUFDckQsS0FBSyxZQUFZO0lBQ2pCLEtBQUssZ0JBQWdCO0dBQ3RCLE9BQU87SUFDTixJQUFJLENBQUMsS0FBSyxpQkFBaUIsS0FBSyxjQUFjLFdBQVcsVUFBVSxRQUFRLG9CQUFvQixJQUFJO0lBQ25HLFVBQVUsS0FBSyxRQUFRO0lBQ3ZCLEtBQUssY0FBYyxLQUFLLFNBQVMsUUFBUSxTQUFTLENBQUM7R0FDcEQ7RUFDRDtDQUNEO0NBQ0EsSUFBSSxxQkFBcUIsV0FBVyxRQUFRLElBQUksSUFBSSxHQUFHLE9BQU8sS0FBSztDQUNuRSxPQUFPLEtBQUs7QUFDYjtBQUNBLFNBQVMsWUFBWSxNQUFNLE9BQU8sUUFBUTtDQUN6QyxJQUFJLFVBQVUsY0FBYyxXQUFXLFdBQVcsV0FBVyxRQUFRLElBQUksSUFBSSxJQUFJLEtBQUssU0FBUyxLQUFLO0NBQ3BHLElBQUksQ0FBQyxLQUFLLGNBQWMsQ0FBQyxLQUFLLFdBQVcsU0FBUyxLQUFLLEdBQUc7RUFDekQsSUFBSSxZQUFZO0dBQ2YsTUFBTSxvQkFBb0IsV0FBVztHQUNyQyxJQUFJLHFCQUFxQixDQUFDLFVBQVUsV0FBVyxRQUFRLElBQUksSUFBSSxHQUFHO0lBQ2pFLFdBQVcsUUFBUSxJQUFJLElBQUk7SUFDM0IsS0FBSyxTQUFTO0dBQ2Y7R0FDQSxJQUFJLENBQUMsbUJBQW1CLEtBQUssUUFBUTtFQUN0QyxPQUFPLEtBQUssUUFBUTtFQUNwQixJQUFJLEtBQUssYUFBYSxLQUFLLFVBQVUsUUFBUSxpQkFBaUI7R0FDN0QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssVUFBVSxRQUFRLEtBQUssR0FBRztJQUNsRCxNQUFNLElBQUksS0FBSyxVQUFVO0lBQ3pCLE1BQU0sb0JBQW9CLGNBQWMsV0FBVztJQUNuRCxJQUFJLHFCQUFxQixXQUFXLFNBQVMsSUFBSSxDQUFDLEdBQUc7SUFDckQsSUFBSSxvQkFBb0IsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxFQUFFLE9BQU87S0FDN0MsSUFBSSxFQUFFLE1BQU0sUUFBUSxLQUFLLENBQUM7VUFDckIsUUFBUSxLQUFLLENBQUM7S0FDbkIsSUFBSSxFQUFFLFdBQVcsZUFBZSxDQUFDO0lBQ2xDO0lBQ0EsSUFBSSxDQUFDLG1CQUFtQixFQUFFLFFBQVE7U0FDN0IsRUFBRSxTQUFTO0dBQ2pCO0dBQ0EsSUFBSSxRQUFRLFNBQVMsS0FBSztJQUN6QixVQUFVLENBQUM7SUFDWCxNQUFNLElBQUksTUFBTTtHQUNqQjtFQUNELEdBQUcsS0FBSztDQUNUO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTTtDQUNoQyxJQUFJLENBQUMsS0FBSyxJQUFJO0NBQ2QsVUFBVSxNQUFNLElBQUk7Q0FDcEIsTUFBTSxPQUFPO0NBQ2IsZUFBZSxNQUFNLGNBQWMsV0FBVyxXQUFXLFdBQVcsUUFBUSxJQUFJLElBQUksSUFBSSxLQUFLLFNBQVMsS0FBSyxPQUFPLElBQUk7Q0FDdEgsSUFBSSxjQUFjLENBQUMsV0FBVyxXQUFXLFdBQVcsUUFBUSxJQUFJLElBQUksR0FBRyxxQkFBcUI7RUFDM0YsaUJBQWlCO0dBQ2hCLGVBQWUsV0FBVyxVQUFVO0dBQ3BDLFdBQVcsUUFBUTtHQUNuQixlQUFlLE1BQU0sS0FBSyxRQUFRLElBQUk7R0FDdEMsV0FBVyxRQUFRO0VBQ3BCLEdBQUcsS0FBSztDQUNULENBQUM7QUFDRjtBQUNBLFNBQVMsZUFBZSxNQUFNLE9BQU8sTUFBTTtDQUMxQyxJQUFJO0NBQ0osTUFBTSxRQUFRLE9BQU8sV0FBVztDQUNoQyxXQUFXLFFBQVE7Q0FDbkIsSUFBSTtFQUNILFlBQVksS0FBSyxHQUFHLEtBQUs7Q0FDMUIsU0FBUyxLQUFLO0VBQ2IsSUFBSSxLQUFLLE1BQU07R0FDZCxJQUFJLGNBQWMsV0FBVyxTQUFTO0lBQ3JDLEtBQUssU0FBUztJQUNkLEtBQUssVUFBVSxLQUFLLE9BQU8sU0FBUyxNQUFNLFVBQVUsQ0FBQyxDQUFDO0lBQ3RELEtBQUssU0FBUyxLQUFLO0dBQ3BCLE9BQU87SUFDTixLQUFLLFFBQVE7SUFDYixLQUFLLFNBQVMsS0FBSyxNQUFNLFNBQVMsTUFBTSxVQUFVLENBQUMsQ0FBQztJQUNwRCxLQUFLLFFBQVE7R0FDZDtFQUNEO0VBQ0EsS0FBSyxZQUFZLE9BQU87RUFDeEIsT0FBTyxZQUFZLEdBQUc7Q0FDdkIsVUFBVTtFQUNULFdBQVc7RUFDWCxRQUFRO0NBQ1Q7Q0FDQSxJQUFJLENBQUMsS0FBSyxhQUFhLEtBQUssYUFBYSxNQUFNO0VBQzlDLElBQUksS0FBSyxhQUFhLFFBQVEsZUFBZSxNQUFNLFlBQVksTUFBTSxXQUFXLElBQUk7T0FDL0UsSUFBSSxjQUFjLFdBQVcsV0FBVyxLQUFLLE1BQU07R0FDdkQsSUFBSSxDQUFDLFdBQVcsUUFBUSxJQUFJLElBQUksR0FBRyxLQUFLLFFBQVE7R0FDaEQsV0FBVyxRQUFRLElBQUksSUFBSTtHQUMzQixLQUFLLFNBQVM7RUFDZixPQUFPLEtBQUssUUFBUTtFQUNwQixLQUFLLFlBQVk7Q0FDbEI7QUFDRDtBQUNBLFNBQVMsa0JBQWtCLElBQUksTUFBTSxNQUFNLFFBQVEsT0FBTyxTQUFTO0NBQ2xFLE1BQU0sSUFBSTtFQUNUO0VBQ0E7RUFDQSxXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxhQUFhO0VBQ2IsVUFBVTtFQUNWLE9BQU87RUFDUCxPQUFPO0VBQ1AsU0FBUyxRQUFRLE1BQU0sVUFBVTtFQUNqQztDQUNEO0NBQ0EsSUFBSSxjQUFjLFdBQVcsU0FBUztFQUNyQyxFQUFFLFFBQVE7RUFDVixFQUFFLFNBQVM7Q0FDWjtDQUNBLElBQUksVUFBVTtNQUNULElBQUksVUFBVSxTQUFTO0VBQzNCLElBQUksY0FBYyxXQUFXLFdBQVcsTUFBTSxNQUFNO0dBQ25ELElBQUksQ0FBQyxNQUFNLFFBQVEsTUFBTSxTQUFTLENBQUMsQ0FBQztRQUMvQixNQUFNLE9BQU8sS0FBSyxDQUFDO0VBQ3pCLE9BQU8sSUFBSSxDQUFDLE1BQU0sT0FBTyxNQUFNLFFBQVEsQ0FBQyxDQUFDO09BQ3BDLE1BQU0sTUFBTSxLQUFLLENBQUM7Q0FDeEI7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLE9BQU8sTUFBTTtDQUNyQixNQUFNLG9CQUFvQixjQUFjLFdBQVc7Q0FDbkQsS0FBSyxvQkFBb0IsS0FBSyxTQUFTLEtBQUssV0FBVyxHQUFHO0NBQzFELEtBQUssb0JBQW9CLEtBQUssU0FBUyxLQUFLLFdBQVcsU0FBUyxPQUFPLGFBQWEsSUFBSTtDQUN4RixJQUFJLEtBQUssWUFBWSxRQUFRLEtBQUssU0FBUyxVQUFVLEdBQUcsT0FBTyxLQUFLLFNBQVMsUUFBUSxLQUFLLElBQUk7Q0FDOUYsTUFBTSxZQUFZLENBQUMsSUFBSTtDQUN2QixRQUFRLE9BQU8sS0FBSyxXQUFXLENBQUMsS0FBSyxhQUFhLEtBQUssWUFBWSxZQUFZO0VBQzlFLElBQUkscUJBQXFCLFdBQVcsU0FBUyxJQUFJLElBQUksR0FBRztFQUN4RCxJQUFJLG9CQUFvQixLQUFLLFNBQVMsS0FBSyxPQUFPLFVBQVUsS0FBSyxJQUFJO0NBQ3RFO0NBQ0EsS0FBSyxJQUFJLElBQUksVUFBVSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7RUFDL0MsT0FBTyxVQUFVO0VBQ2pCLElBQUksbUJBQW1CO0dBQ3RCLElBQUksTUFBTSxNQUFNLE9BQU8sVUFBVSxJQUFJO0dBQ3JDLFFBQVEsTUFBTSxJQUFJLFVBQVUsUUFBUSxNQUFNLElBQUksV0FBVyxTQUFTLElBQUksR0FBRyxHQUFHO0VBQzdFO0VBQ0EsS0FBSyxvQkFBb0IsS0FBSyxTQUFTLEtBQUssV0FBVyxPQUFPLGtCQUFrQixJQUFJO09BQy9FLEtBQUssb0JBQW9CLEtBQUssU0FBUyxLQUFLLFdBQVcsU0FBUztHQUNwRSxNQUFNLFVBQVU7R0FDaEIsVUFBVTtHQUNWLGlCQUFpQixhQUFhLE1BQU0sVUFBVSxFQUFFLEdBQUcsS0FBSztHQUN4RCxVQUFVO0VBQ1g7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxXQUFXLElBQUksTUFBTTtDQUM3QixJQUFJLFNBQVMsT0FBTyxHQUFHO0NBQ3ZCLElBQUksT0FBTztDQUNYLElBQUksQ0FBQyxNQUFNLFVBQVUsQ0FBQztDQUN0QixJQUFJLFNBQVMsT0FBTztNQUNmLFVBQVUsQ0FBQztDQUNoQjtDQUNBLElBQUk7RUFDSCxNQUFNLE1BQU0sR0FBRztFQUNmLGdCQUFnQixJQUFJO0VBQ3BCLE9BQU87Q0FDUixTQUFTLEtBQUs7RUFDYixJQUFJLENBQUMsTUFBTSxVQUFVO0VBQ3JCLFVBQVU7RUFDVixZQUFZLEdBQUc7Q0FDaEI7QUFDRDtBQUNBLFNBQVMsZ0JBQWdCLE1BQU07Q0FDOUIsSUFBSSxTQUFTO0VBQ1osU0FBUyxPQUFPO0VBQ2hCLFVBQVU7Q0FDWDtDQUNBLElBQUksTUFBTTtDQUNWLElBQUk7Q0FDSixJQUFJLFlBQVk7RUFDZixJQUFJLENBQUMsV0FBVyxTQUFTLFFBQVEsQ0FBQyxXQUFXLE1BQU0sTUFBTTtHQUN4RCxNQUFNLFVBQVUsV0FBVztHQUMzQixNQUFNLFdBQVcsV0FBVztHQUM1QixRQUFRLEtBQUssTUFBTSxTQUFTLFdBQVcsT0FBTztHQUM5QyxNQUFNLFdBQVc7R0FDakIsS0FBSyxNQUFNLEtBQUssU0FBUztJQUN4QixZQUFZLE1BQU0sRUFBRSxRQUFRLEVBQUU7SUFDOUIsT0FBTyxFQUFFO0dBQ1Y7R0FDQSxhQUFhO0dBQ2IsaUJBQWlCO0lBQ2hCLEtBQUssTUFBTSxLQUFLLFVBQVUsVUFBVSxDQUFDO0lBQ3JDLEtBQUssTUFBTSxLQUFLLFNBQVM7S0FDeEIsRUFBRSxRQUFRLEVBQUU7S0FDWixJQUFJLEVBQUUsT0FBTyxLQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sRUFBRSxNQUFNLFFBQVEsSUFBSSxLQUFLLEtBQUssVUFBVSxFQUFFLE1BQU0sRUFBRTtLQUNyRixJQUFJLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRTtLQUMxQixPQUFPLEVBQUU7S0FDVCxPQUFPLEVBQUU7S0FDVCxFQUFFLFNBQVM7SUFDWjtJQUNBLGdCQUFnQixLQUFLO0dBQ3RCLEdBQUcsS0FBSztFQUNULE9BQU8sSUFBSSxXQUFXLFNBQVM7R0FDOUIsV0FBVyxVQUFVO0dBQ3JCLFdBQVcsUUFBUSxLQUFLLE1BQU0sV0FBVyxTQUFTLE9BQU87R0FDekQsVUFBVTtHQUNWLGdCQUFnQixJQUFJO0dBQ3BCO0VBQ0Q7Q0FDRDtDQUNBLE1BQU0sSUFBSTtDQUNWLFVBQVU7Q0FDVixJQUFJLEVBQUUsUUFBUSxpQkFBaUIsV0FBVyxDQUFDLEdBQUcsS0FBSztDQUNuRCxJQUFJLEtBQUssSUFBSTtBQUNkO0FBQ0EsU0FBUyxTQUFTLE9BQU87Q0FDeEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLLE9BQU8sTUFBTSxFQUFFO0FBQ3ZEO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDOUIsSUFBSSxHQUFHLGFBQWE7Q0FDcEIsS0FBSyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztFQUNsQyxNQUFNLElBQUksTUFBTTtFQUNoQixJQUFJLENBQUMsRUFBRSxNQUFNLE9BQU8sQ0FBQztPQUNoQixNQUFNLGdCQUFnQjtDQUM1QjtDQUNBLElBQUksYUFBYSxTQUFTO0VBQ3pCLElBQUksYUFBYSxPQUFPO0dBQ3ZCLGFBQWEsWUFBWSxhQUFhLFVBQVUsQ0FBQztHQUNqRCxhQUFhLFFBQVEsS0FBSyxHQUFHLE1BQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQztHQUN2RDtFQUNEO0VBQ0Esa0JBQWtCO0NBQ25CO0NBQ0EsSUFBSSxhQUFhLFlBQVksYUFBYSxRQUFRLENBQUMsYUFBYSxRQUFRO0VBQ3ZFLFFBQVEsQ0FBQyxHQUFHLGFBQWEsU0FBUyxHQUFHLEtBQUs7RUFDMUMsY0FBYyxhQUFhLFFBQVE7RUFDbkMsT0FBTyxhQUFhO0NBQ3JCO0NBQ0EsS0FBSyxJQUFJLEdBQUcsSUFBSSxZQUFZLEtBQUssT0FBTyxNQUFNLEVBQUU7QUFDakQ7QUFDQSxTQUFTLGFBQWEsTUFBTSxRQUFRO0NBQ25DLE1BQU0sb0JBQW9CLGNBQWMsV0FBVztDQUNuRCxJQUFJLG1CQUFtQixLQUFLLFNBQVM7TUFDaEMsS0FBSyxRQUFRO0NBQ2xCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsUUFBUSxLQUFLLEdBQUc7RUFDaEQsTUFBTSxTQUFTLEtBQUssUUFBUTtFQUM1QixJQUFJLE9BQU8sU0FBUztHQUNuQixNQUFNLFFBQVEsb0JBQW9CLE9BQU8sU0FBUyxPQUFPO0dBQ3pELElBQUksVUFBVSxPQUNUO1FBQUEsV0FBVyxXQUFXLENBQUMsT0FBTyxhQUFhLE9BQU8sWUFBWSxZQUFZLE9BQU8sTUFBTTtHQUFBLE9BQ3JGLElBQUksVUFBVSxTQUFTLGFBQWEsUUFBUSxNQUFNO0VBQzFEO0NBQ0Q7QUFDRDtBQUNBLFNBQVMsZUFBZSxNQUFNO0NBQzdCLE1BQU0sb0JBQW9CLGNBQWMsV0FBVztDQUNuRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxVQUFVLFFBQVEsS0FBSyxHQUFHO0VBQ2xELE1BQU0sSUFBSSxLQUFLLFVBQVU7RUFDekIsSUFBSSxvQkFBb0IsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxFQUFFLE9BQU87R0FDN0MsSUFBSSxtQkFBbUIsRUFBRSxTQUFTO1FBQzdCLEVBQUUsUUFBUTtHQUNmLElBQUksRUFBRSxNQUFNLFFBQVEsS0FBSyxDQUFDO1FBQ3JCLFFBQVEsS0FBSyxDQUFDO0dBQ25CLEVBQUUsYUFBYSxlQUFlLENBQUM7RUFDaEM7Q0FDRDtBQUNEO0FBQ0EsU0FBUyx3QkFBd0IsTUFBTTtDQUN0QyxJQUFJLGNBQWMsV0FBVyxRQUFRLElBQUksSUFBSSxHQUFHO0VBQy9DLFdBQVcsUUFBUSxPQUFPLElBQUk7RUFDOUIsT0FBTyxLQUFLO0NBQ2I7QUFDRDtBQUNBLFNBQVMsVUFBVSxNQUFNLFdBQVc7Q0FDbkMsSUFBSTtDQUNKLElBQUksS0FBSyxTQUFTLE9BQU8sS0FBSyxRQUFRLFFBQVE7RUFDN0MsTUFBTSxTQUFTLEtBQUssUUFBUSxJQUFJLEdBQUcsUUFBUSxLQUFLLFlBQVksSUFBSSxHQUFHLE1BQU0sT0FBTztFQUNoRixJQUFJLE9BQU8sSUFBSSxRQUFRO0dBQ3RCLElBQUksQ0FBQyxPQUFPLGlCQUFpQixPQUFPLGNBQWMsV0FBVyxJQUFJLFFBQVEsb0JBQW9CLE1BQU07R0FDbkcsTUFBTSxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxjQUFjLElBQUk7R0FDbEQsSUFBSSxRQUFRLElBQUksUUFBUTtJQUN2QixFQUFFLFlBQVksS0FBSztJQUNuQixJQUFJLFNBQVM7SUFDYixPQUFPLGNBQWMsU0FBUztHQUMvQjtFQUNEO0VBQ0EsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxXQUFXLFlBQVksd0JBQXdCLE1BQU07Q0FDdEY7Q0FDQSxJQUFJLEtBQUssUUFBUTtFQUNoQixLQUFLLElBQUksS0FBSyxPQUFPLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSyxVQUFVLEtBQUssT0FBTyxFQUFFO0VBQ3RFLE9BQU8sS0FBSztDQUNiO0NBQ0EsSUFBSSxjQUFjLFdBQVcsV0FBVyxLQUFLLE1BQU0sTUFBTSxNQUFNLElBQUk7TUFDOUQsSUFBSSxLQUFLLE9BQU87RUFDcEIsS0FBSyxJQUFJLEtBQUssTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUssVUFBVSxLQUFLLE1BQU0sRUFBRTtFQUNwRSxLQUFLLFFBQVE7Q0FDZDtDQUNBLElBQUksQ0FBQyxXQUFXLHdCQUF3QixJQUFJO0NBQzVDLElBQUksS0FBSyxVQUFVO0VBQ2xCLEtBQUssSUFBSSxLQUFLLFNBQVMsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLLEtBQUssU0FBUyxFQUFFLENBQUM7RUFDakUsS0FBSyxXQUFXO0NBQ2pCO0NBQ0EsSUFBSSxjQUFjLFdBQVcsU0FBUyxLQUFLLFNBQVM7TUFDL0MsS0FBSyxRQUFRO0FBQ25CO0FBQ0EsU0FBUyxNQUFNLE1BQU0sS0FBSztDQUN6QixJQUFJLENBQUMsS0FBSztFQUNULEtBQUssU0FBUztFQUNkLFdBQVcsU0FBUyxJQUFJLElBQUk7RUFDNUIsd0JBQXdCLElBQUk7Q0FDN0I7Q0FDQSxJQUFJLEtBQUssT0FBTyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxNQUFNLFFBQVEsS0FBSyxNQUFNLEtBQUssTUFBTSxFQUFFO0FBQ2hGO0FBQ0EsU0FBUyxVQUFVLEtBQUs7Q0FDdkIsSUFBSSxlQUFlLE9BQU8sT0FBTztDQUNqQyxPQUFPLElBQUksTUFBTSxPQUFPLFFBQVEsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sSUFBSSxDQUFDO0FBQ2pGO0FBQ0EsU0FBUyxZQUFZLEtBQUssUUFBUSxPQUFPO0NBQ3hDLE1BQU0sVUFBVSxHQUFHO0FBQ3BCO0FBQ0EsU0FBUyxnQkFBZ0IsVUFBVTtDQUNsQyxJQUFJLE9BQU8sYUFBYSxjQUFjLENBQUMsU0FBUyxRQUFRLE9BQU8sZ0JBQWdCLFNBQVMsQ0FBQztDQUN6RixJQUFJLE1BQU0sUUFBUSxRQUFRLEdBQUc7RUFDNUIsTUFBTSxVQUFVLENBQUM7RUFDakIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0dBQ3pDLE1BQU0sU0FBUyxnQkFBZ0IsU0FBUyxFQUFFO0dBQzFDLElBQUksTUFBTSxRQUFRLE1BQU0sR0FBRztJQUMxQixJQUFJLE9BQU8sU0FBUyxPQUFPLFFBQVEsS0FBSyxNQUFNLFNBQVMsTUFBTTtTQUN4RCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUssUUFBUSxLQUFLLE9BQU8sRUFBRTtHQUNwRSxPQUFPLFFBQVEsS0FBSyxNQUFNO0VBQzNCO0VBQ0EsT0FBTztDQUNSO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxlQUFlLElBQUksU0FBUztDQUNwQyxPQUFPLFNBQVMsU0FBUyxPQUFPO0VBQy9CLElBQUk7RUFDSix5QkFBeUIsTUFBTSxjQUFjO0dBQzVDLE1BQU0sVUFBVTtJQUNmLEdBQUcsTUFBTTtLQUNSLEtBQUssTUFBTTtHQUNiO0dBQ0EsT0FBTyxlQUFlLE1BQU0sUUFBUTtFQUNyQyxDQUFDLEdBQUcsS0FBSyxDQUFDO0VBQ1YsT0FBTztDQUNSO0FBQ0Q7QUFDQSxJQUFNLFdBQVcsT0FBTyxVQUFVO0FBQ2xDLFNBQVMsUUFBUSxHQUFHO0NBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSyxFQUFFLEVBQUUsQ0FBQztBQUN6QztBQUNBLFNBQVMsU0FBUyxNQUFNLE9BQU8sVUFBVSxDQUFDLEdBQUc7Q0FDNUMsSUFBSSxRQUFRLENBQUMsR0FBRyxTQUFTLENBQUMsR0FBRyxZQUFZLENBQUMsR0FBRyxNQUFNLEdBQUcsVUFBVSxNQUFNLFNBQVMsSUFBSSxDQUFDLElBQUk7Q0FDeEYsZ0JBQWdCLFFBQVEsU0FBUyxDQUFDO0NBQ2xDLGFBQWE7RUFDWixJQUFJLFdBQVcsS0FBSyxLQUFLLENBQUMsR0FBRyxTQUFTLFNBQVMsUUFBUSxHQUFHO0VBQzFELFNBQVM7RUFDVCxPQUFPLGNBQWM7R0FDcEIsSUFBSSxZQUFZLGdCQUFnQixNQUFNLGVBQWUsYUFBYSxPQUFPLEtBQUssUUFBUTtHQUN0RixJQUFJLFdBQVcsR0FBRztJQUNqQixJQUFJLFFBQVEsR0FBRztLQUNkLFFBQVEsU0FBUztLQUNqQixZQUFZLENBQUM7S0FDYixRQUFRLENBQUM7S0FDVCxTQUFTLENBQUM7S0FDVixNQUFNO0tBQ04sWUFBWSxVQUFVLENBQUM7SUFDeEI7SUFDQSxJQUFJLFFBQVEsVUFBVTtLQUNyQixRQUFRLENBQUMsUUFBUTtLQUNqQixPQUFPLEtBQUssWUFBWSxhQUFhO01BQ3BDLFVBQVUsS0FBSztNQUNmLE9BQU8sUUFBUSxTQUFTO0tBQ3pCLENBQUM7S0FDRCxNQUFNO0lBQ1A7R0FDRCxPQUFPLElBQUksUUFBUSxHQUFHO0lBQ3JCLFNBQVMsSUFBSSxNQUFNLE1BQU07SUFDekIsS0FBSyxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7S0FDNUIsTUFBTSxLQUFLLFNBQVM7S0FDcEIsT0FBTyxLQUFLLFdBQVcsTUFBTTtJQUM5QjtJQUNBLE1BQU07R0FDUCxPQUFPO0lBQ04sT0FBTyxJQUFJLE1BQU0sTUFBTTtJQUN2QixnQkFBZ0IsSUFBSSxNQUFNLE1BQU07SUFDaEMsWUFBWSxjQUFjLElBQUksTUFBTSxNQUFNO0lBQzFDLEtBQUssUUFBUSxHQUFHLE1BQU0sS0FBSyxJQUFJLEtBQUssTUFBTSxHQUFHLFFBQVEsT0FBTyxNQUFNLFdBQVcsU0FBUyxRQUFRO0lBQzlGLEtBQUssTUFBTSxNQUFNLEdBQUcsU0FBUyxTQUFTLEdBQUcsT0FBTyxTQUFTLFVBQVUsU0FBUyxNQUFNLFNBQVMsU0FBUyxTQUFTLE9BQU8sVUFBVTtLQUM3SCxLQUFLLFVBQVUsT0FBTztLQUN0QixjQUFjLFVBQVUsVUFBVTtLQUNsQyxZQUFZLFlBQVksVUFBVSxRQUFRO0lBQzNDO0lBQ0EsNkJBQTZCLElBQUksSUFBSTtJQUNyQyxpQkFBaUIsSUFBSSxNQUFNLFNBQVMsQ0FBQztJQUNyQyxLQUFLLElBQUksUUFBUSxLQUFLLE9BQU8sS0FBSztLQUNqQyxPQUFPLFNBQVM7S0FDaEIsSUFBSSxXQUFXLElBQUksSUFBSTtLQUN2QixlQUFlLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSztLQUN4QyxXQUFXLElBQUksTUFBTSxDQUFDO0lBQ3ZCO0lBQ0EsS0FBSyxJQUFJLE9BQU8sS0FBSyxLQUFLLEtBQUs7S0FDOUIsT0FBTyxNQUFNO0tBQ2IsSUFBSSxXQUFXLElBQUksSUFBSTtLQUN2QixJQUFJLE1BQU0sS0FBSyxLQUFLLE1BQU0sSUFBSTtNQUM3QixLQUFLLEtBQUssT0FBTztNQUNqQixjQUFjLEtBQUssVUFBVTtNQUM3QixZQUFZLFlBQVksS0FBSyxRQUFRO01BQ3JDLElBQUksZUFBZTtNQUNuQixXQUFXLElBQUksTUFBTSxDQUFDO0tBQ3ZCLE9BQU8sVUFBVSxFQUFFLENBQUM7SUFDckI7SUFDQSxLQUFLLElBQUksT0FBTyxJQUFJLFFBQVEsS0FBSyxJQUFJLEtBQUssTUFBTTtLQUMvQyxPQUFPLEtBQUssS0FBSztLQUNqQixVQUFVLEtBQUssY0FBYztLQUM3QixJQUFJLFNBQVM7TUFDWixRQUFRLEtBQUssWUFBWTtNQUN6QixRQUFRLEVBQUUsQ0FBQyxDQUFDO0tBQ2I7SUFDRCxPQUFPLE9BQU8sS0FBSyxXQUFXLE1BQU07SUFDcEMsU0FBUyxPQUFPLE1BQU0sR0FBRyxNQUFNLE1BQU07SUFDckMsUUFBUSxTQUFTLE1BQU0sQ0FBQztHQUN6QjtHQUNBLE9BQU87RUFDUixDQUFDO0VBQ0QsU0FBUyxPQUFPLFVBQVU7R0FDekIsVUFBVSxLQUFLO0dBQ2YsSUFBSSxTQUFTO0lBQ1osTUFBTSxDQUFDLEdBQUcsT0FBTyxhQUFhLENBQUM7SUFDL0IsUUFBUSxLQUFLO0lBQ2IsT0FBTyxNQUFNLFNBQVMsSUFBSSxDQUFDO0dBQzVCO0dBQ0EsT0FBTyxNQUFNLFNBQVMsRUFBRTtFQUN6QjtDQUNEO0FBQ0Q7QUFDQSxTQUFTLFdBQVcsTUFBTSxPQUFPLFVBQVUsQ0FBQyxHQUFHO0NBQzlDLElBQUksUUFBUSxDQUFDLEdBQUcsU0FBUyxDQUFDLEdBQUcsWUFBWSxDQUFDLEdBQUcsVUFBVSxDQUFDLEdBQUcsTUFBTSxHQUFHO0NBQ3BFLGdCQUFnQixRQUFRLFNBQVMsQ0FBQztDQUNsQyxhQUFhO0VBQ1osTUFBTSxXQUFXLEtBQUssS0FBSyxDQUFDLEdBQUcsU0FBUyxTQUFTO0VBQ2pELFNBQVM7RUFDVCxPQUFPLGNBQWM7R0FDcEIsSUFBSSxXQUFXLEdBQUc7SUFDakIsSUFBSSxRQUFRLEdBQUc7S0FDZCxRQUFRLFNBQVM7S0FDakIsWUFBWSxDQUFDO0tBQ2IsUUFBUSxDQUFDO0tBQ1QsU0FBUyxDQUFDO0tBQ1YsTUFBTTtLQUNOLFVBQVUsQ0FBQztJQUNaO0lBQ0EsSUFBSSxRQUFRLFVBQVU7S0FDckIsUUFBUSxDQUFDLFFBQVE7S0FDakIsT0FBTyxLQUFLLFlBQVksYUFBYTtNQUNwQyxVQUFVLEtBQUs7TUFDZixPQUFPLFFBQVEsU0FBUztLQUN6QixDQUFDO0tBQ0QsTUFBTTtJQUNQO0lBQ0EsT0FBTztHQUNSO0dBQ0EsSUFBSSxNQUFNLE9BQU8sVUFBVTtJQUMxQixVQUFVLEVBQUUsQ0FBQztJQUNiLFlBQVksQ0FBQztJQUNiLFFBQVEsQ0FBQztJQUNULFNBQVMsQ0FBQztJQUNWLE1BQU07R0FDUDtHQUNBLEtBQUssSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLLElBQUksSUFBSSxNQUFNLFVBQVUsTUFBTSxPQUFPLFNBQVMsSUFBSSxRQUFRLEVBQUUsT0FBTyxTQUFTLEVBQUU7UUFDdEcsSUFBSSxLQUFLLE1BQU0sUUFBUSxPQUFPLEtBQUssV0FBVyxNQUFNO0dBQ3pELE9BQU8sSUFBSSxNQUFNLFFBQVEsS0FBSyxVQUFVLEVBQUUsQ0FBQztHQUMzQyxNQUFNLFFBQVEsU0FBUyxVQUFVLFNBQVM7R0FDMUMsUUFBUSxTQUFTLE1BQU0sQ0FBQztHQUN4QixPQUFPLFNBQVMsT0FBTyxNQUFNLEdBQUcsR0FBRztFQUNwQyxDQUFDO0VBQ0QsU0FBUyxPQUFPLFVBQVU7R0FDekIsVUFBVSxLQUFLO0dBQ2YsTUFBTSxDQUFDLEdBQUcsT0FBTyxhQUFhLFNBQVMsRUFBRTtHQUN6QyxRQUFRLEtBQUs7R0FDYixPQUFPLE1BQU0sR0FBRyxDQUFDO0VBQ2xCO0NBQ0Q7QUFDRDtBQUNBLFNBQVMsZ0JBQWdCLE1BQU0sT0FBTztDQUNyQyxPQUFPLGNBQWMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDO0FBQ0EsU0FBUyxTQUFTO0NBQ2pCLE9BQU87QUFDUjtBQUNBLElBQU0sWUFBWTtDQUNqQixJQUFJLEdBQUcsVUFBVSxVQUFVO0VBQzFCLElBQUksYUFBYSxRQUFRLE9BQU87RUFDaEMsT0FBTyxFQUFFLElBQUksUUFBUTtDQUN0QjtDQUNBLElBQUksR0FBRyxVQUFVO0VBQ2hCLElBQUksYUFBYSxRQUFRLE9BQU87RUFDaEMsT0FBTyxFQUFFLElBQUksUUFBUTtDQUN0QjtDQUNBLEtBQUs7Q0FDTCxnQkFBZ0I7Q0FDaEIseUJBQXlCLEdBQUcsVUFBVTtFQUNyQyxPQUFPO0dBQ04sY0FBYztHQUNkLFlBQVk7R0FDWixNQUFNO0lBQ0wsT0FBTyxFQUFFLElBQUksUUFBUTtHQUN0QjtHQUNBLEtBQUs7R0FDTCxnQkFBZ0I7RUFDakI7Q0FDRDtDQUNBLFFBQVEsR0FBRztFQUNWLE9BQU8sRUFBRSxLQUFLO0NBQ2Y7QUFDRDtBQUNBLFNBQVMsY0FBYyxHQUFHO0NBQ3pCLE9BQU8sRUFBRSxJQUFJLE9BQU8sTUFBTSxhQUFhLEVBQUUsSUFBSSxLQUFLLENBQUMsSUFBSTtBQUN4RDtBQUNBLFNBQVMsaUJBQWlCO0NBQ3pCLEtBQUssSUFBSSxJQUFJLEdBQUcsU0FBUyxLQUFLLFFBQVEsSUFBSSxRQUFRLEVBQUUsR0FBRztFQUN0RCxNQUFNLElBQUksS0FBSyxFQUFFLENBQUM7RUFDbEIsSUFBSSxNQUFNLEtBQUssR0FBRyxPQUFPO0NBQzFCO0FBQ0Q7QUFDQSxTQUFTLFdBQVcsR0FBRyxTQUFTO0NBQy9CLElBQUksUUFBUTtDQUNaLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztFQUN4QyxNQUFNLElBQUksUUFBUTtFQUNsQixRQUFRLFNBQVMsQ0FBQyxDQUFDLEtBQUssVUFBVTtFQUNsQyxRQUFRLEtBQUssT0FBTyxNQUFNLGNBQWMsUUFBUSxNQUFNLFdBQVcsQ0FBQyxLQUFLO0NBQ3hFO0NBQ0EsSUFBSSxrQkFBa0IsT0FBTyxPQUFPLElBQUksTUFBTTtFQUM3QyxJQUFJLFVBQVU7R0FDYixLQUFLLElBQUksSUFBSSxRQUFRLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztJQUM3QyxNQUFNLElBQUksY0FBYyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQ3BDLElBQUksTUFBTSxLQUFLLEdBQUcsT0FBTztHQUMxQjtFQUNEO0VBQ0EsSUFBSSxVQUFVO0dBQ2IsS0FBSyxJQUFJLElBQUksUUFBUSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUssSUFBSSxZQUFZLGNBQWMsUUFBUSxFQUFFLEdBQUcsT0FBTztHQUNoRyxPQUFPO0VBQ1I7RUFDQSxPQUFPO0dBQ04sTUFBTSxPQUFPLENBQUM7R0FDZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUssS0FBSyxLQUFLLEdBQUcsT0FBTyxLQUFLLGNBQWMsUUFBUSxFQUFFLENBQUMsQ0FBQztHQUM1RixPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksSUFBSSxDQUFDO0VBQ3pCO0NBQ0QsR0FBRyxTQUFTO0NBQ1osTUFBTSxhQUFhLENBQUM7Q0FDcEIsTUFBTSxVQUFVLE9BQU8sT0FBTyxJQUFJO0NBQ2xDLEtBQUssSUFBSSxJQUFJLFFBQVEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0VBQzdDLE1BQU0sU0FBUyxRQUFRO0VBQ3ZCLElBQUksQ0FBQyxRQUFRO0VBQ2IsTUFBTSxhQUFhLE9BQU8sb0JBQW9CLE1BQU07RUFDcEQsS0FBSyxJQUFJLElBQUksV0FBVyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7R0FDaEQsTUFBTSxNQUFNLFdBQVc7R0FDdkIsSUFBSSxRQUFRLGVBQWUsUUFBUSxlQUFlO0dBQ2xELE1BQU0sT0FBTyxPQUFPLHlCQUF5QixRQUFRLEdBQUc7R0FDeEQsSUFBSSxDQUFDLFFBQVEsTUFBTSxRQUFRLE9BQU8sS0FBSyxNQUFNO0lBQzVDLFlBQVk7SUFDWixjQUFjO0lBQ2QsS0FBSyxlQUFlLEtBQUssV0FBVyxPQUFPLENBQUMsS0FBSyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUM7R0FDbkUsSUFBSSxLQUFLLFVBQVUsS0FBSyxJQUFJLE9BQU8sS0FBSztRQUNuQztJQUNKLE1BQU0sVUFBVSxXQUFXO0lBQzNCLElBQUksU0FBUztLQUNaLElBQUksS0FBSyxLQUFLLFFBQVEsS0FBSyxLQUFLLElBQUksS0FBSyxNQUFNLENBQUM7VUFDM0MsSUFBSSxLQUFLLFVBQVUsS0FBSyxHQUFHLFFBQVEsV0FBVyxLQUFLLEtBQUs7SUFDOUQ7R0FDRDtFQUNEO0NBQ0Q7Q0FDQSxNQUFNLFNBQVMsQ0FBQztDQUNoQixNQUFNLGNBQWMsT0FBTyxLQUFLLE9BQU87Q0FDdkMsS0FBSyxJQUFJLElBQUksWUFBWSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7RUFDakQsTUFBTSxNQUFNLFlBQVksSUFBSSxPQUFPLFFBQVE7RUFDM0MsSUFBSSxRQUFRLEtBQUssS0FBSyxPQUFPLGVBQWUsUUFBUSxLQUFLLElBQUk7T0FDeEQsT0FBTyxPQUFPLE9BQU8sS0FBSyxRQUFRLEtBQUs7Q0FDN0M7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLFdBQVcsT0FBTyxHQUFHLE1BQU07Q0FDbkMsTUFBTSxNQUFNLEtBQUs7Q0FDakIsSUFBSSxrQkFBa0IsVUFBVSxPQUFPO0VBQ3RDLE1BQU0sVUFBVSxNQUFNLElBQUksS0FBSyxLQUFLLElBQUksS0FBSztFQUM3QyxNQUFNLDBCQUEwQixJQUFJLElBQUk7RUFDeEMsTUFBTSxNQUFNLEtBQUssS0FBSyxNQUFNO0dBQzNCLE1BQU0sUUFBUSxFQUFFLFFBQVEsYUFBYSxDQUFDLFFBQVEsSUFBSSxRQUFRLE1BQU0sUUFBUSxJQUFJLFFBQVEsR0FBRyxLQUFLO0dBQzVGLE9BQU8sSUFBSSxNQUFNO0lBQ2hCLElBQUksVUFBVTtLQUNiLE9BQU8sTUFBTSxTQUFTLFFBQVEsSUFBSSxNQUFNLFlBQVksS0FBSztJQUMxRDtJQUNBLElBQUksVUFBVTtLQUNiLE9BQU8sTUFBTSxTQUFTLFFBQVEsS0FBSyxZQUFZO0lBQ2hEO0lBQ0EsT0FBTztLQUNOLE9BQU8sTUFBTSxRQUFRLGFBQWEsWUFBWSxLQUFLO0lBQ3BEO0dBQ0QsR0FBRyxTQUFTO0VBQ2IsQ0FBQztFQUNELElBQUksS0FBSyxJQUFJLE1BQU07R0FDbEIsSUFBSSxVQUFVO0lBQ2IsT0FBTyxRQUFRLFNBQVMsUUFBUSxJQUFJLEtBQUssSUFBSSxNQUFNO0dBQ3BEO0dBQ0EsSUFBSSxVQUFVO0lBQ2IsT0FBTyxRQUFRLFNBQVMsUUFBUSxJQUFJLFFBQVEsWUFBWTtHQUN6RDtHQUNBLE9BQU87SUFDTixPQUFPLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxRQUFRLE1BQU0sQ0FBQyxRQUFRLFNBQVMsQ0FBQyxDQUFDO0dBQzdEO0VBQ0QsR0FBRyxTQUFTLENBQUM7RUFDYixPQUFPO0NBQ1I7Q0FDQSxNQUFNLFVBQVUsQ0FBQztDQUNqQixLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssS0FBSyxLQUFLLFFBQVEsS0FBSyxDQUFDO0NBQzdDLEtBQUssTUFBTSxZQUFZLE9BQU8sb0JBQW9CLEtBQUssR0FBRztFQUN6RCxJQUFJLFdBQVc7RUFDZixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUssSUFBSSxLQUFLLEVBQUUsQ0FBQyxTQUFTLFFBQVEsR0FBRztHQUNyRSxXQUFXO0dBQ1g7RUFDRDtFQUNBLE1BQU0sT0FBTyxPQUFPLHlCQUF5QixPQUFPLFFBQVE7RUFDNUQsQ0FBQyxLQUFLLE9BQU8sQ0FBQyxLQUFLLE9BQU8sS0FBSyxjQUFjLEtBQUssWUFBWSxLQUFLLGVBQWUsUUFBUSxTQUFTLENBQUMsWUFBWSxLQUFLLFFBQVEsT0FBTyxlQUFlLFFBQVEsV0FBVyxVQUFVLElBQUk7Q0FDckw7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLEtBQUssSUFBSTtDQUNqQixJQUFJO0NBQ0osSUFBSTtDQUNKLE1BQU0sYUFBYTtFQUNsQixJQUFJLENBQUMsR0FBRztHQUNQLE1BQU0sTUFBTSxJQUFJLEdBQUc7R0FDbkIsSUFBSSxNQUFNLFFBQVE7SUFDakIsYUFBYSxJQUFJO0dBQ2xCLFNBQVM7SUFDUixJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUs7R0FDekIsQ0FBQztFQUNGO0VBQ0EsT0FBTztDQUNSO0NBQ0EsTUFBTSxRQUFRLFVBQVU7RUFDdkIsTUFBTSxNQUFNLGFBQWE7RUFDekIsSUFBSSxLQUFLO0dBQ1IsTUFBTSxDQUFDLEdBQUcsT0FBTyxhQUFhO0dBQzlCLGFBQWEsVUFBVSxhQUFhLFFBQVE7R0FDNUMsYUFBYTtHQUNiLEtBQUssQ0FBQyxDQUFDLE1BQU0sUUFBUTtJQUNwQixDQUFDLGFBQWEsUUFBUSxrQkFBa0IsR0FBRztJQUMzQyxhQUFhO0lBQ2IsVUFBVSxJQUFJLE9BQU87SUFDckIsa0JBQWtCO0dBQ25CLElBQUksUUFBUTtJQUNYLENBQUMsYUFBYSxRQUFRLGtCQUFrQixHQUFHO0lBQzNDLGFBQWE7SUFDYixnQkFBZ0I7S0FDZixNQUFNO0lBQ1AsQ0FBQztJQUNELGtCQUFrQjtHQUNuQixDQUFDO0dBQ0QsT0FBTztFQUNSLE9BQU8sSUFBSSxDQUFDLE1BQU07R0FDakIsTUFBTSxDQUFDLEtBQUsscUJBQXFCLEtBQUssQ0FBQyxDQUFDLE1BQU0sUUFBUSxJQUFJLE9BQU8sQ0FBQztHQUNsRSxPQUFPO0dBQ1AsZ0JBQWdCO0lBQ2YsSUFBSSxTQUFTLEdBQUcsT0FBTyxLQUFLO0dBQzdCLENBQUM7RUFDRjtFQUNBLElBQUk7RUFDSixPQUFPLGtCQUFrQixPQUFPLE9BQU8sS0FBSyxjQUFjO0dBQ3pELElBQUksQ0FBQyxPQUFPLGFBQWEsTUFBTSxPQUFPLEtBQUssS0FBSztHQUNoRCxNQUFNLElBQUksYUFBYTtHQUN2QixrQkFBa0IsR0FBRztHQUNyQixNQUFNLElBQUksS0FBSyxLQUFLO0dBQ3BCLGtCQUFrQixDQUFDO0dBQ25CLE9BQU87RUFDUixDQUFDLElBQUksRUFBRTtDQUNSO0NBQ0EsS0FBSyxnQkFBZ0IsS0FBSztDQUMxQixPQUFPO0FBQ1I7QUFDQSxJQUFJLFVBQVU7QUFDZCxTQUFTLGlCQUFpQjtDQUN6QixPQUFPLGFBQWEsVUFBVSxhQUFhLGlCQUFpQixJQUFJLE1BQU07QUFDdkU7QUFDQSxJQUFNLGlCQUFpQixTQUFTLG9CQUFvQixLQUFLO0FBQ3pELFNBQVMsSUFBSSxPQUFPO0NBQ25CLE1BQU0sV0FBVyxjQUFjLFNBQVMsRUFBRSxnQkFBZ0IsTUFBTSxTQUFTO0NBQ3pFLE9BQU8sV0FBVyxlQUFlLE1BQU0sTUFBTSxNQUFNLFVBQVUsWUFBWSxLQUFLLENBQUMsQ0FBQztBQUNqRjtBQUNBLFNBQVMsTUFBTSxPQUFPO0NBQ3JCLE1BQU0sV0FBVyxjQUFjLFNBQVMsRUFBRSxnQkFBZ0IsTUFBTSxTQUFTO0NBQ3pFLE9BQU8sV0FBVyxpQkFBaUIsTUFBTSxNQUFNLE1BQU0sVUFBVSxZQUFZLEtBQUssQ0FBQyxDQUFDO0FBQ25GO0FBQ0EsU0FBUyxLQUFLLE9BQU87Q0FDcEIsTUFBTSxRQUFRLE1BQU07Q0FDcEIsTUFBTSxpQkFBaUIsaUJBQWlCLE1BQU0sTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDO0NBQ2xFLE1BQU0sWUFBWSxRQUFRLGlCQUFpQixXQUFXLGdCQUFnQixLQUFLLEdBQUcsRUFBRSxTQUFTLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7Q0FDN0csT0FBTyxpQkFBaUI7RUFDdkIsTUFBTSxJQUFJLFVBQVU7RUFDcEIsSUFBSSxHQUFHO0dBQ04sTUFBTSxRQUFRLE1BQU07R0FDcEIsT0FBTyxPQUFPLFVBQVUsY0FBYyxNQUFNLFNBQVMsSUFBSSxjQUFjLE1BQU0sUUFBUSxVQUFVO0lBQzlGLElBQUksQ0FBQyxRQUFRLFNBQVMsR0FBRyxNQUFNLGNBQWMsTUFBTTtJQUNuRCxPQUFPLGVBQWU7R0FDdkIsQ0FBQyxDQUFDLElBQUk7RUFDUDtFQUNBLE9BQU8sTUFBTTtDQUNkLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztBQUNsQjtBQUNBLFNBQVMsT0FBTyxPQUFPO0NBQ3RCLE1BQU0sTUFBTSxlQUFlLE1BQU0sUUFBUTtDQUN6QyxNQUFNLGFBQWEsaUJBQWlCO0VBQ25DLE1BQU0sS0FBSyxJQUFJO0VBQ2YsTUFBTSxNQUFNLE1BQU0sUUFBUSxFQUFFLElBQUksS0FBSyxDQUFDLEVBQUU7RUFDeEMsSUFBSSxhQUFhLEtBQUs7RUFDdEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0dBQ3BDLE1BQU0sUUFBUTtHQUNkLE1BQU0sS0FBSyxJQUFJO0dBQ2YsTUFBTSxXQUFXO0dBQ2pCLE1BQU0saUJBQWlCLGlCQUFpQixTQUFTLElBQUksS0FBSyxJQUFJLEdBQUcsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDO0dBQ3JGLE1BQU0sWUFBWSxHQUFHLFFBQVEsaUJBQWlCLFdBQVcsZ0JBQWdCLEtBQUssR0FBRyxFQUFFLFNBQVMsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztHQUNoSCxhQUFhLFNBQVMsTUFBTSxVQUFVLElBQUk7SUFDekM7SUFDQTtJQUNBO0dBQ0QsSUFBSSxLQUFLO0VBQ1Y7RUFDQSxPQUFPO0NBQ1IsQ0FBQztDQUNELE9BQU8saUJBQWlCO0VBQ3ZCLE1BQU0sTUFBTSxXQUFXLENBQUMsQ0FBQztFQUN6QixJQUFJLENBQUMsS0FBSyxPQUFPLE1BQU07RUFDdkIsTUFBTSxDQUFDLE9BQU8sZ0JBQWdCLE1BQU07RUFDcEMsTUFBTSxRQUFRLEdBQUc7RUFDakIsT0FBTyxPQUFPLFVBQVUsY0FBYyxNQUFNLFNBQVMsSUFBSSxjQUFjLE1BQU0sR0FBRyxRQUFRLGVBQWUsVUFBVTtHQUNoSCxJQUFJLFFBQVEsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sT0FBTyxNQUFNLGNBQWMsT0FBTztHQUNyRSxPQUFPLGVBQWU7RUFDdkIsQ0FBQyxDQUFDLElBQUk7Q0FDUCxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7QUFDbEI7QUFDQSxTQUFTLE1BQU0sT0FBTztDQUNyQixPQUFPO0FBQ1I7QUFFQSxJQUFNLDJCQUEyQixJQUFJLElBQUk7Q0FDeEM7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNEO0FBQ0QsQ0FBQztBQUNELElBQU0sZ0NBQWdDLElBQUksSUFBSTtDQUM3QztDQUNBO0NBQ0E7Q0FDQTtBQUNELENBQUM7QUFDRCxJQUFNLFVBQXdCLHFCQUFPLE9BQU8sT0FBTyxPQUFPLElBQUksR0FBRztDQUNoRSxXQUFXO0NBQ1gsU0FBUztBQUNWLENBQUM7QUFDRCxJQUFNLGNBQTRCLHFCQUFPLE9BQU8sT0FBTyxPQUFPLElBQUksR0FBRztDQUNwRSxPQUFPO0NBQ1AsWUFBWTtFQUNYLEdBQUc7RUFDSCxNQUFNO0NBQ1A7Q0FDQSxnQkFBZ0I7RUFDZixHQUFHO0VBQ0gsUUFBUTtFQUNSLE9BQU87Q0FDUjtDQUNBLE9BQU87RUFDTixHQUFHO0VBQ0gsS0FBSztDQUNOO0NBQ0EsVUFBVTtFQUNULEdBQUc7RUFDSCxRQUFRO0NBQ1Q7Q0FDQSxhQUFhO0VBQ1osR0FBRztFQUNILE9BQU87Q0FDUjtDQUNBLFVBQVU7RUFDVCxHQUFHO0VBQ0gsT0FBTztFQUNQLFVBQVU7Q0FDWDtDQUNBLGtCQUFrQjtFQUNqQixHQUFHO0VBQ0gsUUFBUTtDQUNUO0NBQ0EsaUJBQWlCO0VBQ2hCLEdBQUc7RUFDSCxRQUFRO0NBQ1Q7Q0FDQSxnQkFBZ0I7RUFDZixHQUFHO0VBQ0gsS0FBSztDQUNOO0NBQ0EsZ0JBQWdCO0VBQ2YsR0FBRztFQUNILE9BQU87Q0FDUjtDQUNBLGNBQWM7RUFDYixHQUFHO0VBQ0gsT0FBTztFQUNQLE9BQU87Q0FDUjtDQUNBLGlCQUFpQjtFQUNoQixHQUFHO0VBQ0gsUUFBUTtDQUNUO0NBQ0EseUJBQXlCO0VBQ3hCLEdBQUc7RUFDSCxPQUFPO0NBQ1I7Q0FDQSx1QkFBdUI7RUFDdEIsR0FBRztFQUNILE9BQU87RUFDUCxPQUFPO0NBQ1I7Q0FDQSxnQkFBZ0I7RUFDZixHQUFHO0VBQ0gsT0FBTztFQUNQLE9BQU87Q0FDUjtDQUNBLG9CQUFvQjtFQUNuQixHQUFHO0VBQ0gsVUFBVTtDQUNYO0NBQ0EsMEJBQTBCO0VBQ3pCLEdBQUc7RUFDSCxVQUFVO0NBQ1g7Q0FDQSx3QkFBd0I7RUFDdkIsR0FBRztFQUNILFVBQVU7Q0FDWDtDQUNBLHVCQUF1QjtFQUN0QixHQUFHO0VBQ0gsUUFBUTtFQUNSLEtBQUs7Q0FDTjtBQUNELENBQUM7QUFDRCxTQUFTLGFBQWEsTUFBTSxTQUFTO0NBQ3BDLE1BQU0sSUFBSSxZQUFZO0NBQ3RCLE9BQU8sT0FBTyxNQUFNLFdBQVcsRUFBRSxXQUFXLEVBQUUsT0FBTyxLQUFLLElBQUk7QUFDL0Q7QUFDQSxJQUFNLGdDQUFnQyxJQUFJLElBQUk7Q0FDN0M7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRCxDQUFDO0FBQ0QsSUFBTSw0QkFBNEIsSUFBSSxJQUFJO0NBQ3pDO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRCxDQUFDO0FBQ0QsSUFBTSxlQUFlO0NBQ3BCLE9BQU87Q0FDUCxLQUFLO0FBQ047QUFDQSxJQUFNLFFBQVEsT0FBTyxpQkFBaUIsR0FBRyxDQUFDO0FBQzFDLFNBQVMsZ0JBQWdCLFlBQVksR0FBRyxHQUFHO0NBQzFDLElBQUksVUFBVSxFQUFFLFFBQVEsT0FBTyxFQUFFLFFBQVEsT0FBTyxTQUFTLFNBQVMsR0FBRyxTQUFTLEdBQUcsUUFBUSxFQUFFLE9BQU8sRUFBRSxDQUFDLGFBQWEsTUFBTTtDQUN4SCxPQUFPLFNBQVMsUUFBUSxTQUFTLE1BQU07RUFDdEMsSUFBSSxFQUFFLFlBQVksRUFBRSxTQUFTO0dBQzVCO0dBQ0E7R0FDQTtFQUNEO0VBQ0EsT0FBTyxFQUFFLE9BQU8sT0FBTyxFQUFFLE9BQU8sSUFBSTtHQUNuQztHQUNBO0VBQ0Q7RUFDQSxJQUFJLFNBQVMsUUFBUTtHQUNwQixNQUFNLE9BQU8sT0FBTyxVQUFVLFNBQVMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxjQUFjLEVBQUUsT0FBTyxVQUFVO0dBQ3RGLE9BQU8sU0FBUyxNQUFNLFdBQVcsYUFBYSxFQUFFLFdBQVcsSUFBSTtFQUNoRSxPQUFPLElBQUksU0FBUyxRQUFRLE9BQU8sU0FBUyxNQUFNO0dBQ2pELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLEVBQUUsT0FBTyxHQUFHLEVBQUUsT0FBTyxDQUFDLE9BQU87R0FDbEQ7RUFDRDtPQUNLLElBQUksRUFBRSxZQUFZLEVBQUUsT0FBTyxNQUFNLEVBQUUsWUFBWSxFQUFFLE9BQU8sSUFBSTtHQUNoRSxNQUFNLE9BQU8sRUFBRSxFQUFFLEtBQUssQ0FBQztHQUN2QixXQUFXLGFBQWEsRUFBRSxXQUFXLEVBQUUsU0FBUyxDQUFDLFdBQVc7R0FDNUQsV0FBVyxhQUFhLEVBQUUsRUFBRSxPQUFPLElBQUk7R0FDdkMsRUFBRSxRQUFRLEVBQUU7RUFDYixPQUFPO0dBQ04sSUFBSSxDQUFDLEtBQUs7SUFDVCxzQkFBc0IsSUFBSSxJQUFJO0lBQzlCLElBQUksSUFBSTtJQUNSLE9BQU8sSUFBSSxNQUFNLElBQUksSUFBSSxFQUFFLElBQUksR0FBRztHQUNuQztHQUNBLE1BQU0sUUFBUSxJQUFJLElBQUksRUFBRSxPQUFPO0dBQy9CLElBQUksU0FBUyxNQUFNO0lBQ2xCLElBQUksU0FBUyxTQUFTLFFBQVEsTUFBTTtLQUNuQyxJQUFJLElBQUksUUFBUSxXQUFXLEdBQUc7S0FDOUIsT0FBTyxFQUFFLElBQUksUUFBUSxJQUFJLE1BQU07TUFDOUIsS0FBSyxJQUFJLElBQUksSUFBSSxFQUFFLEVBQUUsTUFBTSxRQUFRLE1BQU0sUUFBUSxVQUFVO01BQzNEO0tBQ0Q7S0FDQSxJQUFJLFdBQVcsUUFBUSxRQUFRO01BQzlCLE1BQU0sT0FBTyxFQUFFO01BQ2YsT0FBTyxTQUFTLE9BQU8sV0FBVyxhQUFhLEVBQUUsV0FBVyxJQUFJO0tBQ2pFLE9BQU8sV0FBVyxhQUFhLEVBQUUsV0FBVyxFQUFFLFNBQVM7SUFDeEQsT0FBTztHQUNSLE9BQU8sRUFBRSxTQUFTLENBQUMsT0FBTztFQUMzQjtDQUNEO0FBQ0Q7QUFDQSxJQUFNLFdBQVc7QUFDakIsU0FBUyxPQUFPLE1BQU0sU0FBUyxNQUFNLFVBQVUsQ0FBQyxHQUFHO0NBQ2xELElBQUk7Q0FDSixZQUFZLFlBQVk7RUFDdkIsV0FBVztFQUNYLFlBQVksV0FBVyxLQUFLLElBQUksT0FBTyxTQUFTLEtBQUssR0FBRyxDQUFDLFFBQVEsUUFBUSxhQUFhLE9BQU8sS0FBSyxHQUFHLElBQUk7Q0FDMUcsR0FBRyxRQUFRLEtBQUs7Q0FDaEIsYUFBYTtFQUNaLFNBQVM7RUFDVCxRQUFRLGNBQWM7Q0FDdkI7QUFDRDtBQUNBLElBQUk7QUFDSixTQUFTLHNCQUFzQixPQUFPO0NBQ3JDLFNBQVM7QUFDVjtBQUNBLFNBQVMsU0FBUyxNQUFNLGNBQWMsT0FBTyxVQUFVO0NBQ3RELElBQUk7Q0FDSixNQUFNLGVBQWU7RUFDcEIsTUFBTSxJQUFJLFdBQVcsU0FBUyxnQkFBZ0Isc0NBQXNDLFVBQVUsSUFBSSxTQUFTLGNBQWMsVUFBVTtFQUNuSSxFQUFFLFlBQVksU0FBUyxPQUFPLFdBQVcsSUFBSSxJQUFJO0VBQ2pELE9BQU8sUUFBUSxFQUFFLFFBQVEsV0FBVyxhQUFhLFdBQVcsRUFBRSxhQUFhLEVBQUUsUUFBUTtDQUN0RjtDQUNBLE1BQU0sS0FBSyxxQkFBcUIsY0FBYyxTQUFTLFdBQVcsU0FBUyxPQUFPLE9BQU8sSUFBSSxJQUFJLENBQUMsV0FBVyxTQUFTLE9BQU8sT0FBTyxHQUFBLENBQUksVUFBVSxJQUFJO0NBQ3RKLEdBQUcsWUFBWTtDQUNmLE9BQU87QUFDUjtBQUNBLFNBQVMsZUFBZSxZQUFZLFdBQVcsT0FBTyxVQUFVO0NBQy9ELE1BQU0sSUFBSSxTQUFTLGNBQWMsU0FBUyw0QkFBNEIsSUFBSSxJQUFJO0NBQzlFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsSUFBSSxHQUFHLEtBQUs7RUFDbEQsTUFBTSxPQUFPLFdBQVc7RUFDeEIsSUFBSSxDQUFDLEVBQUUsSUFBSSxJQUFJLEdBQUc7R0FDakIsRUFBRSxJQUFJLElBQUk7R0FDVixTQUFTLGlCQUFpQixNQUFNLFlBQVk7RUFDN0M7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxxQkFBcUIsV0FBVyxPQUFPLFVBQVU7Q0FDekQsSUFBSSxTQUFTLFdBQVc7RUFDdkIsS0FBSyxJQUFJLFFBQVEsU0FBUyxTQUFTLENBQUMsS0FBSyxHQUFHLFNBQVMsb0JBQW9CLE1BQU0sWUFBWTtFQUMzRixPQUFPLFNBQVM7Q0FDakI7QUFDRDtBQUNBLFNBQVMsYUFBYSxNQUFNLE1BQU0sT0FBTztDQUN4QyxJQUFJLFlBQVksSUFBSSxHQUFHO0NBQ3ZCLElBQUksU0FBUyxNQUFNLEtBQUssZ0JBQWdCLElBQUk7TUFDdkMsS0FBSyxhQUFhLE1BQU0sS0FBSztBQUNuQztBQUNBLFNBQVMsZUFBZSxNQUFNLFdBQVcsTUFBTSxPQUFPO0NBQ3JELElBQUksWUFBWSxJQUFJLEdBQUc7Q0FDdkIsSUFBSSxTQUFTLE1BQU0sS0FBSyxrQkFBa0IsV0FBVyxJQUFJO01BQ3BELEtBQUssZUFBZSxXQUFXLE1BQU0sS0FBSztBQUNoRDtBQUNBLFNBQVMsaUJBQWlCLE1BQU0sTUFBTSxPQUFPO0NBQzVDLElBQUksWUFBWSxJQUFJLEdBQUc7Q0FDdkIsUUFBUSxLQUFLLGFBQWEsTUFBTSxFQUFFLElBQUksS0FBSyxnQkFBZ0IsSUFBSTtBQUNoRTtBQUNBLFNBQVMsVUFBVSxNQUFNLE9BQU87Q0FDL0IsSUFBSSxZQUFZLElBQUksR0FBRztDQUN2QixJQUFJLFNBQVMsTUFBTSxLQUFLLGdCQUFnQixPQUFPO01BQzFDLEtBQUssWUFBWTtBQUN2QjtBQUNBLFNBQVMsaUJBQWlCLE1BQU0sTUFBTSxTQUFTLFVBQVU7Q0FDeEQsSUFBSSxVQUFVO0VBQ2IsSUFBSSxNQUFNLFFBQVEsT0FBTyxHQUFHO0dBQzNCLEtBQUssS0FBSyxVQUFVLFFBQVE7R0FDNUIsS0FBSyxLQUFLLEtBQUssU0FBUyxRQUFRO0VBQ2pDLE9BQU8sS0FBSyxLQUFLLFVBQVU7Q0FDNUIsT0FBTyxJQUFJLE1BQU0sUUFBUSxPQUFPLEdBQUc7RUFDbEMsTUFBTSxZQUFZLFFBQVE7RUFDMUIsS0FBSyxpQkFBaUIsTUFBTSxRQUFRLE1BQU0sTUFBTSxVQUFVLEtBQUssTUFBTSxRQUFRLElBQUksQ0FBQyxDQUFDO0NBQ3BGLE9BQU8sS0FBSyxpQkFBaUIsTUFBTSxTQUFTLE9BQU8sWUFBWSxjQUFjLE9BQU87QUFDckY7QUFDQSxTQUFTLFVBQVUsTUFBTSxPQUFPLE9BQU8sQ0FBQyxHQUFHO0NBQzFDLE1BQU0sWUFBWSxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsR0FBRyxXQUFXLE9BQU8sS0FBSyxJQUFJO0NBQ3ZFLElBQUksR0FBRztDQUNQLEtBQUssSUFBSSxHQUFHLE1BQU0sU0FBUyxRQUFRLElBQUksS0FBSyxLQUFLO0VBQ2hELE1BQU0sTUFBTSxTQUFTO0VBQ3JCLElBQUksQ0FBQyxPQUFPLFFBQVEsZUFBZSxNQUFNLE1BQU07RUFDL0MsZUFBZSxNQUFNLEtBQUssS0FBSztFQUMvQixPQUFPLEtBQUs7Q0FDYjtDQUNBLEtBQUssSUFBSSxHQUFHLE1BQU0sVUFBVSxRQUFRLElBQUksS0FBSyxLQUFLO0VBQ2pELE1BQU0sTUFBTSxVQUFVLElBQUksYUFBYSxDQUFDLENBQUMsTUFBTTtFQUMvQyxJQUFJLENBQUMsT0FBTyxRQUFRLGVBQWUsS0FBSyxTQUFTLGNBQWMsQ0FBQyxZQUFZO0VBQzVFLGVBQWUsTUFBTSxLQUFLLElBQUk7RUFDOUIsS0FBSyxPQUFPO0NBQ2I7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLE1BQU0sTUFBTSxPQUFPLE1BQU07Q0FDakMsSUFBSSxDQUFDLE9BQU8sT0FBTyxPQUFPLGFBQWEsTUFBTSxPQUFPLElBQUk7Q0FDeEQsTUFBTSxZQUFZLEtBQUs7Q0FDdkIsSUFBSSxPQUFPLFVBQVUsVUFBVSxPQUFPLFVBQVUsVUFBVTtDQUMxRCxPQUFPLFNBQVMsYUFBYSxVQUFVLFVBQVUsT0FBTyxLQUFLO0NBQzdELFNBQVMsT0FBTyxDQUFDO0NBQ2pCLFVBQVUsUUFBUSxDQUFDO0NBQ25CLElBQUksR0FBRztDQUNQLEtBQUssS0FBSyxNQUFNO0VBQ2YsTUFBTSxNQUFNLFVBQVUsZUFBZSxDQUFDO0VBQ3RDLE9BQU8sS0FBSztDQUNiO0NBQ0EsS0FBSyxLQUFLLE9BQU87RUFDaEIsSUFBSSxNQUFNO0VBQ1YsSUFBSSxNQUFNLEtBQUssSUFBSTtHQUNsQixVQUFVLFlBQVksR0FBRyxDQUFDO0dBQzFCLEtBQUssS0FBSztFQUNYO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGlCQUFpQixNQUFNLE1BQU0sT0FBTztDQUM1QyxTQUFTLE9BQU8sS0FBSyxNQUFNLFlBQVksTUFBTSxLQUFLLElBQUksS0FBSyxNQUFNLGVBQWUsSUFBSTtBQUNyRjtBQUNBLFNBQVMsT0FBTyxNQUFNLFFBQVEsQ0FBQyxHQUFHLE9BQU8sY0FBYztDQUN0RCxNQUFNLFlBQVksQ0FBQztDQUNuQixJQUFJLENBQUMsY0FBYyx5QkFBeUIsVUFBVSxXQUFXLGlCQUFpQixNQUFNLE1BQU0sVUFBVSxVQUFVLFFBQVEsQ0FBQztDQUMzSCx5QkFBeUIsT0FBTyxNQUFNLFFBQVEsY0FBYyxJQUFJLE1BQU0sS0FBSyxJQUFJLENBQUM7Q0FDaEYseUJBQXlCLE9BQU8sTUFBTSxPQUFPLE9BQU8sTUFBTSxXQUFXLElBQUksQ0FBQztDQUMxRSxPQUFPO0FBQ1I7QUFDQSxTQUFTLElBQUksSUFBSSxTQUFTLEtBQUs7Q0FDOUIsT0FBTyxjQUFjLEdBQUcsU0FBUyxHQUFHLENBQUM7QUFDdEM7QUFDQSxTQUFTLE9BQU8sUUFBUSxVQUFVLFFBQVEsU0FBUztDQUNsRCxJQUFJLFdBQVcsS0FBSyxLQUFLLENBQUMsU0FBUyxVQUFVLENBQUM7Q0FDOUMsSUFBSSxPQUFPLGFBQWEsWUFBWSxPQUFPLGlCQUFpQixRQUFRLFVBQVUsU0FBUyxNQUFNO0NBQzdGLG9CQUFvQixZQUFZLGlCQUFpQixRQUFRLFNBQVMsR0FBRyxTQUFTLE1BQU0sR0FBRyxPQUFPO0FBQy9GO0FBQ0EsU0FBUyxPQUFPLE1BQU0sT0FBTyxPQUFPLGNBQWMsWUFBWSxDQUFDLEdBQUcsVUFBVSxPQUFPO0NBQ2xGLFVBQVUsUUFBUSxDQUFDO0NBQ25CLEtBQUssTUFBTSxRQUFRLFdBQVcsSUFBSSxFQUFFLFFBQVEsUUFBUTtFQUNuRCxJQUFJLFNBQVMsWUFBWTtFQUN6QixVQUFVLFFBQVEsV0FBVyxNQUFNLE1BQU0sTUFBTSxVQUFVLE9BQU8sT0FBTyxTQUFTLEtBQUs7Q0FDdEY7Q0FDQSxLQUFLLE1BQU0sUUFBUSxPQUFPO0VBQ3pCLElBQUksU0FBUyxZQUFZO0dBQ3hCLElBQUksQ0FBQyxjQUFjLGlCQUFpQixNQUFNLE1BQU0sUUFBUTtHQUN4RDtFQUNEO0VBRUEsVUFBVSxRQUFRLFdBQVcsTUFBTSxNQURyQixNQUFNLE9BQzRCLFVBQVUsT0FBTyxPQUFPLFNBQVMsS0FBSztDQUN2RjtBQUNEO0FBQ0EsU0FBUyxlQUFlLFVBQVU7Q0FDakMsSUFBSSxNQUFNO0NBQ1YsSUFBSSxDQUFDLFlBQVksS0FBSyxFQUFFLE9BQU8sYUFBYSxTQUFTLElBQUksTUFBTSxnQkFBZ0IsQ0FBQyxJQUFJLE9BQU8sU0FBUztDQUNwRyxJQUFJLGFBQWEsV0FBVyxhQUFhLFVBQVUsSUFBSSxJQUFJO0NBQzNELGFBQWEsU0FBUyxPQUFPLEdBQUc7Q0FDaEMsT0FBTztBQUNSO0FBQ0EsU0FBUyxZQUFZLE1BQU07Q0FDMUIsT0FBTyxDQUFDLENBQUMsYUFBYSxXQUFXLENBQUMsYUFBYSxTQUFTLENBQUMsUUFBUSxLQUFLO0FBQ3ZFO0FBQ0EsU0FBUyxlQUFlLE1BQU07Q0FDN0IsT0FBTyxLQUFLLFlBQVksQ0FBQyxDQUFDLFFBQVEsY0FBYyxHQUFHLE1BQU0sRUFBRSxZQUFZLENBQUM7QUFDekU7QUFDQSxTQUFTLGVBQWUsTUFBTSxLQUFLLE9BQU87Q0FDekMsTUFBTSxhQUFhLElBQUksS0FBSyxDQUFDLENBQUMsTUFBTSxLQUFLO0NBQ3pDLEtBQUssSUFBSSxJQUFJLEdBQUcsVUFBVSxXQUFXLFFBQVEsSUFBSSxTQUFTLEtBQUssS0FBSyxVQUFVLE9BQU8sV0FBVyxJQUFJLEtBQUs7QUFDMUc7QUFDQSxTQUFTLFdBQVcsTUFBTSxNQUFNLE9BQU8sTUFBTSxPQUFPLFNBQVMsT0FBTztDQUNuRSxJQUFJLE1BQU0sUUFBUSxhQUFhLFdBQVc7Q0FDMUMsSUFBSSxTQUFTLFNBQVMsT0FBTyxNQUFNLE1BQU0sT0FBTyxJQUFJO0NBQ3BELElBQUksU0FBUyxhQUFhLE9BQU8sVUFBVSxNQUFNLE9BQU8sSUFBSTtDQUM1RCxJQUFJLFVBQVUsTUFBTSxPQUFPO0NBQzNCLElBQUksU0FBUyxPQUNSO01BQUEsQ0FBQyxTQUFTLE1BQU0sSUFBSTtDQUFBLE9BQ2xCLElBQUksS0FBSyxNQUFNLEdBQUcsQ0FBQyxNQUFNLE9BQU87RUFDdEMsTUFBTSxJQUFJLEtBQUssTUFBTSxDQUFDO0VBQ3RCLFFBQVEsS0FBSyxvQkFBb0IsR0FBRyxNQUFNLE9BQU8sU0FBUyxjQUFjLElBQUk7RUFDNUUsU0FBUyxLQUFLLGlCQUFpQixHQUFHLE9BQU8sT0FBTyxVQUFVLGNBQWMsS0FBSztDQUM5RSxPQUFPLElBQUksS0FBSyxNQUFNLEdBQUcsRUFBRSxNQUFNLGNBQWM7RUFDOUMsTUFBTSxJQUFJLEtBQUssTUFBTSxFQUFFO0VBQ3ZCLFFBQVEsS0FBSyxvQkFBb0IsR0FBRyxNQUFNLElBQUk7RUFDOUMsU0FBUyxLQUFLLGlCQUFpQixHQUFHLE9BQU8sSUFBSTtDQUM5QyxPQUFPLElBQUksS0FBSyxNQUFNLEdBQUcsQ0FBQyxNQUFNLE1BQU07RUFDckMsTUFBTSxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxZQUFZO0VBQ3ZDLE1BQU0sV0FBVyxnQkFBZ0IsSUFBSSxJQUFJO0VBQ3pDLElBQUksQ0FBQyxZQUFZLE1BQU07R0FDdEIsTUFBTSxJQUFJLE1BQU0sUUFBUSxJQUFJLElBQUksS0FBSyxLQUFLO0dBQzFDLEtBQUssb0JBQW9CLE1BQU0sQ0FBQztFQUNqQztFQUNBLElBQUksWUFBWSxPQUFPO0dBQ3RCLGlCQUFpQixNQUFNLE1BQU0sT0FBTyxRQUFRO0dBQzVDLFlBQVksZUFBZSxDQUFDLElBQUksQ0FBQztFQUNsQztDQUNELE9BQU8sSUFBSSxLQUFLLE1BQU0sR0FBRyxDQUFDLE1BQU0sU0FBUyxhQUFhLE1BQU0sS0FBSyxNQUFNLENBQUMsR0FBRyxLQUFLO01BQzNFLElBQUksS0FBSyxNQUFNLEdBQUcsQ0FBQyxNQUFNLFNBQVMsaUJBQWlCLE1BQU0sS0FBSyxNQUFNLENBQUMsR0FBRyxLQUFLO01BQzdFLEtBQUssWUFBWSxLQUFLLE1BQU0sR0FBRyxDQUFDLE1BQU0sYUFBYSxjQUFjLGdCQUFnQixJQUFJLElBQUksTUFBTSxDQUFDLFdBQVcsWUFBWSxhQUFhLE1BQU0sS0FBSyxPQUFPLE9BQU8sU0FBUyxXQUFXLElBQUksSUFBSSxRQUFRLE9BQU8sS0FBSyxTQUFTLFNBQVMsR0FBRyxLQUFLLFFBQVEsUUFBUTtFQUMzUCxJQUFJLFdBQVc7R0FDZCxPQUFPLEtBQUssTUFBTSxDQUFDO0dBQ25CLFNBQVM7RUFDVixPQUFPLElBQUksWUFBWSxJQUFJLEdBQUcsT0FBTztFQUNyQyxJQUFJLFNBQVMsV0FBVyxTQUFTLGFBQWEsVUFBVSxNQUFNLEtBQUs7T0FDOUQsSUFBSSxRQUFRLENBQUMsVUFBVSxDQUFDLGFBQWEsS0FBSyxlQUFlLElBQUksS0FBSztPQUNsRSxLQUFLLFNBQVMsV0FBVyxTQUFTLG9CQUFvQixLQUFLLGFBQWEsV0FBVyxLQUFLLGFBQWEsYUFBYSxLQUFLLGFBQWEsUUFBUSxTQUFTO09BQ3JKLEtBQUssYUFBYSxRQUFRO0NBQ2hDLE9BQU87RUFDTixNQUFNLEtBQUssU0FBUyxLQUFLLFFBQVEsR0FBRyxJQUFJLE1BQU0sYUFBYSxLQUFLLE1BQU0sR0FBRyxDQUFDLENBQUM7RUFDM0UsSUFBSSxJQUFJLGVBQWUsTUFBTSxJQUFJLE1BQU0sS0FBSztPQUN2QyxhQUFhLE1BQU0sUUFBUSxTQUFTLE1BQU0sS0FBSztDQUNyRDtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsYUFBYSxHQUFHO0NBQ3hCLElBQUksYUFBYSxZQUFZLGFBQWEsUUFDckM7TUFBQSxhQUFhLE9BQU8sTUFBTSxDQUFDLElBQUksUUFBUSxPQUFPLENBQUMsR0FBRztDQUFBO0NBRXZELElBQUksT0FBTyxFQUFFO0NBQ2IsTUFBTSxNQUFNLEtBQUssRUFBRTtDQUNuQixNQUFNLFlBQVksRUFBRTtDQUNwQixNQUFNLG1CQUFtQixFQUFFO0NBQzNCLE1BQU0sWUFBWSxVQUFVLE9BQU8sZUFBZSxHQUFHLFVBQVU7RUFDOUQsY0FBYztFQUNkO0NBQ0QsQ0FBQztDQUNELE1BQU0sbUJBQW1CO0VBQ3hCLE1BQU0sVUFBVSxLQUFLO0VBQ3JCLElBQUksV0FBVyxDQUFDLEtBQUssVUFBVTtHQUM5QixNQUFNLE9BQU8sS0FBSyxHQUFHLElBQUk7R0FDekIsU0FBUyxLQUFLLElBQUksUUFBUSxLQUFLLE1BQU0sTUFBTSxDQUFDLElBQUksUUFBUSxLQUFLLE1BQU0sQ0FBQztHQUNwRSxJQUFJLEVBQUUsY0FBYztFQUNyQjtFQUNBLEtBQUssUUFBUSxPQUFPLEtBQUssU0FBUyxZQUFZLENBQUMsS0FBSyxLQUFLLFVBQVUsS0FBSyxTQUFTLEVBQUUsTUFBTSxLQUFLLFNBQVMsS0FBSyxJQUFJO0VBQ2hILE9BQU87Q0FDUjtDQUNBLE1BQU0sbUJBQW1CO0VBQ3hCLE9BQU8sV0FBVyxNQUFNLE9BQU8sS0FBSyxVQUFVLEtBQUssY0FBYyxLQUFLO0NBQ3ZFO0NBQ0EsT0FBTyxlQUFlLEdBQUcsaUJBQWlCO0VBQ3pDLGNBQWM7RUFDZCxNQUFNO0dBQ0wsT0FBTyxRQUFRO0VBQ2hCO0NBQ0QsQ0FBQztDQUNELElBQUksYUFBYSxZQUFZLENBQUMsYUFBYSxNQUFNLGFBQWEsT0FBTyxLQUFLLE9BQU87Q0FDakYsSUFBSTtFQUNILElBQUksRUFBRSxjQUFjO0dBQ25CLE1BQU0sT0FBTyxFQUFFLGFBQWE7R0FDNUIsU0FBUyxLQUFLLEVBQUU7R0FDaEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssU0FBUyxHQUFHLEtBQUs7SUFDekMsT0FBTyxLQUFLO0lBQ1osSUFBSSxDQUFDLFdBQVcsR0FBRztJQUNuQixJQUFJLEtBQUssUUFBUTtLQUNoQixPQUFPLEtBQUs7S0FDWixXQUFXO0tBQ1g7SUFDRDtJQUNBLElBQUksS0FBSyxlQUFlLGtCQUFrQjtHQUMzQztFQUNELE9BQU8sV0FBVztFQUNsQixTQUFTLFNBQVM7Q0FDbkIsVUFBVTtFQUNULElBQUksT0FBTztDQUNaO0FBQ0Q7QUFDQSxTQUFTLGlCQUFpQixRQUFRLE9BQU8sU0FBUyxRQUFRLGFBQWE7Q0FDdEUsTUFBTSxZQUFZLFlBQVksTUFBTTtDQUNwQyxJQUFJLFdBQVc7RUFDZCxDQUFDLFlBQVksVUFBVSxDQUFDLEdBQUcsT0FBTyxVQUFVO0VBQzVDLElBQUksVUFBVSxDQUFDO0VBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0dBQ3hDLE1BQU0sT0FBTyxRQUFRO0dBQ3JCLElBQUksS0FBSyxhQUFhLEtBQUssS0FBSyxLQUFLLE1BQU0sR0FBRyxDQUFDLE1BQU0sTUFBTSxLQUFLLE9BQU87UUFDbEUsUUFBUSxLQUFLLElBQUk7RUFDdkI7RUFDQSxVQUFVO0NBQ1g7Q0FDQSxPQUFPLE9BQU8sWUFBWSxZQUFZLFVBQVUsUUFBUTtDQUN4RCxJQUFJLFVBQVUsU0FBUyxPQUFPO0NBQzlCLE1BQU0sSUFBSSxPQUFPLE9BQU8sUUFBUSxXQUFXLEtBQUs7Q0FDaEQsU0FBUyxTQUFTLFFBQVEsTUFBTSxRQUFRLEVBQUUsQ0FBQyxjQUFjO0NBQ3pELElBQUksTUFBTSxZQUFZLE1BQU0sVUFBVTtFQUNyQyxJQUFJLFdBQVcsT0FBTztFQUN0QixJQUFJLE1BQU0sVUFBVTtHQUNuQixRQUFRLE1BQU0sU0FBUztHQUN2QixJQUFJLFVBQVUsU0FBUyxPQUFPO0VBQy9CO0VBQ0EsSUFBSSxPQUFPO0dBQ1YsSUFBSSxPQUFPLFFBQVE7R0FDbkIsSUFBSSxRQUFRLEtBQUssYUFBYSxHQUFHLEtBQUssU0FBUyxVQUFVLEtBQUssT0FBTztRQUNoRSxPQUFPLFNBQVMsZUFBZSxLQUFLO0dBQ3pDLFVBQVUsY0FBYyxRQUFRLFNBQVMsUUFBUSxJQUFJO0VBQ3RELE9BQU8sSUFBSSxZQUFZLE1BQU0sT0FBTyxZQUFZLFVBQVUsVUFBVSxPQUFPLFdBQVcsT0FBTztPQUN4RixVQUFVLE9BQU8sY0FBYztDQUNyQyxPQUFPLElBQUksU0FBUyxRQUFRLE1BQU0sV0FBVztFQUM1QyxJQUFJLFdBQVcsT0FBTztFQUN0QixVQUFVLGNBQWMsUUFBUSxTQUFTLE1BQU07Q0FDaEQsT0FBTyxJQUFJLE1BQU0sWUFBWTtFQUM1Qix5QkFBeUI7R0FDeEIsSUFBSSxJQUFJLE1BQU07R0FDZCxPQUFPLE9BQU8sTUFBTSxZQUFZLElBQUksRUFBRTtHQUN0QyxVQUFVLGlCQUFpQixRQUFRLEdBQUcsU0FBUyxNQUFNO0VBQ3RELENBQUM7RUFDRCxhQUFhO0NBQ2QsT0FBTyxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7RUFDaEMsTUFBTSxRQUFRLENBQUM7RUFDZixNQUFNLGVBQWUsV0FBVyxNQUFNLFFBQVEsT0FBTztFQUNyRCxJQUFJLHVCQUF1QixPQUFPLE9BQU8sU0FBUyxXQUFXLEdBQUc7R0FDL0QseUJBQXlCLFVBQVUsaUJBQWlCLFFBQVEsT0FBTyxTQUFTLFFBQVEsSUFBSSxDQUFDO0dBQ3pGLGFBQWE7RUFDZDtFQUNBLElBQUksV0FBVztHQUNkLElBQUksQ0FBQyxNQUFNLFFBQVEsT0FBTztHQUMxQixJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU8sVUFBVSxDQUFDLEdBQUcsT0FBTyxVQUFVO0dBQzdELElBQUksT0FBTyxNQUFNO0dBQ2pCLElBQUksS0FBSyxlQUFlLFFBQVEsT0FBTztHQUN2QyxNQUFNLFFBQVEsQ0FBQyxJQUFJO0dBQ25CLFFBQVEsT0FBTyxLQUFLLGlCQUFpQixRQUFRLE1BQU0sS0FBSyxJQUFJO0dBQzVELE9BQU8sVUFBVTtFQUNsQjtFQUNBLElBQUksTUFBTSxXQUFXLEdBQUc7R0FDdkIsVUFBVSxjQUFjLFFBQVEsU0FBUyxNQUFNO0dBQy9DLElBQUksT0FBTyxPQUFPO0VBQ25CLE9BQU8sSUFBSSxjQUFjO0dBQ3hCLElBQUksUUFBUSxXQUFXLEdBQUcsWUFBWSxRQUFRLE9BQU8sTUFBTTtRQUN0RCxnQkFBZ0IsUUFBUSxTQUFTLEtBQUs7RUFDNUMsT0FBTztHQUNOLFdBQVcsY0FBYyxNQUFNO0dBQy9CLFlBQVksUUFBUSxLQUFLO0VBQzFCO0VBQ0EsVUFBVTtDQUNYLE9BQU8sSUFBSSxNQUFNLFVBQVU7RUFDMUIsSUFBSSxhQUFhLE1BQU0sWUFBWSxPQUFPLFVBQVUsUUFBUSxDQUFDLEtBQUssSUFBSTtFQUN0RSxJQUFJLE1BQU0sUUFBUSxPQUFPLEdBQUc7R0FDM0IsSUFBSSxPQUFPLE9BQU8sVUFBVSxjQUFjLFFBQVEsU0FBUyxRQUFRLEtBQUs7R0FDeEUsY0FBYyxRQUFRLFNBQVMsTUFBTSxLQUFLO0VBQzNDLE9BQU8sSUFBSSxXQUFXLFFBQVEsWUFBWSxNQUFNLENBQUMsT0FBTyxZQUFZLE9BQU8sWUFBWSxLQUFLO09BQ3ZGLE9BQU8sYUFBYSxPQUFPLE9BQU8sVUFBVTtFQUNqRCxVQUFVO0NBQ1g7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLHVCQUF1QixZQUFZLE9BQU8sU0FBUyxRQUFRO0NBQ25FLElBQUksVUFBVTtDQUNkLEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxNQUFNLFFBQVEsSUFBSSxLQUFLLEtBQUs7RUFDakQsSUFBSSxPQUFPLE1BQU0sSUFBSSxPQUFPLFdBQVcsUUFBUSxXQUFXLFNBQVM7RUFDbkUsSUFBSSxRQUFRLFFBQVEsU0FBUyxRQUFRLFNBQVM7T0FDekMsS0FBSyxJQUFJLE9BQU8sVUFBVSxZQUFZLEtBQUssVUFBVSxXQUFXLEtBQUssSUFBSTtPQUN6RSxJQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUcsVUFBVSx1QkFBdUIsWUFBWSxNQUFNLElBQUksS0FBSztPQUNyRixJQUFJLE1BQU0sWUFBWTtHQUMxQixJQUFJLFFBQVE7SUFDWCxPQUFPLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSztJQUMvQyxVQUFVLHVCQUF1QixZQUFZLE1BQU0sUUFBUSxJQUFJLElBQUksT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLFFBQVEsSUFBSSxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSztHQUMzSCxPQUFPO0lBQ04sV0FBVyxLQUFLLElBQUk7SUFDcEIsVUFBVTtHQUNYO0VBQ0QsT0FBTztHQUNOLE1BQU0sUUFBUSxPQUFPLElBQUk7R0FDekIsSUFBSSxRQUFRLEtBQUssYUFBYSxLQUFLLEtBQUssU0FBUyxPQUFPLFdBQVcsS0FBSyxJQUFJO1FBQ3ZFLFdBQVcsS0FBSyxTQUFTLGVBQWUsS0FBSyxDQUFDO0VBQ3BEO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLFlBQVksUUFBUSxPQUFPLFNBQVMsTUFBTTtDQUNsRCxLQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sTUFBTSxRQUFRLElBQUksS0FBSyxLQUFLLE9BQU8sYUFBYSxNQUFNLElBQUksTUFBTTtBQUN2RjtBQUNBLFNBQVMsY0FBYyxRQUFRLFNBQVMsUUFBUSxhQUFhO0NBQzVELElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTyxPQUFPLGNBQWM7Q0FDbkQsTUFBTSxPQUFPLGVBQWUsU0FBUyxlQUFlLEVBQUU7Q0FDdEQsSUFBSSxRQUFRLFFBQVE7RUFDbkIsSUFBSSxXQUFXO0VBQ2YsS0FBSyxJQUFJLElBQUksUUFBUSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7R0FDN0MsTUFBTSxLQUFLLFFBQVE7R0FDbkIsSUFBSSxTQUFTLElBQUk7SUFDaEIsTUFBTSxXQUFXLEdBQUcsZUFBZTtJQUNuQyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsV0FBVyxPQUFPLGFBQWEsTUFBTSxFQUFFLElBQUksT0FBTyxhQUFhLE1BQU0sTUFBTTtTQUMzRixZQUFZLEdBQUcsT0FBTztHQUM1QixPQUFPLFdBQVc7RUFDbkI7Q0FDRCxPQUFPLE9BQU8sYUFBYSxNQUFNLE1BQU07Q0FDdkMsT0FBTyxDQUFDLElBQUk7QUFDYjtBQUNBLFNBQVMsa0JBQWtCO0NBQzFCLE9BQU8sYUFBYSxpQkFBaUI7QUFDdEM7QUFDQSxJQUFNLGdCQUFnQjtBQUN0QixTQUFTLGNBQWMsU0FBUyxRQUFRLE9BQU8sS0FBSyxLQUFLLEdBQUc7Q0FDM0QsT0FBTyxRQUFRLFNBQVMsZ0JBQWdCLGVBQWUsT0FBTyxJQUFJLFNBQVMsY0FBYyxTQUFTLEVBQUUsR0FBRyxDQUFDO0FBQ3pHO0FBQ0EsU0FBUyxPQUFPLE9BQU87Q0FDdEIsTUFBTSxFQUFFLGNBQWMsT0FBTyxTQUFTLFNBQVMsZUFBZSxFQUFFLEdBQUcsY0FBYyxNQUFNLFNBQVMsU0FBUyxNQUFNLFFBQVEsU0FBUztDQUNoSSxJQUFJO0NBQ0osSUFBSSxZQUFZLENBQUMsQ0FBQyxhQUFhO0NBQy9CLG1CQUFtQjtFQUNsQixJQUFJLFdBQVcsU0FBUyxDQUFDLENBQUMsT0FBTyxZQUFZO0VBQzdDLFlBQVksVUFBVSxhQUFhLGFBQWEsaUJBQWlCLE1BQU0sUUFBUSxDQUFDO0VBQ2hGLE1BQU0sS0FBSyxNQUFNO0VBQ2pCLElBQUksY0FBYyxpQkFBaUI7R0FDbEMsTUFBTSxDQUFDLE9BQU8sWUFBWSxhQUFhLEtBQUs7R0FDNUMsTUFBTSxnQkFBZ0IsU0FBUyxJQUFJO0dBQ25DLFlBQVksWUFBWSxPQUFPLFVBQVUsQ0FBQyxNQUFNLElBQUksUUFBUSxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUM7R0FDaEYsVUFBVSxPQUFPO0VBQ2xCLE9BQU87R0FDTixNQUFNLFlBQVksY0FBYyxNQUFNLFFBQVEsTUFBTSxPQUFPLE1BQU0sS0FBSyxHQUFHLGFBQWEsYUFBYSxVQUFVLGVBQWUsVUFBVSxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUMsSUFBSTtHQUN2SyxPQUFPLGVBQWUsV0FBVyxVQUFVO0lBQzFDLE1BQU07S0FDTCxPQUFPLE9BQU87SUFDZjtJQUNBLGNBQWM7R0FDZixDQUFDO0dBQ0QsT0FBTyxZQUFZLE9BQU87R0FDMUIsR0FBRyxZQUFZLFNBQVM7R0FDeEIsTUFBTSxPQUFPLE1BQU0sSUFBSSxTQUFTO0dBQ2hDLGdCQUFnQixHQUFHLFNBQVMsU0FBUyxLQUFLLEdBQUcsWUFBWSxTQUFTLENBQUM7RUFDcEU7Q0FDRCxHQUFHLEtBQUssR0FBRyxFQUFFLFFBQVEsQ0FBQyxVQUFVLENBQUM7Q0FDakMsT0FBTztBQUNSO0FBQ0EsU0FBUyxjQUFjLFdBQVcsT0FBTztDQUN4QyxNQUFNLFNBQVMsV0FBVyxTQUFTO0NBQ25DLE9BQU8saUJBQWlCO0VBQ3ZCLE1BQU0sWUFBWSxPQUFPO0VBQ3pCLFFBQVEsT0FBTyxXQUFmO0dBQ0MsS0FBSyxZQUFZLE9BQU8sY0FBYyxVQUFVLEtBQUssQ0FBQztHQUN0RCxLQUFLO0lBQ0osTUFBTSxRQUFRLFlBQVksSUFBSSxTQUFTO0lBQ3ZDLE1BQU0sS0FBSyxhQUFhLFVBQVUsZUFBZSxJQUFJLGNBQWMsV0FBVyxPQUFPLGNBQWMsTUFBTSxFQUFFLENBQUM7SUFDNUcsT0FBTyxJQUFJLE9BQU8sS0FBSztJQUN2QixPQUFPO0VBQ1Q7Q0FDRCxDQUFDO0FBQ0Y7QUFDQSxTQUFTLFFBQVEsT0FBTztDQUN2QixNQUFNLEdBQUcsVUFBVSxXQUFXLE9BQU8sQ0FBQyxXQUFXLENBQUM7Q0FDbEQsT0FBTyxvQkFBb0IsTUFBTSxXQUFXLE1BQU07QUFDbkQiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19