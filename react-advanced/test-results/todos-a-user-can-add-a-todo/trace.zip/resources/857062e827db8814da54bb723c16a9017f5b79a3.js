import { m as createComponent, v as createMemo } from "/node_modules/.vite/deps/web-BZdVkndN-D9ynzhLq.js?v=37813280";
import { a as DevtoolsSubscriptionsProvider, c as PiPProvider, d as createLocalStorage, f as getPreferredColorScheme, i as DevtoolsStateProvider, l as QueryDevtoolsContext, n as Devtools, o as I18nProvider, r as DevtoolsOfflineProvider, u as ThemeContext } from "/node_modules/.vite/deps/DevtoolsSubscriptionsProvider-Cl_PUkf2-l22mkk9C.js?v=37813280";
// node_modules/@tanstack/query-devtools/build/DevtoolsComponent-BBTUIw3a.js
var DevtoolsComponent = (props) => {
	const [localStore, setLocalStore] = createLocalStorage({ prefix: "TanstackQueryDevtools" });
	const colorScheme = getPreferredColorScheme();
	const theme = createMemo(() => {
		const preference = props.theme || localStore.theme_preference || "system";
		if (preference !== "system") return preference;
		return colorScheme();
	});
	return createComponent(QueryDevtoolsContext.Provider, {
		value: props,
		get children() {
			return createComponent(DevtoolsStateProvider, { get children() {
				return createComponent(DevtoolsOfflineProvider, { get children() {
					return createComponent(DevtoolsSubscriptionsProvider, { get children() {
						return createComponent(PiPProvider, {
							localStore,
							setLocalStore,
							get children() {
								return createComponent(ThemeContext.Provider, {
									value: theme,
									get children() {
										return createComponent(I18nProvider, {
											locale: "en-US",
											get children() {
												return createComponent(Devtools, {
													localStore,
													setLocalStore
												});
											}
										});
									}
								});
							}
						});
					} });
				} });
			} });
		}
	});
};
export { DevtoolsComponent as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRGV2dG9vbHNDb21wb25lbnQtQkJUVUl3M2EtQ3F2eFQ4UEYuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWRldnRvb2xzL2J1aWxkL0RldnRvb2xzQ29tcG9uZW50LUJCVFVJdzNhLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIEByZWZyZXNoIHNraXAgKi9cbmltcG9ydCB7IE8gYXMgY3JlYXRlTWVtbywgdyBhcyBjcmVhdGVDb21wb25lbnQgfSBmcm9tIFwiLi93ZWItQlpkVmtuZE4uanNcIjtcbmltcG9ydCB7IGEgYXMgRGV2dG9vbHMsIGMgYXMgUGlQUHJvdmlkZXIsIGQgYXMgZ2V0UHJlZmVycmVkQ29sb3JTY2hlbWUsIGYgYXMgY3JlYXRlTG9jYWxTdG9yYWdlLCBsIGFzIFF1ZXJ5RGV2dG9vbHNDb250ZXh0LCBuIGFzIERldnRvb2xzU3RhdGVQcm92aWRlciwgcCBhcyBJMThuUHJvdmlkZXIsIHIgYXMgRGV2dG9vbHNPZmZsaW5lUHJvdmlkZXIsIHMgYXMgVGhlbWVDb250ZXh0LCB0IGFzIERldnRvb2xzU3Vic2NyaXB0aW9uc1Byb3ZpZGVyIH0gZnJvbSBcIi4vRGV2dG9vbHNTdWJzY3JpcHRpb25zUHJvdmlkZXItQ2xfUFVrZjIuanNcIjtcbi8vIHNyYy9EZXZ0b29sc0NvbXBvbmVudC50c3hcbmNvbnN0IERldnRvb2xzQ29tcG9uZW50ID0gKHByb3BzKSA9PiB7XG5cdGNvbnN0IFtsb2NhbFN0b3JlLCBzZXRMb2NhbFN0b3JlXSA9IGNyZWF0ZUxvY2FsU3RvcmFnZSh7IHByZWZpeDogXCJUYW5zdGFja1F1ZXJ5RGV2dG9vbHNcIiB9KTtcblx0Y29uc3QgY29sb3JTY2hlbWUgPSBnZXRQcmVmZXJyZWRDb2xvclNjaGVtZSgpO1xuXHRjb25zdCB0aGVtZSA9IGNyZWF0ZU1lbW8oKCkgPT4ge1xuXHRcdGNvbnN0IHByZWZlcmVuY2UgPSBwcm9wcy50aGVtZSB8fCBsb2NhbFN0b3JlLnRoZW1lX3ByZWZlcmVuY2UgfHwgXCJzeXN0ZW1cIjtcblx0XHRpZiAocHJlZmVyZW5jZSAhPT0gXCJzeXN0ZW1cIikgcmV0dXJuIHByZWZlcmVuY2U7XG5cdFx0cmV0dXJuIGNvbG9yU2NoZW1lKCk7XG5cdH0pO1xuXHRyZXR1cm4gY3JlYXRlQ29tcG9uZW50KFF1ZXJ5RGV2dG9vbHNDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IHByb3BzLFxuXHRcdGdldCBjaGlsZHJlbigpIHtcblx0XHRcdHJldHVybiBjcmVhdGVDb21wb25lbnQoRGV2dG9vbHNTdGF0ZVByb3ZpZGVyLCB7IGdldCBjaGlsZHJlbigpIHtcblx0XHRcdFx0cmV0dXJuIGNyZWF0ZUNvbXBvbmVudChEZXZ0b29sc09mZmxpbmVQcm92aWRlciwgeyBnZXQgY2hpbGRyZW4oKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGNyZWF0ZUNvbXBvbmVudChEZXZ0b29sc1N1YnNjcmlwdGlvbnNQcm92aWRlciwgeyBnZXQgY2hpbGRyZW4oKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gY3JlYXRlQ29tcG9uZW50KFBpUFByb3ZpZGVyLCB7XG5cdFx0XHRcdFx0XHRcdGxvY2FsU3RvcmUsXG5cdFx0XHRcdFx0XHRcdHNldExvY2FsU3RvcmUsXG5cdFx0XHRcdFx0XHRcdGdldCBjaGlsZHJlbigpIHtcblx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gY3JlYXRlQ29tcG9uZW50KFRoZW1lQ29udGV4dC5Qcm92aWRlciwge1xuXHRcdFx0XHRcdFx0XHRcdFx0dmFsdWU6IHRoZW1lLFxuXHRcdFx0XHRcdFx0XHRcdFx0Z2V0IGNoaWxkcmVuKCkge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gY3JlYXRlQ29tcG9uZW50KEkxOG5Qcm92aWRlciwge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGxvY2FsZTogXCJlbi1VU1wiLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGdldCBjaGlsZHJlbigpIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHJldHVybiBjcmVhdGVDb21wb25lbnQoRGV2dG9vbHMsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0bG9jYWxTdG9yZSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0c2V0TG9jYWxTdG9yZVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0fSB9KTtcblx0XHRcdFx0fSB9KTtcblx0XHRcdH0gfSk7XG5cdFx0fVxuXHR9KTtcbn07XG5leHBvcnQgeyBEZXZ0b29sc0NvbXBvbmVudCBhcyBkZWZhdWx0IH07XG4iXSwibWFwcGluZ3MiOiI7OztBQUlBLElBQU0scUJBQXFCLFVBQVU7Q0FDcEMsTUFBTSxDQUFDLFlBQVksaUJBQWlCLG1CQUFtQixFQUFFLFFBQVEsd0JBQXdCLENBQUM7Q0FDMUYsTUFBTSxjQUFjLHdCQUF3QjtDQUM1QyxNQUFNLFFBQVEsaUJBQWlCO0VBQzlCLE1BQU0sYUFBYSxNQUFNLFNBQVMsV0FBVyxvQkFBb0I7RUFDakUsSUFBSSxlQUFlLFVBQVUsT0FBTztFQUNwQyxPQUFPLFlBQVk7Q0FDcEIsQ0FBQztDQUNELE9BQU8sZ0JBQWdCLHFCQUFxQixVQUFVO0VBQ3JELE9BQU87RUFDUCxJQUFJLFdBQVc7R0FDZCxPQUFPLGdCQUFnQix1QkFBdUIsRUFBRSxJQUFJLFdBQVc7SUFDOUQsT0FBTyxnQkFBZ0IseUJBQXlCLEVBQUUsSUFBSSxXQUFXO0tBQ2hFLE9BQU8sZ0JBQWdCLCtCQUErQixFQUFFLElBQUksV0FBVztNQUN0RSxPQUFPLGdCQUFnQixhQUFhO09BQ25DO09BQ0E7T0FDQSxJQUFJLFdBQVc7UUFDZCxPQUFPLGdCQUFnQixhQUFhLFVBQVU7U0FDN0MsT0FBTztTQUNQLElBQUksV0FBVztVQUNkLE9BQU8sZ0JBQWdCLGNBQWM7V0FDcEMsUUFBUTtXQUNSLElBQUksV0FBVztZQUNkLE9BQU8sZ0JBQWdCLFVBQVU7YUFDaEM7YUFDQTtZQUNELENBQUM7V0FDRjtVQUNELENBQUM7U0FDRjtRQUNELENBQUM7T0FDRjtNQUNELENBQUM7S0FDRixFQUFFLENBQUM7SUFDSixFQUFFLENBQUM7R0FDSixFQUFFLENBQUM7RUFDSjtDQUNELENBQUM7QUFDRiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=