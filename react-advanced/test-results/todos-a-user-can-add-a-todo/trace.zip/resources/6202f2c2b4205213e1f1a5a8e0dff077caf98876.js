import { r as __toESM, t as require_react } from "/node_modules/.vite/deps/react-KD50BIoF.js?v=37813280";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-DAn1M0Fv.js?v=37813280";
// node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var IsRestoringContext = import_react.createContext(false);
/**
* If you are using `PersistQueryClientProvider`, you can also use the `useIsRestoring` hook alongside it to
* check if a restore is currently in progress. `useQuery` and friends also check this internally to avoid
* race conditions between the restore and mounting queries.
* @returns `true` while a persisted client is being restored, `false` otherwise.
*/
var useIsRestoring = () => import_react.useContext(IsRestoringContext);
/**
* The Provider that `PersistQueryClientProvider` uses to signal whether a persisted client is currently
* being restored, read by `useIsRestoring`.
*/
var IsRestoringProvider = IsRestoringContext.Provider;
// node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
var import_jsx_runtime = require_jsx_runtime();
/**
* The context that `useQueryClient` reads from. `QueryClientProvider` is the normal way to set it.
*/
var QueryClientContext = import_react.createContext(void 0);
/**
* The `useQueryClient` hook returns the current `QueryClient` instance.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The current `QueryClient` instance.
* @throws {Error} If no `queryClient` argument is passed and no `QueryClientProvider` is found in the
* component tree.
*/
var useQueryClient = (queryClient) => {
	const client = import_react.useContext(QueryClientContext);
	if (queryClient) return queryClient;
	if (!client) throw new Error("No QueryClient set, use QueryClientProvider to set one");
	return client;
};
/**
* Use the `QueryClientProvider` component to connect and provide a `QueryClient` to your application. Also
* calls `client.mount()`/`client.unmount()` as this component mounts/unmounts, which subscribes the client to
* focus/online events (resuming any paused mutations and refetching as needed when the app regains focus or
* comes back online).
* @param props - The `client` to provide, and the `children` that get access to it.
* @returns The provided `children`, wrapped so they can read the `QueryClient` via `useQueryClient`.
* @example
* ```tsx
* import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
*
* const queryClient = new QueryClient()
*
* function App() {
*   return <QueryClientProvider client={queryClient}>...</QueryClientProvider>
* }
* ```
*/
var QueryClientProvider = ({ client, children }) => {
	import_react.useEffect(() => {
		client.mount();
		return () => {
			client.unmount();
		};
	}, [client]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientContext.Provider, {
		value: client,
		children
	});
};
// node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
/**
* Creates the value shared through the boundary's context, which tracks whether a reset was
* requested.
* @returns The `clearReset`, `isReset`, and `reset` functions of the boundary.
*/
function createValue() {
	let isReset = false;
	return {
		/**
		* Clears the reset state, so queries know not to try again until the boundary is reset again.
		*/
		clearReset: () => {
			isReset = false;
		},
		/**
		* Resets any query errors within the boundary, so queries know they can try again.
		*/
		reset: () => {
			isReset = true;
		},
		/**
		* Returns whether the boundary has been reset and not yet cleared.
		* @returns `true` if the boundary has been reset and not yet cleared.
		*/
		isReset: () => {
			return isReset;
		}
	};
}
var QueryErrorResetBoundaryContext = import_react.createContext(createValue());
/**
* This hook will reset any query errors within the closest `QueryErrorResetBoundary`. If there is no boundary
* defined it will reset them globally.
* @returns The boundary's {@link QueryErrorResetBoundaryValue}.
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { useQueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App({ children }: { children: React.ReactNode }) {
*   const { reset } = useQueryErrorResetBoundary()
*
*   return (
*     <ErrorBoundary
*       onReset={reset}
*       fallbackRender={({ resetErrorBoundary }) => (
*         <div>
*           There was an error!
*           <button onClick={() => resetErrorBoundary()}>Try again</button>
*         </div>
*       )}
*     >
*       {children}
*     </ErrorBoundary>
*   )
* }
* ```
*/
var useQueryErrorResetBoundary = () => import_react.useContext(QueryErrorResetBoundaryContext);
/**
* When using `suspense` or `throwOnError` in your queries, you need a way to let queries know that you want to
* try again when re-rendering after some error occurred. With the `QueryErrorResetBoundary` component you can
* reset any query errors within the boundaries of the component.
* @param props - The `children` to render.
* @returns The `children`, rendered as-is, or called with the boundary's {@link QueryErrorResetBoundaryValue}
* if `children` is a function.
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { QueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Page />
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
var QueryErrorResetBoundary = ({ children }) => {
	const [value] = import_react.useState(() => createValue());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryErrorResetBoundaryContext.Provider, {
		value,
		children: typeof children === "function" ? children(value) : children
	});
};
// node_modules/@tanstack/query-core/build/modern/subscribable.js
/**
* The base class behind everything in Query that you can subscribe to: `QueryCache`, `MutationCache`,
* the observers, and the `FocusManager`/`OnlineManager` behind `focusManager` and `onlineManager`.
* Subclasses decide what a listener receives and when it is called.
*/
var Subscribable = class {
	constructor() {
		this.listeners = /* @__PURE__ */ new Set();
		this.subscribe = this.subscribe.bind(this);
	}
	/**
	* Registers a listener to be called on every update this object notifies about. Returns a function
	* that removes the listener again — call it to stop listening. The base class never drops a listener
	* on its own, though some subclasses clear all of theirs in `destroy()`.
	* @param listener - Called on each update, with whatever the subclass passes to its subscribers.
	* @returns A function that removes the listener.
	* @example
	* ```ts
	* const unsubscribe = subscribable.subscribe(() => {
	*   // react to the update
	* })
	*
	* unsubscribe()
	* ```
	*/
	subscribe(listener) {
		this.listeners.add(listener);
		this.onSubscribe();
		return () => {
			this.listeners.delete(listener);
			this.onUnsubscribe();
		};
	}
	/**
	* Returns `true` while at least one listener is registered, `false` once they have all unsubscribed.
	* @returns `true` if at least one listener is registered.
	*/
	hasListeners() {
		return this.listeners.size > 0;
	}
	/**
	* Called after a listener is added. Does nothing here; subclasses override it, e.g. to start
	* tracking what they observe once the first listener subscribes.
	*/
	onSubscribe() {}
	/**
	* Called after a listener is removed. Does nothing here; subclasses override it, e.g. to clean up
	* once the last listener unsubscribes.
	*/
	onUnsubscribe() {}
};
// node_modules/@tanstack/query-core/build/modern/focusManager.js
/**
* The `FocusManager` manages the focus state within TanStack Query.
*
* It can be used to change the default event listeners or to manually change the focus state.
*/
var FocusManager = class extends Subscribable {
	#focused;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onFocus) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const listener = () => onFocus();
				window.addEventListener("visibilitychange", listener, false);
				return () => {
					window.removeEventListener("visibilitychange", listener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the focus state. The provided `setup` function
	* receives a `setFocused` callback: call it with a `boolean` to manually
	* set the focus state, or with no arguments to re-evaluate the current
	* focus state and notify subscribers.
	* @param setup - Receives the `setFocused` callback, registers the event listener, and may return
	* a cleanup function that is called when the listener is replaced or no longer needed.
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* focusManager.setEventListener((handleFocus) => {
	*   const listener = () => handleFocus()
	*   // Listen to visibilitychange
	*   if (typeof window !== 'undefined' && window.addEventListener) {
	*     window.addEventListener('visibilitychange', listener, false)
	*   }
	*
	*   return () => {
	*     // Be sure to unsubscribe if a new handler is set
	*     window.removeEventListener('visibilitychange', listener)
	*   }
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup((focused) => {
			if (typeof focused === "boolean") this.setFocused(focused);
			else this.onFocus();
		});
	}
	/**
	* `setFocused` can be used to manually set the focus state. Set `undefined`
	* to fall back to the default focus check.
	* @param focused - The focus state, or `undefined` to use the default focus check.
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* // Set focused
	* focusManager.setFocused(true)
	*
	* // Set unfocused
	* focusManager.setFocused(false)
	*
	* // Fallback to the default focus check
	* focusManager.setFocused(undefined)
	* ```
	*/
	setFocused(focused) {
		if (this.#focused !== focused) {
			this.#focused = focused;
			this.onFocus();
		}
	}
	/**
	* `onFocus` notifies all subscribed listeners with the current focus state.
	*/
	onFocus() {
		const isFocused = this.isFocused();
		this.listeners.forEach((listener) => {
			listener(isFocused);
		});
	}
	/**
	* `isFocused` can be used to get the current focus state.
	* @returns The focus state set with `setFocused`, or otherwise whether the document is visible.
	*/
	isFocused() {
		if (typeof this.#focused === "boolean") return this.#focused;
		return globalThis.document?.visibilityState !== "hidden";
	}
};
/**
* Singleton instance of {@link FocusManager}, used to manage and observe the focus state within TanStack Query.
*/
var focusManager = new FocusManager();
// node_modules/@tanstack/query-core/build/modern/timeoutManager.js
var defaultTimeoutProvider = {
	setTimeout: (callback, delay) => setTimeout(callback, delay),
	clearTimeout: (timeoutId) => clearTimeout(timeoutId),
	setInterval: (callback, delay) => setInterval(callback, delay),
	clearInterval: (intervalId) => clearInterval(intervalId)
};
/**
* Allows customization of how timeouts are created.
*
* `@tanstack/query-core` makes liberal use of timeouts to implement `staleTime`
* and `gcTime`. The default TimeoutManager provider uses the platform's global
* `setTimeout` implementation, which is known to have scalability issues with
* thousands of timeouts on the event loop.
*
* If you hit this limitation, consider providing a custom TimeoutProvider that
* coalesces timeouts.
*/
var TimeoutManager = class {
	#provider = defaultTimeoutProvider;
	#providerCalled = false;
	/**
	* `setTimeoutProvider` can be used to set a custom implementation of the
	* `setTimeout`, `clearTimeout`, `setInterval`, `clearInterval` functions,
	* called a `TimeoutProvider`.
	*
	* This may be useful if you notice event loop performance issues with
	* thousands of queries. A custom TimeoutProvider could also support timer
	* delays longer than the global `setTimeout` maximum delay value of about
	* 24 days.
	*
	* It is important to call `setTimeoutProvider` before creating a
	* QueryClient or queries, so that the same provider is used consistently
	* for all timers in the application, since different TimeoutProviders
	* cannot cancel each others' timers.
	* @param provider - The `TimeoutProvider` to use for all timers from now on.
	* @example
	* ```ts
	* import { timeoutManager, QueryClient } from '@tanstack/query-core'
	* import { CustomTimeoutProvider } from './CustomTimeoutProvider'
	*
	* timeoutManager.setTimeoutProvider(new CustomTimeoutProvider())
	*
	* export const queryClient = new QueryClient()
	* ```
	*/
	setTimeoutProvider(provider) {
		if (this.#providerCalled && provider !== this.#provider) console.error(`[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.`, {
			previous: this.#provider,
			provider
		});
		this.#provider = provider;
		this.#providerCalled = false;
	}
	/**
	* `setTimeout` schedules a callback to run after approximately `delay`
	* milliseconds, like the global `setTimeout` function. The callback can be
	* canceled with `clearTimeout`.
	*
	* It returns a timer ID, which may be a number or an object that can be
	* coerced to a number via `Symbol.toPrimitive`.
	* @param callback - The function to call when the timeout elapses.
	* @param delay - The time to wait before calling `callback`, in milliseconds.
	* @returns The timer ID, to pass to {@link TimeoutManager#clearTimeout}.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* const timeoutIdNumber: number = Number(timeoutId)
	* ```
	*/
	setTimeout(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setTimeout(callback, delay);
	}
	/**
	* `clearTimeout` cancels a timeout callback scheduled with `setTimeout`,
	* like the global `clearTimeout` function. It should be called with a
	* timer ID returned by `setTimeout`.
	* @param timeoutId - The timer ID returned by `setTimeout`, or `undefined`.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearTimeout(timeoutId)
	* ```
	*/
	clearTimeout(timeoutId) {
		this.#provider.clearTimeout(timeoutId);
	}
	/**
	* `setInterval` schedules a callback to be called approximately every
	* `delay` milliseconds, like the global `setInterval` function.
	*
	* Like `setTimeout`, it returns a timer ID, which may be a number or an
	* object that can be coerced to a number via `Symbol.toPrimitive`.
	* @param callback - The function to call on every interval.
	* @param delay - The time between calls, in milliseconds.
	* @returns The timer ID, to pass to {@link TimeoutManager#clearInterval}.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	* ```
	*/
	setInterval(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setInterval(callback, delay);
	}
	/**
	* `clearInterval` can be used to cancel an interval, like the global
	* `clearInterval` function. It should be called with an interval ID
	* returned by `setInterval`.
	* @param intervalId - The timer ID returned by `setInterval`, or `undefined`.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearInterval(intervalId)
	* ```
	*/
	clearInterval(intervalId) {
		this.#provider.clearInterval(intervalId);
	}
};
/**
* Singleton instance of {@link TimeoutManager}, used throughout TanStack Query to schedule and cancel timers.
*/
var timeoutManager = new TimeoutManager();
/**
* In many cases code wants to delay to the next event loop tick; this is not
* mediated by {@link timeoutManager}.
*
* This function is provided to make auditing the `tanstack/query-core` for
* incorrect use of system `setTimeout` easier.
* @param callback - The function to call on the next event loop tick.
*/
function systemSetTimeoutZero(callback) {
	setTimeout(callback, 0);
}
// node_modules/@tanstack/query-core/build/modern/utils.js
/**
* @deprecated use `environmentManager.isServer()` instead.
*/
var isServer$1 = typeof window === "undefined" || "Deno" in globalThis;
function noop() {}
/**
* Resolves an {@link Updater}: calls it with `input` if it is a function, otherwise returns it as
* is.
* @param updater - The new value, or a function that receives `input` and returns the new value.
* @param input - The current value, passed to `updater` if it is a function.
* @returns The new value.
*/
function functionalUpdate(updater, input) {
	return typeof updater === "function" ? updater(input) : updater;
}
/**
* Checks whether a value can be used as a timeout: a non-negative, finite number.
* @param value - The value to check.
* @returns `true` if `value` is a number that is `>= 0` and not `Infinity`.
*/
function isValidTimeout(value) {
	return typeof value === "number" && value >= 0 && value !== 1e400;
}
/**
* Calculates how long until data updated at `updatedAt` becomes stale.
* @param updatedAt - The timestamp, in milliseconds, at which the data was last updated.
* @param staleTime - The time, in milliseconds, after which data is considered stale. Defaults to
* `0`.
* @returns The remaining time in milliseconds, or `0` if the data is already stale.
*/
function timeUntilStale(updatedAt, staleTime) {
	return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
/**
* Resolves an option that can be given either as a value or as a function of the query, such as
* `staleTime`.
* @param value - The option value, or a function that receives `query` and returns the value.
* @param query - The query passed to `value` if it is a function.
* @returns The resolved value, or `undefined` if `value` is `undefined`.
*/
function resolveQueryValue(value, query) {
	return typeof value === "function" ? value(query) : value;
}
/**
* Checks whether a query matches the given {@link QueryFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
* @param filters - The filters to check the query against.
* @param query - The query to check.
* @returns `true` if the query matches every specified filter.
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
*
* const matchingQueries = queryCache
*   .getAll()
*   .filter((query) => matchQuery({ queryKey: ['posts'] }, query))
* ```
*/
function matchQuery(filters, query) {
	const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
	if (queryKey) {
		if (exact) {
			if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) return false;
		} else if (!partialMatchKey(query.queryKey, queryKey)) return false;
	}
	if (type !== "all") {
		const isActive = query.isActive();
		if (type === "active" && !isActive) return false;
		if (type === "inactive" && isActive) return false;
	}
	if (typeof stale === "boolean" && query.isStale() !== stale) return false;
	if (fetchStatus && fetchStatus !== query.state.fetchStatus) return false;
	if (predicate && !predicate(query)) return false;
	return true;
}
/**
* Checks whether a mutation matches the given {@link MutationFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
* If a `mutationKey` filter is provided but the mutation has no `mutationKey` of its own, it does not match.
* @param filters - The filters to check the mutation against.
* @param mutation - The mutation to check.
* @returns `true` if the mutation matches every specified filter.
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const matchingMutations = mutationCache
*   .getAll()
*   .filter((mutation) => matchMutation({ mutationKey: ['addPost'] }, mutation))
* ```
*/
function matchMutation(filters, mutation) {
	const { exact, status, predicate, mutationKey } = filters;
	if (mutationKey) {
		if (!mutation.options.mutationKey) return false;
		if (exact) {
			if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) return false;
		} else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) return false;
	}
	if (status && mutation.state.status !== status) return false;
	if (predicate && !predicate(mutation)) return false;
	return true;
}
/**
* Hashes a query key with the query's `queryKeyHashFn` option, falling back to {@link hashKey}.
* @param queryKey - The query key to hash.
* @param options - The query options that may provide a custom `queryKeyHashFn`.
* @returns The query hash, a string that identifies the query in the cache.
*/
function hashQueryKeyByOptions(queryKey, options) {
	return (options?.queryKeyHashFn || hashKey)(queryKey);
}
/**
* Default query & mutation keys hash function.
* Hashes the value into a stable hash.
* @param queryKey - The query or mutation key to hash.
* @returns The stable hash of the key, as a JSON string.
* @example
* ```ts
* // Object keys are sorted, so key order doesn't affect the hash:
* hashKey(['todos', { page: 1, filter: 'done' }]) // === '["todos",{"filter":"done","page":1}]'
* ```
*/
function hashKey(queryKey) {
	return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
		result[key] = val[key];
		return result;
	}, {}) : val);
}
function partialMatchKey(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (a && b && typeof a === "object" && typeof b === "object") {
		if (Array.isArray(a) !== Array.isArray(b)) return false;
		if (Array.isArray(a) && Array.isArray(b)) {
			if (b.length > a.length) return false;
			for (let i = 0; i < b.length; i++) if (!partialMatchKey(a[i], b[i])) return false;
			return true;
		}
		const bKeys = Object.keys(b);
		for (const key of bKeys) if (!partialMatchKey(a[key], b[key])) return false;
		return true;
	}
	return false;
}
var hasOwn = Object.prototype.hasOwnProperty;
function replaceEqualDeep(a, b, depth = 0) {
	if (a === b) return a;
	if (depth > 500) return b;
	const array = isPlainArray(a) && isPlainArray(b);
	if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
	const aSize = (array ? a : Object.keys(a)).length;
	const bItems = array ? b : Object.keys(b);
	const bSize = bItems.length;
	const copy = array ? new Array(bSize) : {};
	let equalItems = 0;
	for (let i = 0; i < bSize; i++) {
		const key = array ? i : bItems[i];
		const aItem = a[key];
		const bItem = b[key];
		if (aItem === bItem) {
			copy[key] = aItem;
			if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
			continue;
		}
		if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
			copy[key] = bItem;
			continue;
		}
		const v = replaceEqualDeep(aItem, bItem, depth + 1);
		copy[key] = v;
		if (v === aItem) equalItems++;
	}
	return aSize === bSize && equalItems === aSize ? a : copy;
}
/**
* Shallow compare objects.
* @param a - The first object.
* @param b - The second object, or `undefined`.
* @returns `true` if both objects have the same keys, with strictly equal values for each key.
*/
function shallowEqualObjects(a, b) {
	if (!b || Object.keys(a).length !== Object.keys(b).length) return false;
	for (const key of Object.keys(a)) if (!hasOwn.call(b, key) || a[key] !== b[key]) return false;
	return true;
}
/**
* Checks whether a value is an array with no holes and no extra properties.
* @param value - The value to check.
* @returns `true` if `value` is an array whose number of own keys equals its `length`.
*/
function isPlainArray(value) {
	return Array.isArray(value) && value.length === Object.keys(value).length;
}
/**
* Checks whether a value is a plain object, e.g. created with an object literal or
* `Object.create(null)`.
* @param o - The value to check.
* @returns `true` if `o` is a plain object.
*/
function isPlainObject(o) {
	if (!hasObjectPrototype(o)) return false;
	const objectPrototype = Object.getPrototypeOf(o);
	const ctor = objectPrototype?.constructor;
	if (ctor === void 0) return true;
	if (typeof ctor !== "function") return false;
	const prot = ctor.prototype;
	if (!hasObjectPrototype(prot)) return false;
	if (!prot.hasOwnProperty("isPrototypeOf")) return false;
	if (objectPrototype !== Object.prototype) return false;
	return true;
}
/**
* Checks whether a value's `Object.prototype.toString` tag is `[object Object]`.
* @param o - The value to check.
* @returns `true` if the tag is `[object Object]`.
*/
function hasObjectPrototype(o) {
	return Object.prototype.toString.call(o) === "[object Object]";
}
/**
* Waits for the given time, using the configured {@link timeoutManager}.
* @param timeout - The time to wait, in milliseconds.
* @returns A promise that resolves after `timeout` milliseconds.
*/
function sleep(timeout) {
	return new Promise((resolve) => {
		timeoutManager.setTimeout(resolve, timeout);
	});
}
/**
* Applies a query's `structuralSharing` option when writing new data.
* @param prevData - The previously cached data.
* @param data - The new data.
* @param options - The query options, whose `structuralSharing` decides how the data is merged.
* @returns The result of a custom `structuralSharing` function, `data` with its unchanged parts
* replaced by those of `prevData` by default, or `data` as is if `structuralSharing` is `false`.
* @throws {Error} The error from the default structural sharing, e.g. when the data is not JSON serializable.
* Outside production, it is also logged to the console.
*/
function replaceData(prevData, data, options) {
	if (typeof options.structuralSharing === "function") return options.structuralSharing(prevData, data);
	else if (options.structuralSharing !== false) try {
		return replaceEqualDeep(prevData, data);
	} catch (error) {
		console.error(`Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [${options.queryHash}]: ${error}`);
		throw error;
	}
	return data;
}
/**
* Intended to be passed as a query's `placeholderData` option, for example
* `placeholderData: keepPreviousData`. Instead of resetting the query's data to `undefined` while a new
* query key is fetching, it keeps displaying the previously fetched data until the new data arrives.
* @param previousData - The data of the previous query key, passed by the observer.
* @returns The previous data, unchanged.
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['posts', page],
*   queryFn: () => fetchPosts(page),
*   placeholderData: keepPreviousData,
* })
* ```
*/
function keepPreviousData(previousData) {
	return previousData;
}
/**
* Adds an item to one end of a new array. If the result exceeds `max`, removes
* excess items from the opposite end.
* @param items - The current items.
* @param item - The value to add.
* @param max - The maximum number of items to keep. Omit it or use `0` for no limit.
* @param prepend - Pass `true` to add at the start. The default is to add at the end.
* @returns A new array with `item` added.
*/
function addToArray(items, item, max, prepend) {
	const newItems = prepend ? [item, ...items] : [...items, item];
	if (max && newItems.length > max) return prepend ? newItems.slice(0, max) : newItems.slice(-max);
	return newItems;
}
/**
* Sentinel value that can be passed as a query's `queryFn` to conditionally disable the query (equivalent
* to `enabled: false`) while preserving full type inference for the query's data. Unlike `enabled: false`,
* a query disabled via `skipToken` cannot be triggered with `refetch`.
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['post', postId],
*   queryFn: postId != null ? () => fetchPost(postId) : skipToken,
* })
* ```
*/
var skipToken = Symbol();
/**
* Returns the function to call for a fetch. If there is no `queryFn` but the fetch was started from
* an `initialPromise`, that promise is returned instead. If there is no usable `queryFn` (missing or
* {@link skipToken}), the returned function rejects with a `Missing queryFn` error.
* @param options - The query options with the `queryFn`, and the `queryHash` used in error messages.
* @param fetchOptions - The fetch options, which may carry an `initialPromise`.
* @returns The function to call for the fetch.
*/
function ensureQueryFn(options, fetchOptions) {
	if (options.queryFn === skipToken) console.error(`Attempted to invoke queryFn when set to skipToken. This is likely a configuration error. Query hash: '${options.queryHash}'`);
	if (!options.queryFn && fetchOptions?.initialPromise) return () => fetchOptions.initialPromise;
	if (!options.queryFn || options.queryFn === skipToken) return () => Promise.reject(/* @__PURE__ */ new Error(`Missing queryFn: '${options.queryHash}'`));
	return options.queryFn;
}
/**
* Resolves a `throwOnError` option to a boolean.
* If `throwOnError` is a function, it is called with `params` (e.g. the error and, depending on the caller,
* additional context such as the query or mutation) and its result is returned, allowing the throwing
* behavior to be decided per error. Otherwise, `throwOnError` itself is coerced to a boolean (`undefined`
* resolves to `false`).
* @param throwOnError - The `throwOnError` option: a boolean, a function that decides per error, or
* `undefined`.
* @param params - The arguments passed to `throwOnError` if it is a function.
* @returns Whether the error should be thrown.
* @example
* ```ts
* const throwOnError =
*   query.state.error && typeof options.throwOnError === 'function'
*     ? shouldThrowError(options.throwOnError, [query.state.error, query])
*     : options.throwOnError
* ```
*/
function shouldThrowError(throwOnError, params) {
	if (typeof throwOnError === "function") return throwOnError(...params);
	return !!throwOnError;
}
var fetchSignal = Symbol();
/**
* Adds a lazy `signal` getter to an object, such as a query function context. The first time
* `signal` is read, `onCancelled` is registered for the signal's `abort` event (or called right
* away if it is already aborted), so cancellation is only tracked when the signal is actually used.
* @param object - The object to add the `signal` property to.
* @param getSignal - Returns the `AbortSignal`. Called once, when `signal` is first read.
* @param onCancelled - Called when the signal is aborted, if `signal` was read.
* @param internalSignal - The fetch signal to forward without consuming the getter.
* @returns The same object, with the `signal` property added.
*/
function addConsumeAwareSignal(object, getSignal, onCancelled, internalSignal) {
	let consumed = false;
	let signal;
	Object.defineProperties(object, {
		[fetchSignal]: { value: internalSignal },
		signal: {
			enumerable: true,
			get: () => {
				signal ??= getSignal();
				if (consumed) return signal;
				consumed = true;
				if (signal.aborted) onCancelled();
				else signal.addEventListener("abort", onCancelled, { once: true });
				return signal;
			}
		}
	});
	return object;
}
// node_modules/@tanstack/query-core/build/modern/environmentManager.js
var isServerFn = () => isServer$1;
/**
* Returns whether the current runtime should be treated as a server environment.
* @returns `true` if the runtime is treated as a server.
*/
var isServer = () => isServerFn();
/**
* Manages how TanStack Query detects whether the current runtime should be treated as
* server-side, which disables scheduling refetch timers and changes the default `retry` count
* and `gcTime`. By default, the detection treats a missing `window` (or the presence of a
* `Deno` global) as server.
*
* Override this for runtimes where that default detection would give the wrong answer — for
* example, a Service Worker, where `window` is undefined even though the environment should
* behave like a client.
* @example
* ```ts
* import { environmentManager } from '@tanstack/query-core'
*
* environmentManager.setIsServer(() => false)
* ```
*/
var environmentManager = {
	isServer,
	/**
	* Overrides the server check globally.
	* @param isServerValue - A function that returns whether the runtime should be treated as a
	* server.
	*/
	setIsServer(isServerValue) {
		isServerFn = isServerValue;
	}
};
// node_modules/@tanstack/query-core/build/modern/hydration.js
/**
* Reads the value of a promise synchronously if it has already resolved, e.g. a thenable that
* resolves within its `then` call.
* @param promise - The promise to read.
* @returns An object with the resolved `data`, or `undefined` if the promise hasn't resolved
* synchronously (or resolved with `undefined`).
*/
function tryResolveSync(promise) {
	let data;
	promise.then((result) => {
		data = result;
		return result;
	}, noop)?.catch?.(noop);
	if (data !== void 0) return { data };
}
/**
* Dehydrates a single `Mutation` into a serializable snapshot of its key, state, scope, and meta.
* @param mutation - The mutation to dehydrate.
* @returns The dehydrated mutation.
*/
function dehydrateMutation(mutation) {
	return {
		mutationKey: mutation.options.mutationKey,
		state: mutation.state,
		...mutation.options.scope && { scope: mutation.options.scope },
		...mutation.meta && { meta: mutation.meta }
	};
}
/**
* Prepares the in-flight promise of a pending query for dehydration: applies `serializeData` to its
* result, and redacts its rejection error unless `shouldRedactErrors` returns `false` for it.
* @param query - The pending query whose promise is dehydrated.
* @param serializeData - Optional transform applied to the resolved data.
* @param shouldRedactErrors - Optional predicate; if it returns `false` for the rejection error,
* that
* error is kept as-is instead of being redacted.
* @returns The transformed promise, or `undefined` if the query has no in-flight promise.
*/
function dehydratePromise(query, serializeData, shouldRedactErrors) {
	const promise = query.promise?.then(serializeData).catch((error) => {
		if (shouldRedactErrors?.(error) === false) return Promise.reject(error);
		console.error(`A query that was dehydrated as pending ended up rejecting. [${query.queryHash}]: ${error}; The error will be redacted in production builds`);
		return Promise.reject(/* @__PURE__ */ new Error("redacted"));
	});
	promise?.catch(noop);
	return promise;
}
/**
* Dehydrates a single `Query` into a serializable `DehydratedQuery` snapshot. Note that most query config (e.g.
* `queryFn`, `staleTime`) is not dehydrated but instead meant to be configured again when consuming the
* de/rehydrated data, typically with `useQuery` on the client. If the query is still `pending`, its in-flight
* promise is dehydrated too so it can be resumed on the other side instead of re-fetched.
* @param query - The query to dehydrate.
* @param serializeData - Optional transform applied to `query.state.data` before it is included in the snapshot.
* @param shouldRedactErrors - Optional predicate; if it returns `false` for the promise's rejection error, that
* error is kept as-is instead of being redacted.
* @returns The dehydrated query.
*/
function dehydrateQuery(query, serializeData, shouldRedactErrors) {
	return {
		dehydratedAt: Date.now(),
		state: {
			...query.state,
			...query.state.data !== void 0 && { data: serializeData ? serializeData(query.state.data) : query.state.data }
		},
		queryKey: query.queryKey,
		queryHash: query.queryHash,
		...query.state.status === "pending" && { promise: dehydratePromise(query, serializeData, shouldRedactErrors) },
		...query.meta && { meta: query.meta },
		...query.queryType && { queryType: query.queryType }
	};
}
/**
* The default `shouldDehydrateMutation` predicate used by `dehydrate`. Only dehydrates mutations that are
* currently paused (e.g. paused by `networkMode` while offline).
* @param mutation - The mutation to check.
* @returns `true` if the mutation is paused.
*/
function defaultShouldDehydrateMutation(mutation) {
	return mutation.state.isPaused;
}
/**
* The default `shouldDehydrateQuery` predicate used by `dehydrate`. Only dehydrates queries whose status is
* `'success'`.
* @param query - The query to check.
* @returns `true` if the query's status is `'success'`.
*/
function defaultShouldDehydrateQuery(query) {
	return query.state.status === "success";
}
/**
* Dehydrates a `QueryClient`'s cache (queries and mutations) into a plain, serializable `DehydratedState`,
* typically to embed in server-rendered markup and later restore into a client-side `QueryClient` via `hydrate`.
* Which queries/mutations are included, and how their data/errors are transformed, is controlled by `options`,
* falling back to the client's `dehydrate` default options, and finally to `defaultShouldDehydrateQuery` /
* `defaultShouldDehydrateMutation`.
* @param client - The client whose cache is dehydrated.
* @param options - Controls which queries and mutations are included and how their data and errors
* are transformed. Each option falls back to the client's `defaultOptions.dehydrate`.
* @returns The dehydrated state, with the included `queries` and `mutations`.
* @example
* ```ts
* const queryClient = new QueryClient()
*
* await queryClient.prefetchQuery({
*   queryKey: ['posts'],
*   queryFn: getPosts,
* })
*
* const dehydratedState = dehydrate(queryClient)
* ```
*/
function dehydrate(client, options = {}) {
	const filterMutation = options.shouldDehydrateMutation ?? client.getDefaultOptions().dehydrate?.shouldDehydrateMutation ?? defaultShouldDehydrateMutation;
	const mutations = client.getMutationCache().getAll().flatMap((mutation) => filterMutation(mutation) ? [dehydrateMutation(mutation)] : []);
	const filterQuery = options.shouldDehydrateQuery ?? client.getDefaultOptions().dehydrate?.shouldDehydrateQuery ?? defaultShouldDehydrateQuery;
	const shouldRedactErrors = options.shouldRedactErrors ?? client.getDefaultOptions().dehydrate?.shouldRedactErrors;
	const serializeData = options.serializeData ?? client.getDefaultOptions().dehydrate?.serializeData;
	return {
		mutations,
		queries: client.getQueryCache().getAll().flatMap((query) => filterQuery(query) ? [dehydrateQuery(query, serializeData, shouldRedactErrors)] : [])
	};
}
/**
* Restores a `DehydratedState` (as produced by `dehydrate`) into a `QueryClient`'s cache, typically to seed the
* client with data already fetched on the server. `mutations` and `queries` are each optional on `dehydratedState`.
* Queries not yet in the cache are built from the dehydrated snapshot; queries that already exist are only updated
* when the dehydrated data is newer than what's already cached. Newly built queries have their `fetchStatus` reset
* to `'idle'` so they don't hydrate stuck in a fetching state. If a dehydrated query still had an in-flight
* promise, it is resumed via `query.fetch()` (reusing that promise as `initialPromise`) rather than re-invoking
* `queryFn`.
* @param client - The client whose cache is restored into.
* @param dehydratedState - The dehydrated state, e.g. produced by `dehydrate` on the server.
* @param options - `defaultOptions` merged into every restored query and mutation (on top of the
* client's `defaultOptions.hydrate`), and `deserializeData` to reverse `serializeData`.
* @example
* ```ts
* // dehydratedState was produced by `dehydrate` on the server
* // and sent to the client, e.g. embedded in server-rendered markup.
* const queryClient = new QueryClient()
*
* hydrate(queryClient, dehydratedState)
* ```
*/
function hydrate(client, dehydratedState, options) {
	const mutationCache = client.getMutationCache();
	const queryCache = client.getQueryCache();
	const deserializeData = options?.defaultOptions?.deserializeData ?? client.getDefaultOptions().hydrate?.deserializeData;
	dehydratedState.mutations?.forEach(({ state, ...mutationOptions }) => {
		mutationCache.build(client, {
			...client.getDefaultOptions().hydrate?.mutations,
			...options?.defaultOptions?.mutations,
			...mutationOptions
		}, state);
	});
	dehydratedState.queries?.forEach(({ queryKey, state, queryHash, meta, promise, dehydratedAt, queryType }) => {
		const syncData = promise ? tryResolveSync(promise) : void 0;
		const rawData = state.data === void 0 ? syncData?.data : state.data;
		const data = rawData === void 0 ? rawData : deserializeData ? deserializeData(rawData) : rawData;
		let query = queryCache.get(queryHash);
		const existingQueryIsPending = query?.state.status === "pending";
		const existingQueryIsFetching = query?.state.fetchStatus === "fetching";
		if (query) {
			const hasNewerSyncData = syncData && dehydratedAt > query.state.dataUpdatedAt;
			if (state.dataUpdatedAt > query.state.dataUpdatedAt || hasNewerSyncData) {
				const { fetchStatus: _ignored, ...serializedState } = state;
				query.setState({
					...serializedState,
					data,
					...state.status === "pending" && data !== void 0 && {
						status: "success",
						dataUpdatedAt: dehydratedAt,
						...!existingQueryIsFetching && { fetchStatus: "idle" }
					}
				});
			}
		} else query = queryCache.build(client, {
			...client.getDefaultOptions().hydrate?.queries,
			...options?.defaultOptions?.queries,
			queryKey,
			queryHash,
			meta,
			_type: queryType
		}, {
			...state,
			data,
			fetchStatus: "idle",
			status: state.status === "pending" && data !== void 0 ? "success" : state.status,
			...state.status === "pending" && data !== void 0 && { dataUpdatedAt: dehydratedAt }
		});
		if (promise && !syncData && !existingQueryIsPending && !existingQueryIsFetching && dehydratedAt > query.state.dataUpdatedAt) query.fetch(void 0, { initialPromise: Promise.resolve(promise).then(deserializeData) }).catch(noop);
	});
}
// node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js
/**
* Creates the behavior that fetches the pages of an infinite query: the next or previous page for
* `fetchNextPage`/`fetchPreviousPage`, or all pages again from the start on a refetch.
* @param pages - The number of pages to fetch from the start when all pages are fetched again,
* e.g. from the `pages` option of `queryClient.infiniteQuery`. Defaults to the number of cached
* pages.
* @returns The query behavior to set on an infinite query.
*/
function infiniteQueryBehavior(pages) {
	return { onFetch: (context, query) => {
		const options = context.options;
		const direction = context.fetchOptions?.meta?.fetchMore?.direction;
		const oldPages = context.state.data?.pages || [];
		const oldPageParams = context.state.data?.pageParams || [];
		let result = {
			pages: [],
			pageParams: []
		};
		let currentPage = 0;
		const fetchFn = async () => {
			let cancelled = false;
			const signalContext = context;
			const addSignalProperty = (object) => {
				addConsumeAwareSignal(object, () => context.signal, () => cancelled = true, signalContext[fetchSignal]);
			};
			const queryFn = ensureQueryFn(context.options, context.fetchOptions);
			const fetchPage = async (data, param, previous) => {
				if (cancelled) return Promise.reject(context.signal.reason);
				if (param == null && data.pages.length) return Promise.resolve(data);
				const createQueryFnContext = () => {
					const queryFnContext = {
						client: context.client,
						queryKey: context.queryKey,
						pageParam: param,
						direction: previous ? "backward" : "forward",
						meta: context.options.meta
					};
					addSignalProperty(queryFnContext);
					return queryFnContext;
				};
				const queryFnContext = createQueryFnContext();
				const page = await queryFn(queryFnContext);
				const { maxPages } = context.options;
				return {
					pages: addToArray(data.pages, page, maxPages, previous),
					pageParams: addToArray(data.pageParams, param, maxPages, previous)
				};
			};
			if (direction && oldPages.length) {
				const previous = direction === "backward";
				const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
				const oldData = {
					pages: oldPages,
					pageParams: oldPageParams
				};
				result = await fetchPage(oldData, pageParamFn(options, oldData), previous);
			} else {
				const remainingPages = pages ?? oldPages.length;
				do {
					const param = currentPage === 0 ? oldPageParams[0] === void 0 ? options.initialPageParam : oldPageParams[0] : getNextPageParam(options, result);
					if (currentPage > 0 && param == null) break;
					result = await fetchPage(result, param);
					currentPage++;
				} while (currentPage < remainingPages);
			}
			return result;
		};
		if (context.options.persister) context.fetchFn = () => {
			return context.options.persister?.(fetchFn, {
				client: context.client,
				queryKey: context.queryKey,
				meta: context.options.meta,
				signal: context.signal
			}, query);
		};
		else context.fetchFn = fetchFn;
	} };
}
/**
* Computes the page param of the page after the last one, with the `getNextPageParam` option.
* @param options - The infinite query options.
* @param data - The current pages and page params.
* @returns The next page param, or `undefined` if there are no pages yet.
*/
function getNextPageParam(options, { pages, pageParams }) {
	const lastIndex = pages.length - 1;
	return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
}
/**
* Computes the page param of the page before the first one, with the `getPreviousPageParam`
* option.
* @param options - The infinite query options.
* @param data - The current pages and page params.
* @returns The previous page param, or `undefined` if there are no pages yet or no
* `getPreviousPageParam` option.
*/
function getPreviousPageParam(options, { pages, pageParams }) {
	return pages.length > 0 ? options.getPreviousPageParam?.(pages[0], pages, pageParams[0], pageParams) : void 0;
}
/**
* Checks if there is a next page.
* @param options - The infinite query options with `getNextPageParam`.
* @param data - The current pages and page params.
* @returns `true` if `getNextPageParam` returns a value other than `null` or `undefined`.
*/
function hasNextPage(options, data) {
	if (!data) return false;
	return getNextPageParam(options, data) != null;
}
/**
* Checks if there is a previous page.
* @param options - The infinite query options with `getPreviousPageParam`.
* @param data - The current pages and page params.
* @returns `true` if `getPreviousPageParam` is set and returns a value other than `null` or
* `undefined`.
*/
function hasPreviousPage(options, data) {
	if (!data || !options.getPreviousPageParam) return false;
	return getPreviousPageParam(options, data) != null;
}
// node_modules/@tanstack/query-core/build/modern/notifyManager.js
/**
* Default scheduling function used by the notify manager.
* Schedules the callback with the system's `setTimeout(callback, 0)`.
*/
var defaultScheduler = systemSetTimeoutZero;
/**
* Creates a notify manager, which schedules and batches notifications to subscribers. Query uses a
* single instance of it, exported as {@link notifyManager}.
* @returns A new notify manager.
*/
function createNotifyManager() {
	let queue = [];
	let transactions = 0;
	let notifyFn = (callback) => {
		callback();
	};
	let batchNotifyFn = (callback) => {
		callback();
	};
	let scheduleFn = defaultScheduler;
	const schedule = (callback) => {
		if (transactions) queue.push(callback);
		else scheduleFn(() => {
			notifyFn(callback);
		});
	};
	const flush = () => {
		const originalQueue = queue;
		queue = [];
		if (originalQueue.length) scheduleFn(() => {
			batchNotifyFn(() => {
				originalQueue.forEach((callback) => {
					notifyFn(callback);
				});
			});
		});
	};
	return {
		/**
		* Batches all updates scheduled inside the passed callback.
		* This is mainly used internally to optimize query client updating.
		* Batches can be nested; the queue is only flushed once the outermost `batch` call finishes.
		* The return value of `callback` is passed through.
		* @param callback - The function to run in the batch.
		* @returns The return value of `callback`.
		*/
		batch: (callback) => {
			let result;
			transactions++;
			try {
				result = callback();
			} finally {
				transactions--;
				if (!transactions) flush();
			}
			return result;
		},
		/**
		* All calls to the wrapped function will be batched.
		* @param callback - The function to wrap.
		* @returns A function that schedules a call to `callback` with the given arguments.
		*/
		batchCalls: (callback) => {
			return (...args) => {
				schedule(() => {
					callback(...args);
				});
			};
		},
		/**
		* Schedules a function to be run on the next batch.
		* By default, the batch is run with a `setTimeout`, but this can be configured via `setScheduler`.
		*/
		schedule,
		/**
		* Use this method to set a custom notify function.
		* This can be used to for example wrap notifications with `React.act` while running tests.
		* @param fn - Receives each notification callback and must call it.
		*/
		setNotifyFunction: (fn) => {
			notifyFn = fn;
		},
		/**
		* Use this method to set a custom function to batch notifications together into a single tick.
		* Framework adapters use this to plug in their own batching primitive, so that a single query
		* update only triggers one re-render instead of one per subscriber.
		* @param fn - Receives a function that runs a batch of notifications and must call it.
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		* import { batch } from 'solid-js'
		*
		* notifyManager.setBatchNotifyFunction(batch)
		* ```
		*/
		setBatchNotifyFunction: (fn) => {
			batchNotifyFn = fn;
		},
		/**
		* Configures a custom callback that schedules when the next batch runs.
		* The default behavior is `setTimeout(callback, 0)`.
		* @param fn - Receives a callback that runs the next batch, and schedules it.
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		*
		* // Schedule batches in the next microtask
		* notifyManager.setScheduler(queueMicrotask)
		*
		* // Schedule batches before the next frame is rendered
		* notifyManager.setScheduler(requestAnimationFrame)
		*
		* // Schedule batches some time in the future
		* notifyManager.setScheduler((cb) => setTimeout(cb, 10))
		* ```
		*/
		setScheduler: (fn) => {
			scheduleFn = fn;
		}
	};
}
/**
* Handles scheduling and batching callbacks in TanStack Query.
*/
var notifyManager = createNotifyManager();
// node_modules/@tanstack/query-core/build/modern/removable.js
/**
* The base class for cache entries that are garbage collected once nothing is using them —
* `Query` and `Mutation` both extend it. `gcTime` controls how long an unused entry is kept.
*/
var Removable = class {
	#gcTimeout;
	/**
	* Clears the pending garbage collection timeout, so the entry is no longer scheduled for removal.
	* A subclass may override this to release what it holds on to as well — `Query` also cancels any
	* in-flight fetch.
	*/
	destroy() {
		this.clearGcTimeout();
	}
	/**
	* Schedules the entry to be removed from its cache after `gcTime`, replacing any timeout scheduled
	* before. Nothing is scheduled if `gcTime` is `Infinity`.
	*/
	scheduleGc() {
		this.clearGcTimeout();
		if (isValidTimeout(this.gcTime)) this.#gcTimeout = timeoutManager.setTimeout(() => {
			this.optionalRemove();
		}, this.gcTime);
	}
	/**
	* Updates `gcTime`, keeping the longest one seen so far. Without a value, it defaults to 5 minutes
	* on the client and `Infinity` on the server.
	* @param newGcTime - The `gcTime` from the latest options, if any.
	*/
	updateGcTime(newGcTime) {
		this.gcTime = Math.max(this.gcTime || 0, newGcTime ?? (isServer() ? 1e400 : 3e5));
	}
	/**
	* Cancels the scheduled removal, if there is one.
	*/
	clearGcTimeout() {
		if (this.#gcTimeout !== void 0) {
			timeoutManager.clearTimeout(this.#gcTimeout);
			this.#gcTimeout = void 0;
		}
	}
};
// node_modules/@tanstack/query-core/build/modern/onlineManager.js
/**
* The `OnlineManager` manages the online state within TanStack Query. It can
* be used to change the default event listeners or to manually change the
* online state.
*
* By default, the `onlineManager` assumes an active network connection, and
* listens to the `online` and `offline` events on the `window` object to
* detect changes.
*/
var OnlineManager = class extends Subscribable {
	#online = true;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onOnline) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const onlineListener = () => onOnline(true);
				const offlineListener = () => onOnline(false);
				window.addEventListener("online", onlineListener, false);
				window.addEventListener("offline", offlineListener, false);
				return () => {
					window.removeEventListener("online", onlineListener);
					window.removeEventListener("offline", offlineListener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the online state. The provided `setup` function
	* receives a `setOnline` callback that should be called with a `boolean`
	* whenever the online state changes.
	* @param setup - Receives the `setOnline` callback, registers the event listener, and may return
	* a cleanup function that is called when the listener is replaced or no longer needed.
	* @example
	* ```ts
	* import NetInfo from '@react-native-community/netinfo'
	* import { onlineManager } from '@tanstack/query-core'
	*
	* onlineManager.setEventListener((setOnline) => {
	*   return NetInfo.addEventListener((state) => {
	*     setOnline(!!state.isConnected)
	*   })
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup(this.setOnline.bind(this));
	}
	/**
	* `setOnline` can be used to manually set the online state.
	* @param online - The online state.
	* @example
	* ```ts
	* import { onlineManager } from '@tanstack/query-core'
	*
	* // Set to online
	* onlineManager.setOnline(true)
	*
	* // Set to offline
	* onlineManager.setOnline(false)
	* ```
	*/
	setOnline(online) {
		if (this.#online !== online) {
			this.#online = online;
			this.listeners.forEach((listener) => {
				listener(online);
			});
		}
	}
	/**
	* `isOnline` can be used to get the current online state.
	* @returns `true` if online.
	*/
	isOnline() {
		return this.#online;
	}
};
/**
* Singleton instance of {@link OnlineManager}, used to manage and observe the online state within TanStack Query.
*/
var onlineManager = new OnlineManager();
// node_modules/@tanstack/query-core/build/modern/retryer.js
/**
* The default `retryDelay`: doubles with every failure, starting at 1 second, up to 30 seconds.
* @param failureCount - The number of failures so far.
* @returns The delay before the next retry, in milliseconds.
*/
function defaultRetryDelay(failureCount) {
	return Math.min(1e3 * 2 ** failureCount, 3e4);
}
/**
* Checks whether a fetch can run for the given network mode.
* @param networkMode - The `networkMode` option. Defaults to `'online'`.
* @returns `true` if the network mode is not `'online'`, or if it is and the client is online.
*/
function canFetch(networkMode) {
	return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
}
/**
* The error thrown by a `Retryer` (and surfaced to `query.promise`/`mutation`) when a fetch is cancelled, e.g. via
* `query.cancel()`. `revert`, if `true`, tells the caller to restore the state the query was in before the fetch
* started instead of surfacing the error. `silent`, if `true`, tells the caller to suppress this error and instead
* resolve with the promise of the fetch that triggered the cancellation.
* @example
* ```ts
* query.cancel()
*
* try {
*   await query.promise
* } catch (error) {
*   if (error instanceof CancelledError) {
*     // the fetch was cancelled, e.g. via `query.cancel()`
*   }
* }
* ```
*/
var CancelledError = class extends Error {
	constructor(options) {
		super("CancelledError");
		this.revert = options?.revert;
		this.silent = options?.silent;
	}
};
/**
* Checks whether a value is a `CancelledError`.
* @param value - The value to check.
* @returns `true` if `value` is a `CancelledError`.
* @deprecated Use instanceof `CancelledError` instead.
*/
function isCancelledError(value) {
	return value instanceof CancelledError;
}
/**
* Creates a retryer, which runs a function and retries it on failure according to the `retry` and
* `retryDelay` options. It pauses while the network mode doesn't allow fetching or `canRun` returns
* `false`, and can be cancelled. Queries and mutations use it to run their `queryFn` and
* `mutationFn`.
* @param config - The function to run, the retry options, and the callbacks for failures, pausing,
* continuing, and cancellation.
* @returns The retryer, whose `promise` settles with the result of the function.
*/
function createRetryer(config) {
	let isRetryCancelled = false;
	let failureCount = 0;
	let continueFn;
	let status = "pending";
	let promiseResolve;
	let promiseReject;
	const promise = new Promise((resolve, reject) => {
		promiseResolve = resolve;
		promiseReject = reject;
	});
	promise.catch(noop);
	const isResolved = () => status !== "pending";
	const cancel = (cancelOptions) => {
		if (!isResolved()) {
			const error = new CancelledError(cancelOptions);
			reject(error);
			config.onCancel?.(error);
		}
	};
	const cancelRetry = () => {
		isRetryCancelled = true;
	};
	const continueRetry = () => {
		isRetryCancelled = false;
	};
	const canContinue = () => focusManager.isFocused() && (config.networkMode === "always" || onlineManager.isOnline()) && config.canRun();
	const canStart = () => canFetch(config.networkMode) && config.canRun();
	const resolve = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "resolved";
			promiseResolve(value);
		}
	};
	const reject = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "rejected";
			promiseReject(value);
		}
	};
	const pause = (canResume) => {
		return new Promise((continueResolve) => {
			continueFn = (value) => {
				if (isResolved() || canResume()) continueResolve(value);
			};
			config.onPause?.();
		}).then(() => {
			continueFn = void 0;
			if (!isResolved()) config.onContinue?.();
		});
	};
	const run = () => {
		if (isResolved()) return;
		let promiseOrValue;
		const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
		try {
			promiseOrValue = initialPromise ?? config.fn();
		} catch (error) {
			promiseOrValue = Promise.reject(error);
		}
		Promise.resolve(promiseOrValue).then(resolve).catch((error) => {
			if (isResolved()) return;
			const retry = config.retry ?? (isServer() ? 0 : 3);
			const retryDelay = config.retryDelay ?? defaultRetryDelay;
			const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
			const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
			if (isRetryCancelled || !shouldRetry) {
				reject(error);
				return;
			}
			failureCount++;
			config.onFail?.(failureCount, error);
			sleep(delay).then(() => {
				return isResolved() || canContinue() ? void 0 : pause(canContinue);
			}).then(() => {
				if (isRetryCancelled) reject(error);
				else run();
			});
		});
	};
	return {
		promise,
		status: () => status,
		cancel,
		continue: () => {
			continueFn?.();
			return promise;
		},
		cancelRetry,
		continueRetry,
		canStart,
		start: () => {
			if (canStart()) run();
			else pause(canStart).then(run);
			return promise;
		}
	};
}
// node_modules/@tanstack/query-core/build/modern/query.js
/**
* Represents a single cached query. A `Query` holds the query's key, options,
* state (data/error/status), and the observers currently subscribed to it.
*
* Instances are created and managed internally by `QueryCache`; application
* code typically interacts with queries indirectly through `QueryClient` or
* a framework hook like `useQuery`. Direct access to a `Query` instance is
* possible via `queryCache.find()`/`findAll()` for inspecting cache state.
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
* const query = queryCache.find({ queryKey: ['posts'] })
*
* if (query) {
*   console.log(query.state.dataUpdatedAt)
* }
* ```
*/
var Query = class extends Removable {
	#queryType;
	#initialState;
	#revertState;
	#cache;
	#client;
	#retryer;
	#fetchPromise;
	#defaultOptions;
	#abortSignalConsumed;
	constructor(config) {
		super();
		this.#abortSignalConsumed = false;
		this.#defaultOptions = config.defaultOptions;
		this.setOptions(config.options);
		this.observers = [];
		this.#client = config.client;
		this.#cache = this.#client.getQueryCache();
		this.queryKey = config.queryKey;
		this.queryHash = config.queryHash;
		this.#initialState = getDefaultState$1(this.options);
		this.state = config.state ?? this.#initialState;
		this.scheduleGc();
	}
	/**
	* The `meta` object passed in the query's options, if any.
	* @returns The query's `meta`, or `undefined` if none was set.
	*/
	get meta() {
		return this.options.meta;
	}
	/**
	* `'infinite'` for an infinite query, otherwise `undefined`.
	* @internal
	* @returns The type of the query, set from the `_type` option (e.g. `'infinite'`).
	*/
	get queryType() {
		return this.#queryType;
	}
	/**
	* The promise for the currently in-flight fetch, if the query is fetching.
	* `undefined` when the query is not fetching.
	* @returns The promise of the in-flight fetch, or `undefined`.
	*/
	get promise() {
		return this.#retryer?.promise;
	}
	/**
	* Replaces the query's options and applies their `gcTime`. If the query has no data yet, it gets
	* the `initialData` from the new options, if any.
	* @internal
	* @param options - The new query options, merged on top of the query's default options.
	*/
	setOptions(options) {
		this.options = {
			...this.#defaultOptions,
			...options
		};
		if (options?._type) this.#queryType = options._type;
		this.updateGcTime(this.options.gcTime);
		if (this.state && this.state.data === void 0) {
			const defaultState = getDefaultState$1(this.options);
			if (defaultState.data !== void 0) {
				this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
				this.#initialState = defaultState;
			}
		}
	}
	optionalRemove() {
		if (!this.observers.length && this.state.fetchStatus === "idle") this.#cache.remove(this);
	}
	/**
	* Writes new data to the query and marks it as successfully fetched.
	* @internal
	* @param newData - The data to write. Structural sharing with the current data is applied.
	* @param options - Set `updatedAt` to override the timestamp, and `manual` to mark the write as
	* manual (e.g. from `queryClient.setQueryData`).
	* @returns The data that was written.
	*/
	setData(newData, options) {
		const data = replaceData(this.state.data, newData, this.options);
		this.#dispatch({
			data,
			type: "success",
			dataUpdatedAt: options?.updatedAt,
			manual: options?.manual
		});
		return data;
	}
	/**
	* Merges the given partial state directly into this query's state, notifying observers. Used
	* by persistence and broadcast plugins to restore a state snapshot, and by devtools to let a
	* user manually trigger a loading/error state or edit the cached data.
	* @param state - The partial state to merge into the query's state.
	*/
	setState(state) {
		this.#dispatch({
			type: "setState",
			state
		});
	}
	/**
	* Cancels the query's currently in-flight fetch, if any.
	* - Returns a promise that resolves once the cancellation has settled.
	* - If no fetch is in progress, resolves immediately.
	* @param options - Set `revert` to restore the state from before the fetch started, and `silent`
	* to suppress the cancellation error when a new fetch replaces the cancelled one.
	* @returns A promise that resolves once the cancellation has settled.
	* @example
	* ```ts
	* await query.cancel()
	* ```
	*/
	cancel(options) {
		const promise = this.#retryer?.promise;
		this.#retryer?.cancel(options);
		return promise ? promise.then(noop).catch(noop) : Promise.resolve();
	}
	/**
	* Silently cancels any in-flight fetch, then clears the query's garbage
	* collection timeout. Called by `QueryCache` when the query is removed from
	* the cache.
	* @see {@link Query#cancel}
	*/
	destroy() {
		this.cancel({ silent: true });
		super.destroy();
	}
	/**
	* The state the query was created with.
	* @internal
	* @returns The state the query had when it was first created, used by {@link Query#reset}.
	*/
	get resetState() {
		return this.#initialState;
	}
	/**
	* Resets the query back to its initial state (the state it had when it was
	* first created, e.g. any `initialData`), destroying it first to cancel any
	* in-flight fetch.
	*/
	reset() {
		this.destroy();
		this.setState(this.resetState);
	}
	/**
	* Returns `true` if the query has at least one observer for which `enabled`
	* does not resolve to `false`.
	* @returns `true` if the query has an enabled observer.
	*/
	isActive() {
		return this.observers.some((observer) => resolveQueryValue(observer.options.enabled, this) !== false);
	}
	/**
	* Returns `true` if the query is disabled, meaning it will not fetch
	* automatically.
	* - If the query has observers, it is disabled when none of them are active
	*   (see `isActive`).
	* - If the query has no observers, it is disabled when its `queryFn` is
	*   `skipToken` or it has never been fetched.
	* @returns `true` if the query is disabled.
	*/
	isDisabled() {
		if (this.getObserversCount() > 0) return !this.isActive();
		return this.options.queryFn === skipToken || !this.isFetched();
	}
	/**
	* Returns `true` if the query has been fetched, i.e. it has resolved with
	* either data or an error at least once.
	* @returns `true` if the query has been fetched.
	*/
	isFetched() {
		return this.state.dataUpdateCount + this.state.errorUpdateCount > 0;
	}
	/**
	* Returns `true` if the query has data and at least one observer configured with
	* `staleTime: 'static'`, meaning it is treated as never stale.
	* @returns `true` if the query is static.
	*/
	isStatic() {
		if (this.state.data === void 0) return false;
		if (this.getObserversCount() > 0) return this.observers.some((observer) => resolveQueryValue(observer.options.staleTime, this) === "static");
		return false;
	}
	/**
	* Returns `true` if the query is stale.
	* - If the query has observers, defers to whether any observer's current
	*   result reports `isStale` (which accounts for each observer's own
	*   `staleTime` and `enabled` state).
	* - If the query has no observers, it is considered stale when it has no
	*   data or has been invalidated.
	* @returns `true` if the query is stale.
	* @see {@link Query#isStaleByTime}
	* @example
	* ```ts
	* if (query.isStale()) {
	*   // refetch or otherwise treat the cached data as outdated
	* }
	* ```
	*/
	isStale() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => observer.getCurrentResult().isStale);
		return this.state.data === void 0 || this.state.isInvalidated;
	}
	/**
	* Returns `true` if the query's data is stale relative to the given
	* `staleTime` (defaults to `0`).
	* - A query with no data is always stale.
	* - `staleTime: 'static'` is never stale.
	* - An invalidated query is always stale.
	* - Otherwise, staleness is based on elapsed time since `dataUpdatedAt`.
	* @param staleTime - The time, in milliseconds, after which data is considered stale, or
	* `'static'` to never treat existing data as stale. A query without data is stale either way.
	* @returns `true` if the query's data is stale.
	* @see {@link Query#isStale}
	* @example
	* ```ts
	* const isStale = query.isStaleByTime(60 * 1000)
	* ```
	*/
	isStaleByTime(staleTime = 0) {
		if (this.state.data === void 0) return true;
		if (staleTime === "static") return false;
		if (this.state.isInvalidated) return true;
		return !timeUntilStale(this.state.dataUpdatedAt, staleTime);
	}
	/**
	* Refetches the query when the window regains focus, if an observer wants that, and continues a
	* paused fetch.
	* @internal
	*/
	onFocus() {
		this.observers.find((x) => x.shouldFetchOnWindowFocus())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/**
	* Refetches the query when the app reconnects, if an observer wants that, and continues a paused
	* fetch.
	* @internal
	*/
	onOnline() {
		this.observers.find((x) => x.shouldFetchOnReconnect())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/**
	* Subscribes an observer to the query and stops its garbage collection.
	* @internal
	* @param observer - The observer to add. Adding an observer that is already subscribed does
	* nothing.
	*/
	addObserver(observer) {
		if (!this.observers.includes(observer)) {
			this.observers.push(observer);
			this.clearGcTimeout();
			this.#cache.notify({
				type: "observerAdded",
				query: this,
				observer
			});
		}
	}
	/**
	* Unsubscribes an observer from the query.
	* @internal
	* @param observer - The observer to remove. When the last observer is removed, the in-flight
	* fetch is cancelled if its abort signal was consumed (otherwise only its retries are stopped),
	* and garbage collection is scheduled if the query is still in the cache.
	*/
	removeObserver(observer) {
		const index = this.observers.indexOf(observer);
		if (index !== -1) {
			this.observers.splice(index, 1);
			if (!this.observers.length) {
				if (this.#retryer) {
					if (this.#abortSignalConsumed || this.state.fetchStatus === "paused" && this.state.status === "pending") this.#retryer.cancel({ revert: true });
					else this.#retryer.cancelRetry();
				}
				this.#scheduleGcIfCached();
			}
			this.#cache.notify({
				type: "observerRemoved",
				query: this,
				observer
			});
		}
	}
	/**
	* Returns the number of observers currently subscribed to this query.
	* @returns The number of observers.
	* @example
	* ```ts
	* if (query.getObserversCount() === 0) {
	*   // no component is currently watching this query
	* }
	* ```
	*/
	getObserversCount() {
		return this.observers.length;
	}
	/**
	* Marks the query as invalidated, unless it is already invalidated. This
	* updates `state.isInvalidated` and notifies observers, but does not by
	* itself trigger a refetch.
	* @example
	* ```ts
	* query.invalidate()
	* ```
	*/
	invalidate() {
		if (!this.state.isInvalidated) this.#dispatch({ type: "invalidate" });
	}
	/**
	* Fetches the query, i.e. runs its `queryFn` (through any configured
	* retryer/behavior) and updates the query's state with the result.
	* - If a fetch is already in flight, returns its promise instead of
	*   starting a new one, unless `fetchOptions.cancelRefetch` is set and the
	*   query already has data, in which case the current fetch is silently
	*   cancelled first.
	* - If `options` is passed, it replaces the query's current options
	*   before fetching.
	* @param options - Query options that replace the query's current options before fetching. They
	* are not applied when an in-flight fetch is reused.
	* @param fetchOptions - Set `cancelRefetch` to cancel an in-flight fetch first (only if the query
	* already has data), and `meta` to pass extra information to the query's behavior.
	* @returns A promise that resolves with the fetched data, or rejects with the fetch error. If the
	* fetch is cancelled with `revert` while the query has data, it resolves with the restored data
	* instead.
	*/
	async fetch(options, fetchOptions) {
		if (this.state.fetchStatus !== "idle" && this.#retryer?.status() !== "rejected") {
			if (this.state.data !== void 0 && fetchOptions?.cancelRefetch) this.cancel({ silent: true });
			else if (this.#retryer && this.#fetchPromise) {
				this.#retryer.continueRetry();
				return this.#fetchPromise;
			}
		}
		if (options) this.setOptions(options);
		if (!this.options.queryFn) {
			const observer = this.observers.find((x) => x.options.queryFn);
			if (observer) this.setOptions(observer.options);
		}
		if (!Array.isArray(this.options.queryKey)) console.error(`As of v4, queryKey needs to be an Array. If you are using a string like 'repoData', please change it to an Array, e.g. ['repoData']`);
		const abortController = new AbortController();
		const addSignalProperty = (object) => {
			Object.defineProperties(object, {
				[fetchSignal]: {
					value: abortController.signal,
					enumerable: true
				},
				signal: {
					enumerable: true,
					get: () => {
						this.#abortSignalConsumed = true;
						return abortController.signal;
					}
				}
			});
		};
		const fetchFn = () => {
			const queryFn = ensureQueryFn(this.options, fetchOptions);
			const createQueryFnContext = () => {
				const queryFnContext = {
					client: this.#client,
					queryKey: this.queryKey,
					meta: this.meta
				};
				addSignalProperty(queryFnContext);
				return queryFnContext;
			};
			const queryFnContext = createQueryFnContext();
			this.#abortSignalConsumed = false;
			if (this.options.persister) return this.options.persister(queryFn, queryFnContext, this);
			return queryFn(queryFnContext);
		};
		const createFetchContext = () => {
			const context = {
				fetchOptions,
				options: this.options,
				queryKey: this.queryKey,
				client: this.#client,
				state: this.state,
				fetchFn
			};
			addSignalProperty(context);
			return context;
		};
		const context = createFetchContext();
		(this.#queryType === "infinite" ? infiniteQueryBehavior(this.options.pages) : this.options.behavior)?.onFetch(context, this);
		this.#revertState = this.state;
		if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== context.fetchOptions?.meta) this.#dispatch({
			type: "fetch",
			meta: context.fetchOptions?.meta
		});
		const retryer = this.#retryer = createRetryer({
			initialPromise: fetchOptions?.initialPromise,
			fn: context.fetchFn,
			onCancel: (error) => {
				if (error instanceof CancelledError && error.revert) this.setState({
					...this.#revertState,
					fetchStatus: "idle"
				});
				abortController.abort();
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue: () => {
				this.#dispatch({ type: "continue" });
			},
			retry: context.options.retry,
			retryDelay: context.options.retryDelay,
			networkMode: context.options.networkMode,
			canRun: () => true
		});
		const fetchPromise = (async () => {
			try {
				const data = await retryer.promise;
				if (data === void 0) {
					console.error(`Query data cannot be undefined. Please make sure to return a value other than undefined from your query function. Affected query key: ${this.queryHash}`);
					throw new Error(`${this.queryHash} data is undefined`);
				}
				this.setData(data);
				this.#cache.config.onSuccess?.(data, this);
				this.#cache.config.onSettled?.(data, this.state.error, this);
				return data;
			} catch (error) {
				if (error instanceof CancelledError) {
					if (error.silent) {
						if (this.#retryer !== retryer && this.#fetchPromise) return this.#fetchPromise;
						throw error;
					} else if (error.revert) {
						if (this.state.data === void 0) throw error;
						return this.state.data;
					}
				}
				this.#dispatch({
					type: "error",
					error
				});
				this.#cache.config.onError?.(error, this);
				this.#cache.config.onSettled?.(this.state.data, error, this);
				throw error;
			} finally {
				if (this.#retryer === retryer) {
					this.#retryer = void 0;
					this.#fetchPromise = void 0;
				}
				this.#scheduleGcIfCached();
			}
		})();
		this.#fetchPromise = fetchPromise;
		retryer.start();
		return fetchPromise;
	}
	#scheduleGcIfCached() {
		if (this.#cache.get(this.queryHash) === this) this.scheduleGc();
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					fetchFailureCount: action.failureCount,
					fetchFailureReason: action.error
				};
				case "pause": return {
					...state,
					fetchStatus: "paused"
				};
				case "continue": return {
					...state,
					fetchStatus: "fetching"
				};
				case "fetch": return {
					...state,
					...fetchState(state.data, this.options),
					fetchMeta: action.meta ?? null
				};
				case "success": {
					const newState = {
						...state,
						...successState(action.data, action.dataUpdatedAt),
						dataUpdateCount: state.dataUpdateCount + 1,
						...!action.manual && {
							fetchStatus: "idle",
							fetchFailureCount: 0,
							fetchFailureReason: null
						}
					};
					this.#revertState = action.manual ? newState : void 0;
					return newState;
				}
				case "error": {
					const error = action.error;
					return {
						...state,
						error,
						errorUpdateCount: state.errorUpdateCount + 1,
						errorUpdatedAt: Date.now(),
						fetchFailureCount: state.fetchFailureCount + 1,
						fetchFailureReason: error,
						fetchStatus: "idle",
						status: "error",
						isInvalidated: true
					};
				}
				case "invalidate": return {
					...state,
					isInvalidated: true
				};
				case "setState": return {
					...state,
					...action.state
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.observers.slice().forEach((observer) => {
				observer.onQueryUpdate();
			});
			this.#cache.notify({
				query: this,
				type: "updated",
				action
			});
		});
	}
};
/**
* Returns the state changes applied when a query starts fetching.
* @param data - The query's current data. If it is `undefined`, the query is also reset to
* `'pending'` with no error.
* @param options - The query options, whose `networkMode` decides whether the query is `'fetching'`
* or `'paused'`.
* @returns The partial query state for a starting fetch.
*/
function fetchState(data, options) {
	return {
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused",
		...data === void 0 && {
			error: null,
			status: "pending"
		}
	};
}
/**
* Returns the state changes applied when a query receives data.
* @param data - The new data.
* @param dataUpdatedAt - The timestamp the data is recorded with. Defaults to the current time.
* @returns The partial query state for a successful update.
*/
function successState(data, dataUpdatedAt) {
	return {
		data,
		dataUpdatedAt: dataUpdatedAt ?? Date.now(),
		error: null,
		isInvalidated: false,
		status: "success"
	};
}
/**
* Returns the initial state of a query, based on its `initialData` and `initialDataUpdatedAt`
* options.
* @param options - The query options.
* @returns The initial query state: `'success'` if `initialData` is set, otherwise `'pending'`.
*/
function getDefaultState$1(options) {
	const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
	const hasData = data !== void 0;
	const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
	return {
		data,
		dataUpdateCount: 0,
		dataUpdatedAt: hasData ? initialDataUpdatedAt ?? Date.now() : 0,
		error: null,
		errorUpdateCount: 0,
		errorUpdatedAt: 0,
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchMeta: null,
		isInvalidated: false,
		status: hasData ? "success" : "pending",
		fetchStatus: "idle"
	};
}
// node_modules/@tanstack/query-core/build/modern/queryObserver.js
/**
* A `QueryObserver` watches a single query in the `QueryCache` and computes a
* `QueryObserverResult` from its state, recomputing and notifying subscribers
* whenever the underlying query (or the observer's options) changes. It is
* the primitive that framework adapters (e.g. `useQuery`) build their hooks
* on top of, but it can also be used directly to observe and switch between
* queries outside of any framework.
* @example
* ```ts
* const observer = new QueryObserver(queryClient, {
*   queryKey: ['posts'],
*   queryFn: fetchPosts,
* })
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result.data)
* })
* ```
*/
var QueryObserver = class extends Subscribable {
	#client;
	#currentQuery = void 0;
	#currentQueryInitialState = void 0;
	#currentResult = void 0;
	#currentResultOptions;
	#selectError;
	#selectFn;
	#selectInput;
	#selectResult;
	#lastQueryWithDefinedData;
	#staleTimeoutId;
	#refetchIntervalId;
	#currentRefetchInterval;
	#trackedProps = /* @__PURE__ */ new Set();
	constructor(client, options) {
		super();
		this.options = options;
		this.#client = client;
		this.#selectError = null;
		this.bindMethods();
		this.setOptions(options);
	}
	/**
	* Binds the methods of the result (`refetch`) to the observer, so they keep working when destructured
	* from it. Subclasses override it to bind their own result methods as well.
	*/
	bindMethods() {
		this.refetch = this.refetch.bind(this);
	}
	onSubscribe() {
		if (this.listeners.size === 1) {
			this.#currentQuery.addObserver(this);
			if (shouldFetchOnMount(this.#currentQuery, this.options)) this.#executeFetch();
			else this.updateResult();
			this.#updateTimers();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.destroy();
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnReconnect` option) to refetch when the network
	* reconnects.
	* @returns `true` if the observer should refetch the query on reconnect.
	*/
	shouldFetchOnReconnect() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnReconnect);
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnWindowFocus` option) to refetch when the window
	* regains focus.
	* @returns `true` if the observer should refetch the query on window focus.
	*/
	shouldFetchOnWindowFocus() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnWindowFocus);
	}
	/**
	* Stops observing the current query: clears all listeners, cancels the
	* stale and refetch-interval timers, and removes this observer from the
	* query it was observing.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#clearStaleTimeout();
		this.#clearRefetchInterval();
		this.#currentQuery.removeObserver(this);
	}
	/**
	* Updates the observer's options. This will re-resolve the query being
	* observed (switching to a different query if the `queryKey` changed),
	* trigger a fetch if the new options require one and the observer has
	* subscribers, recompute the current result, and reschedule the stale and
	* refetch-interval timers as needed.
	* @param options - The new observer options. They are defaulted with {@link
	* QueryClient#defaultQueryOptions} before being applied.
	* @throws {Error} If `enabled` is neither a boolean nor a function.
	* @example
	* ```ts
	* observer.setOptions({ queryKey: ['posts', 1], queryFn: () => fetchPost(1) })
	* // later: switch to a different query, reusing the same observer
	* observer.setOptions({ queryKey: ['posts', 2], queryFn: () => fetchPost(2) })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		const prevQuery = this.#currentQuery;
		this.options = this.#client.defaultQueryOptions(options);
		if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveQueryValue(this.options.enabled, this.#currentQuery) !== "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
		this.#updateQuery();
		this.#currentQuery.setOptions(this.options);
		if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) this.#client.getQueryCache().notify({
			type: "observerOptionsUpdated",
			query: this.#currentQuery,
			observer: this
		});
		const mounted = this.hasListeners();
		if (mounted && shouldFetchOptionally(this.#currentQuery, prevQuery, this.options, prevOptions)) this.#executeFetch();
		this.updateResult();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || resolveQueryValue(this.options.staleTime, this.#currentQuery) !== resolveQueryValue(prevOptions.staleTime, this.#currentQuery))) this.#updateStaleTimeout();
		const nextRefetchInterval = this.#computeRefetchInterval();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || nextRefetchInterval !== this.#currentRefetchInterval)) this.#updateRefetchInterval(nextRefetchInterval);
	}
	/**
	* Computes the result the observer would produce for the given (already-defaulted) options
	* right now, building the underlying `Query` if it doesn't exist yet, without waiting for a
	* subscription callback. Called by framework adapters on every render (e.g. `useQuery`) so the
	* returned value is available synchronously, ahead of `setOptions` triggering an actual fetch.
	* @param options - The defaulted observer options to compute the result for.
	* @returns The result for the given options.
	*/
	getOptimisticResult(options) {
		const query = this.#client.getQueryCache().build(this.#client, options);
		const result = this.createResult(query, options);
		if (!shallowEqualObjects(this.getCurrentResult(), result)) {
			this.#currentResult = result;
			this.#currentResultOptions = options;
		}
		return result;
	}
	/**
	* Returns the most recently computed `QueryObserverResult` for the
	* observed query. This is a point-in-time read; to be notified of updates
	* as they happen, subscribe to the observer instead (its inherited
	* `subscribe` method).
	* @returns The observer's latest result.
	* @example
	* ```ts
	* const result = observer.getCurrentResult()
	* console.log(result.status, result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Wraps a `QueryObserverResult` in a `Proxy` that records which properties are read, via
	* {@link QueryObserver#trackProp} (and an optional `onPropTracked` callback). Used by framework
	* adapters when `notifyOnChangeProps` is not set, to implement its default "only re-render on
	* properties you actually read" behavior.
	* @param result - The result to wrap.
	* @param onPropTracked - Called with the name of each property that is read.
	* @returns A proxy of `result` that tracks property reads.
	*/
	trackResult(result, onPropTracked) {
		return new Proxy(result, { get: (target, key) => {
			this.trackProp(key);
			onPropTracked?.(key);
			return Reflect.get(target, key);
		} });
	}
	/**
	* Records that the given `QueryObserverResult` property was read, so a subsequent update only
	* notifies this observer if a tracked property actually changed. Normally called indirectly via
	* {@link QueryObserver#trackResult}'s proxy; exposed directly for adapters that track property
	* access themselves (e.g. through their own reactivity system) instead of via the proxy.
	* @param key - The name of the property that was read.
	*/
	trackProp(key) {
		this.#trackedProps.add(key);
	}
	/**
	* Returns the `Query` instance this observer is currently observing.
	* @returns The observed query.
	*/
	getCurrentQuery() {
		return this.#currentQuery;
	}
	/**
	* Refetches the observed query and returns a promise that resolves with
	* the resulting `QueryObserverResult`.
	* @param options - Set `cancelRefetch` to `false` to keep a running fetch instead of cancelling
	* it, and `throwOnError` to `true` to reject when the refetch fails.
	* @returns A promise that resolves with the result after the refetch.
	* @example
	* ```ts
	* const result = await observer.refetch({ cancelRefetch: false })
	* console.log(result.data)
	* ```
	*/
	refetch({ ...options } = {}) {
		return this.fetch({ ...options });
	}
	/**
	* Fetches a query defined by the given options without affecting this
	* observer's own tracked query or result, and returns a promise that
	* resolves with the `QueryObserverResult` for that fetch. This is useful
	* for prefetching data that another observer (e.g. a query about to be
	* navigated to) will need, ahead of time.
	* @param options - The observer options of the query to fetch.
	* @returns A promise that resolves with the result for the fetched query.
	* @example
	* ```ts
	* const result = await observer.fetchOptimistic({
	*   queryKey: ['posts', 2],
	*   queryFn: () => fetchPost(2),
	* })
	* console.log(result.data)
	* ```
	*/
	fetchOptimistic(options) {
		const defaultedOptions = this.#client.defaultQueryOptions(options);
		const query = this.#client.getQueryCache().build(this.#client, defaultedOptions);
		let unsubscribe = () => {};
		let resolveEarly;
		const cachePromise = new Promise((resolve) => {
			resolveEarly = resolve;
			unsubscribe = this.#client.getQueryCache().subscribe((event) => {
				if (event.type === "updated" && event.query.queryHash === query.queryHash && query.state.data !== void 0) {
					unsubscribe();
					resolve(this.createResult(query, defaultedOptions));
				}
			});
		});
		return Promise.race([query.fetch(defaultedOptions).then(() => {
			const result = this.createResult(query, defaultedOptions);
			resolveEarly?.(result);
			return result;
		}).finally(() => {
			unsubscribe();
		}), cachePromise]);
	}
	/**
	* Fetches the observed query and updates the result once the fetch settles. Used by `refetch` and,
	* in `InfiniteQueryObserver`, to fetch more pages.
	* @param fetchOptions - Options for this fetch. `cancelRefetch` defaults to `true`.
	* @returns A promise that resolves with the updated result.
	*/
	fetch(fetchOptions) {
		return this.#executeFetch({
			...fetchOptions,
			cancelRefetch: fetchOptions.cancelRefetch ?? true
		}).then(() => {
			this.updateResult();
			return this.#currentResult;
		});
	}
	#executeFetch(fetchOptions) {
		this.#updateQuery();
		let promise = this.#currentQuery.fetch(this.options, fetchOptions);
		if (!fetchOptions?.throwOnError) promise = promise.catch(noop);
		return promise;
	}
	#shouldScheduleTimer(timeout) {
		return !isServer() && resolveQueryValue(this.options.enabled, this.#currentQuery) !== false && isValidTimeout(timeout);
	}
	#updateStaleTimeout() {
		this.#clearStaleTimeout();
		const staleTime = resolveQueryValue(this.options.staleTime, this.#currentQuery);
		if (this.#currentResult.isStale || !this.#shouldScheduleTimer(staleTime)) return;
		const timeout = timeUntilStale(this.#currentResult.dataUpdatedAt, staleTime) + 1;
		this.#staleTimeoutId = timeoutManager.setTimeout(() => {
			if (!this.#currentResult.isStale) this.updateResult();
		}, timeout);
	}
	#computeRefetchInterval() {
		return resolveQueryValue(this.options.refetchInterval, this.#currentQuery) ?? false;
	}
	#updateRefetchInterval(nextInterval) {
		this.#clearRefetchInterval();
		this.#currentRefetchInterval = nextInterval;
		if (this.#currentRefetchInterval === 0 || !this.#shouldScheduleTimer(this.#currentRefetchInterval)) return;
		this.#refetchIntervalId = timeoutManager.setInterval(() => {
			if (this.options.refetchIntervalInBackground || focusManager.isFocused()) this.#executeFetch();
		}, this.#currentRefetchInterval);
	}
	#updateTimers() {
		this.#updateStaleTimeout();
		this.#updateRefetchInterval(this.#computeRefetchInterval());
	}
	#clearStaleTimeout() {
		if (this.#staleTimeoutId !== void 0) {
			timeoutManager.clearTimeout(this.#staleTimeoutId);
			this.#staleTimeoutId = void 0;
		}
	}
	#clearRefetchInterval() {
		if (this.#refetchIntervalId !== void 0) {
			timeoutManager.clearInterval(this.#refetchIntervalId);
			this.#refetchIntervalId = void 0;
		}
	}
	/**
	* Computes the result for a query and options from the query's state, applying `select`,
	* `placeholderData`, and the derived flags. Subclasses override it to add their own fields.
	* @param query - The query to compute the result for.
	* @param options - The observer options to compute the result with.
	* @returns The computed result.
	*/
	createResult(query, options) {
		const prevQuery = this.#currentQuery;
		const prevOptions = this.options;
		const prevResult = this.#currentResult;
		const prevResultOptions = this.#currentResultOptions;
		const queryInitialState = query !== prevQuery ? query.state : this.#currentQueryInitialState;
		const { state } = query;
		let newState = { ...state };
		let isPlaceholderData = false;
		let data;
		if (options._optimisticResults) {
			const mounted = this.hasListeners();
			const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
			const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
			if (fetchOnMount || fetchOptionally) newState = {
				...newState,
				...fetchState(state.data, query.options)
			};
			if (options._optimisticResults === "isRestoring") newState.fetchStatus = "idle";
		}
		let { error, errorUpdatedAt, status } = newState;
		data = newState.data;
		let skipSelect = false;
		if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
			let placeholderData;
			const isMemoizedPlaceholder = prevResult?.isPlaceholderData && options.placeholderData === prevResultOptions?.placeholderData;
			if (isMemoizedPlaceholder) {
				placeholderData = prevResult.data;
				skipSelect = true;
			} else placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(this.#lastQueryWithDefinedData?.state.data, this.#lastQueryWithDefinedData) : options.placeholderData;
			if (isMemoizedPlaceholder || placeholderData !== void 0) {
				status = "success";
				data = replaceData(options.select && !skipSelect ? this.#selectInput : prevResult?.data, placeholderData, options);
				isPlaceholderData = true;
			}
		}
		if (options.select && data !== void 0 && !skipSelect) {
			if (data === this.#selectInput && options.select === this.#selectFn) data = this.#selectResult;
			else try {
				this.#selectFn = options.select;
				this.#selectInput = data;
				data = options.select(data);
				data = replaceData(prevResult?.data, data, options);
				this.#selectResult = data;
				this.#selectError = null;
			} catch (selectError) {
				this.#selectError = selectError;
			}
		} else if (data === void 0) {
			this.#selectInput = void 0;
			this.#selectError = null;
		}
		if (this.#selectError) {
			error = this.#selectError;
			data = this.#selectResult;
			errorUpdatedAt = prevResult?.error === error ? prevResult.errorUpdatedAt : Date.now();
			status = "error";
			isPlaceholderData = false;
		}
		const isFetching = newState.fetchStatus === "fetching";
		const isPending = status === "pending";
		const isError = status === "error";
		const isLoading = isPending && isFetching;
		const hasData = data !== void 0;
		return {
			status,
			fetchStatus: newState.fetchStatus,
			isPending,
			isSuccess: status === "success",
			isError,
			isInitialLoading: isLoading,
			isLoading,
			data,
			dataUpdatedAt: newState.dataUpdatedAt,
			error,
			errorUpdatedAt,
			failureCount: newState.fetchFailureCount,
			failureReason: newState.fetchFailureReason,
			errorUpdateCount: newState.errorUpdateCount,
			isFetched: query.isFetched(),
			isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
			isFetching,
			isRefetching: isFetching && !isPending,
			isLoadingError: isError && !hasData,
			isPaused: newState.fetchStatus === "paused",
			isPlaceholderData,
			isRefetchError: isError && hasData,
			isStale: isStale(query, options),
			refetch: this.refetch,
			isEnabled: resolveQueryValue(options.enabled, query) !== false
		};
	}
	/**
	* Recomputes and stores the current result from the current query/options, notifying listeners
	* if it changed. Framework adapters call this right after subscribing to make sure no query
	* update was missed in the gap between creating the observer and subscribing to it.
	*/
	updateResult() {
		const prevResult = this.#currentResult;
		const nextResult = this.createResult(this.#currentQuery, this.options);
		this.#currentResultOptions = this.options;
		if (this.#currentQuery.state.data !== void 0) this.#lastQueryWithDefinedData = this.#currentQuery;
		if (shallowEqualObjects(nextResult, prevResult)) return;
		this.#currentResult = nextResult;
		const shouldNotifyListeners = () => {
			if (!prevResult) return true;
			const { notifyOnChangeProps } = this.options;
			const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
			if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !this.#trackedProps.size) return true;
			if (this.options.throwOnError && this.#currentResult.error !== prevResult.error) return true;
			for (const key of notifyOnChangePropsValue ?? this.#trackedProps) if (this.#currentResult[key] !== prevResult[key]) return true;
			return false;
		};
		const notifyListeners = shouldNotifyListeners();
		notifyManager.batch(() => {
			if (notifyListeners) this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
			this.#client.getQueryCache().notify({
				query: this.#currentQuery,
				type: "observerResultsUpdated"
			});
		});
	}
	#updateQuery() {
		const query = this.#client.getQueryCache().build(this.#client, this.options);
		if (query === this.#currentQuery) return;
		const prevQuery = this.#currentQuery;
		this.#currentQuery = query;
		this.#currentQueryInitialState = query.state;
		if (this.hasListeners()) {
			prevQuery?.removeObserver(this);
			query.addObserver(this);
		}
	}
	/**
	* Updates the observer's result when the observed query changes, and reschedules its timers if it
	* has listeners.
	* @internal
	*/
	onQueryUpdate() {
		this.updateResult();
		if (this.hasListeners()) this.#updateTimers();
	}
};
/**
* Checks whether a query has no data yet and should do its initial load when an observer mounts.
* @param query - The query to check.
* @param options - The observer options.
* @returns `true` if the query is enabled, has no data, and isn't in an error state with
* `retryOnMount: false`.
*/
function shouldLoadOnMount(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && resolveQueryValue(options.retryOnMount, query) === false);
}
/**
* Checks whether a query should fetch when an observer mounts: either for its initial load, or
* because it has data and `refetchOnMount` asks for a refetch.
* @param query - The query to check.
* @param options - The observer options.
* @returns `true` if the query should fetch on mount.
*/
function shouldFetchOnMount(query, options) {
	return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
}
/**
* Checks whether a query should fetch for a `refetchOnMount`, `refetchOnWindowFocus`, or
* `refetchOnReconnect` option.
* @param query - The query to check.
* @param options - The observer options.
* @param field - The value of the option to check.
* @returns `true` if the query is enabled, not static, and the option is `'always'`, or is not
* `false` and the query is stale.
*/
function shouldFetchOn(query, options, field) {
	if (resolveQueryValue(options.enabled, query) !== false && resolveQueryValue(options.staleTime, query) !== "static") {
		const value = resolveQueryValue(field, query);
		return value === "always" || value !== false && isStale(query, options);
	}
	return false;
}
/**
* Checks whether a query should fetch after the observer's options change.
* @param query - The query observed with the new options.
* @param prevQuery - The query observed with the previous options.
* @param options - The new observer options.
* @param prevOptions - The previous observer options.
* @returns `true` if the query changed or was disabled before, it isn't a suspense query in an
* error state, and it is stale.
*/
function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
	return (query !== prevQuery || resolveQueryValue(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
}
/**
* Checks whether a query is stale for the given observer options.
* @param query - The query to check.
* @param options - The observer options, whose `enabled` and `staleTime` are used.
* @returns `true` if the query is enabled and its data is stale for `staleTime`.
*/
function isStale(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.isStaleByTime(resolveQueryValue(options.staleTime, query));
}
// node_modules/@tanstack/query-core/build/modern/infiniteQueryObserver.js
/**
* An `InfiniteQueryObserver` extends `QueryObserver` to observe and switch
* between infinite queries. It augments the base `QueryObserverResult` with
* infinite-query-specific fields and methods, such as `hasNextPage` and
* `fetchNextPage`, and is the primitive that framework adapters (e.g.
* `useInfiniteQuery`) build their hooks on top of.
* @example
* ```ts
* const observer = new InfiniteQueryObserver(queryClient, {
*   queryKey: ['projects'],
*   queryFn: ({ pageParam }) => fetchProjects(pageParam),
*   initialPageParam: 0,
*   getNextPageParam: (lastPage) => lastPage.nextCursor,
* })
*
* const unsubscribe = observer.subscribe((result) => console.log(result))
* ```
*/
var InfiniteQueryObserver = class extends QueryObserver {
	constructor(client, options) {
		super(client, options);
	}
	bindMethods() {
		super.bindMethods();
		this.fetchNextPage = this.fetchNextPage.bind(this);
		this.fetchPreviousPage = this.fetchPreviousPage.bind(this);
	}
	/**
	* Updates the observer's options. Behaves the same as
	* `QueryObserver.setOptions`, additionally marking the options as
	* belonging to an infinite query before delegating to the base
	* implementation.
	* @param options - The new infinite query observer options.
	*/
	setOptions(options) {
		options._type = "infinite";
		super.setOptions(options);
	}
	/**
	* The infinite-query counterpart of {@link QueryObserver#getOptimisticResult}, marking the
	* options as an infinite query before delegating to it. Called by framework adapters (e.g.
	* `useInfiniteQuery`) ahead of subscribing, to compute the current `InfiniteQueryObserverResult`
	* synchronously.
	* @param options - The defaulted infinite query observer options to compute the result for.
	* @returns The result for the given options.
	*/
	getOptimisticResult(options) {
		options._type = "infinite";
		return super.getOptimisticResult(options);
	}
	/**
	* Fetches the next page of the infinite query and returns a promise that
	* resolves with the resulting `InfiniteQueryObserverResult`. The page
	* param used for the fetch is determined by `getNextPageParam`, which
	* receives the current pages/page params and whose result also determines
	* `hasNextPage`.
	* @param options - Set `cancelRefetch` to `false` to ignore the call while a fetch is running,
	* and `throwOnError` to `true` to reject when the fetch fails.
	* @returns A promise that resolves with the result after the next page is fetched. With
	* `cancelRefetch: false`, a running fetch is reused instead, so the next page may not be fetched.
	* @see {@link InfiniteQueryObserver#fetchPreviousPage}
	* @example
	* ```ts
	* const { hasNextPage } = observer.getCurrentResult()
	*
	* if (hasNextPage) {
	*   await observer.fetchNextPage()
	* }
	* ```
	*/
	fetchNextPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "forward" } }
		});
	}
	/**
	* Fetches the previous page of the infinite query and returns a promise
	* that resolves with the resulting `InfiniteQueryObserverResult`. The page
	* param used for the fetch is determined by `getPreviousPageParam`, which
	* receives the current pages/page params and whose result also determines
	* `hasPreviousPage`.
	* @param options - Set `cancelRefetch` to `false` to ignore the call while a fetch is running,
	* and `throwOnError` to `true` to reject when the fetch fails.
	* @returns A promise that resolves with the result after the previous page is fetched. With
	* `cancelRefetch: false`, a running fetch is reused instead, so the previous page may not be fetched.
	* @see {@link InfiniteQueryObserver#fetchNextPage}
	* @example
	* ```ts
	* const { hasPreviousPage } = observer.getCurrentResult()
	*
	* if (hasPreviousPage) {
	*   await observer.fetchPreviousPage()
	* }
	* ```
	*/
	fetchPreviousPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "backward" } }
		});
	}
	createResult(query, options) {
		const { state } = query;
		const parentResult = super.createResult(query, options);
		const { isFetching, isRefetching, isError, isRefetchError } = parentResult;
		const fetchDirection = state.fetchMeta?.fetchMore?.direction;
		const isFetchNextPageError = isError && fetchDirection === "forward";
		const isFetchingNextPage = isFetching && fetchDirection === "forward";
		const isFetchPreviousPageError = isError && fetchDirection === "backward";
		const isFetchingPreviousPage = isFetching && fetchDirection === "backward";
		return {
			...parentResult,
			fetchNextPage: this.fetchNextPage,
			fetchPreviousPage: this.fetchPreviousPage,
			hasNextPage: hasNextPage(options, state.data),
			hasPreviousPage: hasPreviousPage(options, state.data),
			isFetchNextPageError,
			isFetchingNextPage,
			isFetchPreviousPageError,
			isFetchingPreviousPage,
			isRefetchError: isRefetchError && !isFetchNextPageError && !isFetchPreviousPageError,
			isRefetching: isRefetching && !isFetchingNextPage && !isFetchingPreviousPage
		};
	}
};
// node_modules/@tanstack/query-core/build/modern/mutation.js
/**
* Represents a single mutation attempt. A `Mutation` holds the mutation's
* options, state (data/error/status), and the `MutationObserver`s currently
* subscribed to it.
*
* Instances are created and managed internally by `MutationCache`; application
* code typically interacts with mutations indirectly through `QueryClient` or
* a framework hook like `useMutation`. Direct access to a `Mutation` instance
* is possible via `mutationCache.find()`/`getAll()` for inspecting cache state.
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
* ```
*/
var Mutation = class extends Removable {
	#client;
	#observers;
	#mutationCache;
	#retryer;
	constructor(config) {
		super();
		this.#client = config.client;
		this.mutationId = config.mutationId;
		this.#mutationCache = config.mutationCache;
		this.#observers = [];
		this.state = config.state || getDefaultState();
		this.setOptions(config.options);
		this.scheduleGc();
	}
	/**
	* Replaces the mutation's options and applies their `gcTime`.
	* @internal
	* @param options - The new mutation options.
	*/
	setOptions(options) {
		this.options = options;
		this.updateGcTime(this.options.gcTime);
	}
	/**
	* The `meta` object passed in the mutation's options, if any.
	* @returns The mutation's `meta`, or `undefined` if none was set.
	*/
	get meta() {
		return this.options.meta;
	}
	/**
	* Subscribes an observer to the mutation and stops its garbage collection.
	* @internal
	* @param observer - The observer to add. Adding an observer that is already subscribed does
	* nothing.
	*/
	addObserver(observer) {
		if (!this.#observers.includes(observer)) {
			this.#observers.push(observer);
			this.clearGcTimeout();
			this.#mutationCache.notify({
				type: "observerAdded",
				mutation: this,
				observer
			});
		}
	}
	/**
	* Unsubscribes an observer from the mutation.
	* @internal
	* @param observer - The observer to remove. Schedules garbage collection if the mutation
	* is still in the cache.
	*/
	removeObserver(observer) {
		this.#observers = this.#observers.filter((x) => x !== observer);
		if (this.#mutationCache.has(this)) this.scheduleGc();
		this.#mutationCache.notify({
			type: "observerRemoved",
			mutation: this,
			observer
		});
	}
	optionalRemove() {
		if (!this.#observers.length) {
			if (this.state.status === "pending") this.scheduleGc();
			else this.#mutationCache.remove(this);
		}
	}
	/**
	* Resumes a mutation that is currently paused or was restored from a
	* dehydrated, still-`pending` state.
	*
	* - If this mutation has an active retryer (it paused mid-attempt, e.g. due
	*   to the network mode or scope-based queuing), its retryer is resumed.
	* - Otherwise, if the mutation's status is still `pending` (e.g. it was
	*   dehydrated while an attempt was in flight and never got a retryer in
	*   this instance), `execute` is called again with the last known variables.
	* - Otherwise the mutation has already settled and this resolves immediately
	*   without running anything again.
	* @returns A promise that settles with the resumed mutation: it rejects if the mutation fails.
	* It resolves immediately if the mutation has already settled.
	* @see {@link Mutation#execute}
	* @example
	* ```ts
	* // typically driven by reconnect handling, e.g. queryClient.resumePausedMutations()
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* await mutation?.continue()
	* ```
	*/
	continue() {
		return this.#retryer?.continue() ?? (this.state.status === "pending" ? this.execute(this.state.variables) : Promise.resolve());
	}
	/**
	* Runs the mutation function for the given variables through a retryer, and
	* drives the mutation's state and lifecycle callbacks through to settlement.
	*
	* If this mutation's state is already `pending` when `execute` is called
	* (i.e. it was restored, still in-flight, from a dehydrated state), the
	* `onMutate` step is skipped and a `continue` action is dispatched to
	* unpause it; otherwise a `pending` action is dispatched first, then the
	* mutation cache's `onMutate` and the mutation's own `onMutate` option are
	* awaited in that order, and the resulting context is stored.
	*
	* The mutation function is then run (subject to `retry`/`retryDelay`/
	* `networkMode`, and to the mutation cache's scope-based serialization).
	* On success, the cache's `onSuccess`/`onSettled` callbacks run before the
	* mutation's own `onSuccess`/`onSettled` options, a `success` action is
	* dispatched, and the resolved data is returned. On failure, the same
	* cache-then-option ordering is used for `onError`/`onSettled`, but each of
	* those four callbacks is individually caught so that a throwing callback
	* cannot mask the original error; an `error` action is then dispatched and
	* the original error is re-thrown.
	* @param variables - The variables passed to the `mutationFn`.
	* @returns A promise that resolves with the mutation's data, or rejects with its error.
	* @see {@link Mutation#continue}
	* @example
	* ```ts
	* // Called internally by `MutationObserver.mutate` and `Mutation.continue` —
	* // applications normally trigger mutations through those, not this method.
	* const data = await mutation.execute(variables)
	* ```
	*/
	async execute(variables) {
		const onContinue = () => {
			this.#dispatch({ type: "continue" });
		};
		const mutationFnContext = {
			client: this.#client,
			meta: this.options.meta,
			mutationKey: this.options.mutationKey
		};
		const retryer = this.#retryer = createRetryer({
			fn: () => {
				if (!this.options.mutationFn) return Promise.reject(/* @__PURE__ */ new Error("No mutationFn found"));
				return this.options.mutationFn(variables, mutationFnContext);
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue,
			retry: this.options.retry ?? 0,
			retryDelay: this.options.retryDelay,
			networkMode: this.options.networkMode,
			canRun: () => this.#mutationCache.canRun(this)
		});
		const restored = this.state.status === "pending";
		const isPaused = !retryer.canStart();
		try {
			if (restored) onContinue();
			else {
				this.#dispatch({
					type: "pending",
					variables,
					isPaused
				});
				if (this.#mutationCache.config.onMutate) await this.#mutationCache.config.onMutate(variables, this, mutationFnContext);
				const context = await this.options.onMutate?.(variables, mutationFnContext);
				if (context !== this.state.context) this.#dispatch({
					type: "pending",
					context,
					variables,
					isPaused
				});
			}
			if (this.state.isPaused && retryer.canStart()) onContinue();
			const data = await retryer.start();
			await this.#mutationCache.config.onSuccess?.(data, variables, this.state.context, this, mutationFnContext);
			await this.options.onSuccess?.(data, variables, this.state.context, mutationFnContext);
			await this.#mutationCache.config.onSettled?.(data, null, this.state.variables, this.state.context, this, mutationFnContext);
			await this.options.onSettled?.(data, null, variables, this.state.context, mutationFnContext);
			this.#dispatch({
				type: "success",
				data
			});
			return data;
		} catch (error) {
			try {
				await this.#mutationCache.config.onError?.(error, variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onError?.(error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.#mutationCache.config.onSettled?.(void 0, error, this.state.variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onSettled?.(void 0, error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			this.#dispatch({
				type: "error",
				error
			});
			throw error;
		} finally {
			if (this.#retryer === retryer) this.#retryer = void 0;
			this.#mutationCache.runNext(this);
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					failureCount: action.failureCount,
					failureReason: action.error
				};
				case "pause": return {
					...state,
					isPaused: true
				};
				case "continue": return {
					...state,
					isPaused: false
				};
				case "pending": return {
					...state,
					context: action.context,
					data: void 0,
					failureCount: 0,
					failureReason: null,
					error: null,
					isPaused: action.isPaused,
					status: "pending",
					variables: action.variables,
					submittedAt: Date.now()
				};
				case "success": return {
					...state,
					data: action.data,
					failureCount: 0,
					failureReason: null,
					error: null,
					status: "success",
					isPaused: false
				};
				case "error": return {
					...state,
					data: void 0,
					error: action.error,
					failureCount: state.failureCount + 1,
					failureReason: action.error,
					isPaused: false,
					status: "error"
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.#observers.forEach((observer) => {
				observer.onMutationUpdate(action);
			});
			this.#mutationCache.notify({
				mutation: this,
				type: "updated",
				action
			});
		});
	}
};
/**
* Returns the initial state of a mutation: `'idle'`, with no data, error, or variables.
* @returns The initial mutation state.
*/
function getDefaultState() {
	return {
		context: void 0,
		data: void 0,
		error: null,
		failureCount: 0,
		failureReason: null,
		isPaused: false,
		status: "idle",
		variables: void 0,
		submittedAt: 0
	};
}
// node_modules/@tanstack/query-core/build/modern/mutationCache.js
/**
* The `MutationCache` is the storage for mutations.
*
* Normally, you will not interact with the `MutationCache` directly and instead use a
* `QueryClient`. You can subscribe to it (inherited from `Subscribable`) to be informed of
* safe/known updates to the cache, such as mutations being added, removed, or updated.
* @example
* ```ts
* const unsubscribe = mutationCache.subscribe((event) => {
*   console.log(event.type, event.mutation)
* })
* ```
*/
var MutationCache = class extends Subscribable {
	#mutations;
	#scopes;
	#mutationId;
	constructor(config = {}) {
		super();
		this.config = config;
		this.#mutations = /* @__PURE__ */ new Set();
		this.#scopes = /* @__PURE__ */ new Map();
		this.#mutationId = 0;
	}
	/**
	* Creates a mutation and adds it to the cache.
	* @internal
	* @param client - The client the mutation belongs to, used to default its options.
	* @param options - The mutation options. They are defaulted with {@link
	* QueryClient#defaultMutationOptions}.
	* @param state - The initial state of the mutation, e.g. when restoring a dehydrated mutation.
	* @returns The new mutation, already added to the cache.
	*/
	build(client, options, state) {
		const mutation = new Mutation({
			client,
			mutationCache: this,
			mutationId: ++this.#mutationId,
			options: client.defaultMutationOptions(options),
			state
		});
		this.add(mutation);
		return mutation;
	}
	/**
	* Adds a mutation to the cache.
	* @internal
	* @param mutation - The mutation to add. If it has a `scope`, it is queued in that scope.
	*/
	add(mutation) {
		this.#mutations.add(mutation);
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const scopedMutations = this.#scopes.get(scope);
			if (scopedMutations) scopedMutations.push(mutation);
			else this.#scopes.set(scope, [mutation]);
		}
		this.notify({
			type: "added",
			mutation
		});
	}
	/**
	* Removes a mutation from the cache and clears its garbage collection timer.
	* @internal
	* @param mutation - The mutation to remove, also from its scope's queue.
	*/
	remove(mutation) {
		if (this.#mutations.delete(mutation)) {
			mutation.destroy();
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const scopedMutations = this.#scopes.get(scope);
				if (scopedMutations) {
					if (scopedMutations.length > 1) {
						const index = scopedMutations.indexOf(mutation);
						if (index !== -1) scopedMutations.splice(index, 1);
					} else if (scopedMutations[0] === mutation) this.#scopes.delete(scope);
				}
			}
		}
		this.notify({
			type: "removed",
			mutation
		});
	}
	/**
	* Checks whether this cache still holds the given mutation.
	* @internal
	* @param mutation - The mutation to check.
	* @returns Whether the mutation is in the cache.
	*/
	has(mutation) {
		return this.#mutations.has(mutation);
	}
	/**
	* Checks whether a mutation can run now, given the other mutations in its `scope`.
	* @internal
	* @param mutation - The mutation to check.
	* @returns `true` if the mutation has no `scope`, or no other mutation in its scope is pending
	* ahead of it.
	*/
	canRun(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const firstPendingMutation = this.#scopes.get(scope)?.find((m) => m.state.status === "pending");
			return !firstPendingMutation || firstPendingMutation === mutation;
		} else return true;
	}
	/**
	* Continues the next paused mutation in the same `scope` after a mutation finishes.
	* @internal
	* @param mutation - The mutation that finished.
	* @returns A promise that resolves once the next paused mutation in the same scope has continued,
	* or immediately if there is none.
	*/
	runNext(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") return (this.#scopes.get(scope)?.find((m) => m !== mutation && m.state.isPaused))?.continue() ?? Promise.resolve();
		else return Promise.resolve();
	}
	/**
	* Removes all mutations and clears their garbage collection timers.
	* Mutations that are already running continue to execute.
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* mutationCache.clear()
	* ```
	*/
	clear() {
		notifyManager.batch(() => {
			const mutations = this.getAll();
			this.#mutations.clear();
			this.#scopes.clear();
			mutations.forEach((mutation) => mutation.destroy());
			mutations.forEach((mutation) => {
				this.notify({
					type: "removed",
					mutation
				});
			});
		});
	}
	/**
	* Returns all mutations within the cache.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a mutation in rare scenarios.
	* @returns Every mutation in the cache.
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutations = mutationCache.getAll()
	* ```
	*/
	getAll() {
		return Array.from(this.#mutations);
	}
	/**
	* A slightly more advanced method that can be used to get an existing mutation instance from
	* the cache. If the mutation does not exist, `undefined` is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a mutation in rare scenarios.
	* @param filters - The filters to match. `exact` defaults to `true`.
	* @returns The first matching mutation, or `undefined`.
	* @see {@link MutationCache#findAll}
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* ```
	*/
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((mutation) => matchMutation(defaultedFilters, mutation));
	}
	/**
	* An even more advanced method that can be used to get existing mutation instances from the
	* cache that match the given filters. If no mutations match, an empty array is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about mutations in rare scenarios.
	* @param filters - The filters to match. Without filters, every mutation is returned.
	* @returns The matching mutations.
	* @see {@link MutationCache#find}
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutations = mutationCache.findAll({ mutationKey: ['addPost'] })
	* ```
	*/
	findAll(filters = {}) {
		return this.getAll().filter((mutation) => matchMutation(filters, mutation));
	}
	/**
	* Notifies every cache listener of an event, in one batch.
	* @internal
	* @param event - The event passed to every listener.
	*/
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	/**
	* Continues every paused mutation, e.g. when the app comes back online.
	* @internal
	* @returns A promise that resolves once every paused mutation has continued and settled.
	*/
	resumePausedMutations() {
		const pausedMutations = this.getAll().filter((x) => x.state.isPaused);
		return notifyManager.batch(() => Promise.all(pausedMutations.map((mutation) => mutation.continue().catch(noop))));
	}
};
/**
* Returns the scope id of a mutation, used to run mutations with the same scope one after another.
* @param mutation - The mutation to read the scope of.
* @returns The mutation's `scope.id`, or `undefined` if it has no scope.
*/
function scopeFor(mutation) {
	return mutation.options.scope?.id;
}
// node_modules/@tanstack/query-core/build/modern/mutationObserver.js
/**
* Observes a single mutation and derives a `MutationObserverResult` from it.
* A framework hook like `useMutation` creates one `MutationObserver` per hook
* call, keeps it stable across re-renders, calls `setOptions` when the options
* passed to the hook change, subscribes to it to re-render on updates, and
* reads `getCurrentResult()` for the value to return. Calling `mutate()`
* builds a new underlying `Mutation` in the `MutationCache` and executes it.
* @example
* ```ts
* const observer = new MutationObserver(queryClient, {
*   mutationFn: (variables: { title: string }) => addPost(variables),
* })
* ```
*/
var MutationObserver = class extends Subscribable {
	#client;
	#currentResult = void 0;
	#currentMutation;
	#mutateOptions;
	constructor(client, options) {
		super();
		this.#client = client;
		this.setOptions(options);
		this.bindMethods();
		this.#updateResult();
	}
	/**
	* Binds the methods of the result (`mutate` and `reset`) to the observer, so they keep working when
	* destructured from it.
	*/
	bindMethods() {
		this.mutate = this.mutate.bind(this);
		this.reset = this.reset.bind(this);
	}
	/**
	* Updates the observer's options.
	*
	* If the new `mutationKey` differs from the previous one (and both were
	* defined), the observer is reset, detaching it from the mutation it was
	* observing. Otherwise, if the currently observed mutation is still
	* `pending`, its options are updated in place as well.
	* @param options - The new mutation observer options. They are defaulted with {@link
	* QueryClient#defaultMutationOptions} before being applied.
	* @example
	* ```ts
	* observer.setOptions({
	*   mutationFn: (variables: { title: string }) => addPost(variables),
	*   onSuccess: (data) => console.log(data),
	* })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		this.options = this.#client.defaultMutationOptions(options);
		if (!shallowEqualObjects(this.options, prevOptions)) this.#client.getMutationCache().notify({
			type: "observerOptionsUpdated",
			mutation: this.#currentMutation,
			observer: this
		});
		if (prevOptions?.mutationKey && this.options.mutationKey && hashKey(prevOptions.mutationKey) !== hashKey(this.options.mutationKey)) this.reset();
		else if (this.#currentMutation?.state.status === "pending") this.#currentMutation.setOptions(this.options);
	}
	onSubscribe() {
		if (this.listeners.size === 1 && this.#currentMutation) {
			this.#currentMutation.addObserver(this);
			this.#updateResult();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.#currentMutation?.removeObserver(this);
	}
	/**
	* Updates the observer's result when the observed mutation changes, and notifies its listeners.
	* @internal
	* @param action - The action that updated the observed mutation, passed on to the observer's
	* callbacks.
	*/
	onMutationUpdate(action) {
		this.#updateResult();
		this.#notify(action);
	}
	/**
	* Returns the observer's current result, derived from the observed
	* mutation's state (or the default, `idle` state if no mutation has been
	* built yet, e.g. before the first `mutate()` call or after `reset()`).
	* @returns The observer's latest result.
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Detaches the observer from the mutation it is currently observing (if
	* any) and resets the observed result back to its default, `idle` state.
	*
	* This does not cancel an in-flight mutation; the mutation itself keeps
	* running to completion and its own callbacks still fire, but this
	* observer stops reflecting its state and a subsequent `mutate()` call
	* will build a brand new mutation.
	* @see {@link MutationObserver#mutate}
	* @example
	* ```ts
	* observer.reset()
	* ```
	*/
	reset() {
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = void 0;
		this.#updateResult();
		this.#notify();
	}
	/**
	* Builds a new `Mutation` in the `MutationCache` using the observer's
	* current options, detaches this observer from any previously observed
	* mutation, attaches it to the new one, and executes it with the given
	* variables.
	*
	* The optional per-call `options` (`onSuccess`/`onError`/`onSettled`) are
	* invoked once the mutation settles, in addition to any callbacks defined
	* on the observer's own options.
	* @param variables - The variables passed to the `mutationFn`.
	* @param options - Per-call `onSuccess`, `onError`, and `onSettled` callbacks.
	* @returns A promise that resolves with the mutation's data, or rejects with its error.
	* @example
	* ```ts
	* await observer.mutate(
	*   { title: 'New post' },
	*   { onSuccess: (data) => console.log(data) },
	* )
	* ```
	*/
	mutate(variables, options) {
		this.#mutateOptions = options;
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = this.#client.getMutationCache().build(this.#client, this.options);
		this.#currentMutation.addObserver(this);
		return this.#currentMutation.execute(variables);
	}
	#updateResult() {
		const state = this.#currentMutation?.state ?? getDefaultState();
		this.#currentResult = {
			...state,
			isPending: state.status === "pending",
			isSuccess: state.status === "success",
			isError: state.status === "error",
			isIdle: state.status === "idle",
			mutate: this.mutate,
			reset: this.reset
		};
	}
	#notify(action) {
		notifyManager.batch(() => {
			const mutateOptions = this.#mutateOptions;
			if (mutateOptions && this.hasListeners()) {
				const variables = this.#currentResult.variables;
				const onMutateResult = this.#currentResult.context;
				const context = {
					client: this.#client,
					meta: this.options.meta,
					mutationKey: this.options.mutationKey
				};
				if (action?.type === "success") {
					try {
						mutateOptions.onSuccess?.(action.data, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						mutateOptions.onSettled?.(action.data, null, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				} else if (action?.type === "error") {
					try {
						mutateOptions.onError?.(action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						mutateOptions.onSettled?.(void 0, action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				}
			}
			this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
		});
	}
};
// node_modules/@tanstack/query-core/build/modern/queriesObserver.js
/**
* Returns the items of `array1` that are not in `array2`.
* @param array1 - The items to filter.
* @param array2 - The items to exclude.
* @returns A new array with the items of `array1` that are not in `array2`.
*/
function difference(array1, array2) {
	const excludeSet = new Set(array2);
	return array1.filter((x) => !excludeSet.has(x));
}
/**
* A `QueriesObserver` watches an array of queries at once, exposing them as
* a single array of `QueryObserverResult`s (or, when a `combine` option is
* given, as a combined value derived from that array). It manages one
* internal `QueryObserver` per query, and is the primitive that framework
* adapters (e.g. `useQueries`) build their hooks on top of.
* @example
* ```ts
* const observer = new QueriesObserver(queryClient, [
*   { queryKey: ['post', 1], queryFn: fetchPost },
*   { queryKey: ['post', 2], queryFn: fetchPost },
* ])
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result)
* })
* ```
*/
var QueriesObserver = class extends Subscribable {
	#client;
	#result;
	#queries;
	#options;
	#observers;
	#combinedResult;
	#lastCombine;
	#lastResult;
	#lastQueryHashes;
	#observerMatches = [];
	constructor(client, queries, options) {
		super();
		this.#client = client;
		this.#options = options;
		this.#queries = [];
		this.#observers = [];
		this.#result = [];
		this.setQueries(queries);
	}
	onSubscribe() {
		if (this.listeners.size === 1) this.#observers.forEach((observer) => this.#subscribeTo(observer));
	}
	onUnsubscribe() {
		if (!this.listeners.size) this.destroy();
	}
	/**
	* Stops observing all queries: clears all listeners and destroys every
	* underlying `QueryObserver` this observer manages.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#observers.forEach((observer) => {
			observer.destroy();
		});
	}
	/**
	* Replaces the set of queries being observed. Existing `QueryObserver`s
	* are reused for queries that match an already-observed query hash;
	* observers for queries that are no longer present are destroyed, and new
	* observers are created and subscribed to for newly added queries.
	* @param queries - The options of the queries to observe.
	* @param options - Replaces the observer's options, e.g. its `combine` function.
	* @example
	* ```ts
	* observer.setQueries([
	*   { queryKey: ['post', 1], queryFn: fetchPost },
	*   { queryKey: ['post', 3], queryFn: fetchPost },
	* ])
	* ```
	*/
	setQueries(queries, options) {
		this.#queries = queries;
		this.#options = options;
		{
			const queryHashes = queries.map((query) => this.#client.defaultQueryOptions(query).queryHash);
			if (new Set(queryHashes).size !== queryHashes.length) console.warn("[QueriesObserver]: Duplicate Queries found. This might result in unexpected behavior.");
		}
		notifyManager.batch(() => {
			const prevObservers = this.#observers;
			const newObserverMatches = this.#findMatchingObservers(this.#queries);
			newObserverMatches.forEach((match) => match.observer.setOptions(match.defaultedQueryOptions));
			const newObservers = newObserverMatches.map((match) => match.observer);
			const newResult = newObservers.map((observer) => observer.getCurrentResult());
			const hasLengthChange = prevObservers.length !== newObservers.length;
			const hasIndexChange = newObservers.some((observer, index) => observer !== prevObservers[index]);
			const hasStructuralChange = hasLengthChange || hasIndexChange;
			const hasResultChange = hasStructuralChange ? true : newResult.some((result, index) => {
				const prev = this.#result[index];
				return !prev || !shallowEqualObjects(result, prev);
			});
			if (!hasStructuralChange && !hasResultChange) return;
			if (hasStructuralChange) {
				this.#observerMatches = newObserverMatches;
				this.#observers = newObservers;
			}
			this.#result = newResult;
			if (!this.hasListeners()) return;
			if (hasStructuralChange) {
				difference(prevObservers, newObservers).forEach((observer) => {
					observer.destroy();
				});
				difference(newObservers, prevObservers).forEach((observer) => this.#subscribeTo(observer));
			}
			this.#notify();
		});
	}
	/**
	* Returns the most recently computed array of `QueryObserverResult`s, one
	* per observed query, in the same order as the queries passed to the
	* constructor or `setQueries`.
	* @returns The current results.
	* @example
	* ```ts
	* const results = observer.getCurrentResult()
	* const data = results.map((result) => result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#result;
	}
	/**
	* Returns the underlying `Query` instances currently being observed, in
	* the same order as the queries passed to the constructor or `setQueries`.
	* @returns The observed queries.
	*/
	getQueries() {
		return this.#observers.map((observer) => observer.getCurrentQuery());
	}
	/**
	* Returns the underlying `QueryObserver` instances this observer manages,
	* in the same order as the queries passed to the constructor or
	* `setQueries`.
	* @returns The managed query observers.
	*/
	getObservers() {
		return this.#observers;
	}
	/**
	* The `QueriesObserver` counterpart of {@link QueryObserver#getOptimisticResult} — computes
	* the result for the given (already-defaulted) queries right now, synchronously. Called by
	* framework adapters (e.g. `useQueries`) ahead of subscribing, returning a tuple of the raw
	* per-query results, a function to compute the combined result from them, and a function to
	* wrap the results for property-access tracking. When the queries match the observed ones, the
	* results also become the current result, so a later `setQueries` call with the same queries
	* does not notify the listeners about them.
	* @param queries - The defaulted options of the queries to compute the result for.
	* @param combine - The `combine` function used by the returned `combineResult`, if any.
	* @returns A tuple of the per-query results, a function that computes the combined result, and a
	* function that returns the results wrapped for property-access tracking.
	*/
	getOptimisticResult(queries, combine) {
		const matches = this.#findMatchingObservers(queries);
		const result = matches.map((match) => match.observer.getOptimisticResult(match.defaultedQueryOptions));
		if (matches.length === this.#observers.length && matches.some((match, index) => match.observer.getCurrentResult() !== this.#result[index]) && matches.every((match, index) => match.observer === this.#observers[index])) this.#result = matches.map((match) => match.observer.getCurrentResult());
		const queryHashes = matches.map((match) => match.defaultedQueryOptions.queryHash);
		return [
			result,
			(r) => {
				return this.#combineResult(r ?? result, combine, queryHashes);
			},
			() => {
				return this.#trackResult(result, matches);
			}
		];
	}
	#trackResult(result, matches) {
		const trackedProps = /* @__PURE__ */ new Set();
		return matches.map((match, index) => {
			const observerResult = result[index];
			return !match.defaultedQueryOptions.notifyOnChangeProps ? match.observer.trackResult(observerResult, (accessedProp) => {
				if (!trackedProps.has(accessedProp)) {
					trackedProps.add(accessedProp);
					matches.forEach((m) => {
						m.observer.trackProp(accessedProp);
					});
				}
			}) : observerResult;
		});
	}
	#combineResult(input, combine, queryHashes) {
		if (combine) {
			const lastHashes = this.#lastQueryHashes;
			const queryHashesChanged = queryHashes !== void 0 && lastHashes !== void 0 && (lastHashes.length !== queryHashes.length || queryHashes.some((hash, i) => hash !== lastHashes[i]));
			if (this.#result !== this.#lastResult || queryHashesChanged || combine !== this.#lastCombine) {
				this.#lastCombine = combine;
				this.#lastResult = this.#result;
				if (queryHashes !== void 0) this.#lastQueryHashes = queryHashes;
				this.#combinedResult = replaceEqualDeep(this.#combinedResult, combine(input));
			}
			return this.#combinedResult;
		}
		return input;
	}
	#shouldSkipCombine() {
		return !this.#options?.combine || this.#observers.some((observer, index) => {
			return observer.options.suspense && this.#result[index]?.data === void 0;
		});
	}
	#findMatchingObservers(queries) {
		const prevObserversMap = /* @__PURE__ */ new Map();
		this.#observers.forEach((observer) => {
			const key = observer.options.queryHash;
			if (!key) return;
			const previousObservers = prevObserversMap.get(key);
			if (previousObservers) previousObservers.push(observer);
			else prevObserversMap.set(key, [observer]);
		});
		const observers = [];
		queries.forEach((options) => {
			const defaultedOptions = this.#client.defaultQueryOptions(options);
			const observer = prevObserversMap.get(defaultedOptions.queryHash)?.shift() ?? new QueryObserver(this.#client, defaultedOptions);
			observers.push({
				defaultedQueryOptions: defaultedOptions,
				observer
			});
		});
		return observers;
	}
	#subscribeTo(observer) {
		observer.subscribe((result) => {
			this.#onUpdate(observer, result);
		});
	}
	#onUpdate(observer, result) {
		const index = this.#observers.indexOf(observer);
		if (index !== -1) {
			this.#result = this.#result.slice();
			this.#result[index] = result;
			this.#notify();
		}
	}
	#notify() {
		if (this.hasListeners()) {
			const shouldSkipCombine = this.#shouldSkipCombine();
			const previousResult = this.#combinedResult;
			const newResult = shouldSkipCombine ? previousResult : this.#combineResult(this.#trackResult(this.#result, this.#observerMatches), this.#options?.combine, this.#observerMatches.map((match) => match.defaultedQueryOptions.queryHash));
			if (shouldSkipCombine || previousResult !== newResult) notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(this.#result);
				});
			});
		}
	}
};
// node_modules/@tanstack/query-core/build/modern/queryCache.js
/**
* The `QueryCache` is the storage mechanism for TanStack Query. It stores all the data, meta
* information, and state of the queries it contains.
*
* Normally, you will not interact with the `QueryCache` directly and instead use a `QueryClient`
* for a specific cache. You can subscribe to it (inherited from `Subscribable`) to be informed of
* safe/known updates to the cache, such as queries being added, removed, or updated — updates made
* outside of the cache's own tracked mechanisms (e.g. mutating a query's state object directly) do
* not notify subscribers.
* @example
* ```ts
* const unsubscribe = queryCache.subscribe((event) => {
*   console.log(event.type, event.query)
* })
* ```
*/
var QueryCache = class extends Subscribable {
	#queries;
	constructor(config = {}) {
		super();
		this.config = config;
		this.#queries = /* @__PURE__ */ new Map();
	}
	/**
	* Returns the existing `Query` instance for the given options' `queryKey`/`queryHash`, or
	* builds and adds a new one to the cache if none exists yet. Used by framework adapters and
	* plugins (e.g. broadcast/persistence) that need to get-or-create a `Query` directly, bypassing
	* the reactive `QueryObserver` machinery.
	* @param client - The client the query belongs to, used to default its options.
	* @param options - The query options, including the `queryKey`. A new query is created with the
	* options defaulted by {@link QueryClient#defaultQueryOptions}.
	* @param state - The initial state of a newly created query, e.g. when hydrating. Ignored if the
	* query already exists.
	* @returns The existing or newly created query.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const query = queryCache.build(queryClient, {
	*   queryKey: ['posts'],
	*   queryFn: fetchPosts,
	* })
	* ```
	*/
	build(client, options, state) {
		const queryKey = options.queryKey;
		const queryHash = options.queryHash ?? hashQueryKeyByOptions(queryKey, options);
		let query = this.get(queryHash);
		if (!query) {
			query = new Query({
				client,
				queryKey,
				queryHash,
				options: client.defaultQueryOptions(options),
				state,
				defaultOptions: client.getQueryDefaults(queryKey)
			});
			this.add(query);
		}
		return query;
	}
	/**
	* Adds a query to the cache.
	* @internal
	* @param query - The query to add. If a query with the same hash is already cached, nothing
	* happens.
	*/
	add(query) {
		if (!this.#queries.has(query.queryHash)) {
			this.#queries.set(query.queryHash, query);
			this.notify({
				type: "added",
				query
			});
		}
	}
	/**
	* Destroys the given `Query` and removes it from the cache, notifying subscribers with a
	* `'removed'` event. A no-op if the query is no longer the one currently stored under its hash
	* (e.g. it was already replaced). Used by plugins (e.g. the broadcast client) that mirror
	* removals across `QueryCache` instances.
	* @param query - The query to remove.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	* const query = queryCache.find({ queryKey: ['posts'] })
	*
	* if (query) {
	*   queryCache.remove(query)
	* }
	* ```
	*/
	remove(query) {
		if (this.#queries.get(query.queryHash) === query) {
			query.destroy();
			this.#queries.delete(query.queryHash);
			this.notify({
				type: "removed",
				query
			});
		}
	}
	/**
	* Removes all queries from the cache.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* queryCache.clear()
	* ```
	*/
	clear() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				this.remove(query);
			});
		});
	}
	/**
	* Returns the `Query` instance stored under the given `queryHash`, or `undefined` if none
	* exists. Unlike {@link QueryCache#find}, this looks up by the already-computed hash rather
	* than by `QueryFilters`. Used by plugins (e.g. broadcast/hydration) that already have a hash
	* to look up directly.
	* @param queryHash - The hash of the query to look up.
	* @returns The query stored under the hash, or `undefined`.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	* const queryHash = hashKey(['posts'])
	*
	* const query = queryCache.get(queryHash)
	* ```
	*/
	get(queryHash) {
		return this.#queries.get(queryHash);
	}
	/**
	* Returns all queries within the cache.
	* @returns Every query in the cache.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const queries = queryCache.getAll()
	* ```
	*/
	getAll() {
		return [...this.#queries.values()];
	}
	/**
	* A slightly more advanced method that can be used to get an existing query instance from the
	* cache. This instance not only contains all the state for the query, but all of the instances,
	* and underlying guts of the query as well. If the query does not exist, `undefined` is
	* returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a query in rare scenarios (e.g. looking at `query.state.dataUpdatedAt` to
	* decide whether a query is fresh enough to be used as an initial value).
	* @param filters - The filters to match, including the required `queryKey`. `exact` defaults to
	* `true`.
	* @returns The first matching query, or `undefined`.
	* @see {@link QueryCache#findAll}
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const query = queryCache.find({ queryKey: ['posts'] })
	* ```
	*/
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((query) => matchQuery(defaultedFilters, query));
	}
	/**
	* An even more advanced method that can be used to get existing query instances from the cache
	* that partially match a query key. If no queries match, an empty array is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about queries in rare scenarios.
	* @param filters - The filters to match. Without filters, every query is returned.
	* @returns The matching queries.
	* @see {@link QueryCache#find}
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const queries = queryCache.findAll({ queryKey: ['posts'] })
	* ```
	*/
	findAll(filters = {}) {
		const queries = this.getAll();
		return Object.keys(filters).length > 0 ? queries.filter((query) => matchQuery(filters, query)) : queries;
	}
	/**
	* Notifies every cache listener of an event, in one batch.
	* @internal
	* @param event - The event passed to every listener.
	*/
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	/**
	* Calls {@link Query#onFocus} on every cached query, in one batch.
	* @internal
	*/
	onFocus() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onFocus();
			});
		});
	}
	/**
	* Calls {@link Query#onOnline} on every cached query, in one batch.
	* @internal
	*/
	onOnline() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onOnline();
			});
		});
	}
};
// node_modules/@tanstack/query-core/build/modern/queryClient.js
/**
* `QueryClient` is used to interact with a cache of queries and mutations. It owns a
* `QueryCache` and a `MutationCache` (creating default ones if none are passed in) and holds
* the default options that are applied to queries and mutations created through it.
* @example
* ```ts
* const queryClient = new QueryClient({
*   defaultOptions: {
*     queries: {
*       staleTime: Infinity,
*     },
*   },
* })
*
* await queryClient.query({ queryKey: ['posts'], queryFn: fetchPosts })
* ```
*/
var QueryClient = class {
	#queryCache;
	#mutationCache;
	#defaultOptions;
	#queryDefaults;
	#mutationDefaults;
	#mountCount;
	#unsubscribeFocus;
	#unsubscribeOnline;
	constructor(config = {}) {
		this.#queryCache = config.queryCache || new QueryCache();
		this.#mutationCache = config.mutationCache || new MutationCache();
		this.#defaultOptions = config.defaultOptions || {};
		this.#queryDefaults = /* @__PURE__ */ new Map();
		this.#mutationDefaults = /* @__PURE__ */ new Map();
		this.#mountCount = 0;
	}
	/**
	* Called by a framework adapter's `QueryClientProvider`-equivalent when it mounts, to start
	* listening for focus/online events and resume paused mutations. Ref-counted via an internal
	* mount count, so nested or multiple providers sharing the same `QueryClient` don't tear down
	* the shared listeners until the last one unmounts.
	*/
	mount() {
		this.#mountCount++;
		if (this.#mountCount !== 1) return;
		this.#unsubscribeFocus = focusManager.subscribe(async (focused) => {
			if (focused) {
				await this.resumePausedMutations();
				this.#queryCache.onFocus();
			}
		});
		this.#unsubscribeOnline = onlineManager.subscribe(async (online) => {
			if (online) {
				await this.resumePausedMutations();
				this.#queryCache.onOnline();
			}
		});
	}
	/**
	* The inverse of {@link QueryClient#mount} — called by a framework adapter's
	* `QueryClientProvider`-equivalent when it unmounts. Only tears down the focus/online
	* listeners once the mount count returns to `0`.
	*/
	unmount() {
		this.#mountCount--;
		if (this.#mountCount !== 0) return;
		this.#unsubscribeFocus?.();
		this.#unsubscribeFocus = void 0;
		this.#unsubscribeOnline?.();
		this.#unsubscribeOnline = void 0;
	}
	/**
	* Returns the number of queries in the cache that are currently fetching, optionally
	* matching a set of filters. This includes background-fetching, loading new pages, and
	* loading more infinite query results.
	* @param filters - Narrows down which fetching queries are counted. Without filters, every
	* fetching query is counted.
	* @returns The number of matching queries whose `fetchStatus` is `'fetching'`.
	* @example
	* ```ts
	* if (queryClient.isFetching()) {
	*   console.log('At least one query is fetching!')
	* }
	* ```
	*/
	isFetching(filters) {
		return this.#queryCache.findAll({
			...filters,
			fetchStatus: "fetching"
		}).length;
	}
	/**
	* Returns the number of mutations in the cache that are currently pending, optionally
	* matching a set of filters.
	* @param filters - Narrows down which pending mutations are counted. Without filters, every
	* pending mutation is counted.
	* @returns The number of matching mutations whose `status` is `'pending'`.
	* @example
	* ```ts
	* if (queryClient.isMutating()) {
	*   console.log('At least one mutation is pending!')
	* }
	* ```
	*/
	isMutating(filters) {
		return this.#mutationCache.findAll({
			...filters,
			status: "pending"
		}).length;
	}
	/**
	* Imperative (non-reactive) way to retrieve data for a QueryKey.
	* Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
	*
	* Hint: Do not use this function inside a component, because it won't receive updates.
	* Use `useQuery` to create a `QueryObserver` that subscribes to changes.
	* @param queryKey - The query key of the query to read.
	* @returns The cached data for the query, or `undefined` if no query with this key has been observed yet.
	* @see {@link QueryClient#getQueriesData}
	*/
	getQueryData(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state.data;
	}
	/**
	* Returns the cached data of a query, or fetches it if there is none. With `revalidateIfStale`,
	* stale cached data is also refetched in the background.
	* @param options - The query options. If the query has no cached data yet, it is fetched with
	* these options.
	* @returns A promise that resolves to the cached data, or to the fetched data if nothing was
	* cached yet.
	* @deprecated Use queryClient.query({ ...options, staleTime: 'static' }) instead. This method will be removed in the next major version.
	*/
	ensureQueryData(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		const query = this.#queryCache.build(this, defaultedOptions);
		const cachedData = query.state.data;
		if (cachedData === void 0) return this.fetchQuery(options);
		if (options.revalidateIfStale && query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query))) this.prefetchQuery(defaultedOptions);
		return Promise.resolve(cachedData);
	}
	/**
	* Imperative (non-reactive) way to retrieve the cached data of multiple queries at once.
	* Only queries matching the given filters are returned; if none match, an empty array is
	* returned.
	*
	* Because the matched queries can hold data of different shapes (e.g. a broad filter can match
	* queries with unrelated data types), the `TQueryFnData` generic defaults to `unknown` rather
	* than being inferred. Passing a more specific type is a convenience for call sites that know
	* every matched query holds the same shape — it is not checked against the actual cache
	* contents.
	* @param filters - The filters that select which queries to read.
	* @returns An array of query key and data pairs. The data is `undefined` for a query with no cached data.
	* @see {@link QueryClient#getQueryData}
	* @example
	* ```ts
	* const data = queryClient.getQueriesData({ queryKey: ['posts'] })
	* ```
	*/
	getQueriesData(filters) {
		return this.#queryCache.findAll(filters).map(({ queryKey, state }) => {
			return [queryKey, state.data];
		});
	}
	/**
	* Synchronous way to immediately update a query's cached data. If the updater (or the value
	* passed) resolves to `undefined`, the cache is left untouched and no query is created;
	* otherwise, if the query does not exist yet, it will be created. To update multiple queries
	* at once by partially matching query keys, use {@link QueryClient#setQueriesData} instead.
	*
	* Updates must be performed immutably: do not mutate `oldData`, or data previously retrieved
	* via {@link QueryClient#getQueryData}, in place.
	* @param queryKey - The query key to set data for.
	* @param updater - Either the new data, or a function that receives the current data (which
	* may be `undefined`) and returns the new data.
	* @param options - Set `updatedAt` to override the timestamp the written data is recorded with.
	* @returns The data that was written, or `undefined` if the updater returned `undefined` — in that case
	* the write is skipped and the cache is left unchanged.
	* @example
	* ```ts
	* queryClient.setQueryData(['posts'], newPosts)
	*
	* // Or, using an updater function that receives the current data:
	* queryClient.setQueryData(['posts'], (oldPosts) => [...oldPosts, newPost])
	* ```
	*/
	setQueryData(queryKey, updater, options) {
		const defaultedOptions = this.defaultQueryOptions({ queryKey });
		const data = functionalUpdate(updater, this.#queryCache.get(defaultedOptions.queryHash)?.state.data);
		if (data === void 0) return;
		return this.#queryCache.build(this, defaultedOptions).setData(data, {
			...options,
			manual: true
		});
	}
	/**
	* Synchronous way to immediately update the cached data of multiple queries at once, using
	* filters or partial query key matching. Only queries that already exist and match the given
	* filters are updated; no new cache entries are created. Internally this calls
	* {@link QueryClient#setQueryData} for each matching query.
	* @param filters - The filters that select which existing queries to update.
	* @param updater - Either the new data, or a function that receives each matched query's current
	* data (which may be `undefined`) and returns the new data.
	* @param options - Set `updatedAt` to override the timestamp the written data is recorded with.
	* @returns One `[queryKey, data]` tuple per matched query, in the same shape and with the same
	* `undefined` case as {@link QueryClient#setQueryData}.
	* @example
	* ```ts
	* queryClient.setQueriesData({ queryKey: ['posts'] }, (oldPosts) =>
	*   oldPosts ? oldPosts.filter((post) => post.id !== deletedId) : oldPosts,
	* )
	* ```
	*/
	setQueriesData(filters, updater, options) {
		return notifyManager.batch(() => this.#queryCache.findAll(filters).map(({ queryKey }) => [queryKey, this.setQueryData(queryKey, updater, options)]));
	}
	/**
	* Imperative (non-reactive) way to retrieve an existing query's state. If the query does not
	* exist, `undefined` is returned.
	* @param queryKey - The query key of the query to read.
	* @returns The query's state, or `undefined` if no query with this key exists.
	* @example
	* ```ts
	* const state = queryClient.getQueryState(['posts'])
	* console.log(state?.dataUpdatedAt)
	* ```
	*/
	getQueryState(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state;
	}
	/**
	* Removes queries from the cache that match the given filters. Unlike
	* {@link QueryClient#invalidateQueries} or {@link QueryClient#refetchQueries}, this removes
	* matching queries from the cache instead of refetching them. Without filters, every query in
	* the cache is removed.
	* @param filters - The filters that select which queries to remove. Without filters, every query
	* is removed.
	* @example
	* ```ts
	* queryClient.removeQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	removeQueries(filters) {
		const queryCache = this.#queryCache;
		notifyManager.batch(() => {
			queryCache.findAll(filters).forEach((query) => {
				queryCache.remove(query);
			});
		});
	}
	/**
	* Resets queries matching the given filters back to their initial state (e.g. any
	* `initialData`), notifying subscribers rather than removing them. Active queries among the
	* matched set are then refetched, and the returned promise resolves once that refetch settles.
	* @param filters - The filters that select which queries to reset. Without filters, every query
	* is reset.
	* @param options - Passed to the refetch of the active matched queries, e.g. `cancelRefetch` and
	* `throwOnError`.
	* @returns A promise that resolves once the refetch of the active matched queries settles.
	* @example
	* ```ts
	* await queryClient.resetQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	resetQueries(filters, options) {
		const queryCache = this.#queryCache;
		return notifyManager.batch(() => {
			const matched = queryCache.findAll(filters);
			const queriesToRefetch = new Set(matched);
			matched.forEach((query) => {
				query.reset();
			});
			return this.refetchQueries({
				type: "active",
				predicate: (query) => queriesToRefetch.has(query)
			}, options);
		});
	}
	/**
	* Cancels outgoing fetches for queries matching the given filters. Most useful when performing
	* optimistic updates, since any outgoing refetch that resolves afterwards would otherwise
	* overwrite the optimistic update. By default (`revert: true`), a cancelled query's data is
	* reverted to its state before the outgoing fetch started.
	*
	* The returned promise never rejects, even if individual cancellations fail.
	* @param filters - The filters that select which queries to cancel. Without filters, every query
	* is cancelled.
	* @param cancelOptions - Passed to each matched query's cancellation. `revert` defaults to
	* `true`.
	* @returns A promise that resolves once every cancellation has settled.
	* @example
	* ```ts
	* await queryClient.cancelQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	cancelQueries(filters, cancelOptions = {}) {
		const defaultedCancelOptions = {
			revert: true,
			...cancelOptions
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).map((query) => query.cancel(defaultedCancelOptions)));
		return Promise.all(promises).then(noop).catch(noop);
	}
	/**
	* Marks queries matching the given filters as invalidated. Unlike
	* {@link QueryClient#removeQueries}, invalidated queries stay in the cache.
	*
	* Unless `filters.refetchType` is `'none'`, matching queries are then refetched via
	* {@link QueryClient#refetchQueries}, using `filters.refetchType` if set, otherwise
	* `filters.type`, otherwise `'active'`.
	* @param filters - The filters that select which queries to invalidate, plus `refetchType` to
	* control which of them to refetch afterwards. Without filters, every query is invalidated.
	* @param options - Passed to {@link QueryClient#refetchQueries}, e.g. `cancelRefetch` and
	* `throwOnError`.
	* @returns A promise that resolves once the refetch settles, or immediately if `refetchType` is
	* `'none'`.
	* @example
	* ```ts
	* await queryClient.invalidateQueries({ queryKey: ['posts'], refetchType: 'active' })
	* ```
	*/
	invalidateQueries(filters, options = {}) {
		return notifyManager.batch(() => {
			this.#queryCache.findAll(filters).forEach((query) => {
				query.invalidate();
			});
			if (filters?.refetchType === "none") return Promise.resolve();
			return this.refetchQueries({
				...filters,
				type: filters?.refetchType ?? filters?.type ?? "active"
			}, options);
		});
	}
	/**
	* Refetches queries matching the given filters, regardless of whether they are stale. Without
	* filters, every query in the cache is refetched. Queries that are disabled, or static (only
	* have observers with a static `staleTime`), are never refetched.
	*
	* By default (`cancelRefetch: true`), a currently running fetch is cancelled before the new
	* one starts. The returned promise does not reject on individual query failures unless
	* `throwOnError` is `true`.
	*
	* Initially paused fetches do not delay the returned promise. Their later errors are handled
	* even when `throwOnError` is `true`.
	* @param filters - The filters that select which queries to refetch. Without filters, every query
	* in the cache is included.
	* @param options - Set `cancelRefetch` to `false` to keep a running fetch instead of cancelling
	* it, and `throwOnError` to `true` to reject when a refetch that was not initially paused fails.
	* @returns A promise that resolves once all matching refetches that were not initially paused
	* have settled.
	* @example
	* ```ts
	* // refetch all active queries partially matching a query key:
	* await queryClient.refetchQueries({ queryKey: ['posts'], type: 'active' })
	* ```
	*/
	refetchQueries(filters, options = {}) {
		const fetchOptions = {
			...options,
			cancelRefetch: options.cancelRefetch ?? true
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).filter((query) => !query.isDisabled() && !query.isStatic()).map((query) => {
			let promise = query.fetch(void 0, fetchOptions);
			const isPaused = query.state.fetchStatus === "paused";
			if (!fetchOptions.throwOnError || isPaused) promise = promise.catch(noop);
			return isPaused ? Promise.resolve() : promise;
		}));
		return Promise.all(promises).then(noop);
	}
	/**
	* Asynchronous method to fetch and cache a query, resolving with the data or throwing with
	* the error.
	*
	* If the query already exists in the cache and its data is not stale (per the given
	* `staleTime`), the cached data is returned without fetching. Otherwise, the query is fetched
	* and the promise resolves once the fetch settles. If a `select` function is provided, it is
	* applied to the data in both cases (cached or freshly fetched) before it is returned.
	*
	* Unlike a reactive observer, retries are disabled by default here (`retry: false`) unless
	* explicitly configured, since there is no component to catch a thrown error and retry through
	* re-render.
	*
	* The accepted options are `QueryObserverOptions` minus the fields that only make sense for a
	* reactive observer — `enabled`, `refetchInterval`, `refetchIntervalInBackground`,
	* `refetchOnWindowFocus`, `refetchOnReconnect`, `refetchOnMount`, `retryOnMount`,
	* `notifyOnChangeProps`, `throwOnError`, `suspense`, and `placeholderData` are not part of this
	* method's options.
	*
	* This method replaces the deprecated `fetchQuery`, and — combined with
	* `{ staleTime: 'static' }` — the deprecated `ensureQueryData`.
	* @param options - The query options, including the `queryKey` and the `queryFn` used if the
	* query needs to fetch.
	* @returns A promise that resolves to the data, or to the result of `select` if provided. It
	* rejects with the error from the fetch or from `select`.
	* @example
	* ```ts
	* try {
	*   const data = await queryClient.query({ queryKey, queryFn, staleTime: 10000 })
	* } catch (error) {
	*   console.log(error)
	* }
	* ```
	*/
	async query(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		const queryData = query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query)) ? await query.fetch(defaultedOptions) : query.state.data;
		const select = defaultedOptions.select;
		if (select) return select(queryData);
		return queryData;
	}
	/**
	* Fetches and caches a query, or returns its cached data if it isn't stale. Unlike in observers,
	* the fetch isn't retried unless `retry` is set.
	* @param options - The query options, including the `queryKey` and the `queryFn` used if the
	* query needs to fetch.
	* @returns A promise that resolves to the cached or fetched data, or rejects with the fetch
	* error.
	* @deprecated Use queryClient.query(options) instead. This method will be removed in the next major version.
	*/
	fetchQuery(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		return query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
	}
	/**
	* Fetches and caches a query like {@link QueryClient#fetchQuery}, but ignores the result and any
	* error.
	* @param options - The query options, including the `queryKey` and the `queryFn` used if the
	* query needs to fetch.
	* @returns A promise that resolves once the fetch settles. It never rejects.
	* @deprecated Use queryClient.query(options) instead. You can swallow errors with `.catch(noop)`. This method will be removed in the next major version.
	*/
	prefetchQuery(options) {
		return this.fetchQuery(options).then(noop).catch(noop);
	}
	/**
	* Asynchronous method to fetch and cache an infinite query, resolving with an
	* {@link InfiniteData} object or throwing with the error.
	*
	* Requires `initialPageParam` and `getNextPageParam`. Use `pages` to specify how many
	* pages to fetch. If you omit `pages`, the client fetches up to the number of cached
	* pages, or one page if the cache has no pages.
	*
	* This method replaces the deprecated `fetchInfiniteQuery`, and — combined with
	* `{ staleTime: 'static' }` — the deprecated `ensureInfiniteQueryData`.
	* @param options - The query to fetch and the options that control which pages to fetch.
	* @returns A promise that resolves to the {@link InfiniteData}, or to the result of `select` if
	* provided. It rejects with the error from the fetch or from `select`.
	* @example
	* ```ts
	* try {
	*   const data = await queryClient.infiniteQuery({
	*     queryKey,
	*     queryFn,
	*     initialPageParam: 0,
	*     getNextPageParam: (lastPage) => lastPage.nextCursor,
	*   })
	*   console.log(data.pages)
	* } catch (error) {
	*   console.log(error)
	* }
	* ```
	*/
	infiniteQuery(options) {
		options._type = "infinite";
		return this.query(options);
	}
	/**
	* Fetches and caches an infinite query, or returns its cached data if it isn't stale.
	* @param options - The infinite query options, including `initialPageParam` and `getNextPageParam`.
	* @returns A promise that resolves to the cached or fetched {@link InfiniteData}, or rejects with
	* the fetch error.
	* @deprecated Use queryClient.infiniteQuery(options) instead. This method will be removed in the next major version.
	*/
	fetchInfiniteQuery(options) {
		options._type = "infinite";
		return this.fetchQuery(options);
	}
	/**
	* Fetches and caches an infinite query like {@link QueryClient#fetchInfiniteQuery}, but ignores
	* the result and any error.
	* @param options - The infinite query options, including `initialPageParam` and `getNextPageParam`.
	* @returns A promise that resolves once the fetch settles. It never rejects.
	* @deprecated Use queryClient.infiniteQuery(options) instead. You can swallow errors with `.catch(noop)`. This method will be removed in the next major version.
	*/
	prefetchInfiniteQuery(options) {
		return this.fetchInfiniteQuery(options).then(noop).catch(noop);
	}
	/**
	* Returns the cached data of an infinite query, or fetches it if there is none. With
	* `revalidateIfStale`, stale cached data is also refetched in the background.
	* @param options - The infinite query options, including `initialPageParam` and `getNextPageParam`.
	* @returns A promise that resolves to the cached {@link InfiniteData}, or to the fetched data if
	* nothing was cached yet.
	* @deprecated Use queryClient.infiniteQuery({ ...options, staleTime: 'static' }) instead. This method will be removed in the next major version.
	*/
	ensureInfiniteQueryData(options) {
		options._type = "infinite";
		return this.ensureQueryData(options);
	}
	/**
	* Resumes mutations that were paused because there was no network connection. Does nothing
	* (resolving immediately) if the client is currently offline.
	* @returns A promise that resolves once the resumed mutations have settled.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* await queryClient.resumePausedMutations()
	* ```
	*/
	resumePausedMutations() {
		if (onlineManager.isOnline()) return this.#mutationCache.resumePausedMutations();
		return Promise.resolve();
	}
	/**
	* Returns the query cache this client is connected to.
	* @returns The {@link QueryCache} instance.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const queryCache = queryClient.getQueryCache()
	* const queries = queryCache.findAll({ queryKey: ['posts'] })
	* ```
	*/
	getQueryCache() {
		return this.#queryCache;
	}
	/**
	* Returns the mutation cache this client is connected to.
	* @returns The {@link MutationCache} instance.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const mutationCache = queryClient.getMutationCache()
	* const mutations = mutationCache.findAll({ status: 'pending' })
	* ```
	*/
	getMutationCache() {
		return this.#mutationCache;
	}
	/**
	* Returns the default options that were set when creating the client, or via
	* {@link QueryClient#setDefaultOptions}.
	* @returns The client's current default options.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const defaultOptions = queryClient.getDefaultOptions()
	* ```
	*/
	getDefaultOptions() {
		return this.#defaultOptions;
	}
	/**
	* Dynamically sets the default options for this client, overwriting any previously defined
	* default options.
	* @param options - The new default options for queries and mutations.
	* @see {@link QueryClient#getDefaultOptions}
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* queryClient.setDefaultOptions({
	*   queries: {
	*     staleTime: Infinity,
	*   },
	* })
	* ```
	*/
	setDefaultOptions(options) {
		this.#defaultOptions = options;
	}
	/**
	* Sets default options for queries whose query key partially matches the given `queryKey`.
	*
	* If several registered query defaults match a given query key, they are merged together in
	* registration order by {@link QueryClient#getQueryDefaults}, so register defaults from the
	* most generic key to the least generic one — more specific defaults should be registered
	* after more generic ones so they take precedence.
	* @param queryKey - The query key that query keys are partially matched against.
	* @param options - The default options applied to matching queries.
	* @example
	* ```ts
	* queryClient.setQueryDefaults(['posts'], { queryFn: fetchPosts })
	*
	* await queryClient.query({ queryKey: ['posts'] })
	* ```
	*/
	setQueryDefaults(queryKey, options) {
		this.#queryDefaults.set(hashKey(queryKey), {
			queryKey,
			defaultOptions: options
		});
	}
	/**
	* Returns the default options registered for queries whose query key partially matches the
	* given `queryKey`, via {@link QueryClient#setQueryDefaults}. If multiple registered defaults
	* match, they are merged together in registration order.
	* @param queryKey - The query key to look up registered defaults for.
	* @returns The merged default options of every registration that matches, or an empty object if
	* none match.
	* @example
	* ```ts
	* const defaultOptions = queryClient.getQueryDefaults(['posts'])
	* ```
	*/
	getQueryDefaults(queryKey) {
		const defaults = [...this.#queryDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(queryKey, queryDefault.queryKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	/**
	* Sets default options for mutations whose mutation key partially matches the given
	* `mutationKey`. As with {@link QueryClient#setQueryDefaults}, the order of registration
	* matters when several registered defaults match the same mutation key.
	* @param mutationKey - The mutation key that mutation keys are partially matched against.
	* @param options - The default options applied to matching mutations.
	* @see {@link QueryClient#getMutationDefaults}
	* @example
	* ```ts
	* queryClient.setMutationDefaults(['addPost'], { mutationFn: addPost })
	* ```
	*/
	setMutationDefaults(mutationKey, options) {
		this.#mutationDefaults.set(hashKey(mutationKey), {
			mutationKey,
			defaultOptions: options
		});
	}
	/**
	* Returns the default options registered for mutations whose mutation key partially matches
	* the given `mutationKey`, via {@link QueryClient#setMutationDefaults}. If multiple registered
	* defaults match, they are merged together in registration order.
	* @param mutationKey - The mutation key to look up registered defaults for.
	* @returns The merged default options of every registration that matches, or an empty object if
	* none match.
	* @example
	* ```ts
	* const defaultOptions = queryClient.getMutationDefaults(['addPost'])
	* ```
	*/
	getMutationDefaults(mutationKey) {
		const defaults = [...this.#mutationDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(mutationKey, queryDefault.mutationKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	/**
	* Called by framework adapters (e.g. inside `useQuery`) to resolve the options passed by the
	* caller into their final, defaulted form: merging the client's own `defaultOptions.queries`,
	* then `queryClient.setQueryDefaults` for the given `queryKey`, then the caller's options on
	* top. A no-op if the options are already defaulted (`_defaulted: true`).
	* @param options - The query options passed by the caller.
	* @returns The defaulted options, with `queryHash` and dependent defaults (e.g.
	* `refetchOnReconnect`) filled in.
	*/
	defaultQueryOptions(options) {
		if (options._defaulted) return options;
		const defaultedOptions = {
			...this.#defaultOptions.queries,
			...this.getQueryDefaults(options.queryKey),
			...options,
			_defaulted: true
		};
		if (!defaultedOptions.queryHash) defaultedOptions.queryHash = hashQueryKeyByOptions(defaultedOptions.queryKey, defaultedOptions);
		if (defaultedOptions.refetchOnReconnect === void 0) defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
		if (defaultedOptions.throwOnError === void 0) defaultedOptions.throwOnError = !!defaultedOptions.suspense;
		if (!defaultedOptions.networkMode && defaultedOptions.persister) defaultedOptions.networkMode = "offlineFirst";
		if (defaultedOptions.queryFn === skipToken) defaultedOptions.enabled = false;
		return defaultedOptions;
	}
	/**
	* The mutation counterpart of {@link QueryClient#defaultQueryOptions}. Called by framework
	* adapters (e.g. inside `useMutation`) to merge the client's `defaultOptions.mutations`, then
	* `queryClient.setMutationDefaults` for the given `mutationKey`, then the caller's options on
	* top. A no-op if the options are already defaulted (`_defaulted: true`).
	* @param options - The mutation options passed by the caller.
	* @returns The defaulted options.
	*/
	defaultMutationOptions(options) {
		if (options?._defaulted) return options;
		return {
			...this.#defaultOptions.mutations,
			...options?.mutationKey && this.getMutationDefaults(options.mutationKey),
			...options,
			_defaulted: true
		};
	}
	/**
	* Clears both the query cache and the mutation cache this client is connected to.
	* This clears their garbage collection timers and cancels in-flight query fetches.
	* Running mutations continue to execute.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* queryClient.clear()
	* ```
	*/
	clear() {
		this.#queryCache.clear();
		this.#mutationCache.clear();
	}
};
// node_modules/@tanstack/query-core/build/modern/streamedQuery.js
/**
* This is a helper function to create a query function that streams data from an AsyncIterable.
* Data will be an Array of all the chunks received.
* The query will be in a 'pending' state until the first chunk of data is received, but will go to 'success' after that.
* The query will stay in fetchStatus 'fetching' until the stream ends.
* Explicit cancellation stops further cache updates, even if `streamFn` does not read `signal`.
* If `streamFn` does not read `signal`, the stream continues after the last observer unsubscribes.
* @param options - The `streamFn` that returns an AsyncIterable to stream data from, and the optional
* `refetchMode`, `reducer`, and `initialValue` options.
* @returns A query function to pass as `queryFn`.
* @example
* ```ts
* await queryClient.query({
*   queryKey: ['data'],
*   queryFn: streamedQuery({
*     streamFn: fetchDataInChunks,
*   }),
* })
* ```
*/
function streamedQuery({ streamFn, refetchMode = "reset", reducer = (items, chunk) => [...items, chunk], initialValue = [] }) {
	return async (context) => {
		const signal = context[fetchSignal];
		if (signal?.aborted) return initialValue;
		const query = context.client.getQueryCache().find({
			queryKey: context.queryKey,
			exact: true
		});
		const isRefetch = !!query && query.isFetched();
		if (isRefetch && refetchMode === "reset") query.setState({
			...query.resetState,
			fetchStatus: "fetching"
		});
		let result = initialValue;
		let cancelled = false;
		const streamFnContext = addConsumeAwareSignal({
			client: context.client,
			meta: context.meta,
			queryKey: context.queryKey,
			pageParam: context.pageParam,
			direction: context.direction
		}, () => context.signal, () => cancelled = true, signal);
		const isStreamInactive = () => cancelled || signal?.aborted === true;
		const stream = await streamFn(streamFnContext);
		const isReplaceRefetch = isRefetch && refetchMode === "replace";
		for await (const chunk of stream) {
			if (isStreamInactive()) break;
			if (isReplaceRefetch) result = reducer(result, chunk);
			else context.client.setQueryData(context.queryKey, (prev) => reducer(prev === void 0 ? initialValue : prev, chunk));
		}
		if (isReplaceRefetch && !isStreamInactive()) context.client.setQueryData(context.queryKey, result);
		const data = context.client.getQueryData(context.queryKey);
		return data === void 0 ? initialValue : data;
	};
}
// node_modules/@tanstack/query-core/build/modern/types.js
/* istanbul ignore file */
var dataTagSymbol = Symbol();
var dataTagErrorSymbol = Symbol();
var unsetMarker = Symbol();
// node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
/**
* Turns off `retryOnMount` for a query that throws its errors (with `suspense` or `throwOnError`),
* unless the error boundary has been reset, so a remount doesn't retry the failed query before the
* user resets the boundary. Mutates the options.
* @param options - The defaulted query options to adjust.
* @param errorResetBoundary - The value of the nearest `QueryErrorResetBoundary`.
* @param query - The query, used to evaluate a `throwOnError` function against its error.
*/
var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary, query) => {
	const throwOnError = query?.state.status === "error" && typeof options.throwOnError === "function" ? shouldThrowError(options.throwOnError, [query.state.error, query]) : options.throwOnError;
	if (options.suspense || throwOnError) {
		if (!errorResetBoundary.isReset()) options.retryOnMount = false;
	}
};
/**
* Clears the reset state of the error boundary after the component mounts, so later errors are
* thrown to the boundary again.
* @param errorResetBoundary - The value of the nearest `QueryErrorResetBoundary`.
*/
var useClearResetErrorBoundary = (errorResetBoundary) => {
	import_react.useEffect(() => {
		errorResetBoundary.clearReset();
	}, [errorResetBoundary]);
};
/**
* Checks whether the query error should be thrown to the nearest error boundary: the query errored
* and isn't fetching, the boundary hasn't been reset, and either `suspense` is enabled with no data
* or `throwOnError` says so.
* @param params - The observer `result`, the `errorResetBoundary`, the `throwOnError` option, the
* `query`, and the `suspense` option.
* @returns `true` if the error should be thrown.
*/
var getHasError = ({ result, errorResetBoundary, throwOnError, query, suspense }) => {
	return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
};
// node_modules/@tanstack/react-query/build/modern/suspense.js
/**
* The default `throwOnError` of the suspense hooks: throws the error to the nearest error boundary
* only if the query has no data to show.
* @param _error - The error of the query. Unused.
* @param query - The query that errored.
* @returns `true` if the query has no data.
*/
var defaultThrowOnError = (_error, query) => query.state.data === void 0;
/**
* Raises `staleTime` and a numeric `gcTime` to at least 1000ms when `suspense` is enabled, so a
* component that remounts after suspending doesn't refetch right away or find the query garbage
* collected. A `'static'` `staleTime` is kept as is. Mutates the options.
* @param defaultedOptions - The defaulted query options to adjust.
*/
var ensureSuspenseTimers = (defaultedOptions) => {
	if (defaultedOptions.suspense) {
		const MIN_SUSPENSE_TIME_MS = 1e3;
		const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
		const originalStaleTime = defaultedOptions.staleTime;
		defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
		if (typeof defaultedOptions.gcTime === "number") defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
	}
};
/**
* Checks whether a query should suspend: `suspense` is enabled and the result is still `pending`.
* @param defaultedOptions - The defaulted query options, if any.
* @param result - The current result of the observer.
* @returns `true` if the component should suspend.
*/
var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
/**
* Fetches the query for a suspending component, without affecting the observer's own result. If
* the fetch fails, the reset state of the error boundary is cleared, so the error is thrown to it.
* @param defaultedOptions - The defaulted query options to fetch with.
* @param observer - The observer of the query.
* @param errorResetBoundary - The value of the nearest `QueryErrorResetBoundary`.
* @returns A promise that resolves once the fetch settles. It never rejects.
*/
var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
	errorResetBoundary.clearReset();
});
// node_modules/@tanstack/react-query/build/modern/useQueries.js
/**
* The `useQueries` hook can be used to fetch a variable number of queries.
*
* The `queries` key accepts an array with query option objects mostly identical to `useQuery` — the top-level
* `subscribed` option isn't accepted per query (see `placeholderData` below for another difference). A custom
* `QueryClient` is supplied once, as `useQueries`' own top-level second argument, rather than per query.
*
* Having the same query key more than once in the array of query objects may cause some data to be shared
* between queries. To avoid this, consider de-duplicating the queries and map the results back to the desired
* structure.
*
* The `combine` option can be used to combine the results of the queries into a single value. The result will
* be structurally shared to be as referentially stable as possible.
* @param options - The `queries` array to run, and the optional `combine` and `subscribed` options.
* @param queryClient - Use this to provide a custom `QueryClient`. Otherwise, the one from the nearest context
* will be used.
* @returns The combined result. Without `combine`, this is an array with all the query results, in the same
* order as the input. When `combine` is provided, this is the value returned by `combine` instead.
* @throws {Error} The error of the first query that should be thrown to the nearest error boundary (see
* `throwOnError`). While suspending, it throws a promise instead.
* @remarks The `combine` function only re-runs if it changed referentially, or if any of the query results
* changed. An inlined `combine` function, as shown in the example below, therefore runs on every render — wrap
* it in `useCallback`, or extract it to a stable function reference if it doesn't have any dependencies, to
* avoid that.
*
* Unlike `useQuery`, `useQueries` cannot infer the `data` argument of an _inline_ `select` from its sibling
* `queryFn`. Because `useQueries` infers the type of the whole `queries` array at once, the `select` parameter
* of a query object written inline cannot be contextually typed from that same object's `queryFn`, so it falls
* back to `unknown` — a [known TypeScript limitation](https://github.com/TanStack/query/issues/6556). Annotate
* the `select` parameter explicitly, or define the query with {@link queryOptions}, which resolves its types in
* a single object _before_ it reaches `useQueries`, to work around this — see the example below. The same
* limitation applies to {@link useSuspenseQueries}.
*
* `placeholderData` is supported here too, but unlike `useQuery`, it doesn't receive information from
* previously rendered queries, because the number of queries can differ between renders.
* @example
* ```tsx
* import { useQueries } from '@tanstack/react-query'
*
* function Posts({ ids }: { ids: Array<number> }) {
*   const postQueries = useQueries({
*     queries: ids.map((id) => ({
*       queryKey: ['post', id],
*       queryFn: () => fetchPost(id),
*       staleTime: Infinity,
*     })),
*   })
*
*   return (
*     <ul>
*       {postQueries.map((query, index) => {
*         if (query.isPending) return <li key={ids[index]}>Loading...</li>
*         if (query.isError) return <li key={ids[index]}>Error: {query.error.message}</li>
*         return <li key={ids[index]}>{query.data.title}</li>
*       })}
*     </ul>
*   )
* }
* ```
* @example
* Combining results into a single value:
* ```tsx
* import { useQueries } from '@tanstack/react-query'
*
* function Posts({ ids }: { ids: Array<number> }) {
*   const { data, isPending, isError } = useQueries({
*     queries: ids.map((id) => ({
*       queryKey: ['post', id],
*       queryFn: () => fetchPost(id),
*     })),
*     combine: (postQueries) => {
*       return {
*         data: postQueries.map((query) => query.data),
*         isPending: postQueries.some((query) => query.isPending),
*         isError: postQueries.some((query) => query.isError),
*       }
*     },
*   })
*
*   if (isPending) return 'Loading...'
*   if (isError) return 'Error loading posts'
*
*   return (
*     <ul>
*       {data.map((post) => (
*         <li key={post?.id}>{post?.title}</li>
*       ))}
*     </ul>
*   )
* }
* ```
* @example
* Typing `select` via {@link queryOptions}. Note that spreading a `queryOptions` result and overriding
* `select` inline still falls back to `unknown` — wrap the spread in `queryOptions` again so the override is
* resolved before it reaches `useQueries`:
* ```tsx
* import { queryOptions, useQueries } from '@tanstack/react-query'
*
* const postOptions = (id: number) =>
*   queryOptions({
*     queryKey: ['post', id],
*     queryFn: () => fetchPost(id),
*   })
*
* function PostTitle({ id }: { id: number }) {
*   const [{ data: broken }] = useQueries({
*     queries: [
*       {
*         ...postOptions(id),
*         // ❌ `data` is `unknown` here
*         select: (data) => data.title,
*       },
*     ],
*   })
*
*   const [{ data: fixed }] = useQueries({
*     queries: [
*       queryOptions({
*         ...postOptions(id),
*         // ✅ `data` is `Post`
*         select: (data) => data.title,
*       }),
*     ],
*   })
*
*   return <h1>{fixed}</h1>
* }
* ```
*/
function useQueries({ queries, ...options }, queryClient) {
	const client = useQueryClient(queryClient);
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const subscribed = options.subscribed !== false;
	const defaultedQueries = import_react.useMemo(() => queries.map((opts) => {
		const defaultedOptions = client.defaultQueryOptions(opts);
		defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
		return defaultedOptions;
	}), [
		queries,
		client,
		isRestoring,
		subscribed
	]);
	defaultedQueries.forEach((queryOptions) => {
		ensureSuspenseTimers(queryOptions);
		const query = client.getQueryCache().get(queryOptions.queryHash);
		ensurePreventErrorBoundaryRetry(queryOptions, errorResetBoundary, query);
	});
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new QueriesObserver(client, defaultedQueries, options));
	const [optimisticResult, getCombinedResult, trackResult] = observer.getOptimisticResult(defaultedQueries, options.combine);
	import_react.useEffect(() => {
		observer.setQueries(defaultedQueries, options);
	}, [
		defaultedQueries,
		options,
		observer
	]);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	const suspensePromises = optimisticResult.some((result, index) => shouldSuspend(defaultedQueries[index], result)) ? optimisticResult.flatMap((result, index) => {
		const opts = defaultedQueries[index];
		if (opts && shouldSuspend(opts, result)) return fetchOptimistic(opts, new QueryObserver(client, opts), errorResetBoundary);
		return [];
	}) : [];
	if (suspensePromises.length > 0) throw Promise.all(suspensePromises);
	const firstSingleResultWhichShouldThrow = optimisticResult.find((result, index) => {
		const query = defaultedQueries[index];
		return query && getHasError({
			result,
			errorResetBoundary,
			throwOnError: query.throwOnError,
			query: client.getQueryCache().get(query.queryHash),
			suspense: query.suspense
		});
	});
	if (firstSingleResultWhichShouldThrow) throw firstSingleResultWhichShouldThrow.error;
	return getCombinedResult(trackResult());
}
// node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
/**
* Base implementation shared by `useQuery`, `useInfiniteQuery`, `useSuspenseQuery`, and
* `useSuspenseInfiniteQuery`.
* @param options - The options passed to the calling hook.
* @param Observer - The observer class from query-core (`QueryObserver` or
* `InfiniteQueryObserver`).
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest
* context will be used.
* @returns The query result, tracking which properties are read unless `notifyOnChangeProps` is
* set.
* @throws {Error} If `options` is not an object (outside production), or the query error when it should be
* thrown to the nearest error boundary (see `throwOnError`). While suspending, it throws a promise instead.
*/
function useBaseQuery(options, Observer, queryClient) {
	if (typeof options !== "object" || Array.isArray(options)) throw new Error("Bad argument type. Starting with v5, only the \"Object\" form is allowed when calling query related functions. Please use the error stack to find the culprit call. More info here: https://tanstack.com/query/latest/docs/react/guides/migrating-to-v5#supports-a-single-signature-one-object");
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const client = useQueryClient(queryClient);
	const defaultedOptions = client.defaultQueryOptions(options);
	const query = client.getQueryCache().get(defaultedOptions.queryHash);
	if (!defaultedOptions.queryFn) console.error(`[${defaultedOptions.queryHash}]: No queryFn was passed as an option, and no default queryFn was found. The queryFn parameter is only optional when using a default queryFn. More info here: https://tanstack.com/query/latest/docs/framework/react/guides/default-query-function`);
	const subscribed = options.subscribed !== false;
	defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
	ensureSuspenseTimers(defaultedOptions);
	ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary, query);
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new Observer(client, defaultedOptions));
	const result = observer.getOptimisticResult(defaultedOptions);
	import_react.useEffect(() => {
		observer.setOptions(defaultedOptions);
	}, [defaultedOptions, observer]);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => {
		const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop;
		observer.updateResult();
		return unsubscribe;
	}, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	if (shouldSuspend(defaultedOptions, result)) throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
	if (getHasError({
		result,
		errorResetBoundary,
		throwOnError: defaultedOptions.throwOnError,
		query,
		suspense: defaultedOptions.suspense
	})) throw result.error;
	return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
// node_modules/@tanstack/react-query/build/modern/useQuery.js
function useQuery(options, queryClient) {
	return useBaseQuery(options, QueryObserver, queryClient);
}
// node_modules/@tanstack/react-query/build/modern/useSuspenseQuery.js
/**
* The options for `useSuspenseQuery` are the same as for `useQuery`, except for `throwOnError`, `enabled`, and
* `placeholderData` — and `queryFn` may not be `skipToken`, since Suspense hooks can't render a "disabled" state.
*
* Caveat: cancellation does not work.
* @param options - The {@link UseSuspenseQueryOptions} to use — the same options as `useQuery`, minus the ones listed above.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The same object as `useQuery`, except that `data` is guaranteed to be defined, `isPlaceholderData`
* is missing, and `status` is either `success` or `error` (with the derived flags set accordingly).
* @remarks Multiple `useSuspenseQuery` calls in the same component suspend serially, causing a request
* waterfall — each one blocks rendering until it resolves, so the next doesn't even start fetching until then.
* Use {@link useSuspenseQueries} instead when you have more than one suspenseful query in a component, so they
* fetch in parallel.
* @example
* The query error is thrown if the fetch fails and no cached data exists yet, so an error boundary is
* required around `<Suspense>`. A failed background refetch instead continues to render the cached data.
* Use {@link QueryErrorResetBoundary} to let the user retry after such an error:
* ```tsx
* import { Suspense } from 'react'
* import { ErrorBoundary } from 'react-error-boundary'
* import { QueryErrorResetBoundary, useSuspenseQuery } from '@tanstack/react-query'
*
* function Posts() {
*   // `data` is guaranteed to be defined here — no `isPending` check needed.
*   const { data, isFetching } = useSuspenseQuery({
*     queryKey: ['posts'],
*     queryFn: fetchPosts,
*   })
*
*   return (
*     <div>
*       <h1>Posts {isFetching ? '(refreshing...)' : null}</h1>
*       <ul>
*         {data.map((post) => (
*           <li key={post.id}>{post.title}</li>
*         ))}
*       </ul>
*     </div>
*   )
* }
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Suspense fallback={<h1>Loading posts...</h1>}>
*             <Posts />
*           </Suspense>
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
function useSuspenseQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, QueryObserver, queryClient);
}
// node_modules/@tanstack/react-query/build/modern/useSuspenseInfiniteQuery.js
/**
* The options for `useSuspenseInfiniteQuery` are the same as for `useInfiniteQuery`, except for `throwOnError`,
* `enabled`, and `placeholderData`.
*
* Caveat: cancellation does not work.
* @param options - The {@link UseSuspenseInfiniteQueryOptions} to use — the same options as `useInfiniteQuery`, minus the ones listed above.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The same object as `useInfiniteQuery`, except that `data` is guaranteed to be defined,
* `isPlaceholderData` is missing, and `status` is either `success` or `error` (with the derived flags set
* accordingly).
* @remarks Multiple suspenseful query calls in the same component suspend serially, causing a request
* waterfall — each one blocks rendering until it resolves, so the next doesn't even start fetching until
* then. There's no way to parallelize multiple infinite queries under Suspense. Also keep in mind that
* imperative fetch calls, such as `fetchNextPage`, may interfere with the default refetch behavior,
* resulting in outdated data. Make sure to call these functions only in response to user actions, or add
* conditions like `hasNextPage && !isFetching`.
* @see {@link useInfiniteQuery} for the non-Suspense version of this hook.
* @example
* The query error is thrown if a fetch fails and no cached data exists yet, so an error boundary is
* required around `<Suspense>`. A failed background refetch instead continues to render the cached data.
* Use {@link QueryErrorResetBoundary} to let the user retry after such an error:
* ```tsx
* import { Suspense } from 'react'
* import { ErrorBoundary } from 'react-error-boundary'
* import {
*   QueryErrorResetBoundary,
*   useSuspenseInfiniteQuery,
* } from '@tanstack/react-query'
*
* function Projects() {
*   // `data` is guaranteed to be defined here — no `isPending` check needed.
*   const { data, fetchNextPage, hasNextPage, isFetching, isFetchingNextPage } =
*     useSuspenseInfiniteQuery({
*       queryKey: ['projects'],
*       queryFn: ({ pageParam }) => fetchProjects(pageParam),
*       initialPageParam: 0,
*       getNextPageParam: (lastPage) => lastPage.nextId,
*     })
*
*   return (
*     <div>
*       <ul>
*         {data.pages.map((page) =>
*           page.projects.map((project) => <li key={project.id}>{project.name}</li>),
*         )}
*       </ul>
*       <button
*         onClick={() => fetchNextPage()}
*         disabled={!hasNextPage || isFetching}
*       >
*         {isFetchingNextPage
*           ? 'Loading more...'
*           : hasNextPage
*             ? 'Load More'
*             : 'Nothing more to load'}
*       </button>
*     </div>
*   )
* }
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Suspense fallback={<h1>Loading projects...</h1>}>
*             <Projects />
*           </Suspense>
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
function useSuspenseInfiniteQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseInfiniteQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, InfiniteQueryObserver, queryClient);
}
// node_modules/@tanstack/react-query/build/modern/useSuspenseQueries.js
function useSuspenseQueries(options, queryClient) {
	return useQueries({
		...options,
		queries: options.queries.map((query) => {
			if (query.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQueries");
			return {
				...query,
				suspense: true,
				throwOnError: defaultThrowOnError,
				enabled: true,
				placeholderData: void 0
			};
		})
	}, queryClient);
}
// node_modules/@tanstack/react-query/build/modern/usePrefetchQuery.js
/**
* `usePrefetchQuery` does not return anything, it should be used just to fire a prefetch during render, before
* a suspense boundary that wraps a component that uses `useSuspenseQuery`. You can pass everything to
* `usePrefetchQuery` that you can pass to `queryClient.query`, though `queryKey` is always required, and
* `queryFn` is required unless a default query function has been defined.
*
* The prefetch is skipped if the query already has any cached state — including a `pending`/`error` state left
* over from a previous attempt — so calling this on every render is cheap and won't refetch data that's
* already there or already in flight.
* @param options - The {@link UsePrefetchQueryOptions} to use — everything you can pass to `queryClient.query`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @example
* ```tsx
* import { Suspense } from 'react'
* import { usePrefetchQuery } from '@tanstack/react-query'
*
* function App() {
*   // Fire the prefetch during render, before the suspense boundary below.
*   usePrefetchQuery({
*     queryKey: ['posts'],
*     queryFn: fetchPosts,
*   })
*
*   return (
*     <Suspense fallback={<h1>Loading posts...</h1>}>
*       <Posts />
*     </Suspense>
*   )
* }
* ```
*/
function usePrefetchQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.query(options).catch(noop);
}
// node_modules/@tanstack/react-query/build/modern/usePrefetchInfiniteQuery.js
/**
* `usePrefetchInfiniteQuery` does not return anything, it should be used just to fire a prefetch during render,
* before a suspense boundary that wraps a component that uses `useSuspenseInfiniteQuery`. You can pass
* everything to `usePrefetchInfiniteQuery` that you can pass to `queryClient.infiniteQuery`, though
* `queryKey`, `initialPageParam`, and `getNextPageParam` are always required, and `queryFn` is required unless
* a default query function has been defined.
*
* `getNextPageParam` receives both the last page of the infinite list of data and the full array of all pages,
* as well as pageParam information, and should return a single variable that will be passed to your query
* function as `context.pageParam`. Return `undefined` or `null` to indicate there is no next page available.
*
* The prefetch is skipped if the query already has any cached state — including a `pending`/`error` state left
* over from a previous attempt — so calling this on every render is cheap and won't refetch data that's
* already there or already in flight.
* @param options - The {@link UsePrefetchInfiniteQueryOptions} to use — everything you can pass to `queryClient.infiniteQuery`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @example
* ```tsx
* import { Suspense } from 'react'
* import { infiniteQueryOptions, usePrefetchInfiniteQuery } from '@tanstack/react-query'
*
* const projectsOptions = infiniteQueryOptions({
*   queryKey: ['projects'],
*   queryFn: ({ pageParam }) => fetchProjects(pageParam),
*   initialPageParam: 0,
*   getNextPageParam: (lastPage) => lastPage.nextId,
* })
*
* function App() {
*   // Fire the prefetch during render, before the suspense boundary below.
*   usePrefetchInfiniteQuery(projectsOptions)
*
*   return (
*     <Suspense fallback={<h1>Loading projects...</h1>}>
*       <Projects />
*     </Suspense>
*   )
* }
* ```
*/
function usePrefetchInfiniteQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.infiniteQuery(options).catch(noop);
}
// node_modules/@tanstack/react-query/build/modern/queryOptions.js
function queryOptions(options) {
	return options;
}
// node_modules/@tanstack/react-query/build/modern/infiniteQueryOptions.js
function infiniteQueryOptions(options) {
	return options;
}
// node_modules/@tanstack/react-query/build/modern/HydrationBoundary.js
/**
* `HydrationBoundary` adds a previously dehydrated state into the `queryClient` that would be returned by
* `useQueryClient()`. If the client already contains data, the new queries will be intelligently merged based on
* update timestamp.
*
* Note: Only `queries` can be dehydrated with an `HydrationBoundary`.
* @param props - The dehydrated `state` to hydrate, the hydrate `options`, an optional custom
* `queryClient`, and the `children` to render.
* @returns The provided `children`, rendered unconditionally. New queries in `state` are hydrated into the
* cache during render; for queries already in the cache, only newer dehydrated data is hydrated, in an effect
* after commit.
* @example
* ```tsx
* import { HydrationBoundary } from '@tanstack/react-query'
*
* function App() {
*   return <HydrationBoundary state={dehydratedState}>...</HydrationBoundary>
* }
* ```
* @example
* Server-side prefetch handed off to the client via `dehydrate`:
* ```tsx
* import { HydrationBoundary, dehydrate, noop } from '@tanstack/react-query'
*
* async function ServerComponent() {
*   const queryClient = getQueryClient()
*
*   await queryClient
*     .query({
*       queryKey: ['posts'],
*       queryFn: fetchPosts,
*     })
*     .catch(noop)
*
*   return (
*     <HydrationBoundary state={dehydrate(queryClient)}>
*       <Posts />
*     </HydrationBoundary>
*   )
* }
* ```
*/
var HydrationBoundary = ({ children, options = {}, state, queryClient }) => {
	const client = useQueryClient(queryClient);
	const optionsRef = import_react.useRef(options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	const hydrationQueue = import_react.useMemo(() => {
		if (state) {
			if (typeof state !== "object") return;
			const queryCache = client.getQueryCache();
			const queries = state.queries || [];
			const newQueries = [];
			const existingQueries = [];
			for (const dehydratedQuery of queries) {
				const existingQuery = queryCache.get(dehydratedQuery.queryHash);
				if (!existingQuery) newQueries.push(dehydratedQuery);
				else if (dehydratedQuery.state.dataUpdatedAt > existingQuery.state.dataUpdatedAt || dehydratedQuery.promise && existingQuery.state.status !== "pending" && existingQuery.state.fetchStatus !== "fetching" && dehydratedQuery.dehydratedAt > existingQuery.state.dataUpdatedAt) existingQueries.push(dehydratedQuery);
			}
			if (newQueries.length > 0) hydrate(client, { queries: newQueries }, optionsRef.current);
			if (existingQueries.length > 0) return existingQueries;
		}
	}, [client, state]);
	import_react.useEffect(() => {
		if (hydrationQueue) hydrate(client, { queries: hydrationQueue }, optionsRef.current);
	}, [client, hydrationQueue]);
	return children;
};
// node_modules/@tanstack/react-query/build/modern/useIsFetching.js
/**
* The `useIsFetching` hook returns the `number` of the queries that your application is loading or fetching in
* the background (useful for app-wide loading indicators).
* @param filters - The {@link QueryFilters} to narrow down the matched queries.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be the `number` of the queries that your application is currently loading or fetching in the
* background.
* @example
* ```tsx
* import { useIsFetching } from '@tanstack/react-query'
*
* function PostsFetchingIndicator() {
*   // How many queries matching the posts prefix are fetching?
*   const isFetchingPosts = useIsFetching({ queryKey: ['posts'] })
*
*   return isFetchingPosts ? <span>Refreshing posts...</span> : null
* }
* ```
* @example
* A global loading indicator for any query fetching in the background, not just the ones on screen:
* ```tsx
* import { useIsFetching } from '@tanstack/react-query'
*
* function GlobalLoadingIndicator() {
*   const isFetching = useIsFetching()
*
*   return isFetching ? (
*     <div>Queries are fetching in the background...</div>
*   ) : null
* }
* ```
*/
function useIsFetching(filters, queryClient) {
	const client = useQueryClient(queryClient);
	const queryCache = client.getQueryCache();
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => queryCache.subscribe(notifyManager.batchCalls(onStoreChange)), [queryCache]), () => client.isFetching(filters), () => client.isFetching(filters));
}
// node_modules/@tanstack/react-query/build/modern/useMutationState.js
/**
* The `useIsMutating` hook returns the `number` of mutations that your application currently has `pending`
* (useful for app-wide loading indicators).
* @param filters - The {@link MutationFilters} to narrow down the matched mutations.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be the `number` of the mutations that your application currently has `pending`.
* @example
* ```tsx
* import { useIsMutating } from '@tanstack/react-query'
*
* function PostsMutatingIndicator() {
*   // How many mutations matching the posts prefix are in progress?
*   const isMutatingPosts = useIsMutating({ mutationKey: ['posts'] })
*
*   return isMutatingPosts ? <span>Saving posts...</span> : null
* }
* ```
*/
function useIsMutating(filters, queryClient) {
	const client = useQueryClient(queryClient);
	return useMutationState({ filters: {
		...filters,
		status: "pending"
	} }, client).length;
}
/**
* Creates snapshot getters that share equal selected results across renders.
* A new getter is created on each render. Each getter caches its snapshot until the matching mutations
* or their states change.
* @returns A factory for snapshot getters with a shared result cache.
*/
function createSnapshotFactory() {
	let previousResult;
	return (mutationCache, options) => {
		let inputs = [];
		let snapshot;
		return () => {
			const mutations = mutationCache.findAll(options.filters);
			const nextInputs = mutations.flatMap((mutation) => [mutation, mutation.state]);
			if (!snapshot || nextInputs.length !== inputs.length || nextInputs.some((input, index) => !Object.is(input, inputs[index]))) {
				inputs = nextInputs;
				snapshot = replaceEqualDeep(previousResult, mutations.map((mutation) => options.select ? options.select(mutation) : mutation.state));
				previousResult = snapshot;
			}
			return snapshot;
		};
	};
}
/**
* `useMutationState` is a hook that gives you access to all mutations in the `MutationCache`. You can pass
* `filters` ({@link MutationFilters}) to narrow down your mutations, and `select` to transform the mutation
* state.
* @param options - The `filters` to narrow down matched mutations, and an optional `select` to transform the
* mutation state.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be an Array of whatever `select` returns for each matching mutation.
* @example
* Get all variables of all running mutations:
* ```tsx
* import { useMutationState } from '@tanstack/react-query'
*
* function PendingPosts() {
*   const pendingVariables = useMutationState({
*     filters: { status: 'pending' },
*     select: (mutation) => mutation.state.variables,
*   })
*
*   return <>{pendingVariables.length} posts saving...</>
* }
* ```
* @example
* Get all data for specific mutations via the `mutationKey`:
* ```tsx
* import { useMutation, useMutationState } from '@tanstack/react-query'
*
* const mutationKey = ['posts']
*
* function Posts() {
*   // Some mutation that we want to get the state for
*   const mutation = useMutation({
*     mutationKey,
*     mutationFn: createPosts,
*   })
*
*   const savedPosts = useMutationState({
*     // this mutation key needs to match the mutation key of the given mutation (see above)
*     filters: { mutationKey, status: 'success' },
*     select: (mutation) => mutation.state.data,
*   })
*
*   return (
*     <button onClick={() => mutation.mutate(['New Post'])}>
*       Create post ({savedPosts.length} saved so far)
*     </button>
*   )
* }
* ```
* @example
* Access the latest successful mutation data via the `mutationKey`. Each invocation of `mutate` adds a new
* entry to the mutation cache for `gcTime` milliseconds — with the `status: 'success'` filter below, check the
* last item that `useMutationState` returns to get the latest successful invocation:
* ```tsx
* import { useMutationState } from '@tanstack/react-query'
*
* function LatestPost() {
*   const savedPosts = useMutationState({
*     filters: { mutationKey: ['posts'], status: 'success' },
*     select: (mutation) => mutation.state.data,
*   })
*
*   const latestSavedPost = savedPosts[savedPosts.length - 1]
*
*   return <>{latestSavedPost ? 'Saved' : 'Nothing saved yet'}</>
* }
* ```
*/
function useMutationState(options = {}, queryClient) {
	const mutationCache = useQueryClient(queryClient).getMutationCache();
	const [createSnapshot] = import_react.useState(() => createSnapshotFactory());
	const getSnapshot = createSnapshot(mutationCache, options);
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => mutationCache.subscribe(notifyManager.batchCalls(onStoreChange)), [mutationCache]), getSnapshot, getSnapshot);
}
// node_modules/@tanstack/react-query/build/modern/useMutation.js
/**
* Unlike queries, mutations are typically used to create/update/delete data or perform server side-effects.
* `useMutation` is the hook for that.
* @param options - The {@link UseMutationOptions} to use — everything you can pass to `useMutation`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns `mutate`/`mutateAsync` also accept per-call `onSuccess`/`onError`/`onSettled` callbacks as a second
* argument, useful for triggering call-site side effects (e.g. navigation) without coupling them to the shared
* mutation definition. Hook-level callbacks (passed to `options`) fire for every mutation; per-call callbacks
* fire only for the latest call you've made, and only while the component is still mounted — unmounting before
* the mutation settles removes the subscription and prevents them from firing.
* @throws {Error} The mutation error, when `throwOnError` is `true` or returns `true` for it, so that it is
* thrown to the nearest error boundary.
* @see {@link mutationOptions} to share these options across multiple `useMutation` call sites, or to look
* the mutation up elsewhere via its `mutationKey` (e.g. with `useMutationState`).
* @example
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <button
*       onClick={() =>
*         addMutation.mutate('Item', {
*           onError: (error) => console.error('Failed to add item:', error),
*         })
*       }
*     >
*       Add
*     </button>
*   )
* }
* ```
* @example
* Rendering the mutation's own state, rather than just firing it off:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <div>
*       {addMutation.isPending ? (
*         'Adding todo...'
*       ) : (
*         <>
*           {addMutation.isError ? (
*             <div>An error occurred: {addMutation.error.message}</div>
*           ) : null}
*           <button onClick={() => addMutation.mutate('Item')}>Add</button>
*         </>
*       )}
*     </div>
*   )
* }
* ```
* @example
* Optimistic update via `onMutate`, rolling back on `onError`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onMutate: async (newTodo) => {
*       await queryClient.cancelQueries({ queryKey: ['todos'] })
*       const previousTodos = queryClient.getQueryData<Array<string>>(['todos'])
*
*       queryClient.setQueryData<Array<string>>(['todos'], (old) => [
*         ...(old ?? []),
*         newTodo,
*       ])
*
*       // Passed to `onError` as `onMutateResult` if the mutation fails.
*       return { previousTodos }
*     },
*     onError: (_err, _newTodo, onMutateResult) => {
*       queryClient.setQueryData(['todos'], onMutateResult?.previousTodos)
*     },
*     onSettled: () => {
*       queryClient.invalidateQueries({ queryKey: ['todos'] })
*     },
*   })
*
*   return (
*     <button onClick={() => addMutation.mutate('Item')}>Add</button>
*   )
* }
* ```
* @example
* Callbacks passed per call to `mutate` only fire for the last call — `mutateAsync` gives you a
* promise per call instead, so you can wait for all of them when they succeed:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     try {
*       await Promise.all(todos.map((todo) => addMutation.mutateAsync(todo)))
*     } catch (error) {
*       console.error('Failed to add todos:', error)
*     }
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
* @example
* If some of the mutations above can fail independently of the others, and you want to know which ones
* did — rather than losing that information the moment the first one rejects — swap `Promise.all` for
* `Promise.allSettled`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     const addResults = await Promise.allSettled(
*       todos.map((todo) => addMutation.mutateAsync(todo)),
*     )
*
*     addResults.forEach((addResult, index) => {
*       if (addResult.status === 'rejected') {
*         console.error(`Failed to add "${todos[index]}":`, addResult.reason)
*       }
*     })
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
*/
function useMutation(options, queryClient) {
	const client = useQueryClient(queryClient);
	const [observer] = import_react.useState(() => new MutationObserver(client, options));
	import_react.useEffect(() => {
		observer.setOptions(options);
	}, [observer, options]);
	const result = import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => observer.subscribe(notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	const mutate = import_react.useCallback((...args) => {
		observer.mutate(args[0], args[1]).catch(noop);
	}, [observer]);
	if (result.error && shouldThrowError(observer.options.throwOnError, [result.error])) throw result.error;
	return {
		...result,
		mutate,
		mutateAsync: result.mutate
	};
}
// node_modules/@tanstack/react-query/build/modern/mutationOptions.js
function mutationOptions(options) {
	return options;
}
// node_modules/@tanstack/react-query/build/modern/useInfiniteQuery.js
function useInfiniteQuery(options, queryClient) {
	return useBaseQuery(options, InfiniteQueryObserver, queryClient);
}
// node_modules/@tanstack/react-query/build/modern/index.js
/* istanbul ignore file */
export { QueryErrorResetBoundary as $, CancelledError as A, environmentManager as B, QueriesObserver as C, InfiniteQueryObserver as D, Mutation as E, defaultShouldDehydrateMutation as F, matchQuery as G, isServer$1 as H, defaultShouldDehydrateQuery as I, replaceEqualDeep as J, noop as K, dehydrate as L, onlineManager as M, defaultScheduler as N, QueryObserver as O, notifyManager as P, focusManager as Q, dehydrateQuery as R, QueryCache as S, MutationCache as T, keepPreviousData as U, hashKey as V, matchMutation as W, skipToken as X, shouldThrowError as Y, timeoutManager as Z, dataTagErrorSymbol as _, useMutationState as a, useIsRestoring as at, streamedQuery as b, infiniteQueryOptions as c, usePrefetchQuery as d, useQueryErrorResetBoundary as et, useSuspenseQueries as f, useQueries as g, useQuery as h, useIsMutating as i, IsRestoringProvider as it, isCancelledError as j, Query as k, queryOptions as l, useSuspenseQuery as m, mutationOptions as n, QueryClientProvider as nt, useIsFetching as o, useSuspenseInfiniteQuery as p, partialMatchKey as q, useMutation as r, useQueryClient as rt, HydrationBoundary as s, useInfiniteQuery as t, QueryClientContext as tt, usePrefetchInfiniteQuery as u, dataTagSymbol as v, MutationObserver as w, QueryClient as x, unsetMarker as y, hydrate as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kZXJuLUJadkxTRjN4LmpzIiwibmFtZXMiOlsianN4IiwianN4IiwiaXNTZXJ2ZXIiLCJnZXREZWZhdWx0U3RhdGUiXSwic291cmNlcyI6WyIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL0lzUmVzdG9yaW5nUHJvdmlkZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3N1YnNjcmliYWJsZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9mb2N1c01hbmFnZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vdGltZW91dE1hbmFnZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vdXRpbHMuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vZW52aXJvbm1lbnRNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2h5ZHJhdGlvbi5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vbm90aWZ5TWFuYWdlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9yZW1vdmFibGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vb25saW5lTWFuYWdlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9yZXRyeWVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5T2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9ic2VydmVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uQ2FjaGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vbXV0YXRpb25PYnNlcnZlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyaWVzT2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcXVlcnlDYWNoZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyeUNsaWVudC5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdHJlYW1lZFF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3R5cGVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9lcnJvckJvdW5kYXJ5VXRpbHMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3N1c3BlbnNlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VRdWVyaWVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VCYXNlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VTdXNwZW5zZVF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VTdXNwZW5zZUluZmluaXRlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVN1c3BlbnNlUXVlcmllcy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlUHJlZmV0Y2hRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9xdWVyeU9wdGlvbnMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL2luZmluaXRlUXVlcnlPcHRpb25zLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9IeWRyYXRpb25Cb3VuZGFyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlSXNGZXRjaGluZy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlTXV0YXRpb25TdGF0ZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlTXV0YXRpb24uanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL211dGF0aW9uT3B0aW9ucy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlSW5maW5pdGVRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbi8vIHNyYy9Jc1Jlc3RvcmluZ1Byb3ZpZGVyLnRzXG5jb25zdCBJc1Jlc3RvcmluZ0NvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KGZhbHNlKTtcbi8qKlxuKiBJZiB5b3UgYXJlIHVzaW5nIGBQZXJzaXN0UXVlcnlDbGllbnRQcm92aWRlcmAsIHlvdSBjYW4gYWxzbyB1c2UgdGhlIGB1c2VJc1Jlc3RvcmluZ2AgaG9vayBhbG9uZ3NpZGUgaXQgdG9cbiogY2hlY2sgaWYgYSByZXN0b3JlIGlzIGN1cnJlbnRseSBpbiBwcm9ncmVzcy4gYHVzZVF1ZXJ5YCBhbmQgZnJpZW5kcyBhbHNvIGNoZWNrIHRoaXMgaW50ZXJuYWxseSB0byBhdm9pZFxuKiByYWNlIGNvbmRpdGlvbnMgYmV0d2VlbiB0aGUgcmVzdG9yZSBhbmQgbW91bnRpbmcgcXVlcmllcy5cbiogQHJldHVybnMgYHRydWVgIHdoaWxlIGEgcGVyc2lzdGVkIGNsaWVudCBpcyBiZWluZyByZXN0b3JlZCwgYGZhbHNlYCBvdGhlcndpc2UuXG4qL1xuY29uc3QgdXNlSXNSZXN0b3JpbmcgPSAoKSA9PiBSZWFjdC51c2VDb250ZXh0KElzUmVzdG9yaW5nQ29udGV4dCk7XG4vKipcbiogVGhlIFByb3ZpZGVyIHRoYXQgYFBlcnNpc3RRdWVyeUNsaWVudFByb3ZpZGVyYCB1c2VzIHRvIHNpZ25hbCB3aGV0aGVyIGEgcGVyc2lzdGVkIGNsaWVudCBpcyBjdXJyZW50bHlcbiogYmVpbmcgcmVzdG9yZWQsIHJlYWQgYnkgYHVzZUlzUmVzdG9yaW5nYC5cbiovXG5jb25zdCBJc1Jlc3RvcmluZ1Byb3ZpZGVyID0gSXNSZXN0b3JpbmdDb250ZXh0LlByb3ZpZGVyO1xuZXhwb3J0IHsgSXNSZXN0b3JpbmdQcm92aWRlciwgdXNlSXNSZXN0b3JpbmcgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SXNSZXN0b3JpbmdQcm92aWRlci5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyBzcmMvUXVlcnlDbGllbnRQcm92aWRlci50c3hcbi8qKlxuKiBUaGUgY29udGV4dCB0aGF0IGB1c2VRdWVyeUNsaWVudGAgcmVhZHMgZnJvbS4gYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgIGlzIHRoZSBub3JtYWwgd2F5IHRvIHNldCBpdC5cbiovXG5jb25zdCBRdWVyeUNsaWVudENvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KHZvaWQgMCk7XG4vKipcbiogVGhlIGB1c2VRdWVyeUNsaWVudGAgaG9vayByZXR1cm5zIHRoZSBjdXJyZW50IGBRdWVyeUNsaWVudGAgaW5zdGFuY2UuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIGN1cnJlbnQgYFF1ZXJ5Q2xpZW50YCBpbnN0YW5jZS5cbiogQHRocm93cyB7RXJyb3J9IElmIG5vIGBxdWVyeUNsaWVudGAgYXJndW1lbnQgaXMgcGFzc2VkIGFuZCBubyBgUXVlcnlDbGllbnRQcm92aWRlcmAgaXMgZm91bmQgaW4gdGhlXG4qIGNvbXBvbmVudCB0cmVlLlxuKi9cbmNvbnN0IHVzZVF1ZXJ5Q2xpZW50ID0gKHF1ZXJ5Q2xpZW50KSA9PiB7XG5cdGNvbnN0IGNsaWVudCA9IFJlYWN0LnVzZUNvbnRleHQoUXVlcnlDbGllbnRDb250ZXh0KTtcblx0aWYgKHF1ZXJ5Q2xpZW50KSByZXR1cm4gcXVlcnlDbGllbnQ7XG5cdGlmICghY2xpZW50KSB0aHJvdyBuZXcgRXJyb3IoXCJObyBRdWVyeUNsaWVudCBzZXQsIHVzZSBRdWVyeUNsaWVudFByb3ZpZGVyIHRvIHNldCBvbmVcIik7XG5cdHJldHVybiBjbGllbnQ7XG59O1xuLyoqXG4qIFVzZSB0aGUgYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgIGNvbXBvbmVudCB0byBjb25uZWN0IGFuZCBwcm92aWRlIGEgYFF1ZXJ5Q2xpZW50YCB0byB5b3VyIGFwcGxpY2F0aW9uLiBBbHNvXG4qIGNhbGxzIGBjbGllbnQubW91bnQoKWAvYGNsaWVudC51bm1vdW50KClgIGFzIHRoaXMgY29tcG9uZW50IG1vdW50cy91bm1vdW50cywgd2hpY2ggc3Vic2NyaWJlcyB0aGUgY2xpZW50IHRvXG4qIGZvY3VzL29ubGluZSBldmVudHMgKHJlc3VtaW5nIGFueSBwYXVzZWQgbXV0YXRpb25zIGFuZCByZWZldGNoaW5nIGFzIG5lZWRlZCB3aGVuIHRoZSBhcHAgcmVnYWlucyBmb2N1cyBvclxuKiBjb21lcyBiYWNrIG9ubGluZSkuXG4qIEBwYXJhbSBwcm9wcyAtIFRoZSBgY2xpZW50YCB0byBwcm92aWRlLCBhbmQgdGhlIGBjaGlsZHJlbmAgdGhhdCBnZXQgYWNjZXNzIHRvIGl0LlxuKiBAcmV0dXJucyBUaGUgcHJvdmlkZWQgYGNoaWxkcmVuYCwgd3JhcHBlZCBzbyB0aGV5IGNhbiByZWFkIHRoZSBgUXVlcnlDbGllbnRgIHZpYSBgdXNlUXVlcnlDbGllbnRgLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgUXVlcnlDbGllbnQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiA8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT4uLi48L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4qIH1cbiogYGBgXG4qL1xuY29uc3QgUXVlcnlDbGllbnRQcm92aWRlciA9ICh7IGNsaWVudCwgY2hpbGRyZW4gfSkgPT4ge1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGNsaWVudC5tb3VudCgpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRjbGllbnQudW5tb3VudCgpO1xuXHRcdH07XG5cdH0sIFtjbGllbnRdKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUXVlcnlDbGllbnRDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IGNsaWVudCxcblx0XHRjaGlsZHJlblxuXHR9KTtcbn07XG5leHBvcnQgeyBRdWVyeUNsaWVudENvbnRleHQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIsIHVzZVF1ZXJ5Q2xpZW50IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVF1ZXJ5Q2xpZW50UHJvdmlkZXIuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8gc3JjL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LnRzeFxuLyoqXG4qIENyZWF0ZXMgdGhlIHZhbHVlIHNoYXJlZCB0aHJvdWdoIHRoZSBib3VuZGFyeSdzIGNvbnRleHQsIHdoaWNoIHRyYWNrcyB3aGV0aGVyIGEgcmVzZXQgd2FzXG4qIHJlcXVlc3RlZC5cbiogQHJldHVybnMgVGhlIGBjbGVhclJlc2V0YCwgYGlzUmVzZXRgLCBhbmQgYHJlc2V0YCBmdW5jdGlvbnMgb2YgdGhlIGJvdW5kYXJ5LlxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVZhbHVlKCkge1xuXHRsZXQgaXNSZXNldCA9IGZhbHNlO1xuXHRyZXR1cm4ge1xuXHRcdC8qKlxuXHRcdCogQ2xlYXJzIHRoZSByZXNldCBzdGF0ZSwgc28gcXVlcmllcyBrbm93IG5vdCB0byB0cnkgYWdhaW4gdW50aWwgdGhlIGJvdW5kYXJ5IGlzIHJlc2V0IGFnYWluLlxuXHRcdCovXG5cdFx0Y2xlYXJSZXNldDogKCkgPT4ge1xuXHRcdFx0aXNSZXNldCA9IGZhbHNlO1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBSZXNldHMgYW55IHF1ZXJ5IGVycm9ycyB3aXRoaW4gdGhlIGJvdW5kYXJ5LCBzbyBxdWVyaWVzIGtub3cgdGhleSBjYW4gdHJ5IGFnYWluLlxuXHRcdCovXG5cdFx0cmVzZXQ6ICgpID0+IHtcblx0XHRcdGlzUmVzZXQgPSB0cnVlO1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBSZXR1cm5zIHdoZXRoZXIgdGhlIGJvdW5kYXJ5IGhhcyBiZWVuIHJlc2V0IGFuZCBub3QgeWV0IGNsZWFyZWQuXG5cdFx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIGJvdW5kYXJ5IGhhcyBiZWVuIHJlc2V0IGFuZCBub3QgeWV0IGNsZWFyZWQuXG5cdFx0Ki9cblx0XHRpc1Jlc2V0OiAoKSA9PiB7XG5cdFx0XHRyZXR1cm4gaXNSZXNldDtcblx0XHR9XG5cdH07XG59XG5jb25zdCBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeUNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KGNyZWF0ZVZhbHVlKCkpO1xuLyoqXG4qIFRoaXMgaG9vayB3aWxsIHJlc2V0IGFueSBxdWVyeSBlcnJvcnMgd2l0aGluIHRoZSBjbG9zZXN0IGBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeWAuIElmIHRoZXJlIGlzIG5vIGJvdW5kYXJ5XG4qIGRlZmluZWQgaXQgd2lsbCByZXNldCB0aGVtIGdsb2JhbGx5LlxuKiBAcmV0dXJucyBUaGUgYm91bmRhcnkncyB7QGxpbmsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlWYWx1ZX0uXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBcHAoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuKiAgIGNvbnN0IHsgcmVzZXQgfSA9IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5KClcbipcbiogICByZXR1cm4gKFxuKiAgICAgPEVycm9yQm91bmRhcnlcbiogICAgICAgb25SZXNldD17cmVzZXR9XG4qICAgICAgIGZhbGxiYWNrUmVuZGVyPXsoeyByZXNldEVycm9yQm91bmRhcnkgfSkgPT4gKFxuKiAgICAgICAgIDxkaXY+XG4qICAgICAgICAgICBUaGVyZSB3YXMgYW4gZXJyb3IhXG4qICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlc2V0RXJyb3JCb3VuZGFyeSgpfT5UcnkgYWdhaW48L2J1dHRvbj5cbiogICAgICAgICA8L2Rpdj5cbiogICAgICAgKX1cbiogICAgID5cbiogICAgICAge2NoaWxkcmVufVxuKiAgICAgPC9FcnJvckJvdW5kYXJ5PlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5jb25zdCB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSA9ICgpID0+IFJlYWN0LnVzZUNvbnRleHQoUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlDb250ZXh0KTtcbi8qKlxuKiBXaGVuIHVzaW5nIGBzdXNwZW5zZWAgb3IgYHRocm93T25FcnJvcmAgaW4geW91ciBxdWVyaWVzLCB5b3UgbmVlZCBhIHdheSB0byBsZXQgcXVlcmllcyBrbm93IHRoYXQgeW91IHdhbnQgdG9cbiogdHJ5IGFnYWluIHdoZW4gcmUtcmVuZGVyaW5nIGFmdGVyIHNvbWUgZXJyb3Igb2NjdXJyZWQuIFdpdGggdGhlIGBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeWAgY29tcG9uZW50IHlvdSBjYW5cbiogcmVzZXQgYW55IHF1ZXJ5IGVycm9ycyB3aXRoaW4gdGhlIGJvdW5kYXJpZXMgb2YgdGhlIGNvbXBvbmVudC5cbiogQHBhcmFtIHByb3BzIC0gVGhlIGBjaGlsZHJlbmAgdG8gcmVuZGVyLlxuKiBAcmV0dXJucyBUaGUgYGNoaWxkcmVuYCwgcmVuZGVyZWQgYXMtaXMsIG9yIGNhbGxlZCB3aXRoIHRoZSBib3VuZGFyeSdzIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeVZhbHVlfVxuKiBpZiBgY2hpbGRyZW5gIGlzIGEgZnVuY3Rpb24uXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBcHAoKSB7XG4qICAgcmV0dXJuIChcbiogICAgIDxRdWVyeUVycm9yUmVzZXRCb3VuZGFyeT5cbiogICAgICAgeyh7IHJlc2V0IH0pID0+IChcbiogICAgICAgICA8RXJyb3JCb3VuZGFyeVxuKiAgICAgICAgICAgb25SZXNldD17cmVzZXR9XG4qICAgICAgICAgICBmYWxsYmFja1JlbmRlcj17KHsgcmVzZXRFcnJvckJvdW5kYXJ5IH0pID0+IChcbiogICAgICAgICAgICAgPGRpdj5cbiogICAgICAgICAgICAgICBUaGVyZSB3YXMgYW4gZXJyb3IhXG4qICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiByZXNldEVycm9yQm91bmRhcnkoKX0+VHJ5IGFnYWluPC9idXR0b24+XG4qICAgICAgICAgICAgIDwvZGl2PlxuKiAgICAgICAgICAgKX1cbiogICAgICAgICA+XG4qICAgICAgICAgICA8UGFnZSAvPlxuKiAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiogICAgICAgKX1cbiogICAgIDwvUXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmNvbnN0IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5ID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuXHRjb25zdCBbdmFsdWVdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gY3JlYXRlVmFsdWUoKSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5Q29udGV4dC5Qcm92aWRlciwge1xuXHRcdHZhbHVlLFxuXHRcdGNoaWxkcmVuOiB0eXBlb2YgY2hpbGRyZW4gPT09IFwiZnVuY3Rpb25cIiA/IGNoaWxkcmVuKHZhbHVlKSA6IGNoaWxkcmVuXG5cdH0pO1xufTtcbmV4cG9ydCB7IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1RdWVyeUVycm9yUmVzZXRCb3VuZGFyeS5qcy5tYXAiLCIvLyBzcmMvc3Vic2NyaWJhYmxlLnRzXG4vKipcbiogVGhlIGJhc2UgY2xhc3MgYmVoaW5kIGV2ZXJ5dGhpbmcgaW4gUXVlcnkgdGhhdCB5b3UgY2FuIHN1YnNjcmliZSB0bzogYFF1ZXJ5Q2FjaGVgLCBgTXV0YXRpb25DYWNoZWAsXG4qIHRoZSBvYnNlcnZlcnMsIGFuZCB0aGUgYEZvY3VzTWFuYWdlcmAvYE9ubGluZU1hbmFnZXJgIGJlaGluZCBgZm9jdXNNYW5hZ2VyYCBhbmQgYG9ubGluZU1hbmFnZXJgLlxuKiBTdWJjbGFzc2VzIGRlY2lkZSB3aGF0IGEgbGlzdGVuZXIgcmVjZWl2ZXMgYW5kIHdoZW4gaXQgaXMgY2FsbGVkLlxuKi9cbnZhciBTdWJzY3JpYmFibGUgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdHRoaXMubGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHR0aGlzLnN1YnNjcmliZSA9IHRoaXMuc3Vic2NyaWJlLmJpbmQodGhpcyk7XG5cdH1cblx0LyoqXG5cdCogUmVnaXN0ZXJzIGEgbGlzdGVuZXIgdG8gYmUgY2FsbGVkIG9uIGV2ZXJ5IHVwZGF0ZSB0aGlzIG9iamVjdCBub3RpZmllcyBhYm91dC4gUmV0dXJucyBhIGZ1bmN0aW9uXG5cdCogdGhhdCByZW1vdmVzIHRoZSBsaXN0ZW5lciBhZ2FpbiDigJQgY2FsbCBpdCB0byBzdG9wIGxpc3RlbmluZy4gVGhlIGJhc2UgY2xhc3MgbmV2ZXIgZHJvcHMgYSBsaXN0ZW5lclxuXHQqIG9uIGl0cyBvd24sIHRob3VnaCBzb21lIHN1YmNsYXNzZXMgY2xlYXIgYWxsIG9mIHRoZWlycyBpbiBgZGVzdHJveSgpYC5cblx0KiBAcGFyYW0gbGlzdGVuZXIgLSBDYWxsZWQgb24gZWFjaCB1cGRhdGUsIHdpdGggd2hhdGV2ZXIgdGhlIHN1YmNsYXNzIHBhc3NlcyB0byBpdHMgc3Vic2NyaWJlcnMuXG5cdCogQHJldHVybnMgQSBmdW5jdGlvbiB0aGF0IHJlbW92ZXMgdGhlIGxpc3RlbmVyLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCB1bnN1YnNjcmliZSA9IHN1YnNjcmliYWJsZS5zdWJzY3JpYmUoKCkgPT4ge1xuXHQqICAgLy8gcmVhY3QgdG8gdGhlIHVwZGF0ZVxuXHQqIH0pXG5cdCpcblx0KiB1bnN1YnNjcmliZSgpXG5cdCogYGBgXG5cdCovXG5cdHN1YnNjcmliZShsaXN0ZW5lcikge1xuXHRcdHRoaXMubGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7XG5cdFx0dGhpcy5vblN1YnNjcmliZSgpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHR0aGlzLmxpc3RlbmVycy5kZWxldGUobGlzdGVuZXIpO1xuXHRcdFx0dGhpcy5vblVuc3Vic2NyaWJlKCk7XG5cdFx0fTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGB0cnVlYCB3aGlsZSBhdCBsZWFzdCBvbmUgbGlzdGVuZXIgaXMgcmVnaXN0ZXJlZCwgYGZhbHNlYCBvbmNlIHRoZXkgaGF2ZSBhbGwgdW5zdWJzY3JpYmVkLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiBhdCBsZWFzdCBvbmUgbGlzdGVuZXIgaXMgcmVnaXN0ZXJlZC5cblx0Ki9cblx0aGFzTGlzdGVuZXJzKCkge1xuXHRcdHJldHVybiB0aGlzLmxpc3RlbmVycy5zaXplID4gMDtcblx0fVxuXHQvKipcblx0KiBDYWxsZWQgYWZ0ZXIgYSBsaXN0ZW5lciBpcyBhZGRlZC4gRG9lcyBub3RoaW5nIGhlcmU7IHN1YmNsYXNzZXMgb3ZlcnJpZGUgaXQsIGUuZy4gdG8gc3RhcnRcblx0KiB0cmFja2luZyB3aGF0IHRoZXkgb2JzZXJ2ZSBvbmNlIHRoZSBmaXJzdCBsaXN0ZW5lciBzdWJzY3JpYmVzLlxuXHQqL1xuXHRvblN1YnNjcmliZSgpIHt9XG5cdC8qKlxuXHQqIENhbGxlZCBhZnRlciBhIGxpc3RlbmVyIGlzIHJlbW92ZWQuIERvZXMgbm90aGluZyBoZXJlOyBzdWJjbGFzc2VzIG92ZXJyaWRlIGl0LCBlLmcuIHRvIGNsZWFuIHVwXG5cdCogb25jZSB0aGUgbGFzdCBsaXN0ZW5lciB1bnN1YnNjcmliZXMuXG5cdCovXG5cdG9uVW5zdWJzY3JpYmUoKSB7fVxufTtcbmV4cG9ydCB7IFN1YnNjcmliYWJsZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdWJzY3JpYmFibGUuanMubWFwIiwiaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG4vLyBzcmMvZm9jdXNNYW5hZ2VyLnRzXG4vKipcbiogVGhlIGBGb2N1c01hbmFnZXJgIG1hbmFnZXMgdGhlIGZvY3VzIHN0YXRlIHdpdGhpbiBUYW5TdGFjayBRdWVyeS5cbipcbiogSXQgY2FuIGJlIHVzZWQgdG8gY2hhbmdlIHRoZSBkZWZhdWx0IGV2ZW50IGxpc3RlbmVycyBvciB0byBtYW51YWxseSBjaGFuZ2UgdGhlIGZvY3VzIHN0YXRlLlxuKi9cbnZhciBGb2N1c01hbmFnZXIgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG5cdCNmb2N1c2VkO1xuXHQjY2xlYW51cDtcblx0I3NldHVwO1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI3NldHVwID0gKG9uRm9jdXMpID0+IHtcblx0XHRcdGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKSB7XG5cdFx0XHRcdGNvbnN0IGxpc3RlbmVyID0gKCkgPT4gb25Gb2N1cygpO1xuXHRcdFx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInZpc2liaWxpdHljaGFuZ2VcIiwgbGlzdGVuZXIsIGZhbHNlKTtcblx0XHRcdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInZpc2liaWxpdHljaGFuZ2VcIiwgbGlzdGVuZXIpO1xuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH07XG5cdH1cblx0b25TdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLiNjbGVhbnVwKSB0aGlzLnNldEV2ZW50TGlzdGVuZXIodGhpcy4jc2V0dXApO1xuXHR9XG5cdG9uVW5zdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSB7XG5cdFx0XHR0aGlzLiNjbGVhbnVwPy4oKTtcblx0XHRcdHRoaXMuI2NsZWFudXAgPSB2b2lkIDA7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIGBzZXRFdmVudExpc3RlbmVyYCBjYW4gYmUgdXNlZCB0byBzZXQgYSBjdXN0b20gZXZlbnQgbGlzdGVuZXIgdGhhdCB3aWxsXG5cdCogYmUgdXNlZCB0byBkZXRlcm1pbmUgdGhlIGZvY3VzIHN0YXRlLiBUaGUgcHJvdmlkZWQgYHNldHVwYCBmdW5jdGlvblxuXHQqIHJlY2VpdmVzIGEgYHNldEZvY3VzZWRgIGNhbGxiYWNrOiBjYWxsIGl0IHdpdGggYSBgYm9vbGVhbmAgdG8gbWFudWFsbHlcblx0KiBzZXQgdGhlIGZvY3VzIHN0YXRlLCBvciB3aXRoIG5vIGFyZ3VtZW50cyB0byByZS1ldmFsdWF0ZSB0aGUgY3VycmVudFxuXHQqIGZvY3VzIHN0YXRlIGFuZCBub3RpZnkgc3Vic2NyaWJlcnMuXG5cdCogQHBhcmFtIHNldHVwIC0gUmVjZWl2ZXMgdGhlIGBzZXRGb2N1c2VkYCBjYWxsYmFjaywgcmVnaXN0ZXJzIHRoZSBldmVudCBsaXN0ZW5lciwgYW5kIG1heSByZXR1cm5cblx0KiBhIGNsZWFudXAgZnVuY3Rpb24gdGhhdCBpcyBjYWxsZWQgd2hlbiB0aGUgbGlzdGVuZXIgaXMgcmVwbGFjZWQgb3Igbm8gbG9uZ2VyIG5lZWRlZC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgZm9jdXNNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBmb2N1c01hbmFnZXIuc2V0RXZlbnRMaXN0ZW5lcigoaGFuZGxlRm9jdXMpID0+IHtcblx0KiAgIGNvbnN0IGxpc3RlbmVyID0gKCkgPT4gaGFuZGxlRm9jdXMoKVxuXHQqICAgLy8gTGlzdGVuIHRvIHZpc2liaWxpdHljaGFuZ2Vcblx0KiAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcikge1xuXHQqICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIGxpc3RlbmVyLCBmYWxzZSlcblx0KiAgIH1cblx0KlxuXHQqICAgcmV0dXJuICgpID0+IHtcblx0KiAgICAgLy8gQmUgc3VyZSB0byB1bnN1YnNjcmliZSBpZiBhIG5ldyBoYW5kbGVyIGlzIHNldFxuXHQqICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIGxpc3RlbmVyKVxuXHQqICAgfVxuXHQqIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldEV2ZW50TGlzdGVuZXIoc2V0dXApIHtcblx0XHR0aGlzLiNzZXR1cCA9IHNldHVwO1xuXHRcdHRoaXMuI2NsZWFudXA/LigpO1xuXHRcdHRoaXMuI2NsZWFudXAgPSBzZXR1cCgoZm9jdXNlZCkgPT4ge1xuXHRcdFx0aWYgKHR5cGVvZiBmb2N1c2VkID09PSBcImJvb2xlYW5cIikgdGhpcy5zZXRGb2N1c2VkKGZvY3VzZWQpO1xuXHRcdFx0ZWxzZSB0aGlzLm9uRm9jdXMoKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBgc2V0Rm9jdXNlZGAgY2FuIGJlIHVzZWQgdG8gbWFudWFsbHkgc2V0IHRoZSBmb2N1cyBzdGF0ZS4gU2V0IGB1bmRlZmluZWRgXG5cdCogdG8gZmFsbCBiYWNrIHRvIHRoZSBkZWZhdWx0IGZvY3VzIGNoZWNrLlxuXHQqIEBwYXJhbSBmb2N1c2VkIC0gVGhlIGZvY3VzIHN0YXRlLCBvciBgdW5kZWZpbmVkYCB0byB1c2UgdGhlIGRlZmF1bHQgZm9jdXMgY2hlY2suXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogLy8gU2V0IGZvY3VzZWRcblx0KiBmb2N1c01hbmFnZXIuc2V0Rm9jdXNlZCh0cnVlKVxuXHQqXG5cdCogLy8gU2V0IHVuZm9jdXNlZFxuXHQqIGZvY3VzTWFuYWdlci5zZXRGb2N1c2VkKGZhbHNlKVxuXHQqXG5cdCogLy8gRmFsbGJhY2sgdG8gdGhlIGRlZmF1bHQgZm9jdXMgY2hlY2tcblx0KiBmb2N1c01hbmFnZXIuc2V0Rm9jdXNlZCh1bmRlZmluZWQpXG5cdCogYGBgXG5cdCovXG5cdHNldEZvY3VzZWQoZm9jdXNlZCkge1xuXHRcdGlmICh0aGlzLiNmb2N1c2VkICE9PSBmb2N1c2VkKSB7XG5cdFx0XHR0aGlzLiNmb2N1c2VkID0gZm9jdXNlZDtcblx0XHRcdHRoaXMub25Gb2N1cygpO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgb25Gb2N1c2Agbm90aWZpZXMgYWxsIHN1YnNjcmliZWQgbGlzdGVuZXJzIHdpdGggdGhlIGN1cnJlbnQgZm9jdXMgc3RhdGUuXG5cdCovXG5cdG9uRm9jdXMoKSB7XG5cdFx0Y29uc3QgaXNGb2N1c2VkID0gdGhpcy5pc0ZvY3VzZWQoKTtcblx0XHR0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0bGlzdGVuZXIoaXNGb2N1c2VkKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBgaXNGb2N1c2VkYCBjYW4gYmUgdXNlZCB0byBnZXQgdGhlIGN1cnJlbnQgZm9jdXMgc3RhdGUuXG5cdCogQHJldHVybnMgVGhlIGZvY3VzIHN0YXRlIHNldCB3aXRoIGBzZXRGb2N1c2VkYCwgb3Igb3RoZXJ3aXNlIHdoZXRoZXIgdGhlIGRvY3VtZW50IGlzIHZpc2libGUuXG5cdCovXG5cdGlzRm9jdXNlZCgpIHtcblx0XHRpZiAodHlwZW9mIHRoaXMuI2ZvY3VzZWQgPT09IFwiYm9vbGVhblwiKSByZXR1cm4gdGhpcy4jZm9jdXNlZDtcblx0XHRyZXR1cm4gZ2xvYmFsVGhpcy5kb2N1bWVudD8udmlzaWJpbGl0eVN0YXRlICE9PSBcImhpZGRlblwiO1xuXHR9XG59O1xuLyoqXG4qIFNpbmdsZXRvbiBpbnN0YW5jZSBvZiB7QGxpbmsgRm9jdXNNYW5hZ2VyfSwgdXNlZCB0byBtYW5hZ2UgYW5kIG9ic2VydmUgdGhlIGZvY3VzIHN0YXRlIHdpdGhpbiBUYW5TdGFjayBRdWVyeS5cbiovXG5jb25zdCBmb2N1c01hbmFnZXIgPSBuZXcgRm9jdXNNYW5hZ2VyKCk7XG5leHBvcnQgeyBGb2N1c01hbmFnZXIsIGZvY3VzTWFuYWdlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1mb2N1c01hbmFnZXIuanMubWFwIiwiLy8gc3JjL3RpbWVvdXRNYW5hZ2VyLnRzXG5jb25zdCBkZWZhdWx0VGltZW91dFByb3ZpZGVyID0ge1xuXHRzZXRUaW1lb3V0OiAoY2FsbGJhY2ssIGRlbGF5KSA9PiBzZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSksXG5cdGNsZWFyVGltZW91dDogKHRpbWVvdXRJZCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCksXG5cdHNldEludGVydmFsOiAoY2FsbGJhY2ssIGRlbGF5KSA9PiBzZXRJbnRlcnZhbChjYWxsYmFjaywgZGVsYXkpLFxuXHRjbGVhckludGVydmFsOiAoaW50ZXJ2YWxJZCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKVxufTtcbi8qKlxuKiBBbGxvd3MgY3VzdG9taXphdGlvbiBvZiBob3cgdGltZW91dHMgYXJlIGNyZWF0ZWQuXG4qXG4qIGBAdGFuc3RhY2svcXVlcnktY29yZWAgbWFrZXMgbGliZXJhbCB1c2Ugb2YgdGltZW91dHMgdG8gaW1wbGVtZW50IGBzdGFsZVRpbWVgXG4qIGFuZCBgZ2NUaW1lYC4gVGhlIGRlZmF1bHQgVGltZW91dE1hbmFnZXIgcHJvdmlkZXIgdXNlcyB0aGUgcGxhdGZvcm0ncyBnbG9iYWxcbiogYHNldFRpbWVvdXRgIGltcGxlbWVudGF0aW9uLCB3aGljaCBpcyBrbm93biB0byBoYXZlIHNjYWxhYmlsaXR5IGlzc3VlcyB3aXRoXG4qIHRob3VzYW5kcyBvZiB0aW1lb3V0cyBvbiB0aGUgZXZlbnQgbG9vcC5cbipcbiogSWYgeW91IGhpdCB0aGlzIGxpbWl0YXRpb24sIGNvbnNpZGVyIHByb3ZpZGluZyBhIGN1c3RvbSBUaW1lb3V0UHJvdmlkZXIgdGhhdFxuKiBjb2FsZXNjZXMgdGltZW91dHMuXG4qL1xudmFyIFRpbWVvdXRNYW5hZ2VyID0gY2xhc3Mge1xuXHQjcHJvdmlkZXIgPSBkZWZhdWx0VGltZW91dFByb3ZpZGVyO1xuXHQjcHJvdmlkZXJDYWxsZWQgPSBmYWxzZTtcblx0LyoqXG5cdCogYHNldFRpbWVvdXRQcm92aWRlcmAgY2FuIGJlIHVzZWQgdG8gc2V0IGEgY3VzdG9tIGltcGxlbWVudGF0aW9uIG9mIHRoZVxuXHQqIGBzZXRUaW1lb3V0YCwgYGNsZWFyVGltZW91dGAsIGBzZXRJbnRlcnZhbGAsIGBjbGVhckludGVydmFsYCBmdW5jdGlvbnMsXG5cdCogY2FsbGVkIGEgYFRpbWVvdXRQcm92aWRlcmAuXG5cdCpcblx0KiBUaGlzIG1heSBiZSB1c2VmdWwgaWYgeW91IG5vdGljZSBldmVudCBsb29wIHBlcmZvcm1hbmNlIGlzc3VlcyB3aXRoXG5cdCogdGhvdXNhbmRzIG9mIHF1ZXJpZXMuIEEgY3VzdG9tIFRpbWVvdXRQcm92aWRlciBjb3VsZCBhbHNvIHN1cHBvcnQgdGltZXJcblx0KiBkZWxheXMgbG9uZ2VyIHRoYW4gdGhlIGdsb2JhbCBgc2V0VGltZW91dGAgbWF4aW11bSBkZWxheSB2YWx1ZSBvZiBhYm91dFxuXHQqIDI0IGRheXMuXG5cdCpcblx0KiBJdCBpcyBpbXBvcnRhbnQgdG8gY2FsbCBgc2V0VGltZW91dFByb3ZpZGVyYCBiZWZvcmUgY3JlYXRpbmcgYVxuXHQqIFF1ZXJ5Q2xpZW50IG9yIHF1ZXJpZXMsIHNvIHRoYXQgdGhlIHNhbWUgcHJvdmlkZXIgaXMgdXNlZCBjb25zaXN0ZW50bHlcblx0KiBmb3IgYWxsIHRpbWVycyBpbiB0aGUgYXBwbGljYXRpb24sIHNpbmNlIGRpZmZlcmVudCBUaW1lb3V0UHJvdmlkZXJzXG5cdCogY2Fubm90IGNhbmNlbCBlYWNoIG90aGVycycgdGltZXJzLlxuXHQqIEBwYXJhbSBwcm92aWRlciAtIFRoZSBgVGltZW91dFByb3ZpZGVyYCB0byB1c2UgZm9yIGFsbCB0aW1lcnMgZnJvbSBub3cgb24uXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyLCBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqIGltcG9ydCB7IEN1c3RvbVRpbWVvdXRQcm92aWRlciB9IGZyb20gJy4vQ3VzdG9tVGltZW91dFByb3ZpZGVyJ1xuXHQqXG5cdCogdGltZW91dE1hbmFnZXIuc2V0VGltZW91dFByb3ZpZGVyKG5ldyBDdXN0b21UaW1lb3V0UHJvdmlkZXIoKSlcblx0KlxuXHQqIGV4cG9ydCBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogYGBgXG5cdCovXG5cdHNldFRpbWVvdXRQcm92aWRlcihwcm92aWRlcikge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdGlmICh0aGlzLiNwcm92aWRlckNhbGxlZCAmJiBwcm92aWRlciAhPT0gdGhpcy4jcHJvdmlkZXIpIGNvbnNvbGUuZXJyb3IoYFt0aW1lb3V0TWFuYWdlcl06IFN3aXRjaGluZyBwcm92aWRlciBhZnRlciBjYWxscyB0byBwcmV2aW91cyBwcm92aWRlciBtaWdodCByZXN1bHQgaW4gdW5leHBlY3RlZCBiZWhhdmlvci5gLCB7XG5cdFx0XHRcdHByZXZpb3VzOiB0aGlzLiNwcm92aWRlcixcblx0XHRcdFx0cHJvdmlkZXJcblx0XHRcdH0pO1xuXHRcdH1cblx0XHR0aGlzLiNwcm92aWRlciA9IHByb3ZpZGVyO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHRoaXMuI3Byb3ZpZGVyQ2FsbGVkID0gZmFsc2U7XG5cdH1cblx0LyoqXG5cdCogYHNldFRpbWVvdXRgIHNjaGVkdWxlcyBhIGNhbGxiYWNrIHRvIHJ1biBhZnRlciBhcHByb3hpbWF0ZWx5IGBkZWxheWBcblx0KiBtaWxsaXNlY29uZHMsIGxpa2UgdGhlIGdsb2JhbCBgc2V0VGltZW91dGAgZnVuY3Rpb24uIFRoZSBjYWxsYmFjayBjYW4gYmVcblx0KiBjYW5jZWxlZCB3aXRoIGBjbGVhclRpbWVvdXRgLlxuXHQqXG5cdCogSXQgcmV0dXJucyBhIHRpbWVyIElELCB3aGljaCBtYXkgYmUgYSBudW1iZXIgb3IgYW4gb2JqZWN0IHRoYXQgY2FuIGJlXG5cdCogY29lcmNlZCB0byBhIG51bWJlciB2aWEgYFN5bWJvbC50b1ByaW1pdGl2ZWAuXG5cdCogQHBhcmFtIGNhbGxiYWNrIC0gVGhlIGZ1bmN0aW9uIHRvIGNhbGwgd2hlbiB0aGUgdGltZW91dCBlbGFwc2VzLlxuXHQqIEBwYXJhbSBkZWxheSAtIFRoZSB0aW1lIHRvIHdhaXQgYmVmb3JlIGNhbGxpbmcgYGNhbGxiYWNrYCwgaW4gbWlsbGlzZWNvbmRzLlxuXHQqIEByZXR1cm5zIFRoZSB0aW1lciBJRCwgdG8gcGFzcyB0byB7QGxpbmsgVGltZW91dE1hbmFnZXIjY2xlYXJUaW1lb3V0fS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgdGltZW91dE1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IHRpbWVvdXRJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldFRpbWVvdXQoXG5cdCogICAoKSA9PiBjb25zb2xlLmxvZygncmFuIGF0OicsIG5ldyBEYXRlKCkpLFxuXHQqICAgMTAwMCxcblx0KiApXG5cdCpcblx0KiBjb25zdCB0aW1lb3V0SWROdW1iZXI6IG51bWJlciA9IE51bWJlcih0aW1lb3V0SWQpXG5cdCogYGBgXG5cdCovXG5cdHNldFRpbWVvdXQoY2FsbGJhY2ssIGRlbGF5KSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgdGhpcy4jcHJvdmlkZXJDYWxsZWQgPSB0cnVlO1xuXHRcdHJldHVybiB0aGlzLiNwcm92aWRlci5zZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSk7XG5cdH1cblx0LyoqXG5cdCogYGNsZWFyVGltZW91dGAgY2FuY2VscyBhIHRpbWVvdXQgY2FsbGJhY2sgc2NoZWR1bGVkIHdpdGggYHNldFRpbWVvdXRgLFxuXHQqIGxpa2UgdGhlIGdsb2JhbCBgY2xlYXJUaW1lb3V0YCBmdW5jdGlvbi4gSXQgc2hvdWxkIGJlIGNhbGxlZCB3aXRoIGFcblx0KiB0aW1lciBJRCByZXR1cm5lZCBieSBgc2V0VGltZW91dGAuXG5cdCogQHBhcmFtIHRpbWVvdXRJZCAtIFRoZSB0aW1lciBJRCByZXR1cm5lZCBieSBgc2V0VGltZW91dGAsIG9yIGB1bmRlZmluZWRgLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgdGltZW91dElkID0gdGltZW91dE1hbmFnZXIuc2V0VGltZW91dChcblx0KiAgICgpID0+IGNvbnNvbGUubG9nKCdyYW4gYXQ6JywgbmV3IERhdGUoKSksXG5cdCogICAxMDAwLFxuXHQqIClcblx0KlxuXHQqIHRpbWVvdXRNYW5hZ2VyLmNsZWFyVGltZW91dCh0aW1lb3V0SWQpXG5cdCogYGBgXG5cdCovXG5cdGNsZWFyVGltZW91dCh0aW1lb3V0SWQpIHtcblx0XHR0aGlzLiNwcm92aWRlci5jbGVhclRpbWVvdXQodGltZW91dElkKTtcblx0fVxuXHQvKipcblx0KiBgc2V0SW50ZXJ2YWxgIHNjaGVkdWxlcyBhIGNhbGxiYWNrIHRvIGJlIGNhbGxlZCBhcHByb3hpbWF0ZWx5IGV2ZXJ5XG5cdCogYGRlbGF5YCBtaWxsaXNlY29uZHMsIGxpa2UgdGhlIGdsb2JhbCBgc2V0SW50ZXJ2YWxgIGZ1bmN0aW9uLlxuXHQqXG5cdCogTGlrZSBgc2V0VGltZW91dGAsIGl0IHJldHVybnMgYSB0aW1lciBJRCwgd2hpY2ggbWF5IGJlIGEgbnVtYmVyIG9yIGFuXG5cdCogb2JqZWN0IHRoYXQgY2FuIGJlIGNvZXJjZWQgdG8gYSBudW1iZXIgdmlhIGBTeW1ib2wudG9QcmltaXRpdmVgLlxuXHQqIEBwYXJhbSBjYWxsYmFjayAtIFRoZSBmdW5jdGlvbiB0byBjYWxsIG9uIGV2ZXJ5IGludGVydmFsLlxuXHQqIEBwYXJhbSBkZWxheSAtIFRoZSB0aW1lIGJldHdlZW4gY2FsbHMsIGluIG1pbGxpc2Vjb25kcy5cblx0KiBAcmV0dXJucyBUaGUgdGltZXIgSUQsIHRvIHBhc3MgdG8ge0BsaW5rIFRpbWVvdXRNYW5hZ2VyI2NsZWFySW50ZXJ2YWx9LlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgaW50ZXJ2YWxJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldEludGVydmFsKFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRJbnRlcnZhbChjYWxsYmFjaywgZGVsYXkpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aGlzLiNwcm92aWRlckNhbGxlZCA9IHRydWU7XG5cdFx0cmV0dXJuIHRoaXMuI3Byb3ZpZGVyLnNldEludGVydmFsKGNhbGxiYWNrLCBkZWxheSk7XG5cdH1cblx0LyoqXG5cdCogYGNsZWFySW50ZXJ2YWxgIGNhbiBiZSB1c2VkIHRvIGNhbmNlbCBhbiBpbnRlcnZhbCwgbGlrZSB0aGUgZ2xvYmFsXG5cdCogYGNsZWFySW50ZXJ2YWxgIGZ1bmN0aW9uLiBJdCBzaG91bGQgYmUgY2FsbGVkIHdpdGggYW4gaW50ZXJ2YWwgSURcblx0KiByZXR1cm5lZCBieSBgc2V0SW50ZXJ2YWxgLlxuXHQqIEBwYXJhbSBpbnRlcnZhbElkIC0gVGhlIHRpbWVyIElEIHJldHVybmVkIGJ5IGBzZXRJbnRlcnZhbGAsIG9yIGB1bmRlZmluZWRgLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgaW50ZXJ2YWxJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldEludGVydmFsKFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqXG5cdCogdGltZW91dE1hbmFnZXIuY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKVxuXHQqIGBgYFxuXHQqL1xuXHRjbGVhckludGVydmFsKGludGVydmFsSWQpIHtcblx0XHR0aGlzLiNwcm92aWRlci5jbGVhckludGVydmFsKGludGVydmFsSWQpO1xuXHR9XG59O1xuLyoqXG4qIFNpbmdsZXRvbiBpbnN0YW5jZSBvZiB7QGxpbmsgVGltZW91dE1hbmFnZXJ9LCB1c2VkIHRocm91Z2hvdXQgVGFuU3RhY2sgUXVlcnkgdG8gc2NoZWR1bGUgYW5kIGNhbmNlbCB0aW1lcnMuXG4qL1xuY29uc3QgdGltZW91dE1hbmFnZXIgPSBuZXcgVGltZW91dE1hbmFnZXIoKTtcbi8qKlxuKiBJbiBtYW55IGNhc2VzIGNvZGUgd2FudHMgdG8gZGVsYXkgdG8gdGhlIG5leHQgZXZlbnQgbG9vcCB0aWNrOyB0aGlzIGlzIG5vdFxuKiBtZWRpYXRlZCBieSB7QGxpbmsgdGltZW91dE1hbmFnZXJ9LlxuKlxuKiBUaGlzIGZ1bmN0aW9uIGlzIHByb3ZpZGVkIHRvIG1ha2UgYXVkaXRpbmcgdGhlIGB0YW5zdGFjay9xdWVyeS1jb3JlYCBmb3JcbiogaW5jb3JyZWN0IHVzZSBvZiBzeXN0ZW0gYHNldFRpbWVvdXRgIGVhc2llci5cbiogQHBhcmFtIGNhbGxiYWNrIC0gVGhlIGZ1bmN0aW9uIHRvIGNhbGwgb24gdGhlIG5leHQgZXZlbnQgbG9vcCB0aWNrLlxuKi9cbmZ1bmN0aW9uIHN5c3RlbVNldFRpbWVvdXRaZXJvKGNhbGxiYWNrKSB7XG5cdHNldFRpbWVvdXQoY2FsbGJhY2ssIDApO1xufVxuZXhwb3J0IHsgVGltZW91dE1hbmFnZXIsIGRlZmF1bHRUaW1lb3V0UHJvdmlkZXIsIHN5c3RlbVNldFRpbWVvdXRaZXJvLCB0aW1lb3V0TWFuYWdlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD10aW1lb3V0TWFuYWdlci5qcy5tYXAiLCJpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG4vLyBzcmMvdXRpbHMudHNcbi8qKlxuKiBAZGVwcmVjYXRlZCB1c2UgYGVudmlyb25tZW50TWFuYWdlci5pc1NlcnZlcigpYCBpbnN0ZWFkLlxuKi9cbmNvbnN0IGlzU2VydmVyID0gdHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIiB8fCBcIkRlbm9cIiBpbiBnbG9iYWxUaGlzO1xuZnVuY3Rpb24gbm9vcCgpIHt9XG4vKipcbiogUmVzb2x2ZXMgYW4ge0BsaW5rIFVwZGF0ZXJ9OiBjYWxscyBpdCB3aXRoIGBpbnB1dGAgaWYgaXQgaXMgYSBmdW5jdGlvbiwgb3RoZXJ3aXNlIHJldHVybnMgaXQgYXNcbiogaXMuXG4qIEBwYXJhbSB1cGRhdGVyIC0gVGhlIG5ldyB2YWx1ZSwgb3IgYSBmdW5jdGlvbiB0aGF0IHJlY2VpdmVzIGBpbnB1dGAgYW5kIHJldHVybnMgdGhlIG5ldyB2YWx1ZS5cbiogQHBhcmFtIGlucHV0IC0gVGhlIGN1cnJlbnQgdmFsdWUsIHBhc3NlZCB0byBgdXBkYXRlcmAgaWYgaXQgaXMgYSBmdW5jdGlvbi5cbiogQHJldHVybnMgVGhlIG5ldyB2YWx1ZS5cbiovXG5mdW5jdGlvbiBmdW5jdGlvbmFsVXBkYXRlKHVwZGF0ZXIsIGlucHV0KSB7XG5cdHJldHVybiB0eXBlb2YgdXBkYXRlciA9PT0gXCJmdW5jdGlvblwiID8gdXBkYXRlcihpbnB1dCkgOiB1cGRhdGVyO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgdmFsdWUgY2FuIGJlIHVzZWQgYXMgYSB0aW1lb3V0OiBhIG5vbi1uZWdhdGl2ZSwgZmluaXRlIG51bWJlci5cbiogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhIG51bWJlciB0aGF0IGlzIGA+PSAwYCBhbmQgbm90IGBJbmZpbml0eWAuXG4qL1xuZnVuY3Rpb24gaXNWYWxpZFRpbWVvdXQodmFsdWUpIHtcblx0cmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIiAmJiB2YWx1ZSA+PSAwICYmIHZhbHVlICE9PSBJbmZpbml0eTtcbn1cbi8qKlxuKiBDYWxjdWxhdGVzIGhvdyBsb25nIHVudGlsIGRhdGEgdXBkYXRlZCBhdCBgdXBkYXRlZEF0YCBiZWNvbWVzIHN0YWxlLlxuKiBAcGFyYW0gdXBkYXRlZEF0IC0gVGhlIHRpbWVzdGFtcCwgaW4gbWlsbGlzZWNvbmRzLCBhdCB3aGljaCB0aGUgZGF0YSB3YXMgbGFzdCB1cGRhdGVkLlxuKiBAcGFyYW0gc3RhbGVUaW1lIC0gVGhlIHRpbWUsIGluIG1pbGxpc2Vjb25kcywgYWZ0ZXIgd2hpY2ggZGF0YSBpcyBjb25zaWRlcmVkIHN0YWxlLiBEZWZhdWx0cyB0b1xuKiBgMGAuXG4qIEByZXR1cm5zIFRoZSByZW1haW5pbmcgdGltZSBpbiBtaWxsaXNlY29uZHMsIG9yIGAwYCBpZiB0aGUgZGF0YSBpcyBhbHJlYWR5IHN0YWxlLlxuKi9cbmZ1bmN0aW9uIHRpbWVVbnRpbFN0YWxlKHVwZGF0ZWRBdCwgc3RhbGVUaW1lKSB7XG5cdHJldHVybiBNYXRoLm1heCh1cGRhdGVkQXQgKyAoc3RhbGVUaW1lIHx8IDApIC0gRGF0ZS5ub3coKSwgMCk7XG59XG4vKipcbiogUmVzb2x2ZXMgYW4gb3B0aW9uIHRoYXQgY2FuIGJlIGdpdmVuIGVpdGhlciBhcyBhIHZhbHVlIG9yIGFzIGEgZnVuY3Rpb24gb2YgdGhlIHF1ZXJ5LCBzdWNoIGFzXG4qIGBzdGFsZVRpbWVgLlxuKiBAcGFyYW0gdmFsdWUgLSBUaGUgb3B0aW9uIHZhbHVlLCBvciBhIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgYHF1ZXJ5YCBhbmQgcmV0dXJucyB0aGUgdmFsdWUuXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSBwYXNzZWQgdG8gYHZhbHVlYCBpZiBpdCBpcyBhIGZ1bmN0aW9uLlxuKiBAcmV0dXJucyBUaGUgcmVzb2x2ZWQgdmFsdWUsIG9yIGB1bmRlZmluZWRgIGlmIGB2YWx1ZWAgaXMgYHVuZGVmaW5lZGAuXG4qL1xuZnVuY3Rpb24gcmVzb2x2ZVF1ZXJ5VmFsdWUodmFsdWUsIHF1ZXJ5KSB7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIiA/IHZhbHVlKHF1ZXJ5KSA6IHZhbHVlO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgbWF0Y2hlcyB0aGUgZ2l2ZW4ge0BsaW5rIFF1ZXJ5RmlsdGVyc30uXG4qIEV2ZXJ5IGZpbHRlciB0aGF0IGlzIHNwZWNpZmllZCBtdXN0IG1hdGNoOyBmaWx0ZXJzIHRoYXQgYXJlIGxlZnQgdW5zcGVjaWZpZWQgYXJlIGlnbm9yZWQuXG4qIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdG8gY2hlY2sgdGhlIHF1ZXJ5IGFnYWluc3QuXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0byBjaGVjay5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBtYXRjaGVzIGV2ZXJ5IHNwZWNpZmllZCBmaWx0ZXIuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcbipcbiogY29uc3QgbWF0Y2hpbmdRdWVyaWVzID0gcXVlcnlDYWNoZVxuKiAgIC5nZXRBbGwoKVxuKiAgIC5maWx0ZXIoKHF1ZXJ5KSA9PiBtYXRjaFF1ZXJ5KHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9LCBxdWVyeSkpXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIG1hdGNoUXVlcnkoZmlsdGVycywgcXVlcnkpIHtcblx0Y29uc3QgeyB0eXBlID0gXCJhbGxcIiwgZXhhY3QsIGZldGNoU3RhdHVzLCBwcmVkaWNhdGUsIHF1ZXJ5S2V5LCBzdGFsZSB9ID0gZmlsdGVycztcblx0aWYgKHF1ZXJ5S2V5KSB7XG5cdFx0aWYgKGV4YWN0KSB7XG5cdFx0XHRpZiAocXVlcnkucXVlcnlIYXNoICE9PSBoYXNoUXVlcnlLZXlCeU9wdGlvbnMocXVlcnlLZXksIHF1ZXJ5Lm9wdGlvbnMpKSByZXR1cm4gZmFsc2U7XG5cdFx0fSBlbHNlIGlmICghcGFydGlhbE1hdGNoS2V5KHF1ZXJ5LnF1ZXJ5S2V5LCBxdWVyeUtleSkpIHJldHVybiBmYWxzZTtcblx0fVxuXHRpZiAodHlwZSAhPT0gXCJhbGxcIikge1xuXHRcdGNvbnN0IGlzQWN0aXZlID0gcXVlcnkuaXNBY3RpdmUoKTtcblx0XHRpZiAodHlwZSA9PT0gXCJhY3RpdmVcIiAmJiAhaXNBY3RpdmUpIHJldHVybiBmYWxzZTtcblx0XHRpZiAodHlwZSA9PT0gXCJpbmFjdGl2ZVwiICYmIGlzQWN0aXZlKSByZXR1cm4gZmFsc2U7XG5cdH1cblx0aWYgKHR5cGVvZiBzdGFsZSA9PT0gXCJib29sZWFuXCIgJiYgcXVlcnkuaXNTdGFsZSgpICE9PSBzdGFsZSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoZmV0Y2hTdGF0dXMgJiYgZmV0Y2hTdGF0dXMgIT09IHF1ZXJ5LnN0YXRlLmZldGNoU3RhdHVzKSByZXR1cm4gZmFsc2U7XG5cdGlmIChwcmVkaWNhdGUgJiYgIXByZWRpY2F0ZShxdWVyeSkpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHRydWU7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBtdXRhdGlvbiBtYXRjaGVzIHRoZSBnaXZlbiB7QGxpbmsgTXV0YXRpb25GaWx0ZXJzfS5cbiogRXZlcnkgZmlsdGVyIHRoYXQgaXMgc3BlY2lmaWVkIG11c3QgbWF0Y2g7IGZpbHRlcnMgdGhhdCBhcmUgbGVmdCB1bnNwZWNpZmllZCBhcmUgaWdub3JlZC5cbiogSWYgYSBgbXV0YXRpb25LZXlgIGZpbHRlciBpcyBwcm92aWRlZCBidXQgdGhlIG11dGF0aW9uIGhhcyBubyBgbXV0YXRpb25LZXlgIG9mIGl0cyBvd24sIGl0IGRvZXMgbm90IG1hdGNoLlxuKiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRvIGNoZWNrIHRoZSBtdXRhdGlvbiBhZ2FpbnN0LlxuKiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gY2hlY2suXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgbXV0YXRpb24gbWF0Y2hlcyBldmVyeSBzcGVjaWZpZWQgZmlsdGVyLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG4qXG4qIGNvbnN0IG1hdGNoaW5nTXV0YXRpb25zID0gbXV0YXRpb25DYWNoZVxuKiAgIC5nZXRBbGwoKVxuKiAgIC5maWx0ZXIoKG11dGF0aW9uKSA9PiBtYXRjaE11dGF0aW9uKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0sIG11dGF0aW9uKSlcbiogYGBgXG4qL1xuZnVuY3Rpb24gbWF0Y2hNdXRhdGlvbihmaWx0ZXJzLCBtdXRhdGlvbikge1xuXHRjb25zdCB7IGV4YWN0LCBzdGF0dXMsIHByZWRpY2F0ZSwgbXV0YXRpb25LZXkgfSA9IGZpbHRlcnM7XG5cdGlmIChtdXRhdGlvbktleSkge1xuXHRcdGlmICghbXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSkgcmV0dXJuIGZhbHNlO1xuXHRcdGlmIChleGFjdCkge1xuXHRcdFx0aWYgKGhhc2hLZXkobXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSkgIT09IGhhc2hLZXkobXV0YXRpb25LZXkpKSByZXR1cm4gZmFsc2U7XG5cdFx0fSBlbHNlIGlmICghcGFydGlhbE1hdGNoS2V5KG11dGF0aW9uLm9wdGlvbnMubXV0YXRpb25LZXksIG11dGF0aW9uS2V5KSkgcmV0dXJuIGZhbHNlO1xuXHR9XG5cdGlmIChzdGF0dXMgJiYgbXV0YXRpb24uc3RhdGUuc3RhdHVzICE9PSBzdGF0dXMpIHJldHVybiBmYWxzZTtcblx0aWYgKHByZWRpY2F0ZSAmJiAhcHJlZGljYXRlKG11dGF0aW9uKSkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbi8qKlxuKiBIYXNoZXMgYSBxdWVyeSBrZXkgd2l0aCB0aGUgcXVlcnkncyBgcXVlcnlLZXlIYXNoRm5gIG9wdGlvbiwgZmFsbGluZyBiYWNrIHRvIHtAbGluayBoYXNoS2V5fS5cbiogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSB0byBoYXNoLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zIHRoYXQgbWF5IHByb3ZpZGUgYSBjdXN0b20gYHF1ZXJ5S2V5SGFzaEZuYC5cbiogQHJldHVybnMgVGhlIHF1ZXJ5IGhhc2gsIGEgc3RyaW5nIHRoYXQgaWRlbnRpZmllcyB0aGUgcXVlcnkgaW4gdGhlIGNhY2hlLlxuKi9cbmZ1bmN0aW9uIGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgb3B0aW9ucykge1xuXHRyZXR1cm4gKG9wdGlvbnM/LnF1ZXJ5S2V5SGFzaEZuIHx8IGhhc2hLZXkpKHF1ZXJ5S2V5KTtcbn1cbi8qKlxuKiBEZWZhdWx0IHF1ZXJ5ICYgbXV0YXRpb24ga2V5cyBoYXNoIGZ1bmN0aW9uLlxuKiBIYXNoZXMgdGhlIHZhbHVlIGludG8gYSBzdGFibGUgaGFzaC5cbiogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IG9yIG11dGF0aW9uIGtleSB0byBoYXNoLlxuKiBAcmV0dXJucyBUaGUgc3RhYmxlIGhhc2ggb2YgdGhlIGtleSwgYXMgYSBKU09OIHN0cmluZy5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogLy8gT2JqZWN0IGtleXMgYXJlIHNvcnRlZCwgc28ga2V5IG9yZGVyIGRvZXNuJ3QgYWZmZWN0IHRoZSBoYXNoOlxuKiBoYXNoS2V5KFsndG9kb3MnLCB7IHBhZ2U6IDEsIGZpbHRlcjogJ2RvbmUnIH1dKSAvLyA9PT0gJ1tcInRvZG9zXCIse1wiZmlsdGVyXCI6XCJkb25lXCIsXCJwYWdlXCI6MX1dJ1xuKiBgYGBcbiovXG5mdW5jdGlvbiBoYXNoS2V5KHF1ZXJ5S2V5KSB7XG5cdHJldHVybiBKU09OLnN0cmluZ2lmeShxdWVyeUtleSwgKF8sIHZhbCkgPT4gaXNQbGFpbk9iamVjdCh2YWwpID8gT2JqZWN0LmtleXModmFsKS5zb3J0KCkucmVkdWNlKChyZXN1bHQsIGtleSkgPT4ge1xuXHRcdHJlc3VsdFtrZXldID0gdmFsW2tleV07XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSwge30pIDogdmFsKTtcbn1cbmZ1bmN0aW9uIHBhcnRpYWxNYXRjaEtleShhLCBiKSB7XG5cdGlmIChhID09PSBiKSByZXR1cm4gdHJ1ZTtcblx0aWYgKHR5cGVvZiBhICE9PSB0eXBlb2YgYikgcmV0dXJuIGZhbHNlO1xuXHRpZiAoYSAmJiBiICYmIHR5cGVvZiBhID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBiID09PSBcIm9iamVjdFwiKSB7XG5cdFx0aWYgKEFycmF5LmlzQXJyYXkoYSkgIT09IEFycmF5LmlzQXJyYXkoYikpIHJldHVybiBmYWxzZTtcblx0XHRpZiAoQXJyYXkuaXNBcnJheShhKSAmJiBBcnJheS5pc0FycmF5KGIpKSB7XG5cdFx0XHRpZiAoYi5sZW5ndGggPiBhLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBiLmxlbmd0aDsgaSsrKSBpZiAoIXBhcnRpYWxNYXRjaEtleShhW2ldLCBiW2ldKSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXHRcdGNvbnN0IGJLZXlzID0gT2JqZWN0LmtleXMoYik7XG5cdFx0Zm9yIChjb25zdCBrZXkgb2YgYktleXMpIGlmICghcGFydGlhbE1hdGNoS2V5KGFba2V5XSwgYltrZXldKSkgcmV0dXJuIGZhbHNlO1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cdHJldHVybiBmYWxzZTtcbn1cbmNvbnN0IGhhc093biA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5mdW5jdGlvbiByZXBsYWNlRXF1YWxEZWVwKGEsIGIsIGRlcHRoID0gMCkge1xuXHRpZiAoYSA9PT0gYikgcmV0dXJuIGE7XG5cdGlmIChkZXB0aCA+IDUwMCkgcmV0dXJuIGI7XG5cdGNvbnN0IGFycmF5ID0gaXNQbGFpbkFycmF5KGEpICYmIGlzUGxhaW5BcnJheShiKTtcblx0aWYgKCFhcnJheSAmJiAhKGlzUGxhaW5PYmplY3QoYSkgJiYgaXNQbGFpbk9iamVjdChiKSkpIHJldHVybiBiO1xuXHRjb25zdCBhU2l6ZSA9IChhcnJheSA/IGEgOiBPYmplY3Qua2V5cyhhKSkubGVuZ3RoO1xuXHRjb25zdCBiSXRlbXMgPSBhcnJheSA/IGIgOiBPYmplY3Qua2V5cyhiKTtcblx0Y29uc3QgYlNpemUgPSBiSXRlbXMubGVuZ3RoO1xuXHRjb25zdCBjb3B5ID0gYXJyYXkgPyBuZXcgQXJyYXkoYlNpemUpIDoge307XG5cdGxldCBlcXVhbEl0ZW1zID0gMDtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBiU2l6ZTsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gYXJyYXkgPyBpIDogYkl0ZW1zW2ldO1xuXHRcdGNvbnN0IGFJdGVtID0gYVtrZXldO1xuXHRcdGNvbnN0IGJJdGVtID0gYltrZXldO1xuXHRcdGlmIChhSXRlbSA9PT0gYkl0ZW0pIHtcblx0XHRcdGNvcHlba2V5XSA9IGFJdGVtO1xuXHRcdFx0aWYgKGFycmF5ID8gaSA8IGFTaXplIDogaGFzT3duLmNhbGwoYSwga2V5KSkgZXF1YWxJdGVtcysrO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGlmIChhSXRlbSA9PT0gbnVsbCB8fCBiSXRlbSA9PT0gbnVsbCB8fCB0eXBlb2YgYUl0ZW0gIT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGJJdGVtICE9PSBcIm9iamVjdFwiKSB7XG5cdFx0XHRjb3B5W2tleV0gPSBiSXRlbTtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRjb25zdCB2ID0gcmVwbGFjZUVxdWFsRGVlcChhSXRlbSwgYkl0ZW0sIGRlcHRoICsgMSk7XG5cdFx0Y29weVtrZXldID0gdjtcblx0XHRpZiAodiA9PT0gYUl0ZW0pIGVxdWFsSXRlbXMrKztcblx0fVxuXHRyZXR1cm4gYVNpemUgPT09IGJTaXplICYmIGVxdWFsSXRlbXMgPT09IGFTaXplID8gYSA6IGNvcHk7XG59XG4vKipcbiogU2hhbGxvdyBjb21wYXJlIG9iamVjdHMuXG4qIEBwYXJhbSBhIC0gVGhlIGZpcnN0IG9iamVjdC5cbiogQHBhcmFtIGIgLSBUaGUgc2Vjb25kIG9iamVjdCwgb3IgYHVuZGVmaW5lZGAuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiBib3RoIG9iamVjdHMgaGF2ZSB0aGUgc2FtZSBrZXlzLCB3aXRoIHN0cmljdGx5IGVxdWFsIHZhbHVlcyBmb3IgZWFjaCBrZXkuXG4qL1xuZnVuY3Rpb24gc2hhbGxvd0VxdWFsT2JqZWN0cyhhLCBiKSB7XG5cdGlmICghYiB8fCBPYmplY3Qua2V5cyhhKS5sZW5ndGggIT09IE9iamVjdC5rZXlzKGIpLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhhKSkgaWYgKCFoYXNPd24uY2FsbChiLCBrZXkpIHx8IGFba2V5XSAhPT0gYltrZXldKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgdmFsdWUgaXMgYW4gYXJyYXkgd2l0aCBubyBob2xlcyBhbmQgbm8gZXh0cmEgcHJvcGVydGllcy5cbiogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhbiBhcnJheSB3aG9zZSBudW1iZXIgb2Ygb3duIGtleXMgZXF1YWxzIGl0cyBgbGVuZ3RoYC5cbiovXG5mdW5jdGlvbiBpc1BsYWluQXJyYXkodmFsdWUpIHtcblx0cmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpICYmIHZhbHVlLmxlbmd0aCA9PT0gT2JqZWN0LmtleXModmFsdWUpLmxlbmd0aDtcbn1cbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIHZhbHVlIGlzIGEgcGxhaW4gb2JqZWN0LCBlLmcuIGNyZWF0ZWQgd2l0aCBhbiBvYmplY3QgbGl0ZXJhbCBvclxuKiBgT2JqZWN0LmNyZWF0ZShudWxsKWAuXG4qIEBwYXJhbSBvIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYG9gIGlzIGEgcGxhaW4gb2JqZWN0LlxuKi9cbmZ1bmN0aW9uIGlzUGxhaW5PYmplY3Qobykge1xuXHRpZiAoIWhhc09iamVjdFByb3RvdHlwZShvKSkgcmV0dXJuIGZhbHNlO1xuXHRjb25zdCBvYmplY3RQcm90b3R5cGUgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2Yobyk7XG5cdGNvbnN0IGN0b3IgPSBvYmplY3RQcm90b3R5cGU/LmNvbnN0cnVjdG9yO1xuXHRpZiAoY3RvciA9PT0gdm9pZCAwKSByZXR1cm4gdHJ1ZTtcblx0aWYgKHR5cGVvZiBjdG9yICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBmYWxzZTtcblx0Y29uc3QgcHJvdCA9IGN0b3IucHJvdG90eXBlO1xuXHRpZiAoIWhhc09iamVjdFByb3RvdHlwZShwcm90KSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoIXByb3QuaGFzT3duUHJvcGVydHkoXCJpc1Byb3RvdHlwZU9mXCIpKSByZXR1cm4gZmFsc2U7XG5cdGlmIChvYmplY3RQcm90b3R5cGUgIT09IE9iamVjdC5wcm90b3R5cGUpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHRydWU7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSB2YWx1ZSdzIGBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nYCB0YWcgaXMgYFtvYmplY3QgT2JqZWN0XWAuXG4qIEBwYXJhbSBvIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHRhZyBpcyBgW29iamVjdCBPYmplY3RdYC5cbiovXG5mdW5jdGlvbiBoYXNPYmplY3RQcm90b3R5cGUobykge1xuXHRyZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG8pID09PSBcIltvYmplY3QgT2JqZWN0XVwiO1xufVxuLyoqXG4qIFdhaXRzIGZvciB0aGUgZ2l2ZW4gdGltZSwgdXNpbmcgdGhlIGNvbmZpZ3VyZWQge0BsaW5rIHRpbWVvdXRNYW5hZ2VyfS5cbiogQHBhcmFtIHRpbWVvdXQgLSBUaGUgdGltZSB0byB3YWl0LCBpbiBtaWxsaXNlY29uZHMuXG4qIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIGB0aW1lb3V0YCBtaWxsaXNlY29uZHMuXG4qL1xuZnVuY3Rpb24gc2xlZXAodGltZW91dCkge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHR0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KHJlc29sdmUsIHRpbWVvdXQpO1xuXHR9KTtcbn1cbi8qKlxuKiBBcHBsaWVzIGEgcXVlcnkncyBgc3RydWN0dXJhbFNoYXJpbmdgIG9wdGlvbiB3aGVuIHdyaXRpbmcgbmV3IGRhdGEuXG4qIEBwYXJhbSBwcmV2RGF0YSAtIFRoZSBwcmV2aW91c2x5IGNhY2hlZCBkYXRhLlxuKiBAcGFyYW0gZGF0YSAtIFRoZSBuZXcgZGF0YS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucywgd2hvc2UgYHN0cnVjdHVyYWxTaGFyaW5nYCBkZWNpZGVzIGhvdyB0aGUgZGF0YSBpcyBtZXJnZWQuXG4qIEByZXR1cm5zIFRoZSByZXN1bHQgb2YgYSBjdXN0b20gYHN0cnVjdHVyYWxTaGFyaW5nYCBmdW5jdGlvbiwgYGRhdGFgIHdpdGggaXRzIHVuY2hhbmdlZCBwYXJ0c1xuKiByZXBsYWNlZCBieSB0aG9zZSBvZiBgcHJldkRhdGFgIGJ5IGRlZmF1bHQsIG9yIGBkYXRhYCBhcyBpcyBpZiBgc3RydWN0dXJhbFNoYXJpbmdgIGlzIGBmYWxzZWAuXG4qIEB0aHJvd3Mge0Vycm9yfSBUaGUgZXJyb3IgZnJvbSB0aGUgZGVmYXVsdCBzdHJ1Y3R1cmFsIHNoYXJpbmcsIGUuZy4gd2hlbiB0aGUgZGF0YSBpcyBub3QgSlNPTiBzZXJpYWxpemFibGUuXG4qIE91dHNpZGUgcHJvZHVjdGlvbiwgaXQgaXMgYWxzbyBsb2dnZWQgdG8gdGhlIGNvbnNvbGUuXG4qL1xuZnVuY3Rpb24gcmVwbGFjZURhdGEocHJldkRhdGEsIGRhdGEsIG9wdGlvbnMpIHtcblx0aWYgKHR5cGVvZiBvcHRpb25zLnN0cnVjdHVyYWxTaGFyaW5nID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBvcHRpb25zLnN0cnVjdHVyYWxTaGFyaW5nKHByZXZEYXRhLCBkYXRhKTtcblx0ZWxzZSBpZiAob3B0aW9ucy5zdHJ1Y3R1cmFsU2hhcmluZyAhPT0gZmFsc2UpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0cnkge1xuXHRcdFx0cmV0dXJuIHJlcGxhY2VFcXVhbERlZXAocHJldkRhdGEsIGRhdGEpO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRjb25zb2xlLmVycm9yKGBTdHJ1Y3R1cmFsIHNoYXJpbmcgcmVxdWlyZXMgZGF0YSB0byBiZSBKU09OIHNlcmlhbGl6YWJsZS4gVG8gZml4IHRoaXMsIHR1cm4gb2ZmIHN0cnVjdHVyYWxTaGFyaW5nIG9yIHJldHVybiBKU09OLXNlcmlhbGl6YWJsZSBkYXRhIGZyb20geW91ciBxdWVyeUZuLiBbJHtvcHRpb25zLnF1ZXJ5SGFzaH1dOiAke2Vycm9yfWApO1xuXHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0fVxuXHRcdHJldHVybiByZXBsYWNlRXF1YWxEZWVwKHByZXZEYXRhLCBkYXRhKTtcblx0fVxuXHRyZXR1cm4gZGF0YTtcbn1cbi8qKlxuKiBJbnRlbmRlZCB0byBiZSBwYXNzZWQgYXMgYSBxdWVyeSdzIGBwbGFjZWhvbGRlckRhdGFgIG9wdGlvbiwgZm9yIGV4YW1wbGVcbiogYHBsYWNlaG9sZGVyRGF0YToga2VlcFByZXZpb3VzRGF0YWAuIEluc3RlYWQgb2YgcmVzZXR0aW5nIHRoZSBxdWVyeSdzIGRhdGEgdG8gYHVuZGVmaW5lZGAgd2hpbGUgYSBuZXdcbiogcXVlcnkga2V5IGlzIGZldGNoaW5nLCBpdCBrZWVwcyBkaXNwbGF5aW5nIHRoZSBwcmV2aW91c2x5IGZldGNoZWQgZGF0YSB1bnRpbCB0aGUgbmV3IGRhdGEgYXJyaXZlcy5cbiogQHBhcmFtIHByZXZpb3VzRGF0YSAtIFRoZSBkYXRhIG9mIHRoZSBwcmV2aW91cyBxdWVyeSBrZXksIHBhc3NlZCBieSB0aGUgb2JzZXJ2ZXIuXG4qIEByZXR1cm5zIFRoZSBwcmV2aW91cyBkYXRhLCB1bmNoYW5nZWQuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIG5ldyBRdWVyeU9ic2VydmVyKHF1ZXJ5Q2xpZW50LCB7XG4qICAgcXVlcnlLZXk6IFsncG9zdHMnLCBwYWdlXSxcbiogICBxdWVyeUZuOiAoKSA9PiBmZXRjaFBvc3RzKHBhZ2UpLFxuKiAgIHBsYWNlaG9sZGVyRGF0YToga2VlcFByZXZpb3VzRGF0YSxcbiogfSlcbiogYGBgXG4qL1xuZnVuY3Rpb24ga2VlcFByZXZpb3VzRGF0YShwcmV2aW91c0RhdGEpIHtcblx0cmV0dXJuIHByZXZpb3VzRGF0YTtcbn1cbi8qKlxuKiBBZGRzIGFuIGl0ZW0gdG8gb25lIGVuZCBvZiBhIG5ldyBhcnJheS4gSWYgdGhlIHJlc3VsdCBleGNlZWRzIGBtYXhgLCByZW1vdmVzXG4qIGV4Y2VzcyBpdGVtcyBmcm9tIHRoZSBvcHBvc2l0ZSBlbmQuXG4qIEBwYXJhbSBpdGVtcyAtIFRoZSBjdXJyZW50IGl0ZW1zLlxuKiBAcGFyYW0gaXRlbSAtIFRoZSB2YWx1ZSB0byBhZGQuXG4qIEBwYXJhbSBtYXggLSBUaGUgbWF4aW11bSBudW1iZXIgb2YgaXRlbXMgdG8ga2VlcC4gT21pdCBpdCBvciB1c2UgYDBgIGZvciBubyBsaW1pdC5cbiogQHBhcmFtIHByZXBlbmQgLSBQYXNzIGB0cnVlYCB0byBhZGQgYXQgdGhlIHN0YXJ0LiBUaGUgZGVmYXVsdCBpcyB0byBhZGQgYXQgdGhlIGVuZC5cbiogQHJldHVybnMgQSBuZXcgYXJyYXkgd2l0aCBgaXRlbWAgYWRkZWQuXG4qL1xuZnVuY3Rpb24gYWRkVG9BcnJheShpdGVtcywgaXRlbSwgbWF4LCBwcmVwZW5kKSB7XG5cdGNvbnN0IG5ld0l0ZW1zID0gcHJlcGVuZCA/IFtpdGVtLCAuLi5pdGVtc10gOiBbLi4uaXRlbXMsIGl0ZW1dO1xuXHRpZiAobWF4ICYmIG5ld0l0ZW1zLmxlbmd0aCA+IG1heCkgcmV0dXJuIHByZXBlbmQgPyBuZXdJdGVtcy5zbGljZSgwLCBtYXgpIDogbmV3SXRlbXMuc2xpY2UoLW1heCk7XG5cdHJldHVybiBuZXdJdGVtcztcbn1cbi8qKlxuKiBTZW50aW5lbCB2YWx1ZSB0aGF0IGNhbiBiZSBwYXNzZWQgYXMgYSBxdWVyeSdzIGBxdWVyeUZuYCB0byBjb25kaXRpb25hbGx5IGRpc2FibGUgdGhlIHF1ZXJ5IChlcXVpdmFsZW50XG4qIHRvIGBlbmFibGVkOiBmYWxzZWApIHdoaWxlIHByZXNlcnZpbmcgZnVsbCB0eXBlIGluZmVyZW5jZSBmb3IgdGhlIHF1ZXJ5J3MgZGF0YS4gVW5saWtlIGBlbmFibGVkOiBmYWxzZWAsXG4qIGEgcXVlcnkgZGlzYWJsZWQgdmlhIGBza2lwVG9rZW5gIGNhbm5vdCBiZSB0cmlnZ2VyZWQgd2l0aCBgcmVmZXRjaGAuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIG5ldyBRdWVyeU9ic2VydmVyKHF1ZXJ5Q2xpZW50LCB7XG4qICAgcXVlcnlLZXk6IFsncG9zdCcsIHBvc3RJZF0sXG4qICAgcXVlcnlGbjogcG9zdElkICE9IG51bGwgPyAoKSA9PiBmZXRjaFBvc3QocG9zdElkKSA6IHNraXBUb2tlbixcbiogfSlcbiogYGBgXG4qL1xuY29uc3Qgc2tpcFRva2VuID0gU3ltYm9sKCk7XG4vKipcbiogUmV0dXJucyB0aGUgZnVuY3Rpb24gdG8gY2FsbCBmb3IgYSBmZXRjaC4gSWYgdGhlcmUgaXMgbm8gYHF1ZXJ5Rm5gIGJ1dCB0aGUgZmV0Y2ggd2FzIHN0YXJ0ZWQgZnJvbVxuKiBhbiBgaW5pdGlhbFByb21pc2VgLCB0aGF0IHByb21pc2UgaXMgcmV0dXJuZWQgaW5zdGVhZC4gSWYgdGhlcmUgaXMgbm8gdXNhYmxlIGBxdWVyeUZuYCAobWlzc2luZyBvclxuKiB7QGxpbmsgc2tpcFRva2VufSksIHRoZSByZXR1cm5lZCBmdW5jdGlvbiByZWplY3RzIHdpdGggYSBgTWlzc2luZyBxdWVyeUZuYCBlcnJvci5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucyB3aXRoIHRoZSBgcXVlcnlGbmAsIGFuZCB0aGUgYHF1ZXJ5SGFzaGAgdXNlZCBpbiBlcnJvciBtZXNzYWdlcy5cbiogQHBhcmFtIGZldGNoT3B0aW9ucyAtIFRoZSBmZXRjaCBvcHRpb25zLCB3aGljaCBtYXkgY2FycnkgYW4gYGluaXRpYWxQcm9taXNlYC5cbiogQHJldHVybnMgVGhlIGZ1bmN0aW9uIHRvIGNhbGwgZm9yIHRoZSBmZXRjaC5cbiovXG5mdW5jdGlvbiBlbnN1cmVRdWVyeUZuKG9wdGlvbnMsIGZldGNoT3B0aW9ucykge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0aWYgKG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSBjb25zb2xlLmVycm9yKGBBdHRlbXB0ZWQgdG8gaW52b2tlIHF1ZXJ5Rm4gd2hlbiBzZXQgdG8gc2tpcFRva2VuLiBUaGlzIGlzIGxpa2VseSBhIGNvbmZpZ3VyYXRpb24gZXJyb3IuIFF1ZXJ5IGhhc2g6ICcke29wdGlvbnMucXVlcnlIYXNofSdgKTtcblx0fVxuXHRpZiAoIW9wdGlvbnMucXVlcnlGbiAmJiBmZXRjaE9wdGlvbnM/LmluaXRpYWxQcm9taXNlKSByZXR1cm4gKCkgPT4gZmV0Y2hPcHRpb25zLmluaXRpYWxQcm9taXNlO1xuXHRpZiAoIW9wdGlvbnMucXVlcnlGbiB8fCBvcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikgcmV0dXJuICgpID0+IFByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoYE1pc3NpbmcgcXVlcnlGbjogJyR7b3B0aW9ucy5xdWVyeUhhc2h9J2ApKTtcblx0cmV0dXJuIG9wdGlvbnMucXVlcnlGbjtcbn1cbi8qKlxuKiBSZXNvbHZlcyBhIGB0aHJvd09uRXJyb3JgIG9wdGlvbiB0byBhIGJvb2xlYW4uXG4qIElmIGB0aHJvd09uRXJyb3JgIGlzIGEgZnVuY3Rpb24sIGl0IGlzIGNhbGxlZCB3aXRoIGBwYXJhbXNgIChlLmcuIHRoZSBlcnJvciBhbmQsIGRlcGVuZGluZyBvbiB0aGUgY2FsbGVyLFxuKiBhZGRpdGlvbmFsIGNvbnRleHQgc3VjaCBhcyB0aGUgcXVlcnkgb3IgbXV0YXRpb24pIGFuZCBpdHMgcmVzdWx0IGlzIHJldHVybmVkLCBhbGxvd2luZyB0aGUgdGhyb3dpbmdcbiogYmVoYXZpb3IgdG8gYmUgZGVjaWRlZCBwZXIgZXJyb3IuIE90aGVyd2lzZSwgYHRocm93T25FcnJvcmAgaXRzZWxmIGlzIGNvZXJjZWQgdG8gYSBib29sZWFuIChgdW5kZWZpbmVkYFxuKiByZXNvbHZlcyB0byBgZmFsc2VgKS5cbiogQHBhcmFtIHRocm93T25FcnJvciAtIFRoZSBgdGhyb3dPbkVycm9yYCBvcHRpb246IGEgYm9vbGVhbiwgYSBmdW5jdGlvbiB0aGF0IGRlY2lkZXMgcGVyIGVycm9yLCBvclxuKiBgdW5kZWZpbmVkYC5cbiogQHBhcmFtIHBhcmFtcyAtIFRoZSBhcmd1bWVudHMgcGFzc2VkIHRvIGB0aHJvd09uRXJyb3JgIGlmIGl0IGlzIGEgZnVuY3Rpb24uXG4qIEByZXR1cm5zIFdoZXRoZXIgdGhlIGVycm9yIHNob3VsZCBiZSB0aHJvd24uXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHRocm93T25FcnJvciA9XG4qICAgcXVlcnkuc3RhdGUuZXJyb3IgJiYgdHlwZW9mIG9wdGlvbnMudGhyb3dPbkVycm9yID09PSAnZnVuY3Rpb24nXG4qICAgICA/IHNob3VsZFRocm93RXJyb3Iob3B0aW9ucy50aHJvd09uRXJyb3IsIFtxdWVyeS5zdGF0ZS5lcnJvciwgcXVlcnldKVxuKiAgICAgOiBvcHRpb25zLnRocm93T25FcnJvclxuKiBgYGBcbiovXG5mdW5jdGlvbiBzaG91bGRUaHJvd0Vycm9yKHRocm93T25FcnJvciwgcGFyYW1zKSB7XG5cdGlmICh0eXBlb2YgdGhyb3dPbkVycm9yID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiB0aHJvd09uRXJyb3IoLi4ucGFyYW1zKTtcblx0cmV0dXJuICEhdGhyb3dPbkVycm9yO1xufVxuY29uc3QgZmV0Y2hTaWduYWwgPSBTeW1ib2woKTtcbi8qKlxuKiBBZGRzIGEgbGF6eSBgc2lnbmFsYCBnZXR0ZXIgdG8gYW4gb2JqZWN0LCBzdWNoIGFzIGEgcXVlcnkgZnVuY3Rpb24gY29udGV4dC4gVGhlIGZpcnN0IHRpbWVcbiogYHNpZ25hbGAgaXMgcmVhZCwgYG9uQ2FuY2VsbGVkYCBpcyByZWdpc3RlcmVkIGZvciB0aGUgc2lnbmFsJ3MgYGFib3J0YCBldmVudCAob3IgY2FsbGVkIHJpZ2h0XG4qIGF3YXkgaWYgaXQgaXMgYWxyZWFkeSBhYm9ydGVkKSwgc28gY2FuY2VsbGF0aW9uIGlzIG9ubHkgdHJhY2tlZCB3aGVuIHRoZSBzaWduYWwgaXMgYWN0dWFsbHkgdXNlZC5cbiogQHBhcmFtIG9iamVjdCAtIFRoZSBvYmplY3QgdG8gYWRkIHRoZSBgc2lnbmFsYCBwcm9wZXJ0eSB0by5cbiogQHBhcmFtIGdldFNpZ25hbCAtIFJldHVybnMgdGhlIGBBYm9ydFNpZ25hbGAuIENhbGxlZCBvbmNlLCB3aGVuIGBzaWduYWxgIGlzIGZpcnN0IHJlYWQuXG4qIEBwYXJhbSBvbkNhbmNlbGxlZCAtIENhbGxlZCB3aGVuIHRoZSBzaWduYWwgaXMgYWJvcnRlZCwgaWYgYHNpZ25hbGAgd2FzIHJlYWQuXG4qIEBwYXJhbSBpbnRlcm5hbFNpZ25hbCAtIFRoZSBmZXRjaCBzaWduYWwgdG8gZm9yd2FyZCB3aXRob3V0IGNvbnN1bWluZyB0aGUgZ2V0dGVyLlxuKiBAcmV0dXJucyBUaGUgc2FtZSBvYmplY3QsIHdpdGggdGhlIGBzaWduYWxgIHByb3BlcnR5IGFkZGVkLlxuKi9cbmZ1bmN0aW9uIGFkZENvbnN1bWVBd2FyZVNpZ25hbChvYmplY3QsIGdldFNpZ25hbCwgb25DYW5jZWxsZWQsIGludGVybmFsU2lnbmFsKSB7XG5cdGxldCBjb25zdW1lZCA9IGZhbHNlO1xuXHRsZXQgc2lnbmFsO1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydGllcyhvYmplY3QsIHtcblx0XHRbZmV0Y2hTaWduYWxdOiB7IHZhbHVlOiBpbnRlcm5hbFNpZ25hbCB9LFxuXHRcdHNpZ25hbDoge1xuXHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdGdldDogKCkgPT4ge1xuXHRcdFx0XHRzaWduYWwgPz89IGdldFNpZ25hbCgpO1xuXHRcdFx0XHRpZiAoY29uc3VtZWQpIHJldHVybiBzaWduYWw7XG5cdFx0XHRcdGNvbnN1bWVkID0gdHJ1ZTtcblx0XHRcdFx0aWYgKHNpZ25hbC5hYm9ydGVkKSBvbkNhbmNlbGxlZCgpO1xuXHRcdFx0XHRlbHNlIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25DYW5jZWxsZWQsIHsgb25jZTogdHJ1ZSB9KTtcblx0XHRcdFx0cmV0dXJuIHNpZ25hbDtcblx0XHRcdH1cblx0XHR9XG5cdH0pO1xuXHRyZXR1cm4gb2JqZWN0O1xufVxuZXhwb3J0IHsgYWRkQ29uc3VtZUF3YXJlU2lnbmFsLCBhZGRUb0FycmF5LCBlbnN1cmVRdWVyeUZuLCBmZXRjaFNpZ25hbCwgZnVuY3Rpb25hbFVwZGF0ZSwgaGFzaEtleSwgaGFzaFF1ZXJ5S2V5QnlPcHRpb25zLCBpc1BsYWluQXJyYXksIGlzUGxhaW5PYmplY3QsIGlzU2VydmVyLCBpc1ZhbGlkVGltZW91dCwga2VlcFByZXZpb3VzRGF0YSwgbWF0Y2hNdXRhdGlvbiwgbWF0Y2hRdWVyeSwgbm9vcCwgcGFydGlhbE1hdGNoS2V5LCByZXBsYWNlRGF0YSwgcmVwbGFjZUVxdWFsRGVlcCwgcmVzb2x2ZVF1ZXJ5VmFsdWUsIHNoYWxsb3dFcXVhbE9iamVjdHMsIHNob3VsZFRocm93RXJyb3IsIHNraXBUb2tlbiwgc2xlZXAsIHRpbWVVbnRpbFN0YWxlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXV0aWxzLmpzLm1hcCIsImltcG9ydCB7IGlzU2VydmVyIGFzIGlzU2VydmVyJDEgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuLy8gc3JjL2Vudmlyb25tZW50TWFuYWdlci50c1xubGV0IGlzU2VydmVyRm4gPSAoKSA9PiBpc1NlcnZlciQxO1xuLyoqXG4qIFJldHVybnMgd2hldGhlciB0aGUgY3VycmVudCBydW50aW1lIHNob3VsZCBiZSB0cmVhdGVkIGFzIGEgc2VydmVyIGVudmlyb25tZW50LlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHJ1bnRpbWUgaXMgdHJlYXRlZCBhcyBhIHNlcnZlci5cbiovXG5jb25zdCBpc1NlcnZlciA9ICgpID0+IGlzU2VydmVyRm4oKTtcbi8qKlxuKiBNYW5hZ2VzIGhvdyBUYW5TdGFjayBRdWVyeSBkZXRlY3RzIHdoZXRoZXIgdGhlIGN1cnJlbnQgcnVudGltZSBzaG91bGQgYmUgdHJlYXRlZCBhc1xuKiBzZXJ2ZXItc2lkZSwgd2hpY2ggZGlzYWJsZXMgc2NoZWR1bGluZyByZWZldGNoIHRpbWVycyBhbmQgY2hhbmdlcyB0aGUgZGVmYXVsdCBgcmV0cnlgIGNvdW50XG4qIGFuZCBgZ2NUaW1lYC4gQnkgZGVmYXVsdCwgdGhlIGRldGVjdGlvbiB0cmVhdHMgYSBtaXNzaW5nIGB3aW5kb3dgIChvciB0aGUgcHJlc2VuY2Ugb2YgYVxuKiBgRGVub2AgZ2xvYmFsKSBhcyBzZXJ2ZXIuXG4qXG4qIE92ZXJyaWRlIHRoaXMgZm9yIHJ1bnRpbWVzIHdoZXJlIHRoYXQgZGVmYXVsdCBkZXRlY3Rpb24gd291bGQgZ2l2ZSB0aGUgd3JvbmcgYW5zd2VyIOKAlCBmb3JcbiogZXhhbXBsZSwgYSBTZXJ2aWNlIFdvcmtlciwgd2hlcmUgYHdpbmRvd2AgaXMgdW5kZWZpbmVkIGV2ZW4gdGhvdWdoIHRoZSBlbnZpcm9ubWVudCBzaG91bGRcbiogYmVoYXZlIGxpa2UgYSBjbGllbnQuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGltcG9ydCB7IGVudmlyb25tZW50TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuKlxuKiBlbnZpcm9ubWVudE1hbmFnZXIuc2V0SXNTZXJ2ZXIoKCkgPT4gZmFsc2UpXG4qIGBgYFxuKi9cbmNvbnN0IGVudmlyb25tZW50TWFuYWdlciA9IHtcblx0aXNTZXJ2ZXIsXG5cdC8qKlxuXHQqIE92ZXJyaWRlcyB0aGUgc2VydmVyIGNoZWNrIGdsb2JhbGx5LlxuXHQqIEBwYXJhbSBpc1NlcnZlclZhbHVlIC0gQSBmdW5jdGlvbiB0aGF0IHJldHVybnMgd2hldGhlciB0aGUgcnVudGltZSBzaG91bGQgYmUgdHJlYXRlZCBhcyBhXG5cdCogc2VydmVyLlxuXHQqL1xuXHRzZXRJc1NlcnZlcihpc1NlcnZlclZhbHVlKSB7XG5cdFx0aXNTZXJ2ZXJGbiA9IGlzU2VydmVyVmFsdWU7XG5cdH1cbn07XG5leHBvcnQgeyBlbnZpcm9ubWVudE1hbmFnZXIsIGlzU2VydmVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVudmlyb25tZW50TWFuYWdlci5qcy5tYXAiLCJpbXBvcnQgeyBub29wIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vIHNyYy9oeWRyYXRpb24udHNcbi8qKlxuKiBSZWFkcyB0aGUgdmFsdWUgb2YgYSBwcm9taXNlIHN5bmNocm9ub3VzbHkgaWYgaXQgaGFzIGFscmVhZHkgcmVzb2x2ZWQsIGUuZy4gYSB0aGVuYWJsZSB0aGF0XG4qIHJlc29sdmVzIHdpdGhpbiBpdHMgYHRoZW5gIGNhbGwuXG4qIEBwYXJhbSBwcm9taXNlIC0gVGhlIHByb21pc2UgdG8gcmVhZC5cbiogQHJldHVybnMgQW4gb2JqZWN0IHdpdGggdGhlIHJlc29sdmVkIGBkYXRhYCwgb3IgYHVuZGVmaW5lZGAgaWYgdGhlIHByb21pc2UgaGFzbid0IHJlc29sdmVkXG4qIHN5bmNocm9ub3VzbHkgKG9yIHJlc29sdmVkIHdpdGggYHVuZGVmaW5lZGApLlxuKi9cbmZ1bmN0aW9uIHRyeVJlc29sdmVTeW5jKHByb21pc2UpIHtcblx0bGV0IGRhdGE7XG5cdHByb21pc2UudGhlbigocmVzdWx0KSA9PiB7XG5cdFx0ZGF0YSA9IHJlc3VsdDtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9LCBub29wKT8uY2F0Y2g/Lihub29wKTtcblx0aWYgKGRhdGEgIT09IHZvaWQgMCkgcmV0dXJuIHsgZGF0YSB9O1xufVxuLyoqXG4qIERlaHlkcmF0ZXMgYSBzaW5nbGUgYE11dGF0aW9uYCBpbnRvIGEgc2VyaWFsaXphYmxlIHNuYXBzaG90IG9mIGl0cyBrZXksIHN0YXRlLCBzY29wZSwgYW5kIG1ldGEuXG4qIEBwYXJhbSBtdXRhdGlvbiAtIFRoZSBtdXRhdGlvbiB0byBkZWh5ZHJhdGUuXG4qIEByZXR1cm5zIFRoZSBkZWh5ZHJhdGVkIG11dGF0aW9uLlxuKi9cbmZ1bmN0aW9uIGRlaHlkcmF0ZU11dGF0aW9uKG11dGF0aW9uKSB7XG5cdHJldHVybiB7XG5cdFx0bXV0YXRpb25LZXk6IG11dGF0aW9uLm9wdGlvbnMubXV0YXRpb25LZXksXG5cdFx0c3RhdGU6IG11dGF0aW9uLnN0YXRlLFxuXHRcdC4uLm11dGF0aW9uLm9wdGlvbnMuc2NvcGUgJiYgeyBzY29wZTogbXV0YXRpb24ub3B0aW9ucy5zY29wZSB9LFxuXHRcdC4uLm11dGF0aW9uLm1ldGEgJiYgeyBtZXRhOiBtdXRhdGlvbi5tZXRhIH1cblx0fTtcbn1cbi8qKlxuKiBQcmVwYXJlcyB0aGUgaW4tZmxpZ2h0IHByb21pc2Ugb2YgYSBwZW5kaW5nIHF1ZXJ5IGZvciBkZWh5ZHJhdGlvbjogYXBwbGllcyBgc2VyaWFsaXplRGF0YWAgdG8gaXRzXG4qIHJlc3VsdCwgYW5kIHJlZGFjdHMgaXRzIHJlamVjdGlvbiBlcnJvciB1bmxlc3MgYHNob3VsZFJlZGFjdEVycm9yc2AgcmV0dXJucyBgZmFsc2VgIGZvciBpdC5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHBlbmRpbmcgcXVlcnkgd2hvc2UgcHJvbWlzZSBpcyBkZWh5ZHJhdGVkLlxuKiBAcGFyYW0gc2VyaWFsaXplRGF0YSAtIE9wdGlvbmFsIHRyYW5zZm9ybSBhcHBsaWVkIHRvIHRoZSByZXNvbHZlZCBkYXRhLlxuKiBAcGFyYW0gc2hvdWxkUmVkYWN0RXJyb3JzIC0gT3B0aW9uYWwgcHJlZGljYXRlOyBpZiBpdCByZXR1cm5zIGBmYWxzZWAgZm9yIHRoZSByZWplY3Rpb24gZXJyb3IsXG4qIHRoYXRcbiogZXJyb3IgaXMga2VwdCBhcy1pcyBpbnN0ZWFkIG9mIGJlaW5nIHJlZGFjdGVkLlxuKiBAcmV0dXJucyBUaGUgdHJhbnNmb3JtZWQgcHJvbWlzZSwgb3IgYHVuZGVmaW5lZGAgaWYgdGhlIHF1ZXJ5IGhhcyBubyBpbi1mbGlnaHQgcHJvbWlzZS5cbiovXG5mdW5jdGlvbiBkZWh5ZHJhdGVQcm9taXNlKHF1ZXJ5LCBzZXJpYWxpemVEYXRhLCBzaG91bGRSZWRhY3RFcnJvcnMpIHtcblx0Y29uc3QgcHJvbWlzZSA9IHF1ZXJ5LnByb21pc2U/LnRoZW4oc2VyaWFsaXplRGF0YSkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0aWYgKHNob3VsZFJlZGFjdEVycm9ycz8uKGVycm9yKSA9PT0gZmFsc2UpIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY29uc29sZS5lcnJvcihgQSBxdWVyeSB0aGF0IHdhcyBkZWh5ZHJhdGVkIGFzIHBlbmRpbmcgZW5kZWQgdXAgcmVqZWN0aW5nLiBbJHtxdWVyeS5xdWVyeUhhc2h9XTogJHtlcnJvcn07IFRoZSBlcnJvciB3aWxsIGJlIHJlZGFjdGVkIGluIHByb2R1Y3Rpb24gYnVpbGRzYCk7XG5cdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJyZWRhY3RlZFwiKSk7XG5cdH0pO1xuXHRwcm9taXNlPy5jYXRjaChub29wKTtcblx0cmV0dXJuIHByb21pc2U7XG59XG4vKipcbiogRGVoeWRyYXRlcyBhIHNpbmdsZSBgUXVlcnlgIGludG8gYSBzZXJpYWxpemFibGUgYERlaHlkcmF0ZWRRdWVyeWAgc25hcHNob3QuIE5vdGUgdGhhdCBtb3N0IHF1ZXJ5IGNvbmZpZyAoZS5nLlxuKiBgcXVlcnlGbmAsIGBzdGFsZVRpbWVgKSBpcyBub3QgZGVoeWRyYXRlZCBidXQgaW5zdGVhZCBtZWFudCB0byBiZSBjb25maWd1cmVkIGFnYWluIHdoZW4gY29uc3VtaW5nIHRoZVxuKiBkZS9yZWh5ZHJhdGVkIGRhdGEsIHR5cGljYWxseSB3aXRoIGB1c2VRdWVyeWAgb24gdGhlIGNsaWVudC4gSWYgdGhlIHF1ZXJ5IGlzIHN0aWxsIGBwZW5kaW5nYCwgaXRzIGluLWZsaWdodFxuKiBwcm9taXNlIGlzIGRlaHlkcmF0ZWQgdG9vIHNvIGl0IGNhbiBiZSByZXN1bWVkIG9uIHRoZSBvdGhlciBzaWRlIGluc3RlYWQgb2YgcmUtZmV0Y2hlZC5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGRlaHlkcmF0ZS5cbiogQHBhcmFtIHNlcmlhbGl6ZURhdGEgLSBPcHRpb25hbCB0cmFuc2Zvcm0gYXBwbGllZCB0byBgcXVlcnkuc3RhdGUuZGF0YWAgYmVmb3JlIGl0IGlzIGluY2x1ZGVkIGluIHRoZSBzbmFwc2hvdC5cbiogQHBhcmFtIHNob3VsZFJlZGFjdEVycm9ycyAtIE9wdGlvbmFsIHByZWRpY2F0ZTsgaWYgaXQgcmV0dXJucyBgZmFsc2VgIGZvciB0aGUgcHJvbWlzZSdzIHJlamVjdGlvbiBlcnJvciwgdGhhdFxuKiBlcnJvciBpcyBrZXB0IGFzLWlzIGluc3RlYWQgb2YgYmVpbmcgcmVkYWN0ZWQuXG4qIEByZXR1cm5zIFRoZSBkZWh5ZHJhdGVkIHF1ZXJ5LlxuKi9cbmZ1bmN0aW9uIGRlaHlkcmF0ZVF1ZXJ5KHF1ZXJ5LCBzZXJpYWxpemVEYXRhLCBzaG91bGRSZWRhY3RFcnJvcnMpIHtcblx0cmV0dXJuIHtcblx0XHRkZWh5ZHJhdGVkQXQ6IERhdGUubm93KCksXG5cdFx0c3RhdGU6IHtcblx0XHRcdC4uLnF1ZXJ5LnN0YXRlLFxuXHRcdFx0Li4ucXVlcnkuc3RhdGUuZGF0YSAhPT0gdm9pZCAwICYmIHsgZGF0YTogc2VyaWFsaXplRGF0YSA/IHNlcmlhbGl6ZURhdGEocXVlcnkuc3RhdGUuZGF0YSkgOiBxdWVyeS5zdGF0ZS5kYXRhIH1cblx0XHR9LFxuXHRcdHF1ZXJ5S2V5OiBxdWVyeS5xdWVyeUtleSxcblx0XHRxdWVyeUhhc2g6IHF1ZXJ5LnF1ZXJ5SGFzaCxcblx0XHQuLi5xdWVyeS5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIHsgcHJvbWlzZTogZGVoeWRyYXRlUHJvbWlzZShxdWVyeSwgc2VyaWFsaXplRGF0YSwgc2hvdWxkUmVkYWN0RXJyb3JzKSB9LFxuXHRcdC4uLnF1ZXJ5Lm1ldGEgJiYgeyBtZXRhOiBxdWVyeS5tZXRhIH0sXG5cdFx0Li4ucXVlcnkucXVlcnlUeXBlICYmIHsgcXVlcnlUeXBlOiBxdWVyeS5xdWVyeVR5cGUgfVxuXHR9O1xufVxuLyoqXG4qIFRoZSBkZWZhdWx0IGBzaG91bGREZWh5ZHJhdGVNdXRhdGlvbmAgcHJlZGljYXRlIHVzZWQgYnkgYGRlaHlkcmF0ZWAuIE9ubHkgZGVoeWRyYXRlcyBtdXRhdGlvbnMgdGhhdCBhcmVcbiogY3VycmVudGx5IHBhdXNlZCAoZS5nLiBwYXVzZWQgYnkgYG5ldHdvcmtNb2RlYCB3aGlsZSBvZmZsaW5lKS5cbiogQHBhcmFtIG11dGF0aW9uIC0gVGhlIG11dGF0aW9uIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG11dGF0aW9uIGlzIHBhdXNlZC5cbiovXG5mdW5jdGlvbiBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlTXV0YXRpb24obXV0YXRpb24pIHtcblx0cmV0dXJuIG11dGF0aW9uLnN0YXRlLmlzUGF1c2VkO1xufVxuLyoqXG4qIFRoZSBkZWZhdWx0IGBzaG91bGREZWh5ZHJhdGVRdWVyeWAgcHJlZGljYXRlIHVzZWQgYnkgYGRlaHlkcmF0ZWAuIE9ubHkgZGVoeWRyYXRlcyBxdWVyaWVzIHdob3NlIHN0YXR1cyBpc1xuKiBgJ3N1Y2Nlc3MnYC5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5J3Mgc3RhdHVzIGlzIGAnc3VjY2VzcydgLlxuKi9cbmZ1bmN0aW9uIGRlZmF1bHRTaG91bGREZWh5ZHJhdGVRdWVyeShxdWVyeSkge1xuXHRyZXR1cm4gcXVlcnkuc3RhdGUuc3RhdHVzID09PSBcInN1Y2Nlc3NcIjtcbn1cbi8qKlxuKiBEZWh5ZHJhdGVzIGEgYFF1ZXJ5Q2xpZW50YCdzIGNhY2hlIChxdWVyaWVzIGFuZCBtdXRhdGlvbnMpIGludG8gYSBwbGFpbiwgc2VyaWFsaXphYmxlIGBEZWh5ZHJhdGVkU3RhdGVgLFxuKiB0eXBpY2FsbHkgdG8gZW1iZWQgaW4gc2VydmVyLXJlbmRlcmVkIG1hcmt1cCBhbmQgbGF0ZXIgcmVzdG9yZSBpbnRvIGEgY2xpZW50LXNpZGUgYFF1ZXJ5Q2xpZW50YCB2aWEgYGh5ZHJhdGVgLlxuKiBXaGljaCBxdWVyaWVzL211dGF0aW9ucyBhcmUgaW5jbHVkZWQsIGFuZCBob3cgdGhlaXIgZGF0YS9lcnJvcnMgYXJlIHRyYW5zZm9ybWVkLCBpcyBjb250cm9sbGVkIGJ5IGBvcHRpb25zYCxcbiogZmFsbGluZyBiYWNrIHRvIHRoZSBjbGllbnQncyBgZGVoeWRyYXRlYCBkZWZhdWx0IG9wdGlvbnMsIGFuZCBmaW5hbGx5IHRvIGBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnlgIC9cbiogYGRlZmF1bHRTaG91bGREZWh5ZHJhdGVNdXRhdGlvbmAuXG4qIEBwYXJhbSBjbGllbnQgLSBUaGUgY2xpZW50IHdob3NlIGNhY2hlIGlzIGRlaHlkcmF0ZWQuXG4qIEBwYXJhbSBvcHRpb25zIC0gQ29udHJvbHMgd2hpY2ggcXVlcmllcyBhbmQgbXV0YXRpb25zIGFyZSBpbmNsdWRlZCBhbmQgaG93IHRoZWlyIGRhdGEgYW5kIGVycm9yc1xuKiBhcmUgdHJhbnNmb3JtZWQuIEVhY2ggb3B0aW9uIGZhbGxzIGJhY2sgdG8gdGhlIGNsaWVudCdzIGBkZWZhdWx0T3B0aW9ucy5kZWh5ZHJhdGVgLlxuKiBAcmV0dXJucyBUaGUgZGVoeWRyYXRlZCBzdGF0ZSwgd2l0aCB0aGUgaW5jbHVkZWQgYHF1ZXJpZXNgIGFuZCBgbXV0YXRpb25zYC5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuKlxuKiBhd2FpdCBxdWVyeUNsaWVudC5wcmVmZXRjaFF1ZXJ5KHtcbiogICBxdWVyeUtleTogWydwb3N0cyddLFxuKiAgIHF1ZXJ5Rm46IGdldFBvc3RzLFxuKiB9KVxuKlxuKiBjb25zdCBkZWh5ZHJhdGVkU3RhdGUgPSBkZWh5ZHJhdGUocXVlcnlDbGllbnQpXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGRlaHlkcmF0ZShjbGllbnQsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCBmaWx0ZXJNdXRhdGlvbiA9IG9wdGlvbnMuc2hvdWxkRGVoeWRyYXRlTXV0YXRpb24gPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuZGVoeWRyYXRlPy5zaG91bGREZWh5ZHJhdGVNdXRhdGlvbiA/PyBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlTXV0YXRpb247XG5cdGNvbnN0IG11dGF0aW9ucyA9IGNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKCkuZ2V0QWxsKCkuZmxhdE1hcCgobXV0YXRpb24pID0+IGZpbHRlck11dGF0aW9uKG11dGF0aW9uKSA/IFtkZWh5ZHJhdGVNdXRhdGlvbihtdXRhdGlvbildIDogW10pO1xuXHRjb25zdCBmaWx0ZXJRdWVyeSA9IG9wdGlvbnMuc2hvdWxkRGVoeWRyYXRlUXVlcnkgPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuZGVoeWRyYXRlPy5zaG91bGREZWh5ZHJhdGVRdWVyeSA/PyBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnk7XG5cdGNvbnN0IHNob3VsZFJlZGFjdEVycm9ycyA9IG9wdGlvbnMuc2hvdWxkUmVkYWN0RXJyb3JzID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmRlaHlkcmF0ZT8uc2hvdWxkUmVkYWN0RXJyb3JzO1xuXHRjb25zdCBzZXJpYWxpemVEYXRhID0gb3B0aW9ucy5zZXJpYWxpemVEYXRhID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmRlaHlkcmF0ZT8uc2VyaWFsaXplRGF0YTtcblx0cmV0dXJuIHtcblx0XHRtdXRhdGlvbnMsXG5cdFx0cXVlcmllczogY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5nZXRBbGwoKS5mbGF0TWFwKChxdWVyeSkgPT4gZmlsdGVyUXVlcnkocXVlcnkpID8gW2RlaHlkcmF0ZVF1ZXJ5KHF1ZXJ5LCBzZXJpYWxpemVEYXRhLCBzaG91bGRSZWRhY3RFcnJvcnMpXSA6IFtdKVxuXHR9O1xufVxuLyoqXG4qIFJlc3RvcmVzIGEgYERlaHlkcmF0ZWRTdGF0ZWAgKGFzIHByb2R1Y2VkIGJ5IGBkZWh5ZHJhdGVgKSBpbnRvIGEgYFF1ZXJ5Q2xpZW50YCdzIGNhY2hlLCB0eXBpY2FsbHkgdG8gc2VlZCB0aGVcbiogY2xpZW50IHdpdGggZGF0YSBhbHJlYWR5IGZldGNoZWQgb24gdGhlIHNlcnZlci4gYG11dGF0aW9uc2AgYW5kIGBxdWVyaWVzYCBhcmUgZWFjaCBvcHRpb25hbCBvbiBgZGVoeWRyYXRlZFN0YXRlYC5cbiogUXVlcmllcyBub3QgeWV0IGluIHRoZSBjYWNoZSBhcmUgYnVpbHQgZnJvbSB0aGUgZGVoeWRyYXRlZCBzbmFwc2hvdDsgcXVlcmllcyB0aGF0IGFscmVhZHkgZXhpc3QgYXJlIG9ubHkgdXBkYXRlZFxuKiB3aGVuIHRoZSBkZWh5ZHJhdGVkIGRhdGEgaXMgbmV3ZXIgdGhhbiB3aGF0J3MgYWxyZWFkeSBjYWNoZWQuIE5ld2x5IGJ1aWx0IHF1ZXJpZXMgaGF2ZSB0aGVpciBgZmV0Y2hTdGF0dXNgIHJlc2V0XG4qIHRvIGAnaWRsZSdgIHNvIHRoZXkgZG9uJ3QgaHlkcmF0ZSBzdHVjayBpbiBhIGZldGNoaW5nIHN0YXRlLiBJZiBhIGRlaHlkcmF0ZWQgcXVlcnkgc3RpbGwgaGFkIGFuIGluLWZsaWdodFxuKiBwcm9taXNlLCBpdCBpcyByZXN1bWVkIHZpYSBgcXVlcnkuZmV0Y2goKWAgKHJldXNpbmcgdGhhdCBwcm9taXNlIGFzIGBpbml0aWFsUHJvbWlzZWApIHJhdGhlciB0aGFuIHJlLWludm9raW5nXG4qIGBxdWVyeUZuYC5cbiogQHBhcmFtIGNsaWVudCAtIFRoZSBjbGllbnQgd2hvc2UgY2FjaGUgaXMgcmVzdG9yZWQgaW50by5cbiogQHBhcmFtIGRlaHlkcmF0ZWRTdGF0ZSAtIFRoZSBkZWh5ZHJhdGVkIHN0YXRlLCBlLmcuIHByb2R1Y2VkIGJ5IGBkZWh5ZHJhdGVgIG9uIHRoZSBzZXJ2ZXIuXG4qIEBwYXJhbSBvcHRpb25zIC0gYGRlZmF1bHRPcHRpb25zYCBtZXJnZWQgaW50byBldmVyeSByZXN0b3JlZCBxdWVyeSBhbmQgbXV0YXRpb24gKG9uIHRvcCBvZiB0aGVcbiogY2xpZW50J3MgYGRlZmF1bHRPcHRpb25zLmh5ZHJhdGVgKSwgYW5kIGBkZXNlcmlhbGl6ZURhdGFgIHRvIHJldmVyc2UgYHNlcmlhbGl6ZURhdGFgLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiAvLyBkZWh5ZHJhdGVkU3RhdGUgd2FzIHByb2R1Y2VkIGJ5IGBkZWh5ZHJhdGVgIG9uIHRoZSBzZXJ2ZXJcbiogLy8gYW5kIHNlbnQgdG8gdGhlIGNsaWVudCwgZS5nLiBlbWJlZGRlZCBpbiBzZXJ2ZXItcmVuZGVyZWQgbWFya3VwLlxuKiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG4qXG4qIGh5ZHJhdGUocXVlcnlDbGllbnQsIGRlaHlkcmF0ZWRTdGF0ZSlcbiogYGBgXG4qL1xuZnVuY3Rpb24gaHlkcmF0ZShjbGllbnQsIGRlaHlkcmF0ZWRTdGF0ZSwgb3B0aW9ucykge1xuXHRjb25zdCBtdXRhdGlvbkNhY2hlID0gY2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKTtcblx0Y29uc3QgcXVlcnlDYWNoZSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCk7XG5cdGNvbnN0IGRlc2VyaWFsaXplRGF0YSA9IG9wdGlvbnM/LmRlZmF1bHRPcHRpb25zPy5kZXNlcmlhbGl6ZURhdGEgPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuaHlkcmF0ZT8uZGVzZXJpYWxpemVEYXRhO1xuXHRkZWh5ZHJhdGVkU3RhdGUubXV0YXRpb25zPy5mb3JFYWNoKCh7IHN0YXRlLCAuLi5tdXRhdGlvbk9wdGlvbnMgfSkgPT4ge1xuXHRcdG11dGF0aW9uQ2FjaGUuYnVpbGQoY2xpZW50LCB7XG5cdFx0XHQuLi5jbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5oeWRyYXRlPy5tdXRhdGlvbnMsXG5cdFx0XHQuLi5vcHRpb25zPy5kZWZhdWx0T3B0aW9ucz8ubXV0YXRpb25zLFxuXHRcdFx0Li4ubXV0YXRpb25PcHRpb25zXG5cdFx0fSwgc3RhdGUpO1xuXHR9KTtcblx0ZGVoeWRyYXRlZFN0YXRlLnF1ZXJpZXM/LmZvckVhY2goKHsgcXVlcnlLZXksIHN0YXRlLCBxdWVyeUhhc2gsIG1ldGEsIHByb21pc2UsIGRlaHlkcmF0ZWRBdCwgcXVlcnlUeXBlIH0pID0+IHtcblx0XHRjb25zdCBzeW5jRGF0YSA9IHByb21pc2UgPyB0cnlSZXNvbHZlU3luYyhwcm9taXNlKSA6IHZvaWQgMDtcblx0XHRjb25zdCByYXdEYXRhID0gc3RhdGUuZGF0YSA9PT0gdm9pZCAwID8gc3luY0RhdGE/LmRhdGEgOiBzdGF0ZS5kYXRhO1xuXHRcdGNvbnN0IGRhdGEgPSByYXdEYXRhID09PSB2b2lkIDAgPyByYXdEYXRhIDogZGVzZXJpYWxpemVEYXRhID8gZGVzZXJpYWxpemVEYXRhKHJhd0RhdGEpIDogcmF3RGF0YTtcblx0XHRsZXQgcXVlcnkgPSBxdWVyeUNhY2hlLmdldChxdWVyeUhhc2gpO1xuXHRcdGNvbnN0IGV4aXN0aW5nUXVlcnlJc1BlbmRpbmcgPSBxdWVyeT8uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIjtcblx0XHRjb25zdCBleGlzdGluZ1F1ZXJ5SXNGZXRjaGluZyA9IHF1ZXJ5Py5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJmZXRjaGluZ1wiO1xuXHRcdGlmIChxdWVyeSkge1xuXHRcdFx0Y29uc3QgaGFzTmV3ZXJTeW5jRGF0YSA9IHN5bmNEYXRhICYmIGRlaHlkcmF0ZWRBdCA+IHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQ7XG5cdFx0XHRpZiAoc3RhdGUuZGF0YVVwZGF0ZWRBdCA+IHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQgfHwgaGFzTmV3ZXJTeW5jRGF0YSkge1xuXHRcdFx0XHRjb25zdCB7IGZldGNoU3RhdHVzOiBfaWdub3JlZCwgLi4uc2VyaWFsaXplZFN0YXRlIH0gPSBzdGF0ZTtcblx0XHRcdFx0cXVlcnkuc2V0U3RhdGUoe1xuXHRcdFx0XHRcdC4uLnNlcmlhbGl6ZWRTdGF0ZSxcblx0XHRcdFx0XHRkYXRhLFxuXHRcdFx0XHRcdC4uLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgZGF0YSAhPT0gdm9pZCAwICYmIHtcblx0XHRcdFx0XHRcdHN0YXR1czogXCJzdWNjZXNzXCIsXG5cdFx0XHRcdFx0XHRkYXRhVXBkYXRlZEF0OiBkZWh5ZHJhdGVkQXQsXG5cdFx0XHRcdFx0XHQuLi4hZXhpc3RpbmdRdWVyeUlzRmV0Y2hpbmcgJiYgeyBmZXRjaFN0YXR1czogXCJpZGxlXCIgfVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIHF1ZXJ5ID0gcXVlcnlDYWNoZS5idWlsZChjbGllbnQsIHtcblx0XHRcdC4uLmNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmh5ZHJhdGU/LnF1ZXJpZXMsXG5cdFx0XHQuLi5vcHRpb25zPy5kZWZhdWx0T3B0aW9ucz8ucXVlcmllcyxcblx0XHRcdHF1ZXJ5S2V5LFxuXHRcdFx0cXVlcnlIYXNoLFxuXHRcdFx0bWV0YSxcblx0XHRcdF90eXBlOiBxdWVyeVR5cGVcblx0XHR9LCB7XG5cdFx0XHQuLi5zdGF0ZSxcblx0XHRcdGRhdGEsXG5cdFx0XHRmZXRjaFN0YXR1czogXCJpZGxlXCIsXG5cdFx0XHRzdGF0dXM6IHN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgZGF0YSAhPT0gdm9pZCAwID8gXCJzdWNjZXNzXCIgOiBzdGF0ZS5zdGF0dXMsXG5cdFx0XHQuLi5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIGRhdGEgIT09IHZvaWQgMCAmJiB7IGRhdGFVcGRhdGVkQXQ6IGRlaHlkcmF0ZWRBdCB9XG5cdFx0fSk7XG5cdFx0aWYgKHByb21pc2UgJiYgIXN5bmNEYXRhICYmICFleGlzdGluZ1F1ZXJ5SXNQZW5kaW5nICYmICFleGlzdGluZ1F1ZXJ5SXNGZXRjaGluZyAmJiBkZWh5ZHJhdGVkQXQgPiBxdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0KSBxdWVyeS5mZXRjaCh2b2lkIDAsIHsgaW5pdGlhbFByb21pc2U6IFByb21pc2UucmVzb2x2ZShwcm9taXNlKS50aGVuKGRlc2VyaWFsaXplRGF0YSkgfSkuY2F0Y2gobm9vcCk7XG5cdH0pO1xufVxuZXhwb3J0IHsgZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uLCBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnksIGRlaHlkcmF0ZSwgZGVoeWRyYXRlUXVlcnksIGh5ZHJhdGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aHlkcmF0aW9uLmpzLm1hcCIsImltcG9ydCB7IGFkZENvbnN1bWVBd2FyZVNpZ25hbCwgYWRkVG9BcnJheSwgZW5zdXJlUXVlcnlGbiwgZmV0Y2hTaWduYWwgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuLy8gc3JjL2luZmluaXRlUXVlcnlCZWhhdmlvci50c1xuLyoqXG4qIENyZWF0ZXMgdGhlIGJlaGF2aW9yIHRoYXQgZmV0Y2hlcyB0aGUgcGFnZXMgb2YgYW4gaW5maW5pdGUgcXVlcnk6IHRoZSBuZXh0IG9yIHByZXZpb3VzIHBhZ2UgZm9yXG4qIGBmZXRjaE5leHRQYWdlYC9gZmV0Y2hQcmV2aW91c1BhZ2VgLCBvciBhbGwgcGFnZXMgYWdhaW4gZnJvbSB0aGUgc3RhcnQgb24gYSByZWZldGNoLlxuKiBAcGFyYW0gcGFnZXMgLSBUaGUgbnVtYmVyIG9mIHBhZ2VzIHRvIGZldGNoIGZyb20gdGhlIHN0YXJ0IHdoZW4gYWxsIHBhZ2VzIGFyZSBmZXRjaGVkIGFnYWluLFxuKiBlLmcuIGZyb20gdGhlIGBwYWdlc2Agb3B0aW9uIG9mIGBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5YC4gRGVmYXVsdHMgdG8gdGhlIG51bWJlciBvZiBjYWNoZWRcbiogcGFnZXMuXG4qIEByZXR1cm5zIFRoZSBxdWVyeSBiZWhhdmlvciB0byBzZXQgb24gYW4gaW5maW5pdGUgcXVlcnkuXG4qL1xuZnVuY3Rpb24gaW5maW5pdGVRdWVyeUJlaGF2aW9yKHBhZ2VzKSB7XG5cdHJldHVybiB7IG9uRmV0Y2g6IChjb250ZXh0LCBxdWVyeSkgPT4ge1xuXHRcdGNvbnN0IG9wdGlvbnMgPSBjb250ZXh0Lm9wdGlvbnM7XG5cdFx0Y29uc3QgZGlyZWN0aW9uID0gY29udGV4dC5mZXRjaE9wdGlvbnM/Lm1ldGE/LmZldGNoTW9yZT8uZGlyZWN0aW9uO1xuXHRcdGNvbnN0IG9sZFBhZ2VzID0gY29udGV4dC5zdGF0ZS5kYXRhPy5wYWdlcyB8fCBbXTtcblx0XHRjb25zdCBvbGRQYWdlUGFyYW1zID0gY29udGV4dC5zdGF0ZS5kYXRhPy5wYWdlUGFyYW1zIHx8IFtdO1xuXHRcdGxldCByZXN1bHQgPSB7XG5cdFx0XHRwYWdlczogW10sXG5cdFx0XHRwYWdlUGFyYW1zOiBbXVxuXHRcdH07XG5cdFx0bGV0IGN1cnJlbnRQYWdlID0gMDtcblx0XHRjb25zdCBmZXRjaEZuID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0bGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuXHRcdFx0Y29uc3Qgc2lnbmFsQ29udGV4dCA9IGNvbnRleHQ7XG5cdFx0XHRjb25zdCBhZGRTaWduYWxQcm9wZXJ0eSA9IChvYmplY3QpID0+IHtcblx0XHRcdFx0YWRkQ29uc3VtZUF3YXJlU2lnbmFsKG9iamVjdCwgKCkgPT4gY29udGV4dC5zaWduYWwsICgpID0+IGNhbmNlbGxlZCA9IHRydWUsIHNpZ25hbENvbnRleHRbZmV0Y2hTaWduYWxdKTtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBxdWVyeUZuID0gZW5zdXJlUXVlcnlGbihjb250ZXh0Lm9wdGlvbnMsIGNvbnRleHQuZmV0Y2hPcHRpb25zKTtcblx0XHRcdGNvbnN0IGZldGNoUGFnZSA9IGFzeW5jIChkYXRhLCBwYXJhbSwgcHJldmlvdXMpID0+IHtcblx0XHRcdFx0aWYgKGNhbmNlbGxlZCkgcmV0dXJuIFByb21pc2UucmVqZWN0KGNvbnRleHQuc2lnbmFsLnJlYXNvbik7XG5cdFx0XHRcdGlmIChwYXJhbSA9PSBudWxsICYmIGRhdGEucGFnZXMubGVuZ3RoKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGRhdGEpO1xuXHRcdFx0XHRjb25zdCBjcmVhdGVRdWVyeUZuQ29udGV4dCA9ICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBxdWVyeUZuQ29udGV4dCA9IHtcblx0XHRcdFx0XHRcdGNsaWVudDogY29udGV4dC5jbGllbnQsXG5cdFx0XHRcdFx0XHRxdWVyeUtleTogY29udGV4dC5xdWVyeUtleSxcblx0XHRcdFx0XHRcdHBhZ2VQYXJhbTogcGFyYW0sXG5cdFx0XHRcdFx0XHRkaXJlY3Rpb246IHByZXZpb3VzID8gXCJiYWNrd2FyZFwiIDogXCJmb3J3YXJkXCIsXG5cdFx0XHRcdFx0XHRtZXRhOiBjb250ZXh0Lm9wdGlvbnMubWV0YVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0YWRkU2lnbmFsUHJvcGVydHkocXVlcnlGbkNvbnRleHQpO1xuXHRcdFx0XHRcdHJldHVybiBxdWVyeUZuQ29udGV4dDtcblx0XHRcdFx0fTtcblx0XHRcdFx0Y29uc3QgcXVlcnlGbkNvbnRleHQgPSBjcmVhdGVRdWVyeUZuQ29udGV4dCgpO1xuXHRcdFx0XHRjb25zdCBwYWdlID0gYXdhaXQgcXVlcnlGbihxdWVyeUZuQ29udGV4dCk7XG5cdFx0XHRcdGNvbnN0IHsgbWF4UGFnZXMgfSA9IGNvbnRleHQub3B0aW9ucztcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRwYWdlczogYWRkVG9BcnJheShkYXRhLnBhZ2VzLCBwYWdlLCBtYXhQYWdlcywgcHJldmlvdXMpLFxuXHRcdFx0XHRcdHBhZ2VQYXJhbXM6IGFkZFRvQXJyYXkoZGF0YS5wYWdlUGFyYW1zLCBwYXJhbSwgbWF4UGFnZXMsIHByZXZpb3VzKVxuXHRcdFx0XHR9O1xuXHRcdFx0fTtcblx0XHRcdGlmIChkaXJlY3Rpb24gJiYgb2xkUGFnZXMubGVuZ3RoKSB7XG5cdFx0XHRcdGNvbnN0IHByZXZpb3VzID0gZGlyZWN0aW9uID09PSBcImJhY2t3YXJkXCI7XG5cdFx0XHRcdGNvbnN0IHBhZ2VQYXJhbUZuID0gcHJldmlvdXMgPyBnZXRQcmV2aW91c1BhZ2VQYXJhbSA6IGdldE5leHRQYWdlUGFyYW07XG5cdFx0XHRcdGNvbnN0IG9sZERhdGEgPSB7XG5cdFx0XHRcdFx0cGFnZXM6IG9sZFBhZ2VzLFxuXHRcdFx0XHRcdHBhZ2VQYXJhbXM6IG9sZFBhZ2VQYXJhbXNcblx0XHRcdFx0fTtcblx0XHRcdFx0cmVzdWx0ID0gYXdhaXQgZmV0Y2hQYWdlKG9sZERhdGEsIHBhZ2VQYXJhbUZuKG9wdGlvbnMsIG9sZERhdGEpLCBwcmV2aW91cyk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRjb25zdCByZW1haW5pbmdQYWdlcyA9IHBhZ2VzID8/IG9sZFBhZ2VzLmxlbmd0aDtcblx0XHRcdFx0ZG8ge1xuXHRcdFx0XHRcdGNvbnN0IHBhcmFtID0gY3VycmVudFBhZ2UgPT09IDAgPyBvbGRQYWdlUGFyYW1zWzBdID09PSB2b2lkIDAgPyBvcHRpb25zLmluaXRpYWxQYWdlUGFyYW0gOiBvbGRQYWdlUGFyYW1zWzBdIDogZ2V0TmV4dFBhZ2VQYXJhbShvcHRpb25zLCByZXN1bHQpO1xuXHRcdFx0XHRcdGlmIChjdXJyZW50UGFnZSA+IDAgJiYgcGFyYW0gPT0gbnVsbCkgYnJlYWs7XG5cdFx0XHRcdFx0cmVzdWx0ID0gYXdhaXQgZmV0Y2hQYWdlKHJlc3VsdCwgcGFyYW0pO1xuXHRcdFx0XHRcdGN1cnJlbnRQYWdlKys7XG5cdFx0XHRcdH0gd2hpbGUgKGN1cnJlbnRQYWdlIDwgcmVtYWluaW5nUGFnZXMpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9O1xuXHRcdGlmIChjb250ZXh0Lm9wdGlvbnMucGVyc2lzdGVyKSBjb250ZXh0LmZldGNoRm4gPSAoKSA9PiB7XG5cdFx0XHRyZXR1cm4gY29udGV4dC5vcHRpb25zLnBlcnNpc3Rlcj8uKGZldGNoRm4sIHtcblx0XHRcdFx0Y2xpZW50OiBjb250ZXh0LmNsaWVudCxcblx0XHRcdFx0cXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG5cdFx0XHRcdG1ldGE6IGNvbnRleHQub3B0aW9ucy5tZXRhLFxuXHRcdFx0XHRzaWduYWw6IGNvbnRleHQuc2lnbmFsXG5cdFx0XHR9LCBxdWVyeSk7XG5cdFx0fTtcblx0XHRlbHNlIGNvbnRleHQuZmV0Y2hGbiA9IGZldGNoRm47XG5cdH0gfTtcbn1cbi8qKlxuKiBDb21wdXRlcyB0aGUgcGFnZSBwYXJhbSBvZiB0aGUgcGFnZSBhZnRlciB0aGUgbGFzdCBvbmUsIHdpdGggdGhlIGBnZXROZXh0UGFnZVBhcmFtYCBvcHRpb24uXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMuXG4qIEBwYXJhbSBkYXRhIC0gVGhlIGN1cnJlbnQgcGFnZXMgYW5kIHBhZ2UgcGFyYW1zLlxuKiBAcmV0dXJucyBUaGUgbmV4dCBwYWdlIHBhcmFtLCBvciBgdW5kZWZpbmVkYCBpZiB0aGVyZSBhcmUgbm8gcGFnZXMgeWV0LlxuKi9cbmZ1bmN0aW9uIGdldE5leHRQYWdlUGFyYW0ob3B0aW9ucywgeyBwYWdlcywgcGFnZVBhcmFtcyB9KSB7XG5cdGNvbnN0IGxhc3RJbmRleCA9IHBhZ2VzLmxlbmd0aCAtIDE7XG5cdHJldHVybiBwYWdlcy5sZW5ndGggPiAwID8gb3B0aW9ucy5nZXROZXh0UGFnZVBhcmFtKHBhZ2VzW2xhc3RJbmRleF0sIHBhZ2VzLCBwYWdlUGFyYW1zW2xhc3RJbmRleF0sIHBhZ2VQYXJhbXMpIDogdm9pZCAwO1xufVxuLyoqXG4qIENvbXB1dGVzIHRoZSBwYWdlIHBhcmFtIG9mIHRoZSBwYWdlIGJlZm9yZSB0aGUgZmlyc3Qgb25lLCB3aXRoIHRoZSBgZ2V0UHJldmlvdXNQYWdlUGFyYW1gXG4qIG9wdGlvbi5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgaW5maW5pdGUgcXVlcnkgb3B0aW9ucy5cbiogQHBhcmFtIGRhdGEgLSBUaGUgY3VycmVudCBwYWdlcyBhbmQgcGFnZSBwYXJhbXMuXG4qIEByZXR1cm5zIFRoZSBwcmV2aW91cyBwYWdlIHBhcmFtLCBvciBgdW5kZWZpbmVkYCBpZiB0aGVyZSBhcmUgbm8gcGFnZXMgeWV0IG9yIG5vXG4qIGBnZXRQcmV2aW91c1BhZ2VQYXJhbWAgb3B0aW9uLlxuKi9cbmZ1bmN0aW9uIGdldFByZXZpb3VzUGFnZVBhcmFtKG9wdGlvbnMsIHsgcGFnZXMsIHBhZ2VQYXJhbXMgfSkge1xuXHRyZXR1cm4gcGFnZXMubGVuZ3RoID4gMCA/IG9wdGlvbnMuZ2V0UHJldmlvdXNQYWdlUGFyYW0/LihwYWdlc1swXSwgcGFnZXMsIHBhZ2VQYXJhbXNbMF0sIHBhZ2VQYXJhbXMpIDogdm9pZCAwO1xufVxuLyoqXG4qIENoZWNrcyBpZiB0aGVyZSBpcyBhIG5leHQgcGFnZS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgaW5maW5pdGUgcXVlcnkgb3B0aW9ucyB3aXRoIGBnZXROZXh0UGFnZVBhcmFtYC5cbiogQHBhcmFtIGRhdGEgLSBUaGUgY3VycmVudCBwYWdlcyBhbmQgcGFnZSBwYXJhbXMuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiBgZ2V0TmV4dFBhZ2VQYXJhbWAgcmV0dXJucyBhIHZhbHVlIG90aGVyIHRoYW4gYG51bGxgIG9yIGB1bmRlZmluZWRgLlxuKi9cbmZ1bmN0aW9uIGhhc05leHRQYWdlKG9wdGlvbnMsIGRhdGEpIHtcblx0aWYgKCFkYXRhKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiBnZXROZXh0UGFnZVBhcmFtKG9wdGlvbnMsIGRhdGEpICE9IG51bGw7XG59XG4vKipcbiogQ2hlY2tzIGlmIHRoZXJlIGlzIGEgcHJldmlvdXMgcGFnZS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgaW5maW5pdGUgcXVlcnkgb3B0aW9ucyB3aXRoIGBnZXRQcmV2aW91c1BhZ2VQYXJhbWAuXG4qIEBwYXJhbSBkYXRhIC0gVGhlIGN1cnJlbnQgcGFnZXMgYW5kIHBhZ2UgcGFyYW1zLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYGdldFByZXZpb3VzUGFnZVBhcmFtYCBpcyBzZXQgYW5kIHJldHVybnMgYSB2YWx1ZSBvdGhlciB0aGFuIGBudWxsYCBvclxuKiBgdW5kZWZpbmVkYC5cbiovXG5mdW5jdGlvbiBoYXNQcmV2aW91c1BhZ2Uob3B0aW9ucywgZGF0YSkge1xuXHRpZiAoIWRhdGEgfHwgIW9wdGlvbnMuZ2V0UHJldmlvdXNQYWdlUGFyYW0pIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIGdldFByZXZpb3VzUGFnZVBhcmFtKG9wdGlvbnMsIGRhdGEpICE9IG51bGw7XG59XG5leHBvcnQgeyBoYXNOZXh0UGFnZSwgaGFzUHJldmlvdXNQYWdlLCBpbmZpbml0ZVF1ZXJ5QmVoYXZpb3IgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzLm1hcCIsImltcG9ydCB7IHN5c3RlbVNldFRpbWVvdXRaZXJvIH0gZnJvbSBcIi4vdGltZW91dE1hbmFnZXIuanNcIjtcbi8vIHNyYy9ub3RpZnlNYW5hZ2VyLnRzXG4vKipcbiogRGVmYXVsdCBzY2hlZHVsaW5nIGZ1bmN0aW9uIHVzZWQgYnkgdGhlIG5vdGlmeSBtYW5hZ2VyLlxuKiBTY2hlZHVsZXMgdGhlIGNhbGxiYWNrIHdpdGggdGhlIHN5c3RlbSdzIGBzZXRUaW1lb3V0KGNhbGxiYWNrLCAwKWAuXG4qL1xuY29uc3QgZGVmYXVsdFNjaGVkdWxlciA9IHN5c3RlbVNldFRpbWVvdXRaZXJvO1xuLyoqXG4qIENyZWF0ZXMgYSBub3RpZnkgbWFuYWdlciwgd2hpY2ggc2NoZWR1bGVzIGFuZCBiYXRjaGVzIG5vdGlmaWNhdGlvbnMgdG8gc3Vic2NyaWJlcnMuIFF1ZXJ5IHVzZXMgYVxuKiBzaW5nbGUgaW5zdGFuY2Ugb2YgaXQsIGV4cG9ydGVkIGFzIHtAbGluayBub3RpZnlNYW5hZ2VyfS5cbiogQHJldHVybnMgQSBuZXcgbm90aWZ5IG1hbmFnZXIuXG4qL1xuZnVuY3Rpb24gY3JlYXRlTm90aWZ5TWFuYWdlcigpIHtcblx0bGV0IHF1ZXVlID0gW107XG5cdGxldCB0cmFuc2FjdGlvbnMgPSAwO1xuXHRsZXQgbm90aWZ5Rm4gPSAoY2FsbGJhY2spID0+IHtcblx0XHRjYWxsYmFjaygpO1xuXHR9O1xuXHRsZXQgYmF0Y2hOb3RpZnlGbiA9IChjYWxsYmFjaykgPT4ge1xuXHRcdGNhbGxiYWNrKCk7XG5cdH07XG5cdGxldCBzY2hlZHVsZUZuID0gZGVmYXVsdFNjaGVkdWxlcjtcblx0Y29uc3Qgc2NoZWR1bGUgPSAoY2FsbGJhY2spID0+IHtcblx0XHRpZiAodHJhbnNhY3Rpb25zKSBxdWV1ZS5wdXNoKGNhbGxiYWNrKTtcblx0XHRlbHNlIHNjaGVkdWxlRm4oKCkgPT4ge1xuXHRcdFx0bm90aWZ5Rm4oY2FsbGJhY2spO1xuXHRcdH0pO1xuXHR9O1xuXHRjb25zdCBmbHVzaCA9ICgpID0+IHtcblx0XHRjb25zdCBvcmlnaW5hbFF1ZXVlID0gcXVldWU7XG5cdFx0cXVldWUgPSBbXTtcblx0XHRpZiAob3JpZ2luYWxRdWV1ZS5sZW5ndGgpIHNjaGVkdWxlRm4oKCkgPT4ge1xuXHRcdFx0YmF0Y2hOb3RpZnlGbigoKSA9PiB7XG5cdFx0XHRcdG9yaWdpbmFsUXVldWUuZm9yRWFjaCgoY2FsbGJhY2spID0+IHtcblx0XHRcdFx0XHRub3RpZnlGbihjYWxsYmFjayk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH07XG5cdHJldHVybiB7XG5cdFx0LyoqXG5cdFx0KiBCYXRjaGVzIGFsbCB1cGRhdGVzIHNjaGVkdWxlZCBpbnNpZGUgdGhlIHBhc3NlZCBjYWxsYmFjay5cblx0XHQqIFRoaXMgaXMgbWFpbmx5IHVzZWQgaW50ZXJuYWxseSB0byBvcHRpbWl6ZSBxdWVyeSBjbGllbnQgdXBkYXRpbmcuXG5cdFx0KiBCYXRjaGVzIGNhbiBiZSBuZXN0ZWQ7IHRoZSBxdWV1ZSBpcyBvbmx5IGZsdXNoZWQgb25jZSB0aGUgb3V0ZXJtb3N0IGBiYXRjaGAgY2FsbCBmaW5pc2hlcy5cblx0XHQqIFRoZSByZXR1cm4gdmFsdWUgb2YgYGNhbGxiYWNrYCBpcyBwYXNzZWQgdGhyb3VnaC5cblx0XHQqIEBwYXJhbSBjYWxsYmFjayAtIFRoZSBmdW5jdGlvbiB0byBydW4gaW4gdGhlIGJhdGNoLlxuXHRcdCogQHJldHVybnMgVGhlIHJldHVybiB2YWx1ZSBvZiBgY2FsbGJhY2tgLlxuXHRcdCovXG5cdFx0YmF0Y2g6IChjYWxsYmFjaykgPT4ge1xuXHRcdFx0bGV0IHJlc3VsdDtcblx0XHRcdHRyYW5zYWN0aW9ucysrO1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0cmVzdWx0ID0gY2FsbGJhY2soKTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdHRyYW5zYWN0aW9ucy0tO1xuXHRcdFx0XHRpZiAoIXRyYW5zYWN0aW9ucykgZmx1c2goKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSxcblx0XHQvKipcblx0XHQqIEFsbCBjYWxscyB0byB0aGUgd3JhcHBlZCBmdW5jdGlvbiB3aWxsIGJlIGJhdGNoZWQuXG5cdFx0KiBAcGFyYW0gY2FsbGJhY2sgLSBUaGUgZnVuY3Rpb24gdG8gd3JhcC5cblx0XHQqIEByZXR1cm5zIEEgZnVuY3Rpb24gdGhhdCBzY2hlZHVsZXMgYSBjYWxsIHRvIGBjYWxsYmFja2Agd2l0aCB0aGUgZ2l2ZW4gYXJndW1lbnRzLlxuXHRcdCovXG5cdFx0YmF0Y2hDYWxsczogKGNhbGxiYWNrKSA9PiB7XG5cdFx0XHRyZXR1cm4gKC4uLmFyZ3MpID0+IHtcblx0XHRcdFx0c2NoZWR1bGUoKCkgPT4ge1xuXHRcdFx0XHRcdGNhbGxiYWNrKC4uLmFyZ3MpO1xuXHRcdFx0XHR9KTtcblx0XHRcdH07XG5cdFx0fSxcblx0XHQvKipcblx0XHQqIFNjaGVkdWxlcyBhIGZ1bmN0aW9uIHRvIGJlIHJ1biBvbiB0aGUgbmV4dCBiYXRjaC5cblx0XHQqIEJ5IGRlZmF1bHQsIHRoZSBiYXRjaCBpcyBydW4gd2l0aCBhIGBzZXRUaW1lb3V0YCwgYnV0IHRoaXMgY2FuIGJlIGNvbmZpZ3VyZWQgdmlhIGBzZXRTY2hlZHVsZXJgLlxuXHRcdCovXG5cdFx0c2NoZWR1bGUsXG5cdFx0LyoqXG5cdFx0KiBVc2UgdGhpcyBtZXRob2QgdG8gc2V0IGEgY3VzdG9tIG5vdGlmeSBmdW5jdGlvbi5cblx0XHQqIFRoaXMgY2FuIGJlIHVzZWQgdG8gZm9yIGV4YW1wbGUgd3JhcCBub3RpZmljYXRpb25zIHdpdGggYFJlYWN0LmFjdGAgd2hpbGUgcnVubmluZyB0ZXN0cy5cblx0XHQqIEBwYXJhbSBmbiAtIFJlY2VpdmVzIGVhY2ggbm90aWZpY2F0aW9uIGNhbGxiYWNrIGFuZCBtdXN0IGNhbGwgaXQuXG5cdFx0Ki9cblx0XHRzZXROb3RpZnlGdW5jdGlvbjogKGZuKSA9PiB7XG5cdFx0XHRub3RpZnlGbiA9IGZuO1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBVc2UgdGhpcyBtZXRob2QgdG8gc2V0IGEgY3VzdG9tIGZ1bmN0aW9uIHRvIGJhdGNoIG5vdGlmaWNhdGlvbnMgdG9nZXRoZXIgaW50byBhIHNpbmdsZSB0aWNrLlxuXHRcdCogRnJhbWV3b3JrIGFkYXB0ZXJzIHVzZSB0aGlzIHRvIHBsdWcgaW4gdGhlaXIgb3duIGJhdGNoaW5nIHByaW1pdGl2ZSwgc28gdGhhdCBhIHNpbmdsZSBxdWVyeVxuXHRcdCogdXBkYXRlIG9ubHkgdHJpZ2dlcnMgb25lIHJlLXJlbmRlciBpbnN0ZWFkIG9mIG9uZSBwZXIgc3Vic2NyaWJlci5cblx0XHQqIEBwYXJhbSBmbiAtIFJlY2VpdmVzIGEgZnVuY3Rpb24gdGhhdCBydW5zIGEgYmF0Y2ggb2Ygbm90aWZpY2F0aW9ucyBhbmQgbXVzdCBjYWxsIGl0LlxuXHRcdCogQGV4YW1wbGVcblx0XHQqIGBgYHRzXG5cdFx0KiBpbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdFx0KiBpbXBvcnQgeyBiYXRjaCB9IGZyb20gJ3NvbGlkLWpzJ1xuXHRcdCpcblx0XHQqIG5vdGlmeU1hbmFnZXIuc2V0QmF0Y2hOb3RpZnlGdW5jdGlvbihiYXRjaClcblx0XHQqIGBgYFxuXHRcdCovXG5cdFx0c2V0QmF0Y2hOb3RpZnlGdW5jdGlvbjogKGZuKSA9PiB7XG5cdFx0XHRiYXRjaE5vdGlmeUZuID0gZm47XG5cdFx0fSxcblx0XHQvKipcblx0XHQqIENvbmZpZ3VyZXMgYSBjdXN0b20gY2FsbGJhY2sgdGhhdCBzY2hlZHVsZXMgd2hlbiB0aGUgbmV4dCBiYXRjaCBydW5zLlxuXHRcdCogVGhlIGRlZmF1bHQgYmVoYXZpb3IgaXMgYHNldFRpbWVvdXQoY2FsbGJhY2ssIDApYC5cblx0XHQqIEBwYXJhbSBmbiAtIFJlY2VpdmVzIGEgY2FsbGJhY2sgdGhhdCBydW5zIHRoZSBuZXh0IGJhdGNoLCBhbmQgc2NoZWR1bGVzIGl0LlxuXHRcdCogQGV4YW1wbGVcblx0XHQqIGBgYHRzXG5cdFx0KiBpbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdFx0KlxuXHRcdCogLy8gU2NoZWR1bGUgYmF0Y2hlcyBpbiB0aGUgbmV4dCBtaWNyb3Rhc2tcblx0XHQqIG5vdGlmeU1hbmFnZXIuc2V0U2NoZWR1bGVyKHF1ZXVlTWljcm90YXNrKVxuXHRcdCpcblx0XHQqIC8vIFNjaGVkdWxlIGJhdGNoZXMgYmVmb3JlIHRoZSBuZXh0IGZyYW1lIGlzIHJlbmRlcmVkXG5cdFx0KiBub3RpZnlNYW5hZ2VyLnNldFNjaGVkdWxlcihyZXF1ZXN0QW5pbWF0aW9uRnJhbWUpXG5cdFx0KlxuXHRcdCogLy8gU2NoZWR1bGUgYmF0Y2hlcyBzb21lIHRpbWUgaW4gdGhlIGZ1dHVyZVxuXHRcdCogbm90aWZ5TWFuYWdlci5zZXRTY2hlZHVsZXIoKGNiKSA9PiBzZXRUaW1lb3V0KGNiLCAxMCkpXG5cdFx0KiBgYGBcblx0XHQqL1xuXHRcdHNldFNjaGVkdWxlcjogKGZuKSA9PiB7XG5cdFx0XHRzY2hlZHVsZUZuID0gZm47XG5cdFx0fVxuXHR9O1xufVxuLyoqXG4qIEhhbmRsZXMgc2NoZWR1bGluZyBhbmQgYmF0Y2hpbmcgY2FsbGJhY2tzIGluIFRhblN0YWNrIFF1ZXJ5LlxuKi9cbmNvbnN0IG5vdGlmeU1hbmFnZXIgPSBjcmVhdGVOb3RpZnlNYW5hZ2VyKCk7XG5leHBvcnQgeyBjcmVhdGVOb3RpZnlNYW5hZ2VyLCBkZWZhdWx0U2NoZWR1bGVyLCBub3RpZnlNYW5hZ2VyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vdGlmeU1hbmFnZXIuanMubWFwIiwiaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiLi9lbnZpcm9ubWVudE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSBcIi4vdGltZW91dE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGlzVmFsaWRUaW1lb3V0IH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vIHNyYy9yZW1vdmFibGUudHNcbi8qKlxuKiBUaGUgYmFzZSBjbGFzcyBmb3IgY2FjaGUgZW50cmllcyB0aGF0IGFyZSBnYXJiYWdlIGNvbGxlY3RlZCBvbmNlIG5vdGhpbmcgaXMgdXNpbmcgdGhlbSDigJRcbiogYFF1ZXJ5YCBhbmQgYE11dGF0aW9uYCBib3RoIGV4dGVuZCBpdC4gYGdjVGltZWAgY29udHJvbHMgaG93IGxvbmcgYW4gdW51c2VkIGVudHJ5IGlzIGtlcHQuXG4qL1xudmFyIFJlbW92YWJsZSA9IGNsYXNzIHtcblx0I2djVGltZW91dDtcblx0LyoqXG5cdCogQ2xlYXJzIHRoZSBwZW5kaW5nIGdhcmJhZ2UgY29sbGVjdGlvbiB0aW1lb3V0LCBzbyB0aGUgZW50cnkgaXMgbm8gbG9uZ2VyIHNjaGVkdWxlZCBmb3IgcmVtb3ZhbC5cblx0KiBBIHN1YmNsYXNzIG1heSBvdmVycmlkZSB0aGlzIHRvIHJlbGVhc2Ugd2hhdCBpdCBob2xkcyBvbiB0byBhcyB3ZWxsIOKAlCBgUXVlcnlgIGFsc28gY2FuY2VscyBhbnlcblx0KiBpbi1mbGlnaHQgZmV0Y2guXG5cdCovXG5cdGRlc3Ryb3koKSB7XG5cdFx0dGhpcy5jbGVhckdjVGltZW91dCgpO1xuXHR9XG5cdC8qKlxuXHQqIFNjaGVkdWxlcyB0aGUgZW50cnkgdG8gYmUgcmVtb3ZlZCBmcm9tIGl0cyBjYWNoZSBhZnRlciBgZ2NUaW1lYCwgcmVwbGFjaW5nIGFueSB0aW1lb3V0IHNjaGVkdWxlZFxuXHQqIGJlZm9yZS4gTm90aGluZyBpcyBzY2hlZHVsZWQgaWYgYGdjVGltZWAgaXMgYEluZmluaXR5YC5cblx0Ki9cblx0c2NoZWR1bGVHYygpIHtcblx0XHR0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG5cdFx0aWYgKGlzVmFsaWRUaW1lb3V0KHRoaXMuZ2NUaW1lKSkgdGhpcy4jZ2NUaW1lb3V0ID0gdGltZW91dE1hbmFnZXIuc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHR0aGlzLm9wdGlvbmFsUmVtb3ZlKCk7XG5cdFx0fSwgdGhpcy5nY1RpbWUpO1xuXHR9XG5cdC8qKlxuXHQqIFVwZGF0ZXMgYGdjVGltZWAsIGtlZXBpbmcgdGhlIGxvbmdlc3Qgb25lIHNlZW4gc28gZmFyLiBXaXRob3V0IGEgdmFsdWUsIGl0IGRlZmF1bHRzIHRvIDUgbWludXRlc1xuXHQqIG9uIHRoZSBjbGllbnQgYW5kIGBJbmZpbml0eWAgb24gdGhlIHNlcnZlci5cblx0KiBAcGFyYW0gbmV3R2NUaW1lIC0gVGhlIGBnY1RpbWVgIGZyb20gdGhlIGxhdGVzdCBvcHRpb25zLCBpZiBhbnkuXG5cdCovXG5cdHVwZGF0ZUdjVGltZShuZXdHY1RpbWUpIHtcblx0XHR0aGlzLmdjVGltZSA9IE1hdGgubWF4KHRoaXMuZ2NUaW1lIHx8IDAsIG5ld0djVGltZSA/PyAoaXNTZXJ2ZXIoKSA/IEluZmluaXR5IDogM2U1KSk7XG5cdH1cblx0LyoqXG5cdCogQ2FuY2VscyB0aGUgc2NoZWR1bGVkIHJlbW92YWwsIGlmIHRoZXJlIGlzIG9uZS5cblx0Ki9cblx0Y2xlYXJHY1RpbWVvdXQoKSB7XG5cdFx0aWYgKHRoaXMuI2djVGltZW91dCAhPT0gdm9pZCAwKSB7XG5cdFx0XHR0aW1lb3V0TWFuYWdlci5jbGVhclRpbWVvdXQodGhpcy4jZ2NUaW1lb3V0KTtcblx0XHRcdHRoaXMuI2djVGltZW91dCA9IHZvaWQgMDtcblx0XHR9XG5cdH1cbn07XG5leHBvcnQgeyBSZW1vdmFibGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVtb3ZhYmxlLmpzLm1hcCIsImltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuLy8gc3JjL29ubGluZU1hbmFnZXIudHNcbi8qKlxuKiBUaGUgYE9ubGluZU1hbmFnZXJgIG1hbmFnZXMgdGhlIG9ubGluZSBzdGF0ZSB3aXRoaW4gVGFuU3RhY2sgUXVlcnkuIEl0IGNhblxuKiBiZSB1c2VkIHRvIGNoYW5nZSB0aGUgZGVmYXVsdCBldmVudCBsaXN0ZW5lcnMgb3IgdG8gbWFudWFsbHkgY2hhbmdlIHRoZVxuKiBvbmxpbmUgc3RhdGUuXG4qXG4qIEJ5IGRlZmF1bHQsIHRoZSBgb25saW5lTWFuYWdlcmAgYXNzdW1lcyBhbiBhY3RpdmUgbmV0d29yayBjb25uZWN0aW9uLCBhbmRcbiogbGlzdGVucyB0byB0aGUgYG9ubGluZWAgYW5kIGBvZmZsaW5lYCBldmVudHMgb24gdGhlIGB3aW5kb3dgIG9iamVjdCB0b1xuKiBkZXRlY3QgY2hhbmdlcy5cbiovXG52YXIgT25saW5lTWFuYWdlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I29ubGluZSA9IHRydWU7XG5cdCNjbGVhbnVwO1xuXHQjc2V0dXA7XG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy4jc2V0dXAgPSAob25PbmxpbmUpID0+IHtcblx0XHRcdGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKSB7XG5cdFx0XHRcdGNvbnN0IG9ubGluZUxpc3RlbmVyID0gKCkgPT4gb25PbmxpbmUodHJ1ZSk7XG5cdFx0XHRcdGNvbnN0IG9mZmxpbmVMaXN0ZW5lciA9ICgpID0+IG9uT25saW5lKGZhbHNlKTtcblx0XHRcdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJvbmxpbmVcIiwgb25saW5lTGlzdGVuZXIsIGZhbHNlKTtcblx0XHRcdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJvZmZsaW5lXCIsIG9mZmxpbmVMaXN0ZW5lciwgZmFsc2UpO1xuXHRcdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHRcdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwib25saW5lXCIsIG9ubGluZUxpc3RlbmVyKTtcblx0XHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm9mZmxpbmVcIiwgb2ZmbGluZUxpc3RlbmVyKTtcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHR9XG5cdG9uU3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy4jY2xlYW51cCkgdGhpcy5zZXRFdmVudExpc3RlbmVyKHRoaXMuI3NldHVwKTtcblx0fVxuXHRvblVuc3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuXHRcdFx0dGhpcy4jY2xlYW51cD8uKCk7XG5cdFx0XHR0aGlzLiNjbGVhbnVwID0gdm9pZCAwO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgc2V0RXZlbnRMaXN0ZW5lcmAgY2FuIGJlIHVzZWQgdG8gc2V0IGEgY3VzdG9tIGV2ZW50IGxpc3RlbmVyIHRoYXQgd2lsbFxuXHQqIGJlIHVzZWQgdG8gZGV0ZXJtaW5lIHRoZSBvbmxpbmUgc3RhdGUuIFRoZSBwcm92aWRlZCBgc2V0dXBgIGZ1bmN0aW9uXG5cdCogcmVjZWl2ZXMgYSBgc2V0T25saW5lYCBjYWxsYmFjayB0aGF0IHNob3VsZCBiZSBjYWxsZWQgd2l0aCBhIGBib29sZWFuYFxuXHQqIHdoZW5ldmVyIHRoZSBvbmxpbmUgc3RhdGUgY2hhbmdlcy5cblx0KiBAcGFyYW0gc2V0dXAgLSBSZWNlaXZlcyB0aGUgYHNldE9ubGluZWAgY2FsbGJhY2ssIHJlZ2lzdGVycyB0aGUgZXZlbnQgbGlzdGVuZXIsIGFuZCBtYXkgcmV0dXJuXG5cdCogYSBjbGVhbnVwIGZ1bmN0aW9uIHRoYXQgaXMgY2FsbGVkIHdoZW4gdGhlIGxpc3RlbmVyIGlzIHJlcGxhY2VkIG9yIG5vIGxvbmdlciBuZWVkZWQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCBOZXRJbmZvIGZyb20gJ0ByZWFjdC1uYXRpdmUtY29tbXVuaXR5L25ldGluZm8nXG5cdCogaW1wb3J0IHsgb25saW5lTWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogb25saW5lTWFuYWdlci5zZXRFdmVudExpc3RlbmVyKChzZXRPbmxpbmUpID0+IHtcblx0KiAgIHJldHVybiBOZXRJbmZvLmFkZEV2ZW50TGlzdGVuZXIoKHN0YXRlKSA9PiB7XG5cdCogICAgIHNldE9ubGluZSghIXN0YXRlLmlzQ29ubmVjdGVkKVxuXHQqICAgfSlcblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRFdmVudExpc3RlbmVyKHNldHVwKSB7XG5cdFx0dGhpcy4jc2V0dXAgPSBzZXR1cDtcblx0XHR0aGlzLiNjbGVhbnVwPy4oKTtcblx0XHR0aGlzLiNjbGVhbnVwID0gc2V0dXAodGhpcy5zZXRPbmxpbmUuYmluZCh0aGlzKSk7XG5cdH1cblx0LyoqXG5cdCogYHNldE9ubGluZWAgY2FuIGJlIHVzZWQgdG8gbWFudWFsbHkgc2V0IHRoZSBvbmxpbmUgc3RhdGUuXG5cdCogQHBhcmFtIG9ubGluZSAtIFRoZSBvbmxpbmUgc3RhdGUuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IG9ubGluZU1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIC8vIFNldCB0byBvbmxpbmVcblx0KiBvbmxpbmVNYW5hZ2VyLnNldE9ubGluZSh0cnVlKVxuXHQqXG5cdCogLy8gU2V0IHRvIG9mZmxpbmVcblx0KiBvbmxpbmVNYW5hZ2VyLnNldE9ubGluZShmYWxzZSlcblx0KiBgYGBcblx0Ki9cblx0c2V0T25saW5lKG9ubGluZSkge1xuXHRcdGlmICh0aGlzLiNvbmxpbmUgIT09IG9ubGluZSkge1xuXHRcdFx0dGhpcy4jb25saW5lID0gb25saW5lO1xuXHRcdFx0dGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdFx0bGlzdGVuZXIob25saW5lKTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgaXNPbmxpbmVgIGNhbiBiZSB1c2VkIHRvIGdldCB0aGUgY3VycmVudCBvbmxpbmUgc3RhdGUuXG5cdCogQHJldHVybnMgYHRydWVgIGlmIG9ubGluZS5cblx0Ki9cblx0aXNPbmxpbmUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI29ubGluZTtcblx0fVxufTtcbi8qKlxuKiBTaW5nbGV0b24gaW5zdGFuY2Ugb2Yge0BsaW5rIE9ubGluZU1hbmFnZXJ9LCB1c2VkIHRvIG1hbmFnZSBhbmQgb2JzZXJ2ZSB0aGUgb25saW5lIHN0YXRlIHdpdGhpbiBUYW5TdGFjayBRdWVyeS5cbiovXG5jb25zdCBvbmxpbmVNYW5hZ2VyID0gbmV3IE9ubGluZU1hbmFnZXIoKTtcbmV4cG9ydCB7IE9ubGluZU1hbmFnZXIsIG9ubGluZU1hbmFnZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9b25saW5lTWFuYWdlci5qcy5tYXAiLCJpbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCIuL2Vudmlyb25tZW50TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgZm9jdXNNYW5hZ2VyIH0gZnJvbSBcIi4vZm9jdXNNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBvbmxpbmVNYW5hZ2VyIH0gZnJvbSBcIi4vb25saW5lTWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgbm9vcCwgc2xlZXAgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuLy8gc3JjL3JldHJ5ZXIudHNcbi8qKlxuKiBUaGUgZGVmYXVsdCBgcmV0cnlEZWxheWA6IGRvdWJsZXMgd2l0aCBldmVyeSBmYWlsdXJlLCBzdGFydGluZyBhdCAxIHNlY29uZCwgdXAgdG8gMzAgc2Vjb25kcy5cbiogQHBhcmFtIGZhaWx1cmVDb3VudCAtIFRoZSBudW1iZXIgb2YgZmFpbHVyZXMgc28gZmFyLlxuKiBAcmV0dXJucyBUaGUgZGVsYXkgYmVmb3JlIHRoZSBuZXh0IHJldHJ5LCBpbiBtaWxsaXNlY29uZHMuXG4qL1xuZnVuY3Rpb24gZGVmYXVsdFJldHJ5RGVsYXkoZmFpbHVyZUNvdW50KSB7XG5cdHJldHVybiBNYXRoLm1pbigxZTMgKiAyICoqIGZhaWx1cmVDb3VudCwgM2U0KTtcbn1cbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIGZldGNoIGNhbiBydW4gZm9yIHRoZSBnaXZlbiBuZXR3b3JrIG1vZGUuXG4qIEBwYXJhbSBuZXR3b3JrTW9kZSAtIFRoZSBgbmV0d29ya01vZGVgIG9wdGlvbi4gRGVmYXVsdHMgdG8gYCdvbmxpbmUnYC5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBuZXR3b3JrIG1vZGUgaXMgbm90IGAnb25saW5lJ2AsIG9yIGlmIGl0IGlzIGFuZCB0aGUgY2xpZW50IGlzIG9ubGluZS5cbiovXG5mdW5jdGlvbiBjYW5GZXRjaChuZXR3b3JrTW9kZSkge1xuXHRyZXR1cm4gKG5ldHdvcmtNb2RlID8/IFwib25saW5lXCIpID09PSBcIm9ubGluZVwiID8gb25saW5lTWFuYWdlci5pc09ubGluZSgpIDogdHJ1ZTtcbn1cbi8qKlxuKiBUaGUgZXJyb3IgdGhyb3duIGJ5IGEgYFJldHJ5ZXJgIChhbmQgc3VyZmFjZWQgdG8gYHF1ZXJ5LnByb21pc2VgL2BtdXRhdGlvbmApIHdoZW4gYSBmZXRjaCBpcyBjYW5jZWxsZWQsIGUuZy4gdmlhXG4qIGBxdWVyeS5jYW5jZWwoKWAuIGByZXZlcnRgLCBpZiBgdHJ1ZWAsIHRlbGxzIHRoZSBjYWxsZXIgdG8gcmVzdG9yZSB0aGUgc3RhdGUgdGhlIHF1ZXJ5IHdhcyBpbiBiZWZvcmUgdGhlIGZldGNoXG4qIHN0YXJ0ZWQgaW5zdGVhZCBvZiBzdXJmYWNpbmcgdGhlIGVycm9yLiBgc2lsZW50YCwgaWYgYHRydWVgLCB0ZWxscyB0aGUgY2FsbGVyIHRvIHN1cHByZXNzIHRoaXMgZXJyb3IgYW5kIGluc3RlYWRcbiogcmVzb2x2ZSB3aXRoIHRoZSBwcm9taXNlIG9mIHRoZSBmZXRjaCB0aGF0IHRyaWdnZXJlZCB0aGUgY2FuY2VsbGF0aW9uLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBxdWVyeS5jYW5jZWwoKVxuKlxuKiB0cnkge1xuKiAgIGF3YWl0IHF1ZXJ5LnByb21pc2VcbiogfSBjYXRjaCAoZXJyb3IpIHtcbiogICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBDYW5jZWxsZWRFcnJvcikge1xuKiAgICAgLy8gdGhlIGZldGNoIHdhcyBjYW5jZWxsZWQsIGUuZy4gdmlhIGBxdWVyeS5jYW5jZWwoKWBcbiogICB9XG4qIH1cbiogYGBgXG4qL1xudmFyIENhbmNlbGxlZEVycm9yID0gY2xhc3MgZXh0ZW5kcyBFcnJvciB7XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHRzdXBlcihcIkNhbmNlbGxlZEVycm9yXCIpO1xuXHRcdHRoaXMucmV2ZXJ0ID0gb3B0aW9ucz8ucmV2ZXJ0O1xuXHRcdHRoaXMuc2lsZW50ID0gb3B0aW9ucz8uc2lsZW50O1xuXHR9XG59O1xuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgdmFsdWUgaXMgYSBgQ2FuY2VsbGVkRXJyb3JgLlxuKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gY2hlY2suXG4qIEByZXR1cm5zIGB0cnVlYCBpZiBgdmFsdWVgIGlzIGEgYENhbmNlbGxlZEVycm9yYC5cbiogQGRlcHJlY2F0ZWQgVXNlIGluc3RhbmNlb2YgYENhbmNlbGxlZEVycm9yYCBpbnN0ZWFkLlxuKi9cbmZ1bmN0aW9uIGlzQ2FuY2VsbGVkRXJyb3IodmFsdWUpIHtcblx0cmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3I7XG59XG4vKipcbiogQ3JlYXRlcyBhIHJldHJ5ZXIsIHdoaWNoIHJ1bnMgYSBmdW5jdGlvbiBhbmQgcmV0cmllcyBpdCBvbiBmYWlsdXJlIGFjY29yZGluZyB0byB0aGUgYHJldHJ5YCBhbmRcbiogYHJldHJ5RGVsYXlgIG9wdGlvbnMuIEl0IHBhdXNlcyB3aGlsZSB0aGUgbmV0d29yayBtb2RlIGRvZXNuJ3QgYWxsb3cgZmV0Y2hpbmcgb3IgYGNhblJ1bmAgcmV0dXJuc1xuKiBgZmFsc2VgLCBhbmQgY2FuIGJlIGNhbmNlbGxlZC4gUXVlcmllcyBhbmQgbXV0YXRpb25zIHVzZSBpdCB0byBydW4gdGhlaXIgYHF1ZXJ5Rm5gIGFuZFxuKiBgbXV0YXRpb25GbmAuXG4qIEBwYXJhbSBjb25maWcgLSBUaGUgZnVuY3Rpb24gdG8gcnVuLCB0aGUgcmV0cnkgb3B0aW9ucywgYW5kIHRoZSBjYWxsYmFja3MgZm9yIGZhaWx1cmVzLCBwYXVzaW5nLFxuKiBjb250aW51aW5nLCBhbmQgY2FuY2VsbGF0aW9uLlxuKiBAcmV0dXJucyBUaGUgcmV0cnllciwgd2hvc2UgYHByb21pc2VgIHNldHRsZXMgd2l0aCB0aGUgcmVzdWx0IG9mIHRoZSBmdW5jdGlvbi5cbiovXG5mdW5jdGlvbiBjcmVhdGVSZXRyeWVyKGNvbmZpZykge1xuXHRsZXQgaXNSZXRyeUNhbmNlbGxlZCA9IGZhbHNlO1xuXHRsZXQgZmFpbHVyZUNvdW50ID0gMDtcblx0bGV0IGNvbnRpbnVlRm47XG5cdGxldCBzdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0bGV0IHByb21pc2VSZXNvbHZlO1xuXHRsZXQgcHJvbWlzZVJlamVjdDtcblx0Y29uc3QgcHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRwcm9taXNlUmVzb2x2ZSA9IHJlc29sdmU7XG5cdFx0cHJvbWlzZVJlamVjdCA9IHJlamVjdDtcblx0fSk7XG5cdHByb21pc2UuY2F0Y2gobm9vcCk7XG5cdGNvbnN0IGlzUmVzb2x2ZWQgPSAoKSA9PiBzdGF0dXMgIT09IFwicGVuZGluZ1wiO1xuXHRjb25zdCBjYW5jZWwgPSAoY2FuY2VsT3B0aW9ucykgPT4ge1xuXHRcdGlmICghaXNSZXNvbHZlZCgpKSB7XG5cdFx0XHRjb25zdCBlcnJvciA9IG5ldyBDYW5jZWxsZWRFcnJvcihjYW5jZWxPcHRpb25zKTtcblx0XHRcdHJlamVjdChlcnJvcik7XG5cdFx0XHRjb25maWcub25DYW5jZWw/LihlcnJvcik7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBjYW5jZWxSZXRyeSA9ICgpID0+IHtcblx0XHRpc1JldHJ5Q2FuY2VsbGVkID0gdHJ1ZTtcblx0fTtcblx0Y29uc3QgY29udGludWVSZXRyeSA9ICgpID0+IHtcblx0XHRpc1JldHJ5Q2FuY2VsbGVkID0gZmFsc2U7XG5cdH07XG5cdGNvbnN0IGNhbkNvbnRpbnVlID0gKCkgPT4gZm9jdXNNYW5hZ2VyLmlzRm9jdXNlZCgpICYmIChjb25maWcubmV0d29ya01vZGUgPT09IFwiYWx3YXlzXCIgfHwgb25saW5lTWFuYWdlci5pc09ubGluZSgpKSAmJiBjb25maWcuY2FuUnVuKCk7XG5cdGNvbnN0IGNhblN0YXJ0ID0gKCkgPT4gY2FuRmV0Y2goY29uZmlnLm5ldHdvcmtNb2RlKSAmJiBjb25maWcuY2FuUnVuKCk7XG5cdGNvbnN0IHJlc29sdmUgPSAodmFsdWUpID0+IHtcblx0XHRpZiAoIWlzUmVzb2x2ZWQoKSkge1xuXHRcdFx0Y29udGludWVGbj8uKCk7XG5cdFx0XHRzdGF0dXMgPSBcInJlc29sdmVkXCI7XG5cdFx0XHRwcm9taXNlUmVzb2x2ZSh2YWx1ZSk7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCByZWplY3QgPSAodmFsdWUpID0+IHtcblx0XHRpZiAoIWlzUmVzb2x2ZWQoKSkge1xuXHRcdFx0Y29udGludWVGbj8uKCk7XG5cdFx0XHRzdGF0dXMgPSBcInJlamVjdGVkXCI7XG5cdFx0XHRwcm9taXNlUmVqZWN0KHZhbHVlKTtcblx0XHR9XG5cdH07XG5cdGNvbnN0IHBhdXNlID0gKGNhblJlc3VtZSkgPT4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZSgoY29udGludWVSZXNvbHZlKSA9PiB7XG5cdFx0XHRjb250aW51ZUZuID0gKHZhbHVlKSA9PiB7XG5cdFx0XHRcdGlmIChpc1Jlc29sdmVkKCkgfHwgY2FuUmVzdW1lKCkpIGNvbnRpbnVlUmVzb2x2ZSh2YWx1ZSk7XG5cdFx0XHR9O1xuXHRcdFx0Y29uZmlnLm9uUGF1c2U/LigpO1xuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0Y29udGludWVGbiA9IHZvaWQgMDtcblx0XHRcdGlmICghaXNSZXNvbHZlZCgpKSBjb25maWcub25Db250aW51ZT8uKCk7XG5cdFx0fSk7XG5cdH07XG5cdGNvbnN0IHJ1biA9ICgpID0+IHtcblx0XHRpZiAoaXNSZXNvbHZlZCgpKSByZXR1cm47XG5cdFx0bGV0IHByb21pc2VPclZhbHVlO1xuXHRcdGNvbnN0IGluaXRpYWxQcm9taXNlID0gZmFpbHVyZUNvdW50ID09PSAwID8gY29uZmlnLmluaXRpYWxQcm9taXNlIDogdm9pZCAwO1xuXHRcdHRyeSB7XG5cdFx0XHRwcm9taXNlT3JWYWx1ZSA9IGluaXRpYWxQcm9taXNlID8/IGNvbmZpZy5mbigpO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRwcm9taXNlT3JWYWx1ZSA9IFByb21pc2UucmVqZWN0KGVycm9yKTtcblx0XHR9XG5cdFx0UHJvbWlzZS5yZXNvbHZlKHByb21pc2VPclZhbHVlKS50aGVuKHJlc29sdmUpLmNhdGNoKChlcnJvcikgPT4ge1xuXHRcdFx0aWYgKGlzUmVzb2x2ZWQoKSkgcmV0dXJuO1xuXHRcdFx0Y29uc3QgcmV0cnkgPSBjb25maWcucmV0cnkgPz8gKGlzU2VydmVyKCkgPyAwIDogMyk7XG5cdFx0XHRjb25zdCByZXRyeURlbGF5ID0gY29uZmlnLnJldHJ5RGVsYXkgPz8gZGVmYXVsdFJldHJ5RGVsYXk7XG5cdFx0XHRjb25zdCBkZWxheSA9IHR5cGVvZiByZXRyeURlbGF5ID09PSBcImZ1bmN0aW9uXCIgPyByZXRyeURlbGF5KGZhaWx1cmVDb3VudCwgZXJyb3IpIDogcmV0cnlEZWxheTtcblx0XHRcdGNvbnN0IHNob3VsZFJldHJ5ID0gcmV0cnkgPT09IHRydWUgfHwgdHlwZW9mIHJldHJ5ID09PSBcIm51bWJlclwiICYmIGZhaWx1cmVDb3VudCA8IHJldHJ5IHx8IHR5cGVvZiByZXRyeSA9PT0gXCJmdW5jdGlvblwiICYmIHJldHJ5KGZhaWx1cmVDb3VudCwgZXJyb3IpO1xuXHRcdFx0aWYgKGlzUmV0cnlDYW5jZWxsZWQgfHwgIXNob3VsZFJldHJ5KSB7XG5cdFx0XHRcdHJlamVjdChlcnJvcik7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGZhaWx1cmVDb3VudCsrO1xuXHRcdFx0Y29uZmlnLm9uRmFpbD8uKGZhaWx1cmVDb3VudCwgZXJyb3IpO1xuXHRcdFx0c2xlZXAoZGVsYXkpLnRoZW4oKCkgPT4ge1xuXHRcdFx0XHRyZXR1cm4gaXNSZXNvbHZlZCgpIHx8IGNhbkNvbnRpbnVlKCkgPyB2b2lkIDAgOiBwYXVzZShjYW5Db250aW51ZSk7XG5cdFx0XHR9KS50aGVuKCgpID0+IHtcblx0XHRcdFx0aWYgKGlzUmV0cnlDYW5jZWxsZWQpIHJlamVjdChlcnJvcik7XG5cdFx0XHRcdGVsc2UgcnVuKCk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fTtcblx0cmV0dXJuIHtcblx0XHRwcm9taXNlLFxuXHRcdHN0YXR1czogKCkgPT4gc3RhdHVzLFxuXHRcdGNhbmNlbCxcblx0XHRjb250aW51ZTogKCkgPT4ge1xuXHRcdFx0Y29udGludWVGbj8uKCk7XG5cdFx0XHRyZXR1cm4gcHJvbWlzZTtcblx0XHR9LFxuXHRcdGNhbmNlbFJldHJ5LFxuXHRcdGNvbnRpbnVlUmV0cnksXG5cdFx0Y2FuU3RhcnQsXG5cdFx0c3RhcnQ6ICgpID0+IHtcblx0XHRcdGlmIChjYW5TdGFydCgpKSBydW4oKTtcblx0XHRcdGVsc2UgcGF1c2UoY2FuU3RhcnQpLnRoZW4ocnVuKTtcblx0XHRcdHJldHVybiBwcm9taXNlO1xuXHRcdH1cblx0fTtcbn1cbmV4cG9ydCB7IENhbmNlbGxlZEVycm9yLCBjYW5GZXRjaCwgY3JlYXRlUmV0cnllciwgaXNDYW5jZWxsZWRFcnJvciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZXRyeWVyLmpzLm1hcCIsImltcG9ydCB7IGluZmluaXRlUXVlcnlCZWhhdmlvciB9IGZyb20gXCIuL2luZmluaXRlUXVlcnlCZWhhdmlvci5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IFJlbW92YWJsZSB9IGZyb20gXCIuL3JlbW92YWJsZS5qc1wiO1xuaW1wb3J0IHsgQ2FuY2VsbGVkRXJyb3IsIGNhbkZldGNoLCBjcmVhdGVSZXRyeWVyIH0gZnJvbSBcIi4vcmV0cnllci5qc1wiO1xuaW1wb3J0IHsgZW5zdXJlUXVlcnlGbiwgZmV0Y2hTaWduYWwsIG5vb3AsIHJlcGxhY2VEYXRhLCByZXNvbHZlUXVlcnlWYWx1ZSwgc2tpcFRva2VuLCB0aW1lVW50aWxTdGFsZSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyBzcmMvcXVlcnkudHNcbi8qKlxuKiBSZXByZXNlbnRzIGEgc2luZ2xlIGNhY2hlZCBxdWVyeS4gQSBgUXVlcnlgIGhvbGRzIHRoZSBxdWVyeSdzIGtleSwgb3B0aW9ucyxcbiogc3RhdGUgKGRhdGEvZXJyb3Ivc3RhdHVzKSwgYW5kIHRoZSBvYnNlcnZlcnMgY3VycmVudGx5IHN1YnNjcmliZWQgdG8gaXQuXG4qXG4qIEluc3RhbmNlcyBhcmUgY3JlYXRlZCBhbmQgbWFuYWdlZCBpbnRlcm5hbGx5IGJ5IGBRdWVyeUNhY2hlYDsgYXBwbGljYXRpb25cbiogY29kZSB0eXBpY2FsbHkgaW50ZXJhY3RzIHdpdGggcXVlcmllcyBpbmRpcmVjdGx5IHRocm91Z2ggYFF1ZXJ5Q2xpZW50YCBvclxuKiBhIGZyYW1ld29yayBob29rIGxpa2UgYHVzZVF1ZXJ5YC4gRGlyZWN0IGFjY2VzcyB0byBhIGBRdWVyeWAgaW5zdGFuY2UgaXNcbiogcG9zc2libGUgdmlhIGBxdWVyeUNhY2hlLmZpbmQoKWAvYGZpbmRBbGwoKWAgZm9yIGluc3BlY3RpbmcgY2FjaGUgc3RhdGUuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcbiogY29uc3QgcXVlcnkgPSBxdWVyeUNhY2hlLmZpbmQoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG4qXG4qIGlmIChxdWVyeSkge1xuKiAgIGNvbnNvbGUubG9nKHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQpXG4qIH1cbiogYGBgXG4qL1xudmFyIFF1ZXJ5ID0gY2xhc3MgZXh0ZW5kcyBSZW1vdmFibGUge1xuXHQjcXVlcnlUeXBlO1xuXHQjaW5pdGlhbFN0YXRlO1xuXHQjcmV2ZXJ0U3RhdGU7XG5cdCNjYWNoZTtcblx0I2NsaWVudDtcblx0I3JldHJ5ZXI7XG5cdCNmZXRjaFByb21pc2U7XG5cdCNkZWZhdWx0T3B0aW9ucztcblx0I2Fib3J0U2lnbmFsQ29uc3VtZWQ7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZykge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy4jYWJvcnRTaWduYWxDb25zdW1lZCA9IGZhbHNlO1xuXHRcdHRoaXMuI2RlZmF1bHRPcHRpb25zID0gY29uZmlnLmRlZmF1bHRPcHRpb25zO1xuXHRcdHRoaXMuc2V0T3B0aW9ucyhjb25maWcub3B0aW9ucyk7XG5cdFx0dGhpcy5vYnNlcnZlcnMgPSBbXTtcblx0XHR0aGlzLiNjbGllbnQgPSBjb25maWcuY2xpZW50O1xuXHRcdHRoaXMuI2NhY2hlID0gdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKTtcblx0XHR0aGlzLnF1ZXJ5S2V5ID0gY29uZmlnLnF1ZXJ5S2V5O1xuXHRcdHRoaXMucXVlcnlIYXNoID0gY29uZmlnLnF1ZXJ5SGFzaDtcblx0XHR0aGlzLiNpbml0aWFsU3RhdGUgPSBnZXREZWZhdWx0U3RhdGUodGhpcy5vcHRpb25zKTtcblx0XHR0aGlzLnN0YXRlID0gY29uZmlnLnN0YXRlID8/IHRoaXMuI2luaXRpYWxTdGF0ZTtcblx0XHR0aGlzLnNjaGVkdWxlR2MoKTtcblx0fVxuXHQvKipcblx0KiBUaGUgYG1ldGFgIG9iamVjdCBwYXNzZWQgaW4gdGhlIHF1ZXJ5J3Mgb3B0aW9ucywgaWYgYW55LlxuXHQqIEByZXR1cm5zIFRoZSBxdWVyeSdzIGBtZXRhYCwgb3IgYHVuZGVmaW5lZGAgaWYgbm9uZSB3YXMgc2V0LlxuXHQqL1xuXHRnZXQgbWV0YSgpIHtcblx0XHRyZXR1cm4gdGhpcy5vcHRpb25zLm1ldGE7XG5cdH1cblx0LyoqXG5cdCogYCdpbmZpbml0ZSdgIGZvciBhbiBpbmZpbml0ZSBxdWVyeSwgb3RoZXJ3aXNlIGB1bmRlZmluZWRgLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEByZXR1cm5zIFRoZSB0eXBlIG9mIHRoZSBxdWVyeSwgc2V0IGZyb20gdGhlIGBfdHlwZWAgb3B0aW9uIChlLmcuIGAnaW5maW5pdGUnYCkuXG5cdCovXG5cdGdldCBxdWVyeVR5cGUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJ5VHlwZTtcblx0fVxuXHQvKipcblx0KiBUaGUgcHJvbWlzZSBmb3IgdGhlIGN1cnJlbnRseSBpbi1mbGlnaHQgZmV0Y2gsIGlmIHRoZSBxdWVyeSBpcyBmZXRjaGluZy5cblx0KiBgdW5kZWZpbmVkYCB3aGVuIHRoZSBxdWVyeSBpcyBub3QgZmV0Y2hpbmcuXG5cdCogQHJldHVybnMgVGhlIHByb21pc2Ugb2YgdGhlIGluLWZsaWdodCBmZXRjaCwgb3IgYHVuZGVmaW5lZGAuXG5cdCovXG5cdGdldCBwcm9taXNlKCkge1xuXHRcdHJldHVybiB0aGlzLiNyZXRyeWVyPy5wcm9taXNlO1xuXHR9XG5cdC8qKlxuXHQqIFJlcGxhY2VzIHRoZSBxdWVyeSdzIG9wdGlvbnMgYW5kIGFwcGxpZXMgdGhlaXIgYGdjVGltZWAuIElmIHRoZSBxdWVyeSBoYXMgbm8gZGF0YSB5ZXQsIGl0IGdldHNcblx0KiB0aGUgYGluaXRpYWxEYXRhYCBmcm9tIHRoZSBuZXcgb3B0aW9ucywgaWYgYW55LlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG5ldyBxdWVyeSBvcHRpb25zLCBtZXJnZWQgb24gdG9wIG9mIHRoZSBxdWVyeSdzIGRlZmF1bHQgb3B0aW9ucy5cblx0Ki9cblx0c2V0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0dGhpcy5vcHRpb25zID0ge1xuXHRcdFx0Li4udGhpcy4jZGVmYXVsdE9wdGlvbnMsXG5cdFx0XHQuLi5vcHRpb25zXG5cdFx0fTtcblx0XHRpZiAob3B0aW9ucz8uX3R5cGUpIHRoaXMuI3F1ZXJ5VHlwZSA9IG9wdGlvbnMuX3R5cGU7XG5cdFx0dGhpcy51cGRhdGVHY1RpbWUodGhpcy5vcHRpb25zLmdjVGltZSk7XG5cdFx0aWYgKHRoaXMuc3RhdGUgJiYgdGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDApIHtcblx0XHRcdGNvbnN0IGRlZmF1bHRTdGF0ZSA9IGdldERlZmF1bHRTdGF0ZSh0aGlzLm9wdGlvbnMpO1xuXHRcdFx0aWYgKGRlZmF1bHRTdGF0ZS5kYXRhICE9PSB2b2lkIDApIHtcblx0XHRcdFx0dGhpcy5zZXRTdGF0ZShzdWNjZXNzU3RhdGUoZGVmYXVsdFN0YXRlLmRhdGEsIGRlZmF1bHRTdGF0ZS5kYXRhVXBkYXRlZEF0KSk7XG5cdFx0XHRcdHRoaXMuI2luaXRpYWxTdGF0ZSA9IGRlZmF1bHRTdGF0ZTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblx0b3B0aW9uYWxSZW1vdmUoKSB7XG5cdFx0aWYgKCF0aGlzLm9ic2VydmVycy5sZW5ndGggJiYgdGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJpZGxlXCIpIHRoaXMuI2NhY2hlLnJlbW92ZSh0aGlzKTtcblx0fVxuXHQvKipcblx0KiBXcml0ZXMgbmV3IGRhdGEgdG8gdGhlIHF1ZXJ5IGFuZCBtYXJrcyBpdCBhcyBzdWNjZXNzZnVsbHkgZmV0Y2hlZC5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gbmV3RGF0YSAtIFRoZSBkYXRhIHRvIHdyaXRlLiBTdHJ1Y3R1cmFsIHNoYXJpbmcgd2l0aCB0aGUgY3VycmVudCBkYXRhIGlzIGFwcGxpZWQuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBTZXQgYHVwZGF0ZWRBdGAgdG8gb3ZlcnJpZGUgdGhlIHRpbWVzdGFtcCwgYW5kIGBtYW51YWxgIHRvIG1hcmsgdGhlIHdyaXRlIGFzXG5cdCogbWFudWFsIChlLmcuIGZyb20gYHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGF0YWApLlxuXHQqIEByZXR1cm5zIFRoZSBkYXRhIHRoYXQgd2FzIHdyaXR0ZW4uXG5cdCovXG5cdHNldERhdGEobmV3RGF0YSwgb3B0aW9ucykge1xuXHRcdGNvbnN0IGRhdGEgPSByZXBsYWNlRGF0YSh0aGlzLnN0YXRlLmRhdGEsIG5ld0RhdGEsIHRoaXMub3B0aW9ucyk7XG5cdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0ZGF0YSxcblx0XHRcdHR5cGU6IFwic3VjY2Vzc1wiLFxuXHRcdFx0ZGF0YVVwZGF0ZWRBdDogb3B0aW9ucz8udXBkYXRlZEF0LFxuXHRcdFx0bWFudWFsOiBvcHRpb25zPy5tYW51YWxcblx0XHR9KTtcblx0XHRyZXR1cm4gZGF0YTtcblx0fVxuXHQvKipcblx0KiBNZXJnZXMgdGhlIGdpdmVuIHBhcnRpYWwgc3RhdGUgZGlyZWN0bHkgaW50byB0aGlzIHF1ZXJ5J3Mgc3RhdGUsIG5vdGlmeWluZyBvYnNlcnZlcnMuIFVzZWRcblx0KiBieSBwZXJzaXN0ZW5jZSBhbmQgYnJvYWRjYXN0IHBsdWdpbnMgdG8gcmVzdG9yZSBhIHN0YXRlIHNuYXBzaG90LCBhbmQgYnkgZGV2dG9vbHMgdG8gbGV0IGFcblx0KiB1c2VyIG1hbnVhbGx5IHRyaWdnZXIgYSBsb2FkaW5nL2Vycm9yIHN0YXRlIG9yIGVkaXQgdGhlIGNhY2hlZCBkYXRhLlxuXHQqIEBwYXJhbSBzdGF0ZSAtIFRoZSBwYXJ0aWFsIHN0YXRlIHRvIG1lcmdlIGludG8gdGhlIHF1ZXJ5J3Mgc3RhdGUuXG5cdCovXG5cdHNldFN0YXRlKHN0YXRlKSB7XG5cdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0dHlwZTogXCJzZXRTdGF0ZVwiLFxuXHRcdFx0c3RhdGVcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBDYW5jZWxzIHRoZSBxdWVyeSdzIGN1cnJlbnRseSBpbi1mbGlnaHQgZmV0Y2gsIGlmIGFueS5cblx0KiAtIFJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgY2FuY2VsbGF0aW9uIGhhcyBzZXR0bGVkLlxuXHQqIC0gSWYgbm8gZmV0Y2ggaXMgaW4gcHJvZ3Jlc3MsIHJlc29sdmVzIGltbWVkaWF0ZWx5LlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gU2V0IGByZXZlcnRgIHRvIHJlc3RvcmUgdGhlIHN0YXRlIGZyb20gYmVmb3JlIHRoZSBmZXRjaCBzdGFydGVkLCBhbmQgYHNpbGVudGBcblx0KiB0byBzdXBwcmVzcyB0aGUgY2FuY2VsbGF0aW9uIGVycm9yIHdoZW4gYSBuZXcgZmV0Y2ggcmVwbGFjZXMgdGhlIGNhbmNlbGxlZCBvbmUuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgY2FuY2VsbGF0aW9uIGhhcyBzZXR0bGVkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeS5jYW5jZWwoKVxuXHQqIGBgYFxuXHQqL1xuXHRjYW5jZWwob3B0aW9ucykge1xuXHRcdGNvbnN0IHByb21pc2UgPSB0aGlzLiNyZXRyeWVyPy5wcm9taXNlO1xuXHRcdHRoaXMuI3JldHJ5ZXI/LmNhbmNlbChvcHRpb25zKTtcblx0XHRyZXR1cm4gcHJvbWlzZSA/IHByb21pc2UudGhlbihub29wKS5jYXRjaChub29wKSA6IFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdC8qKlxuXHQqIFNpbGVudGx5IGNhbmNlbHMgYW55IGluLWZsaWdodCBmZXRjaCwgdGhlbiBjbGVhcnMgdGhlIHF1ZXJ5J3MgZ2FyYmFnZVxuXHQqIGNvbGxlY3Rpb24gdGltZW91dC4gQ2FsbGVkIGJ5IGBRdWVyeUNhY2hlYCB3aGVuIHRoZSBxdWVyeSBpcyByZW1vdmVkIGZyb21cblx0KiB0aGUgY2FjaGUuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnkjY2FuY2VsfVxuXHQqL1xuXHRkZXN0cm95KCkge1xuXHRcdHRoaXMuY2FuY2VsKHsgc2lsZW50OiB0cnVlIH0pO1xuXHRcdHN1cGVyLmRlc3Ryb3koKTtcblx0fVxuXHQvKipcblx0KiBUaGUgc3RhdGUgdGhlIHF1ZXJ5IHdhcyBjcmVhdGVkIHdpdGguXG5cdCogQGludGVybmFsXG5cdCogQHJldHVybnMgVGhlIHN0YXRlIHRoZSBxdWVyeSBoYWQgd2hlbiBpdCB3YXMgZmlyc3QgY3JlYXRlZCwgdXNlZCBieSB7QGxpbmsgUXVlcnkjcmVzZXR9LlxuXHQqL1xuXHRnZXQgcmVzZXRTdGF0ZSgpIHtcblx0XHRyZXR1cm4gdGhpcy4jaW5pdGlhbFN0YXRlO1xuXHR9XG5cdC8qKlxuXHQqIFJlc2V0cyB0aGUgcXVlcnkgYmFjayB0byBpdHMgaW5pdGlhbCBzdGF0ZSAodGhlIHN0YXRlIGl0IGhhZCB3aGVuIGl0IHdhc1xuXHQqIGZpcnN0IGNyZWF0ZWQsIGUuZy4gYW55IGBpbml0aWFsRGF0YWApLCBkZXN0cm95aW5nIGl0IGZpcnN0IHRvIGNhbmNlbCBhbnlcblx0KiBpbi1mbGlnaHQgZmV0Y2guXG5cdCovXG5cdHJlc2V0KCkge1xuXHRcdHRoaXMuZGVzdHJveSgpO1xuXHRcdHRoaXMuc2V0U3RhdGUodGhpcy5yZXNldFN0YXRlKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaGFzIGF0IGxlYXN0IG9uZSBvYnNlcnZlciBmb3Igd2hpY2ggYGVuYWJsZWRgXG5cdCogZG9lcyBub3QgcmVzb2x2ZSB0byBgZmFsc2VgLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaGFzIGFuIGVuYWJsZWQgb2JzZXJ2ZXIuXG5cdCovXG5cdGlzQWN0aXZlKCkge1xuXHRcdHJldHVybiB0aGlzLm9ic2VydmVycy5zb21lKChvYnNlcnZlcikgPT4gcmVzb2x2ZVF1ZXJ5VmFsdWUob2JzZXJ2ZXIub3B0aW9ucy5lbmFibGVkLCB0aGlzKSAhPT0gZmFsc2UpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBkaXNhYmxlZCwgbWVhbmluZyBpdCB3aWxsIG5vdCBmZXRjaFxuXHQqIGF1dG9tYXRpY2FsbHkuXG5cdCogLSBJZiB0aGUgcXVlcnkgaGFzIG9ic2VydmVycywgaXQgaXMgZGlzYWJsZWQgd2hlbiBub25lIG9mIHRoZW0gYXJlIGFjdGl2ZVxuXHQqICAgKHNlZSBgaXNBY3RpdmVgKS5cblx0KiAtIElmIHRoZSBxdWVyeSBoYXMgbm8gb2JzZXJ2ZXJzLCBpdCBpcyBkaXNhYmxlZCB3aGVuIGl0cyBgcXVlcnlGbmAgaXNcblx0KiAgIGBza2lwVG9rZW5gIG9yIGl0IGhhcyBuZXZlciBiZWVuIGZldGNoZWQuXG5cdCogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBkaXNhYmxlZC5cblx0Ki9cblx0aXNEaXNhYmxlZCgpIHtcblx0XHRpZiAodGhpcy5nZXRPYnNlcnZlcnNDb3VudCgpID4gMCkgcmV0dXJuICF0aGlzLmlzQWN0aXZlKCk7XG5cdFx0cmV0dXJuIHRoaXMub3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4gfHwgIXRoaXMuaXNGZXRjaGVkKCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBiZWVuIGZldGNoZWQsIGkuZS4gaXQgaGFzIHJlc29sdmVkIHdpdGhcblx0KiBlaXRoZXIgZGF0YSBvciBhbiBlcnJvciBhdCBsZWFzdCBvbmNlLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaGFzIGJlZW4gZmV0Y2hlZC5cblx0Ki9cblx0aXNGZXRjaGVkKCkge1xuXHRcdHJldHVybiB0aGlzLnN0YXRlLmRhdGFVcGRhdGVDb3VudCArIHRoaXMuc3RhdGUuZXJyb3JVcGRhdGVDb3VudCA+IDA7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBkYXRhIGFuZCBhdCBsZWFzdCBvbmUgb2JzZXJ2ZXIgY29uZmlndXJlZCB3aXRoXG5cdCogYHN0YWxlVGltZTogJ3N0YXRpYydgLCBtZWFuaW5nIGl0IGlzIHRyZWF0ZWQgYXMgbmV2ZXIgc3RhbGUuXG5cdCogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBzdGF0aWMuXG5cdCovXG5cdGlzU3RhdGljKCkge1xuXHRcdGlmICh0aGlzLnN0YXRlLmRhdGEgPT09IHZvaWQgMCkgcmV0dXJuIGZhbHNlO1xuXHRcdGlmICh0aGlzLmdldE9ic2VydmVyc0NvdW50KCkgPiAwKSByZXR1cm4gdGhpcy5vYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIpID0+IHJlc29sdmVRdWVyeVZhbHVlKG9ic2VydmVyLm9wdGlvbnMuc3RhbGVUaW1lLCB0aGlzKSA9PT0gXCJzdGF0aWNcIik7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBzdGFsZS5cblx0KiAtIElmIHRoZSBxdWVyeSBoYXMgb2JzZXJ2ZXJzLCBkZWZlcnMgdG8gd2hldGhlciBhbnkgb2JzZXJ2ZXIncyBjdXJyZW50XG5cdCogICByZXN1bHQgcmVwb3J0cyBgaXNTdGFsZWAgKHdoaWNoIGFjY291bnRzIGZvciBlYWNoIG9ic2VydmVyJ3Mgb3duXG5cdCogICBgc3RhbGVUaW1lYCBhbmQgYGVuYWJsZWRgIHN0YXRlKS5cblx0KiAtIElmIHRoZSBxdWVyeSBoYXMgbm8gb2JzZXJ2ZXJzLCBpdCBpcyBjb25zaWRlcmVkIHN0YWxlIHdoZW4gaXQgaGFzIG5vXG5cdCogICBkYXRhIG9yIGhhcyBiZWVuIGludmFsaWRhdGVkLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaXMgc3RhbGUuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnkjaXNTdGFsZUJ5VGltZX1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaWYgKHF1ZXJ5LmlzU3RhbGUoKSkge1xuXHQqICAgLy8gcmVmZXRjaCBvciBvdGhlcndpc2UgdHJlYXQgdGhlIGNhY2hlZCBkYXRhIGFzIG91dGRhdGVkXG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRpc1N0YWxlKCkge1xuXHRcdGlmICh0aGlzLmdldE9ic2VydmVyc0NvdW50KCkgPiAwKSByZXR1cm4gdGhpcy5vYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKS5pc1N0YWxlKTtcblx0XHRyZXR1cm4gdGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDAgfHwgdGhpcy5zdGF0ZS5pc0ludmFsaWRhdGVkO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSdzIGRhdGEgaXMgc3RhbGUgcmVsYXRpdmUgdG8gdGhlIGdpdmVuXG5cdCogYHN0YWxlVGltZWAgKGRlZmF1bHRzIHRvIGAwYCkuXG5cdCogLSBBIHF1ZXJ5IHdpdGggbm8gZGF0YSBpcyBhbHdheXMgc3RhbGUuXG5cdCogLSBgc3RhbGVUaW1lOiAnc3RhdGljJ2AgaXMgbmV2ZXIgc3RhbGUuXG5cdCogLSBBbiBpbnZhbGlkYXRlZCBxdWVyeSBpcyBhbHdheXMgc3RhbGUuXG5cdCogLSBPdGhlcndpc2UsIHN0YWxlbmVzcyBpcyBiYXNlZCBvbiBlbGFwc2VkIHRpbWUgc2luY2UgYGRhdGFVcGRhdGVkQXRgLlxuXHQqIEBwYXJhbSBzdGFsZVRpbWUgLSBUaGUgdGltZSwgaW4gbWlsbGlzZWNvbmRzLCBhZnRlciB3aGljaCBkYXRhIGlzIGNvbnNpZGVyZWQgc3RhbGUsIG9yXG5cdCogYCdzdGF0aWMnYCB0byBuZXZlciB0cmVhdCBleGlzdGluZyBkYXRhIGFzIHN0YWxlLiBBIHF1ZXJ5IHdpdGhvdXQgZGF0YSBpcyBzdGFsZSBlaXRoZXIgd2F5LlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkncyBkYXRhIGlzIHN0YWxlLlxuXHQqIEBzZWUge0BsaW5rIFF1ZXJ5I2lzU3RhbGV9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IGlzU3RhbGUgPSBxdWVyeS5pc1N0YWxlQnlUaW1lKDYwICogMTAwMClcblx0KiBgYGBcblx0Ki9cblx0aXNTdGFsZUJ5VGltZShzdGFsZVRpbWUgPSAwKSB7XG5cdFx0aWYgKHRoaXMuc3RhdGUuZGF0YSA9PT0gdm9pZCAwKSByZXR1cm4gdHJ1ZTtcblx0XHRpZiAoc3RhbGVUaW1lID09PSBcInN0YXRpY1wiKSByZXR1cm4gZmFsc2U7XG5cdFx0aWYgKHRoaXMuc3RhdGUuaXNJbnZhbGlkYXRlZCkgcmV0dXJuIHRydWU7XG5cdFx0cmV0dXJuICF0aW1lVW50aWxTdGFsZSh0aGlzLnN0YXRlLmRhdGFVcGRhdGVkQXQsIHN0YWxlVGltZSk7XG5cdH1cblx0LyoqXG5cdCogUmVmZXRjaGVzIHRoZSBxdWVyeSB3aGVuIHRoZSB3aW5kb3cgcmVnYWlucyBmb2N1cywgaWYgYW4gb2JzZXJ2ZXIgd2FudHMgdGhhdCwgYW5kIGNvbnRpbnVlcyBhXG5cdCogcGF1c2VkIGZldGNoLlxuXHQqIEBpbnRlcm5hbFxuXHQqL1xuXHRvbkZvY3VzKCkge1xuXHRcdHRoaXMub2JzZXJ2ZXJzLmZpbmQoKHgpID0+IHguc2hvdWxkRmV0Y2hPbldpbmRvd0ZvY3VzKCkpPy5yZWZldGNoKHsgY2FuY2VsUmVmZXRjaDogZmFsc2UgfSk7XG5cdFx0dGhpcy4jcmV0cnllcj8uY29udGludWUoKTtcblx0fVxuXHQvKipcblx0KiBSZWZldGNoZXMgdGhlIHF1ZXJ5IHdoZW4gdGhlIGFwcCByZWNvbm5lY3RzLCBpZiBhbiBvYnNlcnZlciB3YW50cyB0aGF0LCBhbmQgY29udGludWVzIGEgcGF1c2VkXG5cdCogZmV0Y2guXG5cdCogQGludGVybmFsXG5cdCovXG5cdG9uT25saW5lKCkge1xuXHRcdHRoaXMub2JzZXJ2ZXJzLmZpbmQoKHgpID0+IHguc2hvdWxkRmV0Y2hPblJlY29ubmVjdCgpKT8ucmVmZXRjaCh7IGNhbmNlbFJlZmV0Y2g6IGZhbHNlIH0pO1xuXHRcdHRoaXMuI3JldHJ5ZXI/LmNvbnRpbnVlKCk7XG5cdH1cblx0LyoqXG5cdCogU3Vic2NyaWJlcyBhbiBvYnNlcnZlciB0byB0aGUgcXVlcnkgYW5kIHN0b3BzIGl0cyBnYXJiYWdlIGNvbGxlY3Rpb24uXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG9ic2VydmVyIC0gVGhlIG9ic2VydmVyIHRvIGFkZC4gQWRkaW5nIGFuIG9ic2VydmVyIHRoYXQgaXMgYWxyZWFkeSBzdWJzY3JpYmVkIGRvZXNcblx0KiBub3RoaW5nLlxuXHQqL1xuXHRhZGRPYnNlcnZlcihvYnNlcnZlcikge1xuXHRcdGlmICghdGhpcy5vYnNlcnZlcnMuaW5jbHVkZXMob2JzZXJ2ZXIpKSB7XG5cdFx0XHR0aGlzLm9ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcblx0XHRcdHRoaXMuY2xlYXJHY1RpbWVvdXQoKTtcblx0XHRcdHRoaXMuI2NhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJBZGRlZFwiLFxuXHRcdFx0XHRxdWVyeTogdGhpcyxcblx0XHRcdFx0b2JzZXJ2ZXJcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBVbnN1YnNjcmliZXMgYW4gb2JzZXJ2ZXIgZnJvbSB0aGUgcXVlcnkuXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG9ic2VydmVyIC0gVGhlIG9ic2VydmVyIHRvIHJlbW92ZS4gV2hlbiB0aGUgbGFzdCBvYnNlcnZlciBpcyByZW1vdmVkLCB0aGUgaW4tZmxpZ2h0XG5cdCogZmV0Y2ggaXMgY2FuY2VsbGVkIGlmIGl0cyBhYm9ydCBzaWduYWwgd2FzIGNvbnN1bWVkIChvdGhlcndpc2Ugb25seSBpdHMgcmV0cmllcyBhcmUgc3RvcHBlZCksXG5cdCogYW5kIGdhcmJhZ2UgY29sbGVjdGlvbiBpcyBzY2hlZHVsZWQgaWYgdGhlIHF1ZXJ5IGlzIHN0aWxsIGluIHRoZSBjYWNoZS5cblx0Ki9cblx0cmVtb3ZlT2JzZXJ2ZXIob2JzZXJ2ZXIpIHtcblx0XHRjb25zdCBpbmRleCA9IHRoaXMub2JzZXJ2ZXJzLmluZGV4T2Yob2JzZXJ2ZXIpO1xuXHRcdGlmIChpbmRleCAhPT0gLTEpIHtcblx0XHRcdHRoaXMub2JzZXJ2ZXJzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0XHRpZiAoIXRoaXMub2JzZXJ2ZXJzLmxlbmd0aCkge1xuXHRcdFx0XHRpZiAodGhpcy4jcmV0cnllcikge1xuXHRcdFx0XHRcdGlmICh0aGlzLiNhYm9ydFNpZ25hbENvbnN1bWVkIHx8IHRoaXMuc3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwicGF1c2VkXCIgJiYgdGhpcy5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiKSB0aGlzLiNyZXRyeWVyLmNhbmNlbCh7IHJldmVydDogdHJ1ZSB9KTtcblx0XHRcdFx0XHRlbHNlIHRoaXMuI3JldHJ5ZXIuY2FuY2VsUmV0cnkoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLiNzY2hlZHVsZUdjSWZDYWNoZWQoKTtcblx0XHRcdH1cblx0XHRcdHRoaXMuI2NhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJSZW1vdmVkXCIsXG5cdFx0XHRcdHF1ZXJ5OiB0aGlzLFxuXHRcdFx0XHRvYnNlcnZlclxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG51bWJlciBvZiBvYnNlcnZlcnMgY3VycmVudGx5IHN1YnNjcmliZWQgdG8gdGhpcyBxdWVyeS5cblx0KiBAcmV0dXJucyBUaGUgbnVtYmVyIG9mIG9ic2VydmVycy5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaWYgKHF1ZXJ5LmdldE9ic2VydmVyc0NvdW50KCkgPT09IDApIHtcblx0KiAgIC8vIG5vIGNvbXBvbmVudCBpcyBjdXJyZW50bHkgd2F0Y2hpbmcgdGhpcyBxdWVyeVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0Z2V0T2JzZXJ2ZXJzQ291bnQoKSB7XG5cdFx0cmV0dXJuIHRoaXMub2JzZXJ2ZXJzLmxlbmd0aDtcblx0fVxuXHQvKipcblx0KiBNYXJrcyB0aGUgcXVlcnkgYXMgaW52YWxpZGF0ZWQsIHVubGVzcyBpdCBpcyBhbHJlYWR5IGludmFsaWRhdGVkLiBUaGlzXG5cdCogdXBkYXRlcyBgc3RhdGUuaXNJbnZhbGlkYXRlZGAgYW5kIG5vdGlmaWVzIG9ic2VydmVycywgYnV0IGRvZXMgbm90IGJ5XG5cdCogaXRzZWxmIHRyaWdnZXIgYSByZWZldGNoLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeS5pbnZhbGlkYXRlKClcblx0KiBgYGBcblx0Ki9cblx0aW52YWxpZGF0ZSgpIHtcblx0XHRpZiAoIXRoaXMuc3RhdGUuaXNJbnZhbGlkYXRlZCkgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcImludmFsaWRhdGVcIiB9KTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIHRoZSBxdWVyeSwgaS5lLiBydW5zIGl0cyBgcXVlcnlGbmAgKHRocm91Z2ggYW55IGNvbmZpZ3VyZWRcblx0KiByZXRyeWVyL2JlaGF2aW9yKSBhbmQgdXBkYXRlcyB0aGUgcXVlcnkncyBzdGF0ZSB3aXRoIHRoZSByZXN1bHQuXG5cdCogLSBJZiBhIGZldGNoIGlzIGFscmVhZHkgaW4gZmxpZ2h0LCByZXR1cm5zIGl0cyBwcm9taXNlIGluc3RlYWQgb2Zcblx0KiAgIHN0YXJ0aW5nIGEgbmV3IG9uZSwgdW5sZXNzIGBmZXRjaE9wdGlvbnMuY2FuY2VsUmVmZXRjaGAgaXMgc2V0IGFuZCB0aGVcblx0KiAgIHF1ZXJ5IGFscmVhZHkgaGFzIGRhdGEsIGluIHdoaWNoIGNhc2UgdGhlIGN1cnJlbnQgZmV0Y2ggaXMgc2lsZW50bHlcblx0KiAgIGNhbmNlbGxlZCBmaXJzdC5cblx0KiAtIElmIGBvcHRpb25zYCBpcyBwYXNzZWQsIGl0IHJlcGxhY2VzIHRoZSBxdWVyeSdzIGN1cnJlbnQgb3B0aW9uc1xuXHQqICAgYmVmb3JlIGZldGNoaW5nLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gUXVlcnkgb3B0aW9ucyB0aGF0IHJlcGxhY2UgdGhlIHF1ZXJ5J3MgY3VycmVudCBvcHRpb25zIGJlZm9yZSBmZXRjaGluZy4gVGhleVxuXHQqIGFyZSBub3QgYXBwbGllZCB3aGVuIGFuIGluLWZsaWdodCBmZXRjaCBpcyByZXVzZWQuXG5cdCogQHBhcmFtIGZldGNoT3B0aW9ucyAtIFNldCBgY2FuY2VsUmVmZXRjaGAgdG8gY2FuY2VsIGFuIGluLWZsaWdodCBmZXRjaCBmaXJzdCAob25seSBpZiB0aGUgcXVlcnlcblx0KiBhbHJlYWR5IGhhcyBkYXRhKSwgYW5kIGBtZXRhYCB0byBwYXNzIGV4dHJhIGluZm9ybWF0aW9uIHRvIHRoZSBxdWVyeSdzIGJlaGF2aW9yLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIGZldGNoZWQgZGF0YSwgb3IgcmVqZWN0cyB3aXRoIHRoZSBmZXRjaCBlcnJvci4gSWYgdGhlXG5cdCogZmV0Y2ggaXMgY2FuY2VsbGVkIHdpdGggYHJldmVydGAgd2hpbGUgdGhlIHF1ZXJ5IGhhcyBkYXRhLCBpdCByZXNvbHZlcyB3aXRoIHRoZSByZXN0b3JlZCBkYXRhXG5cdCogaW5zdGVhZC5cblx0Ki9cblx0YXN5bmMgZmV0Y2gob3B0aW9ucywgZmV0Y2hPcHRpb25zKSB7XG5cdFx0aWYgKHRoaXMuc3RhdGUuZmV0Y2hTdGF0dXMgIT09IFwiaWRsZVwiICYmIHRoaXMuI3JldHJ5ZXI/LnN0YXR1cygpICE9PSBcInJlamVjdGVkXCIpIHtcblx0XHRcdGlmICh0aGlzLnN0YXRlLmRhdGEgIT09IHZvaWQgMCAmJiBmZXRjaE9wdGlvbnM/LmNhbmNlbFJlZmV0Y2gpIHRoaXMuY2FuY2VsKHsgc2lsZW50OiB0cnVlIH0pO1xuXHRcdFx0ZWxzZSBpZiAodGhpcy4jcmV0cnllciAmJiB0aGlzLiNmZXRjaFByb21pc2UpIHtcblx0XHRcdFx0dGhpcy4jcmV0cnllci5jb250aW51ZVJldHJ5KCk7XG5cdFx0XHRcdHJldHVybiB0aGlzLiNmZXRjaFByb21pc2U7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmIChvcHRpb25zKSB0aGlzLnNldE9wdGlvbnMob3B0aW9ucyk7XG5cdFx0aWYgKCF0aGlzLm9wdGlvbnMucXVlcnlGbikge1xuXHRcdFx0Y29uc3Qgb2JzZXJ2ZXIgPSB0aGlzLm9ic2VydmVycy5maW5kKCh4KSA9PiB4Lm9wdGlvbnMucXVlcnlGbik7XG5cdFx0XHRpZiAob2JzZXJ2ZXIpIHRoaXMuc2V0T3B0aW9ucyhvYnNlcnZlci5vcHRpb25zKTtcblx0XHR9XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0aWYgKCFBcnJheS5pc0FycmF5KHRoaXMub3B0aW9ucy5xdWVyeUtleSkpIGNvbnNvbGUuZXJyb3IoYEFzIG9mIHY0LCBxdWVyeUtleSBuZWVkcyB0byBiZSBhbiBBcnJheS4gSWYgeW91IGFyZSB1c2luZyBhIHN0cmluZyBsaWtlICdyZXBvRGF0YScsIHBsZWFzZSBjaGFuZ2UgaXQgdG8gYW4gQXJyYXksIGUuZy4gWydyZXBvRGF0YSddYCk7XG5cdFx0fVxuXHRcdGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRjb25zdCBhZGRTaWduYWxQcm9wZXJ0eSA9IChvYmplY3QpID0+IHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKG9iamVjdCwge1xuXHRcdFx0XHRbZmV0Y2hTaWduYWxdOiB7XG5cdFx0XHRcdFx0dmFsdWU6IGFib3J0Q29udHJvbGxlci5zaWduYWwsXG5cdFx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZVxuXHRcdFx0XHR9LFxuXHRcdFx0XHRzaWduYWw6IHtcblx0XHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0XHRcdGdldDogKCkgPT4ge1xuXHRcdFx0XHRcdFx0dGhpcy4jYWJvcnRTaWduYWxDb25zdW1lZCA9IHRydWU7XG5cdFx0XHRcdFx0XHRyZXR1cm4gYWJvcnRDb250cm9sbGVyLnNpZ25hbDtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0Y29uc3QgZmV0Y2hGbiA9ICgpID0+IHtcblx0XHRcdGNvbnN0IHF1ZXJ5Rm4gPSBlbnN1cmVRdWVyeUZuKHRoaXMub3B0aW9ucywgZmV0Y2hPcHRpb25zKTtcblx0XHRcdGNvbnN0IGNyZWF0ZVF1ZXJ5Rm5Db250ZXh0ID0gKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBxdWVyeUZuQ29udGV4dCA9IHtcblx0XHRcdFx0XHRjbGllbnQ6IHRoaXMuI2NsaWVudCxcblx0XHRcdFx0XHRxdWVyeUtleTogdGhpcy5xdWVyeUtleSxcblx0XHRcdFx0XHRtZXRhOiB0aGlzLm1ldGFcblx0XHRcdFx0fTtcblx0XHRcdFx0YWRkU2lnbmFsUHJvcGVydHkocXVlcnlGbkNvbnRleHQpO1xuXHRcdFx0XHRyZXR1cm4gcXVlcnlGbkNvbnRleHQ7XG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgcXVlcnlGbkNvbnRleHQgPSBjcmVhdGVRdWVyeUZuQ29udGV4dCgpO1xuXHRcdFx0dGhpcy4jYWJvcnRTaWduYWxDb25zdW1lZCA9IGZhbHNlO1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy5wZXJzaXN0ZXIpIHJldHVybiB0aGlzLm9wdGlvbnMucGVyc2lzdGVyKHF1ZXJ5Rm4sIHF1ZXJ5Rm5Db250ZXh0LCB0aGlzKTtcblx0XHRcdHJldHVybiBxdWVyeUZuKHF1ZXJ5Rm5Db250ZXh0KTtcblx0XHR9O1xuXHRcdGNvbnN0IGNyZWF0ZUZldGNoQ29udGV4dCA9ICgpID0+IHtcblx0XHRcdGNvbnN0IGNvbnRleHQgPSB7XG5cdFx0XHRcdGZldGNoT3B0aW9ucyxcblx0XHRcdFx0b3B0aW9uczogdGhpcy5vcHRpb25zLFxuXHRcdFx0XHRxdWVyeUtleTogdGhpcy5xdWVyeUtleSxcblx0XHRcdFx0Y2xpZW50OiB0aGlzLiNjbGllbnQsXG5cdFx0XHRcdHN0YXRlOiB0aGlzLnN0YXRlLFxuXHRcdFx0XHRmZXRjaEZuXG5cdFx0XHR9O1xuXHRcdFx0YWRkU2lnbmFsUHJvcGVydHkoY29udGV4dCk7XG5cdFx0XHRyZXR1cm4gY29udGV4dDtcblx0XHR9O1xuXHRcdGNvbnN0IGNvbnRleHQgPSBjcmVhdGVGZXRjaENvbnRleHQoKTtcblx0XHQodGhpcy4jcXVlcnlUeXBlID09PSBcImluZmluaXRlXCIgPyBpbmZpbml0ZVF1ZXJ5QmVoYXZpb3IodGhpcy5vcHRpb25zLnBhZ2VzKSA6IHRoaXMub3B0aW9ucy5iZWhhdmlvcik/Lm9uRmV0Y2goY29udGV4dCwgdGhpcyk7XG5cdFx0dGhpcy4jcmV2ZXJ0U3RhdGUgPSB0aGlzLnN0YXRlO1xuXHRcdGlmICh0aGlzLnN0YXRlLmZldGNoU3RhdHVzID09PSBcImlkbGVcIiB8fCB0aGlzLnN0YXRlLmZldGNoTWV0YSAhPT0gY29udGV4dC5mZXRjaE9wdGlvbnM/Lm1ldGEpIHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdHR5cGU6IFwiZmV0Y2hcIixcblx0XHRcdG1ldGE6IGNvbnRleHQuZmV0Y2hPcHRpb25zPy5tZXRhXG5cdFx0fSk7XG5cdFx0Y29uc3QgcmV0cnllciA9IHRoaXMuI3JldHJ5ZXIgPSBjcmVhdGVSZXRyeWVyKHtcblx0XHRcdGluaXRpYWxQcm9taXNlOiBmZXRjaE9wdGlvbnM/LmluaXRpYWxQcm9taXNlLFxuXHRcdFx0Zm46IGNvbnRleHQuZmV0Y2hGbixcblx0XHRcdG9uQ2FuY2VsOiAoZXJyb3IpID0+IHtcblx0XHRcdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3IgJiYgZXJyb3IucmV2ZXJ0KSB0aGlzLnNldFN0YXRlKHtcblx0XHRcdFx0XHQuLi50aGlzLiNyZXZlcnRTdGF0ZSxcblx0XHRcdFx0XHRmZXRjaFN0YXR1czogXCJpZGxlXCJcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xuXHRcdFx0fSxcblx0XHRcdG9uRmFpbDogKGZhaWx1cmVDb3VudCwgZXJyb3IpID0+IHtcblx0XHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHRcdHR5cGU6IFwiZmFpbGVkXCIsXG5cdFx0XHRcdFx0ZmFpbHVyZUNvdW50LFxuXHRcdFx0XHRcdGVycm9yXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSxcblx0XHRcdG9uUGF1c2U6ICgpID0+IHtcblx0XHRcdFx0dGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcInBhdXNlXCIgfSk7XG5cdFx0XHR9LFxuXHRcdFx0b25Db250aW51ZTogKCkgPT4ge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiY29udGludWVcIiB9KTtcblx0XHRcdH0sXG5cdFx0XHRyZXRyeTogY29udGV4dC5vcHRpb25zLnJldHJ5LFxuXHRcdFx0cmV0cnlEZWxheTogY29udGV4dC5vcHRpb25zLnJldHJ5RGVsYXksXG5cdFx0XHRuZXR3b3JrTW9kZTogY29udGV4dC5vcHRpb25zLm5ldHdvcmtNb2RlLFxuXHRcdFx0Y2FuUnVuOiAoKSA9PiB0cnVlXG5cdFx0fSk7XG5cdFx0Y29uc3QgZmV0Y2hQcm9taXNlID0gKGFzeW5jICgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGRhdGEgPSBhd2FpdCByZXRyeWVyLnByb21pc2U7XG5cdFx0XHRcdGlmIChkYXRhID09PSB2b2lkIDApIHtcblx0XHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjb25zb2xlLmVycm9yKGBRdWVyeSBkYXRhIGNhbm5vdCBiZSB1bmRlZmluZWQuIFBsZWFzZSBtYWtlIHN1cmUgdG8gcmV0dXJuIGEgdmFsdWUgb3RoZXIgdGhhbiB1bmRlZmluZWQgZnJvbSB5b3VyIHF1ZXJ5IGZ1bmN0aW9uLiBBZmZlY3RlZCBxdWVyeSBrZXk6ICR7dGhpcy5xdWVyeUhhc2h9YCk7XG5cdFx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKGAke3RoaXMucXVlcnlIYXNofSBkYXRhIGlzIHVuZGVmaW5lZGApO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuc2V0RGF0YShkYXRhKTtcblx0XHRcdFx0dGhpcy4jY2FjaGUuY29uZmlnLm9uU3VjY2Vzcz8uKGRhdGEsIHRoaXMpO1xuXHRcdFx0XHR0aGlzLiNjYWNoZS5jb25maWcub25TZXR0bGVkPy4oZGF0YSwgdGhpcy5zdGF0ZS5lcnJvciwgdGhpcyk7XG5cdFx0XHRcdHJldHVybiBkYXRhO1xuXHRcdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3IpIHtcblx0XHRcdFx0XHRpZiAoZXJyb3Iuc2lsZW50KSB7XG5cdFx0XHRcdFx0XHRpZiAodGhpcy4jcmV0cnllciAhPT0gcmV0cnllciAmJiB0aGlzLiNmZXRjaFByb21pc2UpIHJldHVybiB0aGlzLiNmZXRjaFByb21pc2U7XG5cdFx0XHRcdFx0XHR0aHJvdyBlcnJvcjtcblx0XHRcdFx0XHR9IGVsc2UgaWYgKGVycm9yLnJldmVydCkge1xuXHRcdFx0XHRcdFx0aWYgKHRoaXMuc3RhdGUuZGF0YSA9PT0gdm9pZCAwKSB0aHJvdyBlcnJvcjtcblx0XHRcdFx0XHRcdHJldHVybiB0aGlzLnN0YXRlLmRhdGE7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0XHR0eXBlOiBcImVycm9yXCIsXG5cdFx0XHRcdFx0ZXJyb3Jcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHRoaXMuI2NhY2hlLmNvbmZpZy5vbkVycm9yPy4oZXJyb3IsIHRoaXMpO1xuXHRcdFx0XHR0aGlzLiNjYWNoZS5jb25maWcub25TZXR0bGVkPy4odGhpcy5zdGF0ZS5kYXRhLCBlcnJvciwgdGhpcyk7XG5cdFx0XHRcdHRocm93IGVycm9yO1xuXHRcdFx0fSBmaW5hbGx5IHtcblx0XHRcdFx0aWYgKHRoaXMuI3JldHJ5ZXIgPT09IHJldHJ5ZXIpIHtcblx0XHRcdFx0XHR0aGlzLiNyZXRyeWVyID0gdm9pZCAwO1xuXHRcdFx0XHRcdHRoaXMuI2ZldGNoUHJvbWlzZSA9IHZvaWQgMDtcblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLiNzY2hlZHVsZUdjSWZDYWNoZWQoKTtcblx0XHRcdH1cblx0XHR9KSgpO1xuXHRcdHRoaXMuI2ZldGNoUHJvbWlzZSA9IGZldGNoUHJvbWlzZTtcblx0XHRyZXRyeWVyLnN0YXJ0KCk7XG5cdFx0cmV0dXJuIGZldGNoUHJvbWlzZTtcblx0fVxuXHQjc2NoZWR1bGVHY0lmQ2FjaGVkKCkge1xuXHRcdGlmICh0aGlzLiNjYWNoZS5nZXQodGhpcy5xdWVyeUhhc2gpID09PSB0aGlzKSB0aGlzLnNjaGVkdWxlR2MoKTtcblx0fVxuXHQjZGlzcGF0Y2goYWN0aW9uKSB7XG5cdFx0Y29uc3QgcmVkdWNlciA9IChzdGF0ZSkgPT4ge1xuXHRcdFx0c3dpdGNoIChhY3Rpb24udHlwZSkge1xuXHRcdFx0XHRjYXNlIFwiZmFpbGVkXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IGFjdGlvbi5mYWlsdXJlQ291bnQsXG5cdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlUmVhc29uOiBhY3Rpb24uZXJyb3Jcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcInBhdXNlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZmV0Y2hTdGF0dXM6IFwicGF1c2VkXCJcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcImNvbnRpbnVlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZmV0Y2hTdGF0dXM6IFwiZmV0Y2hpbmdcIlxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwiZmV0Y2hcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHQuLi5mZXRjaFN0YXRlKHN0YXRlLmRhdGEsIHRoaXMub3B0aW9ucyksXG5cdFx0XHRcdFx0ZmV0Y2hNZXRhOiBhY3Rpb24ubWV0YSA/PyBudWxsXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJzdWNjZXNzXCI6IHtcblx0XHRcdFx0XHRjb25zdCBuZXdTdGF0ZSA9IHtcblx0XHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdFx0Li4uc3VjY2Vzc1N0YXRlKGFjdGlvbi5kYXRhLCBhY3Rpb24uZGF0YVVwZGF0ZWRBdCksXG5cdFx0XHRcdFx0XHRkYXRhVXBkYXRlQ291bnQ6IHN0YXRlLmRhdGFVcGRhdGVDb3VudCArIDEsXG5cdFx0XHRcdFx0XHQuLi4hYWN0aW9uLm1hbnVhbCAmJiB7XG5cdFx0XHRcdFx0XHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIixcblx0XHRcdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG5cdFx0XHRcdFx0XHRcdGZldGNoRmFpbHVyZVJlYXNvbjogbnVsbFxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0dGhpcy4jcmV2ZXJ0U3RhdGUgPSBhY3Rpb24ubWFudWFsID8gbmV3U3RhdGUgOiB2b2lkIDA7XG5cdFx0XHRcdFx0cmV0dXJuIG5ld1N0YXRlO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNhc2UgXCJlcnJvclwiOiB7XG5cdFx0XHRcdFx0Y29uc3QgZXJyb3IgPSBhY3Rpb24uZXJyb3I7XG5cdFx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdFx0ZXJyb3IsXG5cdFx0XHRcdFx0XHRlcnJvclVwZGF0ZUNvdW50OiBzdGF0ZS5lcnJvclVwZGF0ZUNvdW50ICsgMSxcblx0XHRcdFx0XHRcdGVycm9yVXBkYXRlZEF0OiBEYXRlLm5vdygpLFxuXHRcdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IHN0YXRlLmZldGNoRmFpbHVyZUNvdW50ICsgMSxcblx0XHRcdFx0XHRcdGZldGNoRmFpbHVyZVJlYXNvbjogZXJyb3IsXG5cdFx0XHRcdFx0XHRmZXRjaFN0YXR1czogXCJpZGxlXCIsXG5cdFx0XHRcdFx0XHRzdGF0dXM6IFwiZXJyb3JcIixcblx0XHRcdFx0XHRcdGlzSW52YWxpZGF0ZWQ6IHRydWVcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNhc2UgXCJpbnZhbGlkYXRlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0aXNJbnZhbGlkYXRlZDogdHJ1ZVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwic2V0U3RhdGVcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHQuLi5hY3Rpb24uc3RhdGVcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdHRoaXMuc3RhdGUgPSByZWR1Y2VyKHRoaXMuc3RhdGUpO1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy5vYnNlcnZlcnMuc2xpY2UoKS5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0XHRvYnNlcnZlci5vblF1ZXJ5VXBkYXRlKCk7XG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuI2NhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdHF1ZXJ5OiB0aGlzLFxuXHRcdFx0XHR0eXBlOiBcInVwZGF0ZWRcIixcblx0XHRcdFx0YWN0aW9uXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbi8qKlxuKiBSZXR1cm5zIHRoZSBzdGF0ZSBjaGFuZ2VzIGFwcGxpZWQgd2hlbiBhIHF1ZXJ5IHN0YXJ0cyBmZXRjaGluZy5cbiogQHBhcmFtIGRhdGEgLSBUaGUgcXVlcnkncyBjdXJyZW50IGRhdGEuIElmIGl0IGlzIGB1bmRlZmluZWRgLCB0aGUgcXVlcnkgaXMgYWxzbyByZXNldCB0b1xuKiBgJ3BlbmRpbmcnYCB3aXRoIG5vIGVycm9yLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zLCB3aG9zZSBgbmV0d29ya01vZGVgIGRlY2lkZXMgd2hldGhlciB0aGUgcXVlcnkgaXMgYCdmZXRjaGluZydgXG4qIG9yIGAncGF1c2VkJ2AuXG4qIEByZXR1cm5zIFRoZSBwYXJ0aWFsIHF1ZXJ5IHN0YXRlIGZvciBhIHN0YXJ0aW5nIGZldGNoLlxuKi9cbmZ1bmN0aW9uIGZldGNoU3RhdGUoZGF0YSwgb3B0aW9ucykge1xuXHRyZXR1cm4ge1xuXHRcdGZldGNoRmFpbHVyZUNvdW50OiAwLFxuXHRcdGZldGNoRmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRmZXRjaFN0YXR1czogY2FuRmV0Y2gob3B0aW9ucy5uZXR3b3JrTW9kZSkgPyBcImZldGNoaW5nXCIgOiBcInBhdXNlZFwiLFxuXHRcdC4uLmRhdGEgPT09IHZvaWQgMCAmJiB7XG5cdFx0XHRlcnJvcjogbnVsbCxcblx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCJcblx0XHR9XG5cdH07XG59XG4vKipcbiogUmV0dXJucyB0aGUgc3RhdGUgY2hhbmdlcyBhcHBsaWVkIHdoZW4gYSBxdWVyeSByZWNlaXZlcyBkYXRhLlxuKiBAcGFyYW0gZGF0YSAtIFRoZSBuZXcgZGF0YS5cbiogQHBhcmFtIGRhdGFVcGRhdGVkQXQgLSBUaGUgdGltZXN0YW1wIHRoZSBkYXRhIGlzIHJlY29yZGVkIHdpdGguIERlZmF1bHRzIHRvIHRoZSBjdXJyZW50IHRpbWUuXG4qIEByZXR1cm5zIFRoZSBwYXJ0aWFsIHF1ZXJ5IHN0YXRlIGZvciBhIHN1Y2Nlc3NmdWwgdXBkYXRlLlxuKi9cbmZ1bmN0aW9uIHN1Y2Nlc3NTdGF0ZShkYXRhLCBkYXRhVXBkYXRlZEF0KSB7XG5cdHJldHVybiB7XG5cdFx0ZGF0YSxcblx0XHRkYXRhVXBkYXRlZEF0OiBkYXRhVXBkYXRlZEF0ID8/IERhdGUubm93KCksXG5cdFx0ZXJyb3I6IG51bGwsXG5cdFx0aXNJbnZhbGlkYXRlZDogZmFsc2UsXG5cdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIlxuXHR9O1xufVxuLyoqXG4qIFJldHVybnMgdGhlIGluaXRpYWwgc3RhdGUgb2YgYSBxdWVyeSwgYmFzZWQgb24gaXRzIGBpbml0aWFsRGF0YWAgYW5kIGBpbml0aWFsRGF0YVVwZGF0ZWRBdGBcbiogb3B0aW9ucy5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucy5cbiogQHJldHVybnMgVGhlIGluaXRpYWwgcXVlcnkgc3RhdGU6IGAnc3VjY2VzcydgIGlmIGBpbml0aWFsRGF0YWAgaXMgc2V0LCBvdGhlcndpc2UgYCdwZW5kaW5nJ2AuXG4qL1xuZnVuY3Rpb24gZ2V0RGVmYXVsdFN0YXRlKG9wdGlvbnMpIHtcblx0Y29uc3QgZGF0YSA9IHR5cGVvZiBvcHRpb25zLmluaXRpYWxEYXRhID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLmluaXRpYWxEYXRhKCkgOiBvcHRpb25zLmluaXRpYWxEYXRhO1xuXHRjb25zdCBoYXNEYXRhID0gZGF0YSAhPT0gdm9pZCAwO1xuXHRjb25zdCBpbml0aWFsRGF0YVVwZGF0ZWRBdCA9IGhhc0RhdGEgPyB0eXBlb2Ygb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCA9PT0gXCJmdW5jdGlvblwiID8gb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCgpIDogb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCA6IDA7XG5cdHJldHVybiB7XG5cdFx0ZGF0YSxcblx0XHRkYXRhVXBkYXRlQ291bnQ6IDAsXG5cdFx0ZGF0YVVwZGF0ZWRBdDogaGFzRGF0YSA/IGluaXRpYWxEYXRhVXBkYXRlZEF0ID8/IERhdGUubm93KCkgOiAwLFxuXHRcdGVycm9yOiBudWxsLFxuXHRcdGVycm9yVXBkYXRlQ291bnQ6IDAsXG5cdFx0ZXJyb3JVcGRhdGVkQXQ6IDAsXG5cdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG5cdFx0ZmV0Y2hGYWlsdXJlUmVhc29uOiBudWxsLFxuXHRcdGZldGNoTWV0YTogbnVsbCxcblx0XHRpc0ludmFsaWRhdGVkOiBmYWxzZSxcblx0XHRzdGF0dXM6IGhhc0RhdGEgPyBcInN1Y2Nlc3NcIiA6IFwicGVuZGluZ1wiLFxuXHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIlxuXHR9O1xufVxuZXhwb3J0IHsgUXVlcnksIGZldGNoU3RhdGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnkuanMubWFwIiwiaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiLi9lbnZpcm9ubWVudE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gXCIuL2ZvY3VzTWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGZldGNoU3RhdGUgfSBmcm9tIFwiLi9xdWVyeS5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBpc1ZhbGlkVGltZW91dCwgbm9vcCwgcmVwbGFjZURhdGEsIHJlc29sdmVRdWVyeVZhbHVlLCBzaGFsbG93RXF1YWxPYmplY3RzLCB0aW1lVW50aWxTdGFsZSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyBzcmMvcXVlcnlPYnNlcnZlci50c1xuLyoqXG4qIEEgYFF1ZXJ5T2JzZXJ2ZXJgIHdhdGNoZXMgYSBzaW5nbGUgcXVlcnkgaW4gdGhlIGBRdWVyeUNhY2hlYCBhbmQgY29tcHV0ZXMgYVxuKiBgUXVlcnlPYnNlcnZlclJlc3VsdGAgZnJvbSBpdHMgc3RhdGUsIHJlY29tcHV0aW5nIGFuZCBub3RpZnlpbmcgc3Vic2NyaWJlcnNcbiogd2hlbmV2ZXIgdGhlIHVuZGVybHlpbmcgcXVlcnkgKG9yIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMpIGNoYW5nZXMuIEl0IGlzXG4qIHRoZSBwcmltaXRpdmUgdGhhdCBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy4gYHVzZVF1ZXJ5YCkgYnVpbGQgdGhlaXIgaG9va3Ncbiogb24gdG9wIG9mLCBidXQgaXQgY2FuIGFsc28gYmUgdXNlZCBkaXJlY3RseSB0byBvYnNlcnZlIGFuZCBzd2l0Y2ggYmV0d2VlblxuKiBxdWVyaWVzIG91dHNpZGUgb2YgYW55IGZyYW1ld29yay5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgUXVlcnlPYnNlcnZlcihxdWVyeUNsaWVudCwge1xuKiAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sXG4qICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcbiogfSlcbipcbiogY29uc3QgdW5zdWJzY3JpYmUgPSBvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhKVxuKiB9KVxuKiBgYGBcbiovXG52YXIgUXVlcnlPYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I2NsaWVudDtcblx0I2N1cnJlbnRRdWVyeSA9IHZvaWQgMDtcblx0I2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZSA9IHZvaWQgMDtcblx0I2N1cnJlbnRSZXN1bHQgPSB2b2lkIDA7XG5cdCNjdXJyZW50UmVzdWx0T3B0aW9ucztcblx0I3NlbGVjdEVycm9yO1xuXHQjc2VsZWN0Rm47XG5cdCNzZWxlY3RJbnB1dDtcblx0I3NlbGVjdFJlc3VsdDtcblx0I2xhc3RRdWVyeVdpdGhEZWZpbmVkRGF0YTtcblx0I3N0YWxlVGltZW91dElkO1xuXHQjcmVmZXRjaEludGVydmFsSWQ7XG5cdCNjdXJyZW50UmVmZXRjaEludGVydmFsO1xuXHQjdHJhY2tlZFByb3BzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0Y29uc3RydWN0b3IoY2xpZW50LCBvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuXHRcdHRoaXMuI2NsaWVudCA9IGNsaWVudDtcblx0XHR0aGlzLiNzZWxlY3RFcnJvciA9IG51bGw7XG5cdFx0dGhpcy5iaW5kTWV0aG9kcygpO1xuXHRcdHRoaXMuc2V0T3B0aW9ucyhvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBCaW5kcyB0aGUgbWV0aG9kcyBvZiB0aGUgcmVzdWx0IChgcmVmZXRjaGApIHRvIHRoZSBvYnNlcnZlciwgc28gdGhleSBrZWVwIHdvcmtpbmcgd2hlbiBkZXN0cnVjdHVyZWRcblx0KiBmcm9tIGl0LiBTdWJjbGFzc2VzIG92ZXJyaWRlIGl0IHRvIGJpbmQgdGhlaXIgb3duIHJlc3VsdCBtZXRob2RzIGFzIHdlbGwuXG5cdCovXG5cdGJpbmRNZXRob2RzKCkge1xuXHRcdHRoaXMucmVmZXRjaCA9IHRoaXMucmVmZXRjaC5iaW5kKHRoaXMpO1xuXHR9XG5cdG9uU3Vic2NyaWJlKCkge1xuXHRcdGlmICh0aGlzLmxpc3RlbmVycy5zaXplID09PSAxKSB7XG5cdFx0XHR0aGlzLiNjdXJyZW50UXVlcnkuYWRkT2JzZXJ2ZXIodGhpcyk7XG5cdFx0XHRpZiAoc2hvdWxkRmV0Y2hPbk1vdW50KHRoaXMuI2N1cnJlbnRRdWVyeSwgdGhpcy5vcHRpb25zKSkgdGhpcy4jZXhlY3V0ZUZldGNoKCk7XG5cdFx0XHRlbHNlIHRoaXMudXBkYXRlUmVzdWx0KCk7XG5cdFx0XHR0aGlzLiN1cGRhdGVUaW1lcnMoKTtcblx0XHR9XG5cdH1cblx0b25VbnN1YnNjcmliZSgpIHtcblx0XHRpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHRoaXMuZGVzdHJveSgpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgd2hldGhlciB0aGUgb2JzZXJ2ZWQgcXVlcnkgaXMgY3VycmVudGx5IHN0YWxlIGFuZCBjb25maWd1cmVkXG5cdCogKHZpYSB0aGUgYHJlZmV0Y2hPblJlY29ubmVjdGAgb3B0aW9uKSB0byByZWZldGNoIHdoZW4gdGhlIG5ldHdvcmtcblx0KiByZWNvbm5lY3RzLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgb2JzZXJ2ZXIgc2hvdWxkIHJlZmV0Y2ggdGhlIHF1ZXJ5IG9uIHJlY29ubmVjdC5cblx0Ki9cblx0c2hvdWxkRmV0Y2hPblJlY29ubmVjdCgpIHtcblx0XHRyZXR1cm4gc2hvdWxkRmV0Y2hPbih0aGlzLiNjdXJyZW50UXVlcnksIHRoaXMub3B0aW9ucywgdGhpcy5vcHRpb25zLnJlZmV0Y2hPblJlY29ubmVjdCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB3aGV0aGVyIHRoZSBvYnNlcnZlZCBxdWVyeSBpcyBjdXJyZW50bHkgc3RhbGUgYW5kIGNvbmZpZ3VyZWRcblx0KiAodmlhIHRoZSBgcmVmZXRjaE9uV2luZG93Rm9jdXNgIG9wdGlvbikgdG8gcmVmZXRjaCB3aGVuIHRoZSB3aW5kb3dcblx0KiByZWdhaW5zIGZvY3VzLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgb2JzZXJ2ZXIgc2hvdWxkIHJlZmV0Y2ggdGhlIHF1ZXJ5IG9uIHdpbmRvdyBmb2N1cy5cblx0Ki9cblx0c2hvdWxkRmV0Y2hPbldpbmRvd0ZvY3VzKCkge1xuXHRcdHJldHVybiBzaG91bGRGZXRjaE9uKHRoaXMuI2N1cnJlbnRRdWVyeSwgdGhpcy5vcHRpb25zLCB0aGlzLm9wdGlvbnMucmVmZXRjaE9uV2luZG93Rm9jdXMpO1xuXHR9XG5cdC8qKlxuXHQqIFN0b3BzIG9ic2VydmluZyB0aGUgY3VycmVudCBxdWVyeTogY2xlYXJzIGFsbCBsaXN0ZW5lcnMsIGNhbmNlbHMgdGhlXG5cdCogc3RhbGUgYW5kIHJlZmV0Y2gtaW50ZXJ2YWwgdGltZXJzLCBhbmQgcmVtb3ZlcyB0aGlzIG9ic2VydmVyIGZyb20gdGhlXG5cdCogcXVlcnkgaXQgd2FzIG9ic2VydmluZy5cblx0Ki9cblx0ZGVzdHJveSgpIHtcblx0XHR0aGlzLmxpc3RlbmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0dGhpcy4jY2xlYXJTdGFsZVRpbWVvdXQoKTtcblx0XHR0aGlzLiNjbGVhclJlZmV0Y2hJbnRlcnZhbCgpO1xuXHRcdHRoaXMuI2N1cnJlbnRRdWVyeS5yZW1vdmVPYnNlcnZlcih0aGlzKTtcblx0fVxuXHQvKipcblx0KiBVcGRhdGVzIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMuIFRoaXMgd2lsbCByZS1yZXNvbHZlIHRoZSBxdWVyeSBiZWluZ1xuXHQqIG9ic2VydmVkIChzd2l0Y2hpbmcgdG8gYSBkaWZmZXJlbnQgcXVlcnkgaWYgdGhlIGBxdWVyeUtleWAgY2hhbmdlZCksXG5cdCogdHJpZ2dlciBhIGZldGNoIGlmIHRoZSBuZXcgb3B0aW9ucyByZXF1aXJlIG9uZSBhbmQgdGhlIG9ic2VydmVyIGhhc1xuXHQqIHN1YnNjcmliZXJzLCByZWNvbXB1dGUgdGhlIGN1cnJlbnQgcmVzdWx0LCBhbmQgcmVzY2hlZHVsZSB0aGUgc3RhbGUgYW5kXG5cdCogcmVmZXRjaC1pbnRlcnZhbCB0aW1lcnMgYXMgbmVlZGVkLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG5ldyBvYnNlcnZlciBvcHRpb25zLiBUaGV5IGFyZSBkZWZhdWx0ZWQgd2l0aCB7QGxpbmtcblx0KiBRdWVyeUNsaWVudCNkZWZhdWx0UXVlcnlPcHRpb25zfSBiZWZvcmUgYmVpbmcgYXBwbGllZC5cblx0KiBAdGhyb3dzIHtFcnJvcn0gSWYgYGVuYWJsZWRgIGlzIG5laXRoZXIgYSBib29sZWFuIG5vciBhIGZ1bmN0aW9uLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBvYnNlcnZlci5zZXRPcHRpb25zKHsgcXVlcnlLZXk6IFsncG9zdHMnLCAxXSwgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KDEpIH0pXG5cdCogLy8gbGF0ZXI6IHN3aXRjaCB0byBhIGRpZmZlcmVudCBxdWVyeSwgcmV1c2luZyB0aGUgc2FtZSBvYnNlcnZlclxuXHQqIG9ic2VydmVyLnNldE9wdGlvbnMoeyBxdWVyeUtleTogWydwb3N0cycsIDJdLCBxdWVyeUZuOiAoKSA9PiBmZXRjaFBvc3QoMikgfSlcblx0KiBgYGBcblx0Ki9cblx0c2V0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0Y29uc3QgcHJldk9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cdFx0Y29uc3QgcHJldlF1ZXJ5ID0gdGhpcy4jY3VycmVudFF1ZXJ5O1xuXHRcdHRoaXMub3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGlmICh0aGlzLm9wdGlvbnMuZW5hYmxlZCAhPT0gdm9pZCAwICYmIHR5cGVvZiB0aGlzLm9wdGlvbnMuZW5hYmxlZCAhPT0gXCJib29sZWFuXCIgJiYgdHlwZW9mIHRoaXMub3B0aW9ucy5lbmFibGVkICE9PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mIHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpICE9PSBcImJvb2xlYW5cIikgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgZW5hYmxlZCB0byBiZSBhIGJvb2xlYW4gb3IgYSBjYWxsYmFjayB0aGF0IHJldHVybnMgYSBib29sZWFuXCIpO1xuXHRcdHRoaXMuI3VwZGF0ZVF1ZXJ5KCk7XG5cdFx0dGhpcy4jY3VycmVudFF1ZXJ5LnNldE9wdGlvbnModGhpcy5vcHRpb25zKTtcblx0XHRpZiAocHJldk9wdGlvbnMuX2RlZmF1bHRlZCAmJiAhc2hhbGxvd0VxdWFsT2JqZWN0cyh0aGlzLm9wdGlvbnMsIHByZXZPcHRpb25zKSkgdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5ub3RpZnkoe1xuXHRcdFx0dHlwZTogXCJvYnNlcnZlck9wdGlvbnNVcGRhdGVkXCIsXG5cdFx0XHRxdWVyeTogdGhpcy4jY3VycmVudFF1ZXJ5LFxuXHRcdFx0b2JzZXJ2ZXI6IHRoaXNcblx0XHR9KTtcblx0XHRjb25zdCBtb3VudGVkID0gdGhpcy5oYXNMaXN0ZW5lcnMoKTtcblx0XHRpZiAobW91bnRlZCAmJiBzaG91bGRGZXRjaE9wdGlvbmFsbHkodGhpcy4jY3VycmVudFF1ZXJ5LCBwcmV2UXVlcnksIHRoaXMub3B0aW9ucywgcHJldk9wdGlvbnMpKSB0aGlzLiNleGVjdXRlRmV0Y2goKTtcblx0XHR0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdGlmIChtb3VudGVkICYmICh0aGlzLiNjdXJyZW50UXVlcnkgIT09IHByZXZRdWVyeSB8fCByZXNvbHZlUXVlcnlWYWx1ZSh0aGlzLm9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSAhPT0gcmVzb2x2ZVF1ZXJ5VmFsdWUocHJldk9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSB8fCByZXNvbHZlUXVlcnlWYWx1ZSh0aGlzLm9wdGlvbnMuc3RhbGVUaW1lLCB0aGlzLiNjdXJyZW50UXVlcnkpICE9PSByZXNvbHZlUXVlcnlWYWx1ZShwcmV2T3B0aW9ucy5zdGFsZVRpbWUsIHRoaXMuI2N1cnJlbnRRdWVyeSkpKSB0aGlzLiN1cGRhdGVTdGFsZVRpbWVvdXQoKTtcblx0XHRjb25zdCBuZXh0UmVmZXRjaEludGVydmFsID0gdGhpcy4jY29tcHV0ZVJlZmV0Y2hJbnRlcnZhbCgpO1xuXHRcdGlmIChtb3VudGVkICYmICh0aGlzLiNjdXJyZW50UXVlcnkgIT09IHByZXZRdWVyeSB8fCByZXNvbHZlUXVlcnlWYWx1ZSh0aGlzLm9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSAhPT0gcmVzb2x2ZVF1ZXJ5VmFsdWUocHJldk9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSB8fCBuZXh0UmVmZXRjaEludGVydmFsICE9PSB0aGlzLiNjdXJyZW50UmVmZXRjaEludGVydmFsKSkgdGhpcy4jdXBkYXRlUmVmZXRjaEludGVydmFsKG5leHRSZWZldGNoSW50ZXJ2YWwpO1xuXHR9XG5cdC8qKlxuXHQqIENvbXB1dGVzIHRoZSByZXN1bHQgdGhlIG9ic2VydmVyIHdvdWxkIHByb2R1Y2UgZm9yIHRoZSBnaXZlbiAoYWxyZWFkeS1kZWZhdWx0ZWQpIG9wdGlvbnNcblx0KiByaWdodCBub3csIGJ1aWxkaW5nIHRoZSB1bmRlcmx5aW5nIGBRdWVyeWAgaWYgaXQgZG9lc24ndCBleGlzdCB5ZXQsIHdpdGhvdXQgd2FpdGluZyBmb3IgYVxuXHQqIHN1YnNjcmlwdGlvbiBjYWxsYmFjay4gQ2FsbGVkIGJ5IGZyYW1ld29yayBhZGFwdGVycyBvbiBldmVyeSByZW5kZXIgKGUuZy4gYHVzZVF1ZXJ5YCkgc28gdGhlXG5cdCogcmV0dXJuZWQgdmFsdWUgaXMgYXZhaWxhYmxlIHN5bmNocm9ub3VzbHksIGFoZWFkIG9mIGBzZXRPcHRpb25zYCB0cmlnZ2VyaW5nIGFuIGFjdHVhbCBmZXRjaC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBkZWZhdWx0ZWQgb2JzZXJ2ZXIgb3B0aW9ucyB0byBjb21wdXRlIHRoZSByZXN1bHQgZm9yLlxuXHQqIEByZXR1cm5zIFRoZSByZXN1bHQgZm9yIHRoZSBnaXZlbiBvcHRpb25zLlxuXHQqL1xuXHRnZXRPcHRpbWlzdGljUmVzdWx0KG9wdGlvbnMpIHtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuYnVpbGQodGhpcy4jY2xpZW50LCBvcHRpb25zKTtcblx0XHRjb25zdCByZXN1bHQgPSB0aGlzLmNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucyk7XG5cdFx0aWYgKCFzaGFsbG93RXF1YWxPYmplY3RzKHRoaXMuZ2V0Q3VycmVudFJlc3VsdCgpLCByZXN1bHQpKSB7XG5cdFx0XHR0aGlzLiNjdXJyZW50UmVzdWx0ID0gcmVzdWx0O1xuXHRcdFx0dGhpcy4jY3VycmVudFJlc3VsdE9wdGlvbnMgPSBvcHRpb25zO1xuXHRcdH1cblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG1vc3QgcmVjZW50bHkgY29tcHV0ZWQgYFF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgIGZvciB0aGVcblx0KiBvYnNlcnZlZCBxdWVyeS4gVGhpcyBpcyBhIHBvaW50LWluLXRpbWUgcmVhZDsgdG8gYmUgbm90aWZpZWQgb2YgdXBkYXRlc1xuXHQqIGFzIHRoZXkgaGFwcGVuLCBzdWJzY3JpYmUgdG8gdGhlIG9ic2VydmVyIGluc3RlYWQgKGl0cyBpbmhlcml0ZWRcblx0KiBgc3Vic2NyaWJlYCBtZXRob2QpLlxuXHQqIEByZXR1cm5zIFRoZSBvYnNlcnZlcidzIGxhdGVzdCByZXN1bHQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuXHQqIGNvbnNvbGUubG9nKHJlc3VsdC5zdGF0dXMsIHJlc3VsdC5kYXRhKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRDdXJyZW50UmVzdWx0KCkge1xuXHRcdHJldHVybiB0aGlzLiNjdXJyZW50UmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFdyYXBzIGEgYFF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgIGluIGEgYFByb3h5YCB0aGF0IHJlY29yZHMgd2hpY2ggcHJvcGVydGllcyBhcmUgcmVhZCwgdmlhXG5cdCoge0BsaW5rIFF1ZXJ5T2JzZXJ2ZXIjdHJhY2tQcm9wfSAoYW5kIGFuIG9wdGlvbmFsIGBvblByb3BUcmFja2VkYCBjYWxsYmFjaykuIFVzZWQgYnkgZnJhbWV3b3JrXG5cdCogYWRhcHRlcnMgd2hlbiBgbm90aWZ5T25DaGFuZ2VQcm9wc2AgaXMgbm90IHNldCwgdG8gaW1wbGVtZW50IGl0cyBkZWZhdWx0IFwib25seSByZS1yZW5kZXIgb25cblx0KiBwcm9wZXJ0aWVzIHlvdSBhY3R1YWxseSByZWFkXCIgYmVoYXZpb3IuXG5cdCogQHBhcmFtIHJlc3VsdCAtIFRoZSByZXN1bHQgdG8gd3JhcC5cblx0KiBAcGFyYW0gb25Qcm9wVHJhY2tlZCAtIENhbGxlZCB3aXRoIHRoZSBuYW1lIG9mIGVhY2ggcHJvcGVydHkgdGhhdCBpcyByZWFkLlxuXHQqIEByZXR1cm5zIEEgcHJveHkgb2YgYHJlc3VsdGAgdGhhdCB0cmFja3MgcHJvcGVydHkgcmVhZHMuXG5cdCovXG5cdHRyYWNrUmVzdWx0KHJlc3VsdCwgb25Qcm9wVHJhY2tlZCkge1xuXHRcdHJldHVybiBuZXcgUHJveHkocmVzdWx0LCB7IGdldDogKHRhcmdldCwga2V5KSA9PiB7XG5cdFx0XHR0aGlzLnRyYWNrUHJvcChrZXkpO1xuXHRcdFx0b25Qcm9wVHJhY2tlZD8uKGtleSk7XG5cdFx0XHRyZXR1cm4gUmVmbGVjdC5nZXQodGFyZ2V0LCBrZXkpO1xuXHRcdH0gfSk7XG5cdH1cblx0LyoqXG5cdCogUmVjb3JkcyB0aGF0IHRoZSBnaXZlbiBgUXVlcnlPYnNlcnZlclJlc3VsdGAgcHJvcGVydHkgd2FzIHJlYWQsIHNvIGEgc3Vic2VxdWVudCB1cGRhdGUgb25seVxuXHQqIG5vdGlmaWVzIHRoaXMgb2JzZXJ2ZXIgaWYgYSB0cmFja2VkIHByb3BlcnR5IGFjdHVhbGx5IGNoYW5nZWQuIE5vcm1hbGx5IGNhbGxlZCBpbmRpcmVjdGx5IHZpYVxuXHQqIHtAbGluayBRdWVyeU9ic2VydmVyI3RyYWNrUmVzdWx0fSdzIHByb3h5OyBleHBvc2VkIGRpcmVjdGx5IGZvciBhZGFwdGVycyB0aGF0IHRyYWNrIHByb3BlcnR5XG5cdCogYWNjZXNzIHRoZW1zZWx2ZXMgKGUuZy4gdGhyb3VnaCB0aGVpciBvd24gcmVhY3Rpdml0eSBzeXN0ZW0pIGluc3RlYWQgb2YgdmlhIHRoZSBwcm94eS5cblx0KiBAcGFyYW0ga2V5IC0gVGhlIG5hbWUgb2YgdGhlIHByb3BlcnR5IHRoYXQgd2FzIHJlYWQuXG5cdCovXG5cdHRyYWNrUHJvcChrZXkpIHtcblx0XHR0aGlzLiN0cmFja2VkUHJvcHMuYWRkKGtleSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgYFF1ZXJ5YCBpbnN0YW5jZSB0aGlzIG9ic2VydmVyIGlzIGN1cnJlbnRseSBvYnNlcnZpbmcuXG5cdCogQHJldHVybnMgVGhlIG9ic2VydmVkIHF1ZXJ5LlxuXHQqL1xuXHRnZXRDdXJyZW50UXVlcnkoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRRdWVyeTtcblx0fVxuXHQvKipcblx0KiBSZWZldGNoZXMgdGhlIG9ic2VydmVkIHF1ZXJ5IGFuZCByZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGhcblx0KiB0aGUgcmVzdWx0aW5nIGBRdWVyeU9ic2VydmVyUmVzdWx0YC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFNldCBgY2FuY2VsUmVmZXRjaGAgdG8gYGZhbHNlYCB0byBrZWVwIGEgcnVubmluZyBmZXRjaCBpbnN0ZWFkIG9mIGNhbmNlbGxpbmdcblx0KiBpdCwgYW5kIGB0aHJvd09uRXJyb3JgIHRvIGB0cnVlYCB0byByZWplY3Qgd2hlbiB0aGUgcmVmZXRjaCBmYWlscy5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHQgYWZ0ZXIgdGhlIHJlZmV0Y2guXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9ic2VydmVyLnJlZmV0Y2goeyBjYW5jZWxSZWZldGNoOiBmYWxzZSB9KVxuXHQqIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhKVxuXHQqIGBgYFxuXHQqL1xuXHRyZWZldGNoKHsgLi4ub3B0aW9ucyB9ID0ge30pIHtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaCh7IC4uLm9wdGlvbnMgfSk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyBhIHF1ZXJ5IGRlZmluZWQgYnkgdGhlIGdpdmVuIG9wdGlvbnMgd2l0aG91dCBhZmZlY3RpbmcgdGhpc1xuXHQqIG9ic2VydmVyJ3Mgb3duIHRyYWNrZWQgcXVlcnkgb3IgcmVzdWx0LCBhbmQgcmV0dXJucyBhIHByb21pc2UgdGhhdFxuXHQqIHJlc29sdmVzIHdpdGggdGhlIGBRdWVyeU9ic2VydmVyUmVzdWx0YCBmb3IgdGhhdCBmZXRjaC4gVGhpcyBpcyB1c2VmdWxcblx0KiBmb3IgcHJlZmV0Y2hpbmcgZGF0YSB0aGF0IGFub3RoZXIgb2JzZXJ2ZXIgKGUuZy4gYSBxdWVyeSBhYm91dCB0byBiZVxuXHQqIG5hdmlnYXRlZCB0bykgd2lsbCBuZWVkLCBhaGVhZCBvZiB0aW1lLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9ic2VydmVyIG9wdGlvbnMgb2YgdGhlIHF1ZXJ5IHRvIGZldGNoLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHJlc3VsdCBmb3IgdGhlIGZldGNoZWQgcXVlcnkuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9ic2VydmVyLmZldGNoT3B0aW1pc3RpYyh7XG5cdCogICBxdWVyeUtleTogWydwb3N0cycsIDJdLFxuXHQqICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KDIpLFxuXHQqIH0pXG5cdCogY29uc29sZS5sb2cocmVzdWx0LmRhdGEpXG5cdCogYGBgXG5cdCovXG5cdGZldGNoT3B0aW1pc3RpYyhvcHRpb25zKSB7XG5cdFx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdGxldCB1bnN1YnNjcmliZSA9ICgpID0+IHt9O1xuXHRcdGxldCByZXNvbHZlRWFybHk7XG5cdFx0Y29uc3QgY2FjaGVQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdHJlc29sdmVFYXJseSA9IHJlc29sdmU7XG5cdFx0XHR1bnN1YnNjcmliZSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuc3Vic2NyaWJlKChldmVudCkgPT4ge1xuXHRcdFx0XHRpZiAoZXZlbnQudHlwZSA9PT0gXCJ1cGRhdGVkXCIgJiYgZXZlbnQucXVlcnkucXVlcnlIYXNoID09PSBxdWVyeS5xdWVyeUhhc2ggJiYgcXVlcnkuc3RhdGUuZGF0YSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0dW5zdWJzY3JpYmUoKTtcblx0XHRcdFx0XHRyZXNvbHZlKHRoaXMuY3JlYXRlUmVzdWx0KHF1ZXJ5LCBkZWZhdWx0ZWRPcHRpb25zKSk7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdHJldHVybiBQcm9taXNlLnJhY2UoW3F1ZXJ5LmZldGNoKGRlZmF1bHRlZE9wdGlvbnMpLnRoZW4oKCkgPT4ge1xuXHRcdFx0Y29uc3QgcmVzdWx0ID0gdGhpcy5jcmVhdGVSZXN1bHQocXVlcnksIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdFx0cmVzb2x2ZUVhcmx5Py4ocmVzdWx0KTtcblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSkuZmluYWxseSgoKSA9PiB7XG5cdFx0XHR1bnN1YnNjcmliZSgpO1xuXHRcdH0pLCBjYWNoZVByb21pc2VdKTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIHRoZSBvYnNlcnZlZCBxdWVyeSBhbmQgdXBkYXRlcyB0aGUgcmVzdWx0IG9uY2UgdGhlIGZldGNoIHNldHRsZXMuIFVzZWQgYnkgYHJlZmV0Y2hgIGFuZCxcblx0KiBpbiBgSW5maW5pdGVRdWVyeU9ic2VydmVyYCwgdG8gZmV0Y2ggbW9yZSBwYWdlcy5cblx0KiBAcGFyYW0gZmV0Y2hPcHRpb25zIC0gT3B0aW9ucyBmb3IgdGhpcyBmZXRjaC4gYGNhbmNlbFJlZmV0Y2hgIGRlZmF1bHRzIHRvIGB0cnVlYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSB1cGRhdGVkIHJlc3VsdC5cblx0Ki9cblx0ZmV0Y2goZmV0Y2hPcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2V4ZWN1dGVGZXRjaCh7XG5cdFx0XHQuLi5mZXRjaE9wdGlvbnMsXG5cdFx0XHRjYW5jZWxSZWZldGNoOiBmZXRjaE9wdGlvbnMuY2FuY2VsUmVmZXRjaCA/PyB0cnVlXG5cdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHR0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG5cdFx0fSk7XG5cdH1cblx0I2V4ZWN1dGVGZXRjaChmZXRjaE9wdGlvbnMpIHtcblx0XHR0aGlzLiN1cGRhdGVRdWVyeSgpO1xuXHRcdGxldCBwcm9taXNlID0gdGhpcy4jY3VycmVudFF1ZXJ5LmZldGNoKHRoaXMub3B0aW9ucywgZmV0Y2hPcHRpb25zKTtcblx0XHRpZiAoIWZldGNoT3B0aW9ucz8udGhyb3dPbkVycm9yKSBwcm9taXNlID0gcHJvbWlzZS5jYXRjaChub29wKTtcblx0XHRyZXR1cm4gcHJvbWlzZTtcblx0fVxuXHQjc2hvdWxkU2NoZWR1bGVUaW1lcih0aW1lb3V0KSB7XG5cdFx0cmV0dXJuICFpc1NlcnZlcigpICYmIHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpICE9PSBmYWxzZSAmJiBpc1ZhbGlkVGltZW91dCh0aW1lb3V0KTtcblx0fVxuXHQjdXBkYXRlU3RhbGVUaW1lb3V0KCkge1xuXHRcdHRoaXMuI2NsZWFyU3RhbGVUaW1lb3V0KCk7XG5cdFx0Y29uc3Qgc3RhbGVUaW1lID0gcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLnN0YWxlVGltZSwgdGhpcy4jY3VycmVudFF1ZXJ5KTtcblx0XHRpZiAodGhpcy4jY3VycmVudFJlc3VsdC5pc1N0YWxlIHx8ICF0aGlzLiNzaG91bGRTY2hlZHVsZVRpbWVyKHN0YWxlVGltZSkpIHJldHVybjtcblx0XHRjb25zdCB0aW1lb3V0ID0gdGltZVVudGlsU3RhbGUodGhpcy4jY3VycmVudFJlc3VsdC5kYXRhVXBkYXRlZEF0LCBzdGFsZVRpbWUpICsgMTtcblx0XHR0aGlzLiNzdGFsZVRpbWVvdXRJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0aWYgKCF0aGlzLiNjdXJyZW50UmVzdWx0LmlzU3RhbGUpIHRoaXMudXBkYXRlUmVzdWx0KCk7XG5cdFx0fSwgdGltZW91dCk7XG5cdH1cblx0I2NvbXB1dGVSZWZldGNoSW50ZXJ2YWwoKSB7XG5cdFx0cmV0dXJuIHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5yZWZldGNoSW50ZXJ2YWwsIHRoaXMuI2N1cnJlbnRRdWVyeSkgPz8gZmFsc2U7XG5cdH1cblx0I3VwZGF0ZVJlZmV0Y2hJbnRlcnZhbChuZXh0SW50ZXJ2YWwpIHtcblx0XHR0aGlzLiNjbGVhclJlZmV0Y2hJbnRlcnZhbCgpO1xuXHRcdHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwgPSBuZXh0SW50ZXJ2YWw7XG5cdFx0aWYgKHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwgPT09IDAgfHwgIXRoaXMuI3Nob3VsZFNjaGVkdWxlVGltZXIodGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCkpIHJldHVybjtcblx0XHR0aGlzLiNyZWZldGNoSW50ZXJ2YWxJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldEludGVydmFsKCgpID0+IHtcblx0XHRcdGlmICh0aGlzLm9wdGlvbnMucmVmZXRjaEludGVydmFsSW5CYWNrZ3JvdW5kIHx8IGZvY3VzTWFuYWdlci5pc0ZvY3VzZWQoKSkgdGhpcy4jZXhlY3V0ZUZldGNoKCk7XG5cdFx0fSwgdGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCk7XG5cdH1cblx0I3VwZGF0ZVRpbWVycygpIHtcblx0XHR0aGlzLiN1cGRhdGVTdGFsZVRpbWVvdXQoKTtcblx0XHR0aGlzLiN1cGRhdGVSZWZldGNoSW50ZXJ2YWwodGhpcy4jY29tcHV0ZVJlZmV0Y2hJbnRlcnZhbCgpKTtcblx0fVxuXHQjY2xlYXJTdGFsZVRpbWVvdXQoKSB7XG5cdFx0aWYgKHRoaXMuI3N0YWxlVGltZW91dElkICE9PSB2b2lkIDApIHtcblx0XHRcdHRpbWVvdXRNYW5hZ2VyLmNsZWFyVGltZW91dCh0aGlzLiNzdGFsZVRpbWVvdXRJZCk7XG5cdFx0XHR0aGlzLiNzdGFsZVRpbWVvdXRJZCA9IHZvaWQgMDtcblx0XHR9XG5cdH1cblx0I2NsZWFyUmVmZXRjaEludGVydmFsKCkge1xuXHRcdGlmICh0aGlzLiNyZWZldGNoSW50ZXJ2YWxJZCAhPT0gdm9pZCAwKSB7XG5cdFx0XHR0aW1lb3V0TWFuYWdlci5jbGVhckludGVydmFsKHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkKTtcblx0XHRcdHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkID0gdm9pZCAwO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBDb21wdXRlcyB0aGUgcmVzdWx0IGZvciBhIHF1ZXJ5IGFuZCBvcHRpb25zIGZyb20gdGhlIHF1ZXJ5J3Mgc3RhdGUsIGFwcGx5aW5nIGBzZWxlY3RgLFxuXHQqIGBwbGFjZWhvbGRlckRhdGFgLCBhbmQgdGhlIGRlcml2ZWQgZmxhZ3MuIFN1YmNsYXNzZXMgb3ZlcnJpZGUgaXQgdG8gYWRkIHRoZWlyIG93biBmaWVsZHMuXG5cdCogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGNvbXB1dGUgdGhlIHJlc3VsdCBmb3IuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb2JzZXJ2ZXIgb3B0aW9ucyB0byBjb21wdXRlIHRoZSByZXN1bHQgd2l0aC5cblx0KiBAcmV0dXJucyBUaGUgY29tcHV0ZWQgcmVzdWx0LlxuXHQqL1xuXHRjcmVhdGVSZXN1bHQocXVlcnksIG9wdGlvbnMpIHtcblx0XHRjb25zdCBwcmV2UXVlcnkgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG5cdFx0Y29uc3QgcHJldk9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cdFx0Y29uc3QgcHJldlJlc3VsdCA9IHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG5cdFx0Y29uc3QgcHJldlJlc3VsdE9wdGlvbnMgPSB0aGlzLiNjdXJyZW50UmVzdWx0T3B0aW9ucztcblx0XHRjb25zdCBxdWVyeUluaXRpYWxTdGF0ZSA9IHF1ZXJ5ICE9PSBwcmV2UXVlcnkgPyBxdWVyeS5zdGF0ZSA6IHRoaXMuI2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZTtcblx0XHRjb25zdCB7IHN0YXRlIH0gPSBxdWVyeTtcblx0XHRsZXQgbmV3U3RhdGUgPSB7IC4uLnN0YXRlIH07XG5cdFx0bGV0IGlzUGxhY2Vob2xkZXJEYXRhID0gZmFsc2U7XG5cdFx0bGV0IGRhdGE7XG5cdFx0aWYgKG9wdGlvbnMuX29wdGltaXN0aWNSZXN1bHRzKSB7XG5cdFx0XHRjb25zdCBtb3VudGVkID0gdGhpcy5oYXNMaXN0ZW5lcnMoKTtcblx0XHRcdGNvbnN0IGZldGNoT25Nb3VudCA9ICFtb3VudGVkICYmIHNob3VsZEZldGNoT25Nb3VudChxdWVyeSwgb3B0aW9ucyk7XG5cdFx0XHRjb25zdCBmZXRjaE9wdGlvbmFsbHkgPSBtb3VudGVkICYmIHNob3VsZEZldGNoT3B0aW9uYWxseShxdWVyeSwgcHJldlF1ZXJ5LCBvcHRpb25zLCBwcmV2T3B0aW9ucyk7XG5cdFx0XHRpZiAoZmV0Y2hPbk1vdW50IHx8IGZldGNoT3B0aW9uYWxseSkgbmV3U3RhdGUgPSB7XG5cdFx0XHRcdC4uLm5ld1N0YXRlLFxuXHRcdFx0XHQuLi5mZXRjaFN0YXRlKHN0YXRlLmRhdGEsIHF1ZXJ5Lm9wdGlvbnMpXG5cdFx0XHR9O1xuXHRcdFx0aWYgKG9wdGlvbnMuX29wdGltaXN0aWNSZXN1bHRzID09PSBcImlzUmVzdG9yaW5nXCIpIG5ld1N0YXRlLmZldGNoU3RhdHVzID0gXCJpZGxlXCI7XG5cdFx0fVxuXHRcdGxldCB7IGVycm9yLCBlcnJvclVwZGF0ZWRBdCwgc3RhdHVzIH0gPSBuZXdTdGF0ZTtcblx0XHRkYXRhID0gbmV3U3RhdGUuZGF0YTtcblx0XHRsZXQgc2tpcFNlbGVjdCA9IGZhbHNlO1xuXHRcdGlmIChvcHRpb25zLnBsYWNlaG9sZGVyRGF0YSAhPT0gdm9pZCAwICYmIGRhdGEgPT09IHZvaWQgMCAmJiBzdGF0dXMgPT09IFwicGVuZGluZ1wiKSB7XG5cdFx0XHRsZXQgcGxhY2Vob2xkZXJEYXRhO1xuXHRcdFx0Y29uc3QgaXNNZW1vaXplZFBsYWNlaG9sZGVyID0gcHJldlJlc3VsdD8uaXNQbGFjZWhvbGRlckRhdGEgJiYgb3B0aW9ucy5wbGFjZWhvbGRlckRhdGEgPT09IHByZXZSZXN1bHRPcHRpb25zPy5wbGFjZWhvbGRlckRhdGE7XG5cdFx0XHRpZiAoaXNNZW1vaXplZFBsYWNlaG9sZGVyKSB7XG5cdFx0XHRcdHBsYWNlaG9sZGVyRGF0YSA9IHByZXZSZXN1bHQuZGF0YTtcblx0XHRcdFx0c2tpcFNlbGVjdCA9IHRydWU7XG5cdFx0XHR9IGVsc2UgcGxhY2Vob2xkZXJEYXRhID0gdHlwZW9mIG9wdGlvbnMucGxhY2Vob2xkZXJEYXRhID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YSh0aGlzLiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGE/LnN0YXRlLmRhdGEsIHRoaXMuI2xhc3RRdWVyeVdpdGhEZWZpbmVkRGF0YSkgOiBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YTtcblx0XHRcdGlmIChpc01lbW9pemVkUGxhY2Vob2xkZXIgfHwgcGxhY2Vob2xkZXJEYXRhICE9PSB2b2lkIDApIHtcblx0XHRcdFx0c3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0XHRcdGRhdGEgPSByZXBsYWNlRGF0YShvcHRpb25zLnNlbGVjdCAmJiAhc2tpcFNlbGVjdCA/IHRoaXMuI3NlbGVjdElucHV0IDogcHJldlJlc3VsdD8uZGF0YSwgcGxhY2Vob2xkZXJEYXRhLCBvcHRpb25zKTtcblx0XHRcdFx0aXNQbGFjZWhvbGRlckRhdGEgPSB0cnVlO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZiAob3B0aW9ucy5zZWxlY3QgJiYgZGF0YSAhPT0gdm9pZCAwICYmICFza2lwU2VsZWN0KSB7XG5cdFx0XHRpZiAoZGF0YSA9PT0gdGhpcy4jc2VsZWN0SW5wdXQgJiYgb3B0aW9ucy5zZWxlY3QgPT09IHRoaXMuI3NlbGVjdEZuKSBkYXRhID0gdGhpcy4jc2VsZWN0UmVzdWx0O1xuXHRcdFx0ZWxzZSB0cnkge1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RGbiA9IG9wdGlvbnMuc2VsZWN0O1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RJbnB1dCA9IGRhdGE7XG5cdFx0XHRcdGRhdGEgPSBvcHRpb25zLnNlbGVjdChkYXRhKTtcblx0XHRcdFx0ZGF0YSA9IHJlcGxhY2VEYXRhKHByZXZSZXN1bHQ/LmRhdGEsIGRhdGEsIG9wdGlvbnMpO1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RSZXN1bHQgPSBkYXRhO1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RFcnJvciA9IG51bGw7XG5cdFx0XHR9IGNhdGNoIChzZWxlY3RFcnJvcikge1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RFcnJvciA9IHNlbGVjdEVycm9yO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBpZiAoZGF0YSA9PT0gdm9pZCAwKSB7XG5cdFx0XHR0aGlzLiNzZWxlY3RJbnB1dCA9IHZvaWQgMDtcblx0XHRcdHRoaXMuI3NlbGVjdEVycm9yID0gbnVsbDtcblx0XHR9XG5cdFx0aWYgKHRoaXMuI3NlbGVjdEVycm9yKSB7XG5cdFx0XHRlcnJvciA9IHRoaXMuI3NlbGVjdEVycm9yO1xuXHRcdFx0ZGF0YSA9IHRoaXMuI3NlbGVjdFJlc3VsdDtcblx0XHRcdGVycm9yVXBkYXRlZEF0ID0gcHJldlJlc3VsdD8uZXJyb3IgPT09IGVycm9yID8gcHJldlJlc3VsdC5lcnJvclVwZGF0ZWRBdCA6IERhdGUubm93KCk7XG5cdFx0XHRzdGF0dXMgPSBcImVycm9yXCI7XG5cdFx0XHRpc1BsYWNlaG9sZGVyRGF0YSA9IGZhbHNlO1xuXHRcdH1cblx0XHRjb25zdCBpc0ZldGNoaW5nID0gbmV3U3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwiZmV0Y2hpbmdcIjtcblx0XHRjb25zdCBpc1BlbmRpbmcgPSBzdGF0dXMgPT09IFwicGVuZGluZ1wiO1xuXHRcdGNvbnN0IGlzRXJyb3IgPSBzdGF0dXMgPT09IFwiZXJyb3JcIjtcblx0XHRjb25zdCBpc0xvYWRpbmcgPSBpc1BlbmRpbmcgJiYgaXNGZXRjaGluZztcblx0XHRjb25zdCBoYXNEYXRhID0gZGF0YSAhPT0gdm9pZCAwO1xuXHRcdHJldHVybiB7XG5cdFx0XHRzdGF0dXMsXG5cdFx0XHRmZXRjaFN0YXR1czogbmV3U3RhdGUuZmV0Y2hTdGF0dXMsXG5cdFx0XHRpc1BlbmRpbmcsXG5cdFx0XHRpc1N1Y2Nlc3M6IHN0YXR1cyA9PT0gXCJzdWNjZXNzXCIsXG5cdFx0XHRpc0Vycm9yLFxuXHRcdFx0aXNJbml0aWFsTG9hZGluZzogaXNMb2FkaW5nLFxuXHRcdFx0aXNMb2FkaW5nLFxuXHRcdFx0ZGF0YSxcblx0XHRcdGRhdGFVcGRhdGVkQXQ6IG5ld1N0YXRlLmRhdGFVcGRhdGVkQXQsXG5cdFx0XHRlcnJvcixcblx0XHRcdGVycm9yVXBkYXRlZEF0LFxuXHRcdFx0ZmFpbHVyZUNvdW50OiBuZXdTdGF0ZS5mZXRjaEZhaWx1cmVDb3VudCxcblx0XHRcdGZhaWx1cmVSZWFzb246IG5ld1N0YXRlLmZldGNoRmFpbHVyZVJlYXNvbixcblx0XHRcdGVycm9yVXBkYXRlQ291bnQ6IG5ld1N0YXRlLmVycm9yVXBkYXRlQ291bnQsXG5cdFx0XHRpc0ZldGNoZWQ6IHF1ZXJ5LmlzRmV0Y2hlZCgpLFxuXHRcdFx0aXNGZXRjaGVkQWZ0ZXJNb3VudDogbmV3U3RhdGUuZGF0YVVwZGF0ZUNvdW50ID4gcXVlcnlJbml0aWFsU3RhdGUuZGF0YVVwZGF0ZUNvdW50IHx8IG5ld1N0YXRlLmVycm9yVXBkYXRlQ291bnQgPiBxdWVyeUluaXRpYWxTdGF0ZS5lcnJvclVwZGF0ZUNvdW50LFxuXHRcdFx0aXNGZXRjaGluZyxcblx0XHRcdGlzUmVmZXRjaGluZzogaXNGZXRjaGluZyAmJiAhaXNQZW5kaW5nLFxuXHRcdFx0aXNMb2FkaW5nRXJyb3I6IGlzRXJyb3IgJiYgIWhhc0RhdGEsXG5cdFx0XHRpc1BhdXNlZDogbmV3U3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwicGF1c2VkXCIsXG5cdFx0XHRpc1BsYWNlaG9sZGVyRGF0YSxcblx0XHRcdGlzUmVmZXRjaEVycm9yOiBpc0Vycm9yICYmIGhhc0RhdGEsXG5cdFx0XHRpc1N0YWxlOiBpc1N0YWxlKHF1ZXJ5LCBvcHRpb25zKSxcblx0XHRcdHJlZmV0Y2g6IHRoaXMucmVmZXRjaCxcblx0XHRcdGlzRW5hYmxlZDogcmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlXG5cdFx0fTtcblx0fVxuXHQvKipcblx0KiBSZWNvbXB1dGVzIGFuZCBzdG9yZXMgdGhlIGN1cnJlbnQgcmVzdWx0IGZyb20gdGhlIGN1cnJlbnQgcXVlcnkvb3B0aW9ucywgbm90aWZ5aW5nIGxpc3RlbmVyc1xuXHQqIGlmIGl0IGNoYW5nZWQuIEZyYW1ld29yayBhZGFwdGVycyBjYWxsIHRoaXMgcmlnaHQgYWZ0ZXIgc3Vic2NyaWJpbmcgdG8gbWFrZSBzdXJlIG5vIHF1ZXJ5XG5cdCogdXBkYXRlIHdhcyBtaXNzZWQgaW4gdGhlIGdhcCBiZXR3ZWVuIGNyZWF0aW5nIHRoZSBvYnNlcnZlciBhbmQgc3Vic2NyaWJpbmcgdG8gaXQuXG5cdCovXG5cdHVwZGF0ZVJlc3VsdCgpIHtcblx0XHRjb25zdCBwcmV2UmVzdWx0ID0gdGhpcy4jY3VycmVudFJlc3VsdDtcblx0XHRjb25zdCBuZXh0UmVzdWx0ID0gdGhpcy5jcmVhdGVSZXN1bHQodGhpcy4jY3VycmVudFF1ZXJ5LCB0aGlzLm9wdGlvbnMpO1xuXHRcdHRoaXMuI2N1cnJlbnRSZXN1bHRPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdGlmICh0aGlzLiNjdXJyZW50UXVlcnkuc3RhdGUuZGF0YSAhPT0gdm9pZCAwKSB0aGlzLiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGEgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG5cdFx0aWYgKHNoYWxsb3dFcXVhbE9iamVjdHMobmV4dFJlc3VsdCwgcHJldlJlc3VsdCkpIHJldHVybjtcblx0XHR0aGlzLiNjdXJyZW50UmVzdWx0ID0gbmV4dFJlc3VsdDtcblx0XHRjb25zdCBzaG91bGROb3RpZnlMaXN0ZW5lcnMgPSAoKSA9PiB7XG5cdFx0XHRpZiAoIXByZXZSZXN1bHQpIHJldHVybiB0cnVlO1xuXHRcdFx0Y29uc3QgeyBub3RpZnlPbkNoYW5nZVByb3BzIH0gPSB0aGlzLm9wdGlvbnM7XG5cdFx0XHRjb25zdCBub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgPSB0eXBlb2Ygbm90aWZ5T25DaGFuZ2VQcm9wcyA9PT0gXCJmdW5jdGlvblwiID8gbm90aWZ5T25DaGFuZ2VQcm9wcygpIDogbm90aWZ5T25DaGFuZ2VQcm9wcztcblx0XHRcdGlmIChub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgPT09IFwiYWxsXCIgfHwgIW5vdGlmeU9uQ2hhbmdlUHJvcHNWYWx1ZSAmJiAhdGhpcy4jdHJhY2tlZFByb3BzLnNpemUpIHJldHVybiB0cnVlO1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy50aHJvd09uRXJyb3IgJiYgdGhpcy4jY3VycmVudFJlc3VsdC5lcnJvciAhPT0gcHJldlJlc3VsdC5lcnJvcikgcmV0dXJuIHRydWU7XG5cdFx0XHRmb3IgKGNvbnN0IGtleSBvZiBub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgPz8gdGhpcy4jdHJhY2tlZFByb3BzKSBpZiAodGhpcy4jY3VycmVudFJlc3VsdFtrZXldICE9PSBwcmV2UmVzdWx0W2tleV0pIHJldHVybiB0cnVlO1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH07XG5cdFx0Y29uc3Qgbm90aWZ5TGlzdGVuZXJzID0gc2hvdWxkTm90aWZ5TGlzdGVuZXJzKCk7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRpZiAobm90aWZ5TGlzdGVuZXJzKSB0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0XHRsaXN0ZW5lcih0aGlzLiNjdXJyZW50UmVzdWx0KTtcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5ub3RpZnkoe1xuXHRcdFx0XHRxdWVyeTogdGhpcy4jY3VycmVudFF1ZXJ5LFxuXHRcdFx0XHR0eXBlOiBcIm9ic2VydmVyUmVzdWx0c1VwZGF0ZWRcIlxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0I3VwZGF0ZVF1ZXJ5KCkge1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIHRoaXMub3B0aW9ucyk7XG5cdFx0aWYgKHF1ZXJ5ID09PSB0aGlzLiNjdXJyZW50UXVlcnkpIHJldHVybjtcblx0XHRjb25zdCBwcmV2UXVlcnkgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG5cdFx0dGhpcy4jY3VycmVudFF1ZXJ5ID0gcXVlcnk7XG5cdFx0dGhpcy4jY3VycmVudFF1ZXJ5SW5pdGlhbFN0YXRlID0gcXVlcnkuc3RhdGU7XG5cdFx0aWYgKHRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcblx0XHRcdHByZXZRdWVyeT8ucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG5cdFx0XHRxdWVyeS5hZGRPYnNlcnZlcih0aGlzKTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogVXBkYXRlcyB0aGUgb2JzZXJ2ZXIncyByZXN1bHQgd2hlbiB0aGUgb2JzZXJ2ZWQgcXVlcnkgY2hhbmdlcywgYW5kIHJlc2NoZWR1bGVzIGl0cyB0aW1lcnMgaWYgaXRcblx0KiBoYXMgbGlzdGVuZXJzLlxuXHQqIEBpbnRlcm5hbFxuXHQqL1xuXHRvblF1ZXJ5VXBkYXRlKCkge1xuXHRcdHRoaXMudXBkYXRlUmVzdWx0KCk7XG5cdFx0aWYgKHRoaXMuaGFzTGlzdGVuZXJzKCkpIHRoaXMuI3VwZGF0ZVRpbWVycygpO1xuXHR9XG59O1xuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgaGFzIG5vIGRhdGEgeWV0IGFuZCBzaG91bGQgZG8gaXRzIGluaXRpYWwgbG9hZCB3aGVuIGFuIG9ic2VydmVyIG1vdW50cy5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGNoZWNrLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvYnNlcnZlciBvcHRpb25zLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGlzIGVuYWJsZWQsIGhhcyBubyBkYXRhLCBhbmQgaXNuJ3QgaW4gYW4gZXJyb3Igc3RhdGUgd2l0aFxuKiBgcmV0cnlPbk1vdW50OiBmYWxzZWAuXG4qL1xuZnVuY3Rpb24gc2hvdWxkTG9hZE9uTW91bnQocXVlcnksIG9wdGlvbnMpIHtcblx0cmV0dXJuIHJlc29sdmVRdWVyeVZhbHVlKG9wdGlvbnMuZW5hYmxlZCwgcXVlcnkpICE9PSBmYWxzZSAmJiBxdWVyeS5zdGF0ZS5kYXRhID09PSB2b2lkIDAgJiYgIShxdWVyeS5zdGF0ZS5zdGF0dXMgPT09IFwiZXJyb3JcIiAmJiByZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLnJldHJ5T25Nb3VudCwgcXVlcnkpID09PSBmYWxzZSk7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBxdWVyeSBzaG91bGQgZmV0Y2ggd2hlbiBhbiBvYnNlcnZlciBtb3VudHM6IGVpdGhlciBmb3IgaXRzIGluaXRpYWwgbG9hZCwgb3JcbiogYmVjYXVzZSBpdCBoYXMgZGF0YSBhbmQgYHJlZmV0Y2hPbk1vdW50YCBhc2tzIGZvciBhIHJlZmV0Y2guXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0byBjaGVjay5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb2JzZXJ2ZXIgb3B0aW9ucy5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBzaG91bGQgZmV0Y2ggb24gbW91bnQuXG4qL1xuZnVuY3Rpb24gc2hvdWxkRmV0Y2hPbk1vdW50KHF1ZXJ5LCBvcHRpb25zKSB7XG5cdHJldHVybiBzaG91bGRMb2FkT25Nb3VudChxdWVyeSwgb3B0aW9ucykgfHwgcXVlcnkuc3RhdGUuZGF0YSAhPT0gdm9pZCAwICYmIHNob3VsZEZldGNoT24ocXVlcnksIG9wdGlvbnMsIG9wdGlvbnMucmVmZXRjaE9uTW91bnQpO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgc2hvdWxkIGZldGNoIGZvciBhIGByZWZldGNoT25Nb3VudGAsIGByZWZldGNoT25XaW5kb3dGb2N1c2AsIG9yXG4qIGByZWZldGNoT25SZWNvbm5lY3RgIG9wdGlvbi5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGNoZWNrLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvYnNlcnZlciBvcHRpb25zLlxuKiBAcGFyYW0gZmllbGQgLSBUaGUgdmFsdWUgb2YgdGhlIG9wdGlvbiB0byBjaGVjay5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBlbmFibGVkLCBub3Qgc3RhdGljLCBhbmQgdGhlIG9wdGlvbiBpcyBgJ2Fsd2F5cydgLCBvciBpcyBub3RcbiogYGZhbHNlYCBhbmQgdGhlIHF1ZXJ5IGlzIHN0YWxlLlxuKi9cbmZ1bmN0aW9uIHNob3VsZEZldGNoT24ocXVlcnksIG9wdGlvbnMsIGZpZWxkKSB7XG5cdGlmIChyZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSAhPT0gZmFsc2UgJiYgcmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSAhPT0gXCJzdGF0aWNcIikge1xuXHRcdGNvbnN0IHZhbHVlID0gcmVzb2x2ZVF1ZXJ5VmFsdWUoZmllbGQsIHF1ZXJ5KTtcblx0XHRyZXR1cm4gdmFsdWUgPT09IFwiYWx3YXlzXCIgfHwgdmFsdWUgIT09IGZhbHNlICYmIGlzU3RhbGUocXVlcnksIG9wdGlvbnMpO1xuXHR9XG5cdHJldHVybiBmYWxzZTtcbn1cbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIHF1ZXJ5IHNob3VsZCBmZXRjaCBhZnRlciB0aGUgb2JzZXJ2ZXIncyBvcHRpb25zIGNoYW5nZS5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IG9ic2VydmVkIHdpdGggdGhlIG5ldyBvcHRpb25zLlxuKiBAcGFyYW0gcHJldlF1ZXJ5IC0gVGhlIHF1ZXJ5IG9ic2VydmVkIHdpdGggdGhlIHByZXZpb3VzIG9wdGlvbnMuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIG5ldyBvYnNlcnZlciBvcHRpb25zLlxuKiBAcGFyYW0gcHJldk9wdGlvbnMgLSBUaGUgcHJldmlvdXMgb2JzZXJ2ZXIgb3B0aW9ucy5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBjaGFuZ2VkIG9yIHdhcyBkaXNhYmxlZCBiZWZvcmUsIGl0IGlzbid0IGEgc3VzcGVuc2UgcXVlcnkgaW4gYW5cbiogZXJyb3Igc3RhdGUsIGFuZCBpdCBpcyBzdGFsZS5cbiovXG5mdW5jdGlvbiBzaG91bGRGZXRjaE9wdGlvbmFsbHkocXVlcnksIHByZXZRdWVyeSwgb3B0aW9ucywgcHJldk9wdGlvbnMpIHtcblx0cmV0dXJuIChxdWVyeSAhPT0gcHJldlF1ZXJ5IHx8IHJlc29sdmVRdWVyeVZhbHVlKHByZXZPcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSA9PT0gZmFsc2UpICYmICghb3B0aW9ucy5zdXNwZW5zZSB8fCBxdWVyeS5zdGF0ZS5zdGF0dXMgIT09IFwiZXJyb3JcIikgJiYgaXNTdGFsZShxdWVyeSwgb3B0aW9ucyk7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBxdWVyeSBpcyBzdGFsZSBmb3IgdGhlIGdpdmVuIG9ic2VydmVyIG9wdGlvbnMuXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0byBjaGVjay5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb2JzZXJ2ZXIgb3B0aW9ucywgd2hvc2UgYGVuYWJsZWRgIGFuZCBgc3RhbGVUaW1lYCBhcmUgdXNlZC5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBlbmFibGVkIGFuZCBpdHMgZGF0YSBpcyBzdGFsZSBmb3IgYHN0YWxlVGltZWAuXG4qL1xuZnVuY3Rpb24gaXNTdGFsZShxdWVyeSwgb3B0aW9ucykge1xuXHRyZXR1cm4gcmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlICYmIHF1ZXJ5LmlzU3RhbGVCeVRpbWUocmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSk7XG59XG5leHBvcnQgeyBRdWVyeU9ic2VydmVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJ5T2JzZXJ2ZXIuanMubWFwIiwiaW1wb3J0IHsgaGFzTmV4dFBhZ2UsIGhhc1ByZXZpb3VzUGFnZSB9IGZyb20gXCIuL2luZmluaXRlUXVlcnlCZWhhdmlvci5qc1wiO1xuaW1wb3J0IHsgUXVlcnlPYnNlcnZlciB9IGZyb20gXCIuL3F1ZXJ5T2JzZXJ2ZXIuanNcIjtcbi8vIHNyYy9pbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIudHNcbi8qKlxuKiBBbiBgSW5maW5pdGVRdWVyeU9ic2VydmVyYCBleHRlbmRzIGBRdWVyeU9ic2VydmVyYCB0byBvYnNlcnZlIGFuZCBzd2l0Y2hcbiogYmV0d2VlbiBpbmZpbml0ZSBxdWVyaWVzLiBJdCBhdWdtZW50cyB0aGUgYmFzZSBgUXVlcnlPYnNlcnZlclJlc3VsdGAgd2l0aFxuKiBpbmZpbml0ZS1xdWVyeS1zcGVjaWZpYyBmaWVsZHMgYW5kIG1ldGhvZHMsIHN1Y2ggYXMgYGhhc05leHRQYWdlYCBhbmRcbiogYGZldGNoTmV4dFBhZ2VgLCBhbmQgaXMgdGhlIHByaW1pdGl2ZSB0aGF0IGZyYW1ld29yayBhZGFwdGVycyAoZS5nLlxuKiBgdXNlSW5maW5pdGVRdWVyeWApIGJ1aWxkIHRoZWlyIGhvb2tzIG9uIHRvcCBvZi5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgSW5maW5pdGVRdWVyeU9ic2VydmVyKHF1ZXJ5Q2xpZW50LCB7XG4qICAgcXVlcnlLZXk6IFsncHJvamVjdHMnXSxcbiogICBxdWVyeUZuOiAoeyBwYWdlUGFyYW0gfSkgPT4gZmV0Y2hQcm9qZWN0cyhwYWdlUGFyYW0pLFxuKiAgIGluaXRpYWxQYWdlUGFyYW06IDAsXG4qICAgZ2V0TmV4dFBhZ2VQYXJhbTogKGxhc3RQYWdlKSA9PiBsYXN0UGFnZS5uZXh0Q3Vyc29yLFxuKiB9KVxuKlxuKiBjb25zdCB1bnN1YnNjcmliZSA9IG9ic2VydmVyLnN1YnNjcmliZSgocmVzdWx0KSA9PiBjb25zb2xlLmxvZyhyZXN1bHQpKVxuKiBgYGBcbiovXG52YXIgSW5maW5pdGVRdWVyeU9ic2VydmVyID0gY2xhc3MgZXh0ZW5kcyBRdWVyeU9ic2VydmVyIHtcblx0Y29uc3RydWN0b3IoY2xpZW50LCBvcHRpb25zKSB7XG5cdFx0c3VwZXIoY2xpZW50LCBvcHRpb25zKTtcblx0fVxuXHRiaW5kTWV0aG9kcygpIHtcblx0XHRzdXBlci5iaW5kTWV0aG9kcygpO1xuXHRcdHRoaXMuZmV0Y2hOZXh0UGFnZSA9IHRoaXMuZmV0Y2hOZXh0UGFnZS5iaW5kKHRoaXMpO1xuXHRcdHRoaXMuZmV0Y2hQcmV2aW91c1BhZ2UgPSB0aGlzLmZldGNoUHJldmlvdXNQYWdlLmJpbmQodGhpcyk7XG5cdH1cblx0LyoqXG5cdCogVXBkYXRlcyB0aGUgb2JzZXJ2ZXIncyBvcHRpb25zLiBCZWhhdmVzIHRoZSBzYW1lIGFzXG5cdCogYFF1ZXJ5T2JzZXJ2ZXIuc2V0T3B0aW9uc2AsIGFkZGl0aW9uYWxseSBtYXJraW5nIHRoZSBvcHRpb25zIGFzXG5cdCogYmVsb25naW5nIHRvIGFuIGluZmluaXRlIHF1ZXJ5IGJlZm9yZSBkZWxlZ2F0aW5nIHRvIHRoZSBiYXNlXG5cdCogaW1wbGVtZW50YXRpb24uXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgbmV3IGluZmluaXRlIHF1ZXJ5IG9ic2VydmVyIG9wdGlvbnMuXG5cdCovXG5cdHNldE9wdGlvbnMob3B0aW9ucykge1xuXHRcdG9wdGlvbnMuX3R5cGUgPSBcImluZmluaXRlXCI7XG5cdFx0c3VwZXIuc2V0T3B0aW9ucyhvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBUaGUgaW5maW5pdGUtcXVlcnkgY291bnRlcnBhcnQgb2Yge0BsaW5rIFF1ZXJ5T2JzZXJ2ZXIjZ2V0T3B0aW1pc3RpY1Jlc3VsdH0sIG1hcmtpbmcgdGhlXG5cdCogb3B0aW9ucyBhcyBhbiBpbmZpbml0ZSBxdWVyeSBiZWZvcmUgZGVsZWdhdGluZyB0byBpdC4gQ2FsbGVkIGJ5IGZyYW1ld29yayBhZGFwdGVycyAoZS5nLlxuXHQqIGB1c2VJbmZpbml0ZVF1ZXJ5YCkgYWhlYWQgb2Ygc3Vic2NyaWJpbmcsIHRvIGNvbXB1dGUgdGhlIGN1cnJlbnQgYEluZmluaXRlUXVlcnlPYnNlcnZlclJlc3VsdGBcblx0KiBzeW5jaHJvbm91c2x5LlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGRlZmF1bHRlZCBpbmZpbml0ZSBxdWVyeSBvYnNlcnZlciBvcHRpb25zIHRvIGNvbXB1dGUgdGhlIHJlc3VsdCBmb3IuXG5cdCogQHJldHVybnMgVGhlIHJlc3VsdCBmb3IgdGhlIGdpdmVuIG9wdGlvbnMuXG5cdCovXG5cdGdldE9wdGltaXN0aWNSZXN1bHQob3B0aW9ucykge1xuXHRcdG9wdGlvbnMuX3R5cGUgPSBcImluZmluaXRlXCI7XG5cdFx0cmV0dXJuIHN1cGVyLmdldE9wdGltaXN0aWNSZXN1bHQob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyB0aGUgbmV4dCBwYWdlIG9mIHRoZSBpbmZpbml0ZSBxdWVyeSBhbmQgcmV0dXJucyBhIHByb21pc2UgdGhhdFxuXHQqIHJlc29sdmVzIHdpdGggdGhlIHJlc3VsdGluZyBgSW5maW5pdGVRdWVyeU9ic2VydmVyUmVzdWx0YC4gVGhlIHBhZ2Vcblx0KiBwYXJhbSB1c2VkIGZvciB0aGUgZmV0Y2ggaXMgZGV0ZXJtaW5lZCBieSBgZ2V0TmV4dFBhZ2VQYXJhbWAsIHdoaWNoXG5cdCogcmVjZWl2ZXMgdGhlIGN1cnJlbnQgcGFnZXMvcGFnZSBwYXJhbXMgYW5kIHdob3NlIHJlc3VsdCBhbHNvIGRldGVybWluZXNcblx0KiBgaGFzTmV4dFBhZ2VgLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gU2V0IGBjYW5jZWxSZWZldGNoYCB0byBgZmFsc2VgIHRvIGlnbm9yZSB0aGUgY2FsbCB3aGlsZSBhIGZldGNoIGlzIHJ1bm5pbmcsXG5cdCogYW5kIGB0aHJvd09uRXJyb3JgIHRvIGB0cnVlYCB0byByZWplY3Qgd2hlbiB0aGUgZmV0Y2ggZmFpbHMuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgcmVzdWx0IGFmdGVyIHRoZSBuZXh0IHBhZ2UgaXMgZmV0Y2hlZC4gV2l0aFxuXHQqIGBjYW5jZWxSZWZldGNoOiBmYWxzZWAsIGEgcnVubmluZyBmZXRjaCBpcyByZXVzZWQgaW5zdGVhZCwgc28gdGhlIG5leHQgcGFnZSBtYXkgbm90IGJlIGZldGNoZWQuXG5cdCogQHNlZSB7QGxpbmsgSW5maW5pdGVRdWVyeU9ic2VydmVyI2ZldGNoUHJldmlvdXNQYWdlfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCB7IGhhc05leHRQYWdlIH0gPSBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KClcblx0KlxuXHQqIGlmIChoYXNOZXh0UGFnZSkge1xuXHQqICAgYXdhaXQgb2JzZXJ2ZXIuZmV0Y2hOZXh0UGFnZSgpXG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRmZXRjaE5leHRQYWdlKG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaCh7XG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0bWV0YTogeyBmZXRjaE1vcmU6IHsgZGlyZWN0aW9uOiBcImZvcndhcmRcIiB9IH1cblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIHRoZSBwcmV2aW91cyBwYWdlIG9mIHRoZSBpbmZpbml0ZSBxdWVyeSBhbmQgcmV0dXJucyBhIHByb21pc2Vcblx0KiB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHJlc3VsdGluZyBgSW5maW5pdGVRdWVyeU9ic2VydmVyUmVzdWx0YC4gVGhlIHBhZ2Vcblx0KiBwYXJhbSB1c2VkIGZvciB0aGUgZmV0Y2ggaXMgZGV0ZXJtaW5lZCBieSBgZ2V0UHJldmlvdXNQYWdlUGFyYW1gLCB3aGljaFxuXHQqIHJlY2VpdmVzIHRoZSBjdXJyZW50IHBhZ2VzL3BhZ2UgcGFyYW1zIGFuZCB3aG9zZSByZXN1bHQgYWxzbyBkZXRlcm1pbmVzXG5cdCogYGhhc1ByZXZpb3VzUGFnZWAuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBTZXQgYGNhbmNlbFJlZmV0Y2hgIHRvIGBmYWxzZWAgdG8gaWdub3JlIHRoZSBjYWxsIHdoaWxlIGEgZmV0Y2ggaXMgcnVubmluZyxcblx0KiBhbmQgYHRocm93T25FcnJvcmAgdG8gYHRydWVgIHRvIHJlamVjdCB3aGVuIHRoZSBmZXRjaCBmYWlscy5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHQgYWZ0ZXIgdGhlIHByZXZpb3VzIHBhZ2UgaXMgZmV0Y2hlZC4gV2l0aFxuXHQqIGBjYW5jZWxSZWZldGNoOiBmYWxzZWAsIGEgcnVubmluZyBmZXRjaCBpcyByZXVzZWQgaW5zdGVhZCwgc28gdGhlIHByZXZpb3VzIHBhZ2UgbWF5IG5vdCBiZSBmZXRjaGVkLlxuXHQqIEBzZWUge0BsaW5rIEluZmluaXRlUXVlcnlPYnNlcnZlciNmZXRjaE5leHRQYWdlfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCB7IGhhc1ByZXZpb3VzUGFnZSB9ID0gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpXG5cdCpcblx0KiBpZiAoaGFzUHJldmlvdXNQYWdlKSB7XG5cdCogICBhd2FpdCBvYnNlcnZlci5mZXRjaFByZXZpb3VzUGFnZSgpXG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRmZXRjaFByZXZpb3VzUGFnZShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2goe1xuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdG1ldGE6IHsgZmV0Y2hNb3JlOiB7IGRpcmVjdGlvbjogXCJiYWNrd2FyZFwiIH0gfVxuXHRcdH0pO1xuXHR9XG5cdGNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucykge1xuXHRcdGNvbnN0IHsgc3RhdGUgfSA9IHF1ZXJ5O1xuXHRcdGNvbnN0IHBhcmVudFJlc3VsdCA9IHN1cGVyLmNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucyk7XG5cdFx0Y29uc3QgeyBpc0ZldGNoaW5nLCBpc1JlZmV0Y2hpbmcsIGlzRXJyb3IsIGlzUmVmZXRjaEVycm9yIH0gPSBwYXJlbnRSZXN1bHQ7XG5cdFx0Y29uc3QgZmV0Y2hEaXJlY3Rpb24gPSBzdGF0ZS5mZXRjaE1ldGE/LmZldGNoTW9yZT8uZGlyZWN0aW9uO1xuXHRcdGNvbnN0IGlzRmV0Y2hOZXh0UGFnZUVycm9yID0gaXNFcnJvciAmJiBmZXRjaERpcmVjdGlvbiA9PT0gXCJmb3J3YXJkXCI7XG5cdFx0Y29uc3QgaXNGZXRjaGluZ05leHRQYWdlID0gaXNGZXRjaGluZyAmJiBmZXRjaERpcmVjdGlvbiA9PT0gXCJmb3J3YXJkXCI7XG5cdFx0Y29uc3QgaXNGZXRjaFByZXZpb3VzUGFnZUVycm9yID0gaXNFcnJvciAmJiBmZXRjaERpcmVjdGlvbiA9PT0gXCJiYWNrd2FyZFwiO1xuXHRcdGNvbnN0IGlzRmV0Y2hpbmdQcmV2aW91c1BhZ2UgPSBpc0ZldGNoaW5nICYmIGZldGNoRGlyZWN0aW9uID09PSBcImJhY2t3YXJkXCI7XG5cdFx0cmV0dXJuIHtcblx0XHRcdC4uLnBhcmVudFJlc3VsdCxcblx0XHRcdGZldGNoTmV4dFBhZ2U6IHRoaXMuZmV0Y2hOZXh0UGFnZSxcblx0XHRcdGZldGNoUHJldmlvdXNQYWdlOiB0aGlzLmZldGNoUHJldmlvdXNQYWdlLFxuXHRcdFx0aGFzTmV4dFBhZ2U6IGhhc05leHRQYWdlKG9wdGlvbnMsIHN0YXRlLmRhdGEpLFxuXHRcdFx0aGFzUHJldmlvdXNQYWdlOiBoYXNQcmV2aW91c1BhZ2Uob3B0aW9ucywgc3RhdGUuZGF0YSksXG5cdFx0XHRpc0ZldGNoTmV4dFBhZ2VFcnJvcixcblx0XHRcdGlzRmV0Y2hpbmdOZXh0UGFnZSxcblx0XHRcdGlzRmV0Y2hQcmV2aW91c1BhZ2VFcnJvcixcblx0XHRcdGlzRmV0Y2hpbmdQcmV2aW91c1BhZ2UsXG5cdFx0XHRpc1JlZmV0Y2hFcnJvcjogaXNSZWZldGNoRXJyb3IgJiYgIWlzRmV0Y2hOZXh0UGFnZUVycm9yICYmICFpc0ZldGNoUHJldmlvdXNQYWdlRXJyb3IsXG5cdFx0XHRpc1JlZmV0Y2hpbmc6IGlzUmVmZXRjaGluZyAmJiAhaXNGZXRjaGluZ05leHRQYWdlICYmICFpc0ZldGNoaW5nUHJldmlvdXNQYWdlXG5cdFx0fTtcblx0fVxufTtcbmV4cG9ydCB7IEluZmluaXRlUXVlcnlPYnNlcnZlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIuanMubWFwIiwiaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IFJlbW92YWJsZSB9IGZyb20gXCIuL3JlbW92YWJsZS5qc1wiO1xuaW1wb3J0IHsgY3JlYXRlUmV0cnllciB9IGZyb20gXCIuL3JldHJ5ZXIuanNcIjtcbi8vIHNyYy9tdXRhdGlvbi50c1xuLyoqXG4qIFJlcHJlc2VudHMgYSBzaW5nbGUgbXV0YXRpb24gYXR0ZW1wdC4gQSBgTXV0YXRpb25gIGhvbGRzIHRoZSBtdXRhdGlvbidzXG4qIG9wdGlvbnMsIHN0YXRlIChkYXRhL2Vycm9yL3N0YXR1cyksIGFuZCB0aGUgYE11dGF0aW9uT2JzZXJ2ZXJgcyBjdXJyZW50bHlcbiogc3Vic2NyaWJlZCB0byBpdC5cbipcbiogSW5zdGFuY2VzIGFyZSBjcmVhdGVkIGFuZCBtYW5hZ2VkIGludGVybmFsbHkgYnkgYE11dGF0aW9uQ2FjaGVgOyBhcHBsaWNhdGlvblxuKiBjb2RlIHR5cGljYWxseSBpbnRlcmFjdHMgd2l0aCBtdXRhdGlvbnMgaW5kaXJlY3RseSB0aHJvdWdoIGBRdWVyeUNsaWVudGAgb3JcbiogYSBmcmFtZXdvcmsgaG9vayBsaWtlIGB1c2VNdXRhdGlvbmAuIERpcmVjdCBhY2Nlc3MgdG8gYSBgTXV0YXRpb25gIGluc3RhbmNlXG4qIGlzIHBvc3NpYmxlIHZpYSBgbXV0YXRpb25DYWNoZS5maW5kKClgL2BnZXRBbGwoKWAgZm9yIGluc3BlY3RpbmcgY2FjaGUgc3RhdGUuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcbipcbiogY29uc3QgbXV0YXRpb24gPSBtdXRhdGlvbkNhY2hlLmZpbmQoeyBtdXRhdGlvbktleTogWydhZGRQb3N0J10gfSlcbiogYGBgXG4qL1xudmFyIE11dGF0aW9uID0gY2xhc3MgZXh0ZW5kcyBSZW1vdmFibGUge1xuXHQjY2xpZW50O1xuXHQjb2JzZXJ2ZXJzO1xuXHQjbXV0YXRpb25DYWNoZTtcblx0I3JldHJ5ZXI7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZykge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy4jY2xpZW50ID0gY29uZmlnLmNsaWVudDtcblx0XHR0aGlzLm11dGF0aW9uSWQgPSBjb25maWcubXV0YXRpb25JZDtcblx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlID0gY29uZmlnLm11dGF0aW9uQ2FjaGU7XG5cdFx0dGhpcy4jb2JzZXJ2ZXJzID0gW107XG5cdFx0dGhpcy5zdGF0ZSA9IGNvbmZpZy5zdGF0ZSB8fCBnZXREZWZhdWx0U3RhdGUoKTtcblx0XHR0aGlzLnNldE9wdGlvbnMoY29uZmlnLm9wdGlvbnMpO1xuXHRcdHRoaXMuc2NoZWR1bGVHYygpO1xuXHR9XG5cdC8qKlxuXHQqIFJlcGxhY2VzIHRoZSBtdXRhdGlvbidzIG9wdGlvbnMgYW5kIGFwcGxpZXMgdGhlaXIgYGdjVGltZWAuXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgbmV3IG11dGF0aW9uIG9wdGlvbnMuXG5cdCovXG5cdHNldE9wdGlvbnMob3B0aW9ucykge1xuXHRcdHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG5cdFx0dGhpcy51cGRhdGVHY1RpbWUodGhpcy5vcHRpb25zLmdjVGltZSk7XG5cdH1cblx0LyoqXG5cdCogVGhlIGBtZXRhYCBvYmplY3QgcGFzc2VkIGluIHRoZSBtdXRhdGlvbidzIG9wdGlvbnMsIGlmIGFueS5cblx0KiBAcmV0dXJucyBUaGUgbXV0YXRpb24ncyBgbWV0YWAsIG9yIGB1bmRlZmluZWRgIGlmIG5vbmUgd2FzIHNldC5cblx0Ki9cblx0Z2V0IG1ldGEoKSB7XG5cdFx0cmV0dXJuIHRoaXMub3B0aW9ucy5tZXRhO1xuXHR9XG5cdC8qKlxuXHQqIFN1YnNjcmliZXMgYW4gb2JzZXJ2ZXIgdG8gdGhlIG11dGF0aW9uIGFuZCBzdG9wcyBpdHMgZ2FyYmFnZSBjb2xsZWN0aW9uLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBvYnNlcnZlciAtIFRoZSBvYnNlcnZlciB0byBhZGQuIEFkZGluZyBhbiBvYnNlcnZlciB0aGF0IGlzIGFscmVhZHkgc3Vic2NyaWJlZCBkb2VzXG5cdCogbm90aGluZy5cblx0Ki9cblx0YWRkT2JzZXJ2ZXIob2JzZXJ2ZXIpIHtcblx0XHRpZiAoIXRoaXMuI29ic2VydmVycy5pbmNsdWRlcyhvYnNlcnZlcikpIHtcblx0XHRcdHRoaXMuI29ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcblx0XHRcdHRoaXMuY2xlYXJHY1RpbWVvdXQoKTtcblx0XHRcdHRoaXMuI211dGF0aW9uQ2FjaGUubm90aWZ5KHtcblx0XHRcdFx0dHlwZTogXCJvYnNlcnZlckFkZGVkXCIsXG5cdFx0XHRcdG11dGF0aW9uOiB0aGlzLFxuXHRcdFx0XHRvYnNlcnZlclxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIFVuc3Vic2NyaWJlcyBhbiBvYnNlcnZlciBmcm9tIHRoZSBtdXRhdGlvbi5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gb2JzZXJ2ZXIgLSBUaGUgb2JzZXJ2ZXIgdG8gcmVtb3ZlLiBTY2hlZHVsZXMgZ2FyYmFnZSBjb2xsZWN0aW9uIGlmIHRoZSBtdXRhdGlvblxuXHQqIGlzIHN0aWxsIGluIHRoZSBjYWNoZS5cblx0Ki9cblx0cmVtb3ZlT2JzZXJ2ZXIob2JzZXJ2ZXIpIHtcblx0XHR0aGlzLiNvYnNlcnZlcnMgPSB0aGlzLiNvYnNlcnZlcnMuZmlsdGVyKCh4KSA9PiB4ICE9PSBvYnNlcnZlcik7XG5cdFx0aWYgKHRoaXMuI211dGF0aW9uQ2FjaGUuaGFzKHRoaXMpKSB0aGlzLnNjaGVkdWxlR2MoKTtcblx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcIm9ic2VydmVyUmVtb3ZlZFwiLFxuXHRcdFx0bXV0YXRpb246IHRoaXMsXG5cdFx0XHRvYnNlcnZlclxuXHRcdH0pO1xuXHR9XG5cdG9wdGlvbmFsUmVtb3ZlKCkge1xuXHRcdGlmICghdGhpcy4jb2JzZXJ2ZXJzLmxlbmd0aCkge1xuXHRcdFx0aWYgKHRoaXMuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIikgdGhpcy5zY2hlZHVsZUdjKCk7XG5cdFx0XHRlbHNlIHRoaXMuI211dGF0aW9uQ2FjaGUucmVtb3ZlKHRoaXMpO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBSZXN1bWVzIGEgbXV0YXRpb24gdGhhdCBpcyBjdXJyZW50bHkgcGF1c2VkIG9yIHdhcyByZXN0b3JlZCBmcm9tIGFcblx0KiBkZWh5ZHJhdGVkLCBzdGlsbC1gcGVuZGluZ2Agc3RhdGUuXG5cdCpcblx0KiAtIElmIHRoaXMgbXV0YXRpb24gaGFzIGFuIGFjdGl2ZSByZXRyeWVyIChpdCBwYXVzZWQgbWlkLWF0dGVtcHQsIGUuZy4gZHVlXG5cdCogICB0byB0aGUgbmV0d29yayBtb2RlIG9yIHNjb3BlLWJhc2VkIHF1ZXVpbmcpLCBpdHMgcmV0cnllciBpcyByZXN1bWVkLlxuXHQqIC0gT3RoZXJ3aXNlLCBpZiB0aGUgbXV0YXRpb24ncyBzdGF0dXMgaXMgc3RpbGwgYHBlbmRpbmdgIChlLmcuIGl0IHdhc1xuXHQqICAgZGVoeWRyYXRlZCB3aGlsZSBhbiBhdHRlbXB0IHdhcyBpbiBmbGlnaHQgYW5kIG5ldmVyIGdvdCBhIHJldHJ5ZXIgaW5cblx0KiAgIHRoaXMgaW5zdGFuY2UpLCBgZXhlY3V0ZWAgaXMgY2FsbGVkIGFnYWluIHdpdGggdGhlIGxhc3Qga25vd24gdmFyaWFibGVzLlxuXHQqIC0gT3RoZXJ3aXNlIHRoZSBtdXRhdGlvbiBoYXMgYWxyZWFkeSBzZXR0bGVkIGFuZCB0aGlzIHJlc29sdmVzIGltbWVkaWF0ZWx5XG5cdCogICB3aXRob3V0IHJ1bm5pbmcgYW55dGhpbmcgYWdhaW4uXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgc2V0dGxlcyB3aXRoIHRoZSByZXN1bWVkIG11dGF0aW9uOiBpdCByZWplY3RzIGlmIHRoZSBtdXRhdGlvbiBmYWlscy5cblx0KiBJdCByZXNvbHZlcyBpbW1lZGlhdGVseSBpZiB0aGUgbXV0YXRpb24gaGFzIGFscmVhZHkgc2V0dGxlZC5cblx0KiBAc2VlIHtAbGluayBNdXRhdGlvbiNleGVjdXRlfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiAvLyB0eXBpY2FsbHkgZHJpdmVuIGJ5IHJlY29ubmVjdCBoYW5kbGluZywgZS5nLiBxdWVyeUNsaWVudC5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKVxuXHQqIGNvbnN0IG11dGF0aW9uID0gbXV0YXRpb25DYWNoZS5maW5kKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0pXG5cdCogYXdhaXQgbXV0YXRpb24/LmNvbnRpbnVlKClcblx0KiBgYGBcblx0Ki9cblx0Y29udGludWUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3JldHJ5ZXI/LmNvbnRpbnVlKCkgPz8gKHRoaXMuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiA/IHRoaXMuZXhlY3V0ZSh0aGlzLnN0YXRlLnZhcmlhYmxlcykgOiBQcm9taXNlLnJlc29sdmUoKSk7XG5cdH1cblx0LyoqXG5cdCogUnVucyB0aGUgbXV0YXRpb24gZnVuY3Rpb24gZm9yIHRoZSBnaXZlbiB2YXJpYWJsZXMgdGhyb3VnaCBhIHJldHJ5ZXIsIGFuZFxuXHQqIGRyaXZlcyB0aGUgbXV0YXRpb24ncyBzdGF0ZSBhbmQgbGlmZWN5Y2xlIGNhbGxiYWNrcyB0aHJvdWdoIHRvIHNldHRsZW1lbnQuXG5cdCpcblx0KiBJZiB0aGlzIG11dGF0aW9uJ3Mgc3RhdGUgaXMgYWxyZWFkeSBgcGVuZGluZ2Agd2hlbiBgZXhlY3V0ZWAgaXMgY2FsbGVkXG5cdCogKGkuZS4gaXQgd2FzIHJlc3RvcmVkLCBzdGlsbCBpbi1mbGlnaHQsIGZyb20gYSBkZWh5ZHJhdGVkIHN0YXRlKSwgdGhlXG5cdCogYG9uTXV0YXRlYCBzdGVwIGlzIHNraXBwZWQgYW5kIGEgYGNvbnRpbnVlYCBhY3Rpb24gaXMgZGlzcGF0Y2hlZCB0b1xuXHQqIHVucGF1c2UgaXQ7IG90aGVyd2lzZSBhIGBwZW5kaW5nYCBhY3Rpb24gaXMgZGlzcGF0Y2hlZCBmaXJzdCwgdGhlbiB0aGVcblx0KiBtdXRhdGlvbiBjYWNoZSdzIGBvbk11dGF0ZWAgYW5kIHRoZSBtdXRhdGlvbidzIG93biBgb25NdXRhdGVgIG9wdGlvbiBhcmVcblx0KiBhd2FpdGVkIGluIHRoYXQgb3JkZXIsIGFuZCB0aGUgcmVzdWx0aW5nIGNvbnRleHQgaXMgc3RvcmVkLlxuXHQqXG5cdCogVGhlIG11dGF0aW9uIGZ1bmN0aW9uIGlzIHRoZW4gcnVuIChzdWJqZWN0IHRvIGByZXRyeWAvYHJldHJ5RGVsYXlgL1xuXHQqIGBuZXR3b3JrTW9kZWAsIGFuZCB0byB0aGUgbXV0YXRpb24gY2FjaGUncyBzY29wZS1iYXNlZCBzZXJpYWxpemF0aW9uKS5cblx0KiBPbiBzdWNjZXNzLCB0aGUgY2FjaGUncyBgb25TdWNjZXNzYC9gb25TZXR0bGVkYCBjYWxsYmFja3MgcnVuIGJlZm9yZSB0aGVcblx0KiBtdXRhdGlvbidzIG93biBgb25TdWNjZXNzYC9gb25TZXR0bGVkYCBvcHRpb25zLCBhIGBzdWNjZXNzYCBhY3Rpb24gaXNcblx0KiBkaXNwYXRjaGVkLCBhbmQgdGhlIHJlc29sdmVkIGRhdGEgaXMgcmV0dXJuZWQuIE9uIGZhaWx1cmUsIHRoZSBzYW1lXG5cdCogY2FjaGUtdGhlbi1vcHRpb24gb3JkZXJpbmcgaXMgdXNlZCBmb3IgYG9uRXJyb3JgL2BvblNldHRsZWRgLCBidXQgZWFjaCBvZlxuXHQqIHRob3NlIGZvdXIgY2FsbGJhY2tzIGlzIGluZGl2aWR1YWxseSBjYXVnaHQgc28gdGhhdCBhIHRocm93aW5nIGNhbGxiYWNrXG5cdCogY2Fubm90IG1hc2sgdGhlIG9yaWdpbmFsIGVycm9yOyBhbiBgZXJyb3JgIGFjdGlvbiBpcyB0aGVuIGRpc3BhdGNoZWQgYW5kXG5cdCogdGhlIG9yaWdpbmFsIGVycm9yIGlzIHJlLXRocm93bi5cblx0KiBAcGFyYW0gdmFyaWFibGVzIC0gVGhlIHZhcmlhYmxlcyBwYXNzZWQgdG8gdGhlIGBtdXRhdGlvbkZuYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBtdXRhdGlvbidzIGRhdGEsIG9yIHJlamVjdHMgd2l0aCBpdHMgZXJyb3IuXG5cdCogQHNlZSB7QGxpbmsgTXV0YXRpb24jY29udGludWV9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIC8vIENhbGxlZCBpbnRlcm5hbGx5IGJ5IGBNdXRhdGlvbk9ic2VydmVyLm11dGF0ZWAgYW5kIGBNdXRhdGlvbi5jb250aW51ZWAg4oCUXG5cdCogLy8gYXBwbGljYXRpb25zIG5vcm1hbGx5IHRyaWdnZXIgbXV0YXRpb25zIHRocm91Z2ggdGhvc2UsIG5vdCB0aGlzIG1ldGhvZC5cblx0KiBjb25zdCBkYXRhID0gYXdhaXQgbXV0YXRpb24uZXhlY3V0ZSh2YXJpYWJsZXMpXG5cdCogYGBgXG5cdCovXG5cdGFzeW5jIGV4ZWN1dGUodmFyaWFibGVzKSB7XG5cdFx0Y29uc3Qgb25Db250aW51ZSA9ICgpID0+IHtcblx0XHRcdHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJjb250aW51ZVwiIH0pO1xuXHRcdH07XG5cdFx0Y29uc3QgbXV0YXRpb25GbkNvbnRleHQgPSB7XG5cdFx0XHRjbGllbnQ6IHRoaXMuI2NsaWVudCxcblx0XHRcdG1ldGE6IHRoaXMub3B0aW9ucy5tZXRhLFxuXHRcdFx0bXV0YXRpb25LZXk6IHRoaXMub3B0aW9ucy5tdXRhdGlvbktleVxuXHRcdH07XG5cdFx0Y29uc3QgcmV0cnllciA9IHRoaXMuI3JldHJ5ZXIgPSBjcmVhdGVSZXRyeWVyKHtcblx0XHRcdGZuOiAoKSA9PiB7XG5cdFx0XHRcdGlmICghdGhpcy5vcHRpb25zLm11dGF0aW9uRm4pIHJldHVybiBQcm9taXNlLnJlamVjdCgvKiBAX19QVVJFX18gKi8gbmV3IEVycm9yKFwiTm8gbXV0YXRpb25GbiBmb3VuZFwiKSk7XG5cdFx0XHRcdHJldHVybiB0aGlzLm9wdGlvbnMubXV0YXRpb25Gbih2YXJpYWJsZXMsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdH0sXG5cdFx0XHRvbkZhaWw6IChmYWlsdXJlQ291bnQsIGVycm9yKSA9PiB7XG5cdFx0XHRcdHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0XHR0eXBlOiBcImZhaWxlZFwiLFxuXHRcdFx0XHRcdGZhaWx1cmVDb3VudCxcblx0XHRcdFx0XHRlcnJvclxuXHRcdFx0XHR9KTtcblx0XHRcdH0sXG5cdFx0XHRvblBhdXNlOiAoKSA9PiB7XG5cdFx0XHRcdHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJwYXVzZVwiIH0pO1xuXHRcdFx0fSxcblx0XHRcdG9uQ29udGludWUsXG5cdFx0XHRyZXRyeTogdGhpcy5vcHRpb25zLnJldHJ5ID8/IDAsXG5cdFx0XHRyZXRyeURlbGF5OiB0aGlzLm9wdGlvbnMucmV0cnlEZWxheSxcblx0XHRcdG5ldHdvcmtNb2RlOiB0aGlzLm9wdGlvbnMubmV0d29ya01vZGUsXG5cdFx0XHRjYW5SdW46ICgpID0+IHRoaXMuI211dGF0aW9uQ2FjaGUuY2FuUnVuKHRoaXMpXG5cdFx0fSk7XG5cdFx0Y29uc3QgcmVzdG9yZWQgPSB0aGlzLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCI7XG5cdFx0Y29uc3QgaXNQYXVzZWQgPSAhcmV0cnllci5jYW5TdGFydCgpO1xuXHRcdHRyeSB7XG5cdFx0XHRpZiAocmVzdG9yZWQpIG9uQ29udGludWUoKTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdFx0dHlwZTogXCJwZW5kaW5nXCIsXG5cdFx0XHRcdFx0dmFyaWFibGVzLFxuXHRcdFx0XHRcdGlzUGF1c2VkXG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRpZiAodGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25NdXRhdGUpIGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uTXV0YXRlKHZhcmlhYmxlcywgdGhpcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0XHRjb25zdCBjb250ZXh0ID0gYXdhaXQgdGhpcy5vcHRpb25zLm9uTXV0YXRlPy4odmFyaWFibGVzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHRcdGlmIChjb250ZXh0ICE9PSB0aGlzLnN0YXRlLmNvbnRleHQpIHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0XHR0eXBlOiBcInBlbmRpbmdcIixcblx0XHRcdFx0XHRjb250ZXh0LFxuXHRcdFx0XHRcdHZhcmlhYmxlcyxcblx0XHRcdFx0XHRpc1BhdXNlZFxuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHRcdGlmICh0aGlzLnN0YXRlLmlzUGF1c2VkICYmIHJldHJ5ZXIuY2FuU3RhcnQoKSkgb25Db250aW51ZSgpO1xuXHRcdFx0Y29uc3QgZGF0YSA9IGF3YWl0IHJldHJ5ZXIuc3RhcnQoKTtcblx0XHRcdGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uU3VjY2Vzcz8uKGRhdGEsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCB0aGlzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHRhd2FpdCB0aGlzLm9wdGlvbnMub25TdWNjZXNzPy4oZGF0YSwgdmFyaWFibGVzLCB0aGlzLnN0YXRlLmNvbnRleHQsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uU2V0dGxlZD8uKGRhdGEsIG51bGwsIHRoaXMuc3RhdGUudmFyaWFibGVzLCB0aGlzLnN0YXRlLmNvbnRleHQsIHRoaXMsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vblNldHRsZWQ/LihkYXRhLCBudWxsLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHR0eXBlOiBcInN1Y2Nlc3NcIixcblx0XHRcdFx0ZGF0YVxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gZGF0YTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25FcnJvcj8uKGVycm9yLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgdGhpcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vbkVycm9yPy4oZXJyb3IsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25TZXR0bGVkPy4odm9pZCAwLCBlcnJvciwgdGhpcy5zdGF0ZS52YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgdGhpcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vblNldHRsZWQ/Lih2b2lkIDAsIGVycm9yLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdH1cblx0XHRcdHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0dHlwZTogXCJlcnJvclwiLFxuXHRcdFx0XHRlcnJvclxuXHRcdFx0fSk7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0aWYgKHRoaXMuI3JldHJ5ZXIgPT09IHJldHJ5ZXIpIHRoaXMuI3JldHJ5ZXIgPSB2b2lkIDA7XG5cdFx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlLnJ1bk5leHQodGhpcyk7XG5cdFx0fVxuXHR9XG5cdCNkaXNwYXRjaChhY3Rpb24pIHtcblx0XHRjb25zdCByZWR1Y2VyID0gKHN0YXRlKSA9PiB7XG5cdFx0XHRzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG5cdFx0XHRcdGNhc2UgXCJmYWlsZWRcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQ6IGFjdGlvbi5mYWlsdXJlQ291bnQsXG5cdFx0XHRcdFx0ZmFpbHVyZVJlYXNvbjogYWN0aW9uLmVycm9yXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJwYXVzZVwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiB0cnVlXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJjb250aW51ZVwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiBmYWxzZVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwicGVuZGluZ1wiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGNvbnRleHQ6IGFjdGlvbi5jb250ZXh0LFxuXHRcdFx0XHRcdGRhdGE6IHZvaWQgMCxcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQ6IDAsXG5cdFx0XHRcdFx0ZmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRcdFx0XHRlcnJvcjogbnVsbCxcblx0XHRcdFx0XHRpc1BhdXNlZDogYWN0aW9uLmlzUGF1c2VkLFxuXHRcdFx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCIsXG5cdFx0XHRcdFx0dmFyaWFibGVzOiBhY3Rpb24udmFyaWFibGVzLFxuXHRcdFx0XHRcdHN1Ym1pdHRlZEF0OiBEYXRlLm5vdygpXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJzdWNjZXNzXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZGF0YTogYWN0aW9uLmRhdGEsXG5cdFx0XHRcdFx0ZmFpbHVyZUNvdW50OiAwLFxuXHRcdFx0XHRcdGZhaWx1cmVSZWFzb246IG51bGwsXG5cdFx0XHRcdFx0ZXJyb3I6IG51bGwsXG5cdFx0XHRcdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIixcblx0XHRcdFx0XHRpc1BhdXNlZDogZmFsc2Vcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcImVycm9yXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZGF0YTogdm9pZCAwLFxuXHRcdFx0XHRcdGVycm9yOiBhY3Rpb24uZXJyb3IsXG5cdFx0XHRcdFx0ZmFpbHVyZUNvdW50OiBzdGF0ZS5mYWlsdXJlQ291bnQgKyAxLFxuXHRcdFx0XHRcdGZhaWx1cmVSZWFzb246IGFjdGlvbi5lcnJvcixcblx0XHRcdFx0XHRpc1BhdXNlZDogZmFsc2UsXG5cdFx0XHRcdFx0c3RhdHVzOiBcImVycm9yXCJcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdHRoaXMuc3RhdGUgPSByZWR1Y2VyKHRoaXMuc3RhdGUpO1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRcdG9ic2VydmVyLm9uTXV0YXRpb25VcGRhdGUoYWN0aW9uKTtcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy4jbXV0YXRpb25DYWNoZS5ub3RpZnkoe1xuXHRcdFx0XHRtdXRhdGlvbjogdGhpcyxcblx0XHRcdFx0dHlwZTogXCJ1cGRhdGVkXCIsXG5cdFx0XHRcdGFjdGlvblxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn07XG4vKipcbiogUmV0dXJucyB0aGUgaW5pdGlhbCBzdGF0ZSBvZiBhIG11dGF0aW9uOiBgJ2lkbGUnYCwgd2l0aCBubyBkYXRhLCBlcnJvciwgb3IgdmFyaWFibGVzLlxuKiBAcmV0dXJucyBUaGUgaW5pdGlhbCBtdXRhdGlvbiBzdGF0ZS5cbiovXG5mdW5jdGlvbiBnZXREZWZhdWx0U3RhdGUoKSB7XG5cdHJldHVybiB7XG5cdFx0Y29udGV4dDogdm9pZCAwLFxuXHRcdGRhdGE6IHZvaWQgMCxcblx0XHRlcnJvcjogbnVsbCxcblx0XHRmYWlsdXJlQ291bnQ6IDAsXG5cdFx0ZmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRpc1BhdXNlZDogZmFsc2UsXG5cdFx0c3RhdHVzOiBcImlkbGVcIixcblx0XHR2YXJpYWJsZXM6IHZvaWQgMCxcblx0XHRzdWJtaXR0ZWRBdDogMFxuXHR9O1xufVxuZXhwb3J0IHsgTXV0YXRpb24sIGdldERlZmF1bHRTdGF0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1tdXRhdGlvbi5qcy5tYXAiLCJpbXBvcnQgeyBNdXRhdGlvbiB9IGZyb20gXCIuL211dGF0aW9uLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyBtYXRjaE11dGF0aW9uLCBub29wIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vIHNyYy9tdXRhdGlvbkNhY2hlLnRzXG4vKipcbiogVGhlIGBNdXRhdGlvbkNhY2hlYCBpcyB0aGUgc3RvcmFnZSBmb3IgbXV0YXRpb25zLlxuKlxuKiBOb3JtYWxseSwgeW91IHdpbGwgbm90IGludGVyYWN0IHdpdGggdGhlIGBNdXRhdGlvbkNhY2hlYCBkaXJlY3RseSBhbmQgaW5zdGVhZCB1c2UgYVxuKiBgUXVlcnlDbGllbnRgLiBZb3UgY2FuIHN1YnNjcmliZSB0byBpdCAoaW5oZXJpdGVkIGZyb20gYFN1YnNjcmliYWJsZWApIHRvIGJlIGluZm9ybWVkIG9mXG4qIHNhZmUva25vd24gdXBkYXRlcyB0byB0aGUgY2FjaGUsIHN1Y2ggYXMgbXV0YXRpb25zIGJlaW5nIGFkZGVkLCByZW1vdmVkLCBvciB1cGRhdGVkLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCB1bnN1YnNjcmliZSA9IG11dGF0aW9uQ2FjaGUuc3Vic2NyaWJlKChldmVudCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKGV2ZW50LnR5cGUsIGV2ZW50Lm11dGF0aW9uKVxuKiB9KVxuKiBgYGBcbiovXG52YXIgTXV0YXRpb25DYWNoZSA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I211dGF0aW9ucztcblx0I3Njb3Blcztcblx0I211dGF0aW9uSWQ7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZyA9IHt9KSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZztcblx0XHR0aGlzLiNtdXRhdGlvbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHRoaXMuI3Njb3BlcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy4jbXV0YXRpb25JZCA9IDA7XG5cdH1cblx0LyoqXG5cdCogQ3JlYXRlcyBhIG11dGF0aW9uIGFuZCBhZGRzIGl0IHRvIHRoZSBjYWNoZS5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gY2xpZW50IC0gVGhlIGNsaWVudCB0aGUgbXV0YXRpb24gYmVsb25ncyB0bywgdXNlZCB0byBkZWZhdWx0IGl0cyBvcHRpb25zLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG11dGF0aW9uIG9wdGlvbnMuIFRoZXkgYXJlIGRlZmF1bHRlZCB3aXRoIHtAbGlua1xuXHQqIFF1ZXJ5Q2xpZW50I2RlZmF1bHRNdXRhdGlvbk9wdGlvbnN9LlxuXHQqIEBwYXJhbSBzdGF0ZSAtIFRoZSBpbml0aWFsIHN0YXRlIG9mIHRoZSBtdXRhdGlvbiwgZS5nLiB3aGVuIHJlc3RvcmluZyBhIGRlaHlkcmF0ZWQgbXV0YXRpb24uXG5cdCogQHJldHVybnMgVGhlIG5ldyBtdXRhdGlvbiwgYWxyZWFkeSBhZGRlZCB0byB0aGUgY2FjaGUuXG5cdCovXG5cdGJ1aWxkKGNsaWVudCwgb3B0aW9ucywgc3RhdGUpIHtcblx0XHRjb25zdCBtdXRhdGlvbiA9IG5ldyBNdXRhdGlvbih7XG5cdFx0XHRjbGllbnQsXG5cdFx0XHRtdXRhdGlvbkNhY2hlOiB0aGlzLFxuXHRcdFx0bXV0YXRpb25JZDogKyt0aGlzLiNtdXRhdGlvbklkLFxuXHRcdFx0b3B0aW9uczogY2xpZW50LmRlZmF1bHRNdXRhdGlvbk9wdGlvbnMob3B0aW9ucyksXG5cdFx0XHRzdGF0ZVxuXHRcdH0pO1xuXHRcdHRoaXMuYWRkKG11dGF0aW9uKTtcblx0XHRyZXR1cm4gbXV0YXRpb247XG5cdH1cblx0LyoqXG5cdCogQWRkcyBhIG11dGF0aW9uIHRvIHRoZSBjYWNoZS5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gYWRkLiBJZiBpdCBoYXMgYSBgc2NvcGVgLCBpdCBpcyBxdWV1ZWQgaW4gdGhhdCBzY29wZS5cblx0Ki9cblx0YWRkKG11dGF0aW9uKSB7XG5cdFx0dGhpcy4jbXV0YXRpb25zLmFkZChtdXRhdGlvbik7XG5cdFx0Y29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG5cdFx0aWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0Y29uc3Qgc2NvcGVkTXV0YXRpb25zID0gdGhpcy4jc2NvcGVzLmdldChzY29wZSk7XG5cdFx0XHRpZiAoc2NvcGVkTXV0YXRpb25zKSBzY29wZWRNdXRhdGlvbnMucHVzaChtdXRhdGlvbik7XG5cdFx0XHRlbHNlIHRoaXMuI3Njb3Blcy5zZXQoc2NvcGUsIFttdXRhdGlvbl0pO1xuXHRcdH1cblx0XHR0aGlzLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcImFkZGVkXCIsXG5cdFx0XHRtdXRhdGlvblxuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJlbW92ZXMgYSBtdXRhdGlvbiBmcm9tIHRoZSBjYWNoZSBhbmQgY2xlYXJzIGl0cyBnYXJiYWdlIGNvbGxlY3Rpb24gdGltZXIuXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG11dGF0aW9uIC0gVGhlIG11dGF0aW9uIHRvIHJlbW92ZSwgYWxzbyBmcm9tIGl0cyBzY29wZSdzIHF1ZXVlLlxuXHQqL1xuXHRyZW1vdmUobXV0YXRpb24pIHtcblx0XHRpZiAodGhpcy4jbXV0YXRpb25zLmRlbGV0ZShtdXRhdGlvbikpIHtcblx0XHRcdG11dGF0aW9uLmRlc3Ryb3koKTtcblx0XHRcdGNvbnN0IHNjb3BlID0gc2NvcGVGb3IobXV0YXRpb24pO1xuXHRcdFx0aWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0XHRjb25zdCBzY29wZWRNdXRhdGlvbnMgPSB0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKTtcblx0XHRcdFx0aWYgKHNjb3BlZE11dGF0aW9ucykge1xuXHRcdFx0XHRcdGlmIChzY29wZWRNdXRhdGlvbnMubGVuZ3RoID4gMSkge1xuXHRcdFx0XHRcdFx0Y29uc3QgaW5kZXggPSBzY29wZWRNdXRhdGlvbnMuaW5kZXhPZihtdXRhdGlvbik7XG5cdFx0XHRcdFx0XHRpZiAoaW5kZXggIT09IC0xKSBzY29wZWRNdXRhdGlvbnMuc3BsaWNlKGluZGV4LCAxKTtcblx0XHRcdFx0XHR9IGVsc2UgaWYgKHNjb3BlZE11dGF0aW9uc1swXSA9PT0gbXV0YXRpb24pIHRoaXMuI3Njb3Blcy5kZWxldGUoc2NvcGUpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHRcdHRoaXMubm90aWZ5KHtcblx0XHRcdHR5cGU6IFwicmVtb3ZlZFwiLFxuXHRcdFx0bXV0YXRpb25cblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBDaGVja3Mgd2hldGhlciB0aGlzIGNhY2hlIHN0aWxsIGhvbGRzIHRoZSBnaXZlbiBtdXRhdGlvbi5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gY2hlY2suXG5cdCogQHJldHVybnMgV2hldGhlciB0aGUgbXV0YXRpb24gaXMgaW4gdGhlIGNhY2hlLlxuXHQqL1xuXHRoYXMobXV0YXRpb24pIHtcblx0XHRyZXR1cm4gdGhpcy4jbXV0YXRpb25zLmhhcyhtdXRhdGlvbik7XG5cdH1cblx0LyoqXG5cdCogQ2hlY2tzIHdoZXRoZXIgYSBtdXRhdGlvbiBjYW4gcnVuIG5vdywgZ2l2ZW4gdGhlIG90aGVyIG11dGF0aW9ucyBpbiBpdHMgYHNjb3BlYC5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gY2hlY2suXG5cdCogQHJldHVybnMgYHRydWVgIGlmIHRoZSBtdXRhdGlvbiBoYXMgbm8gYHNjb3BlYCwgb3Igbm8gb3RoZXIgbXV0YXRpb24gaW4gaXRzIHNjb3BlIGlzIHBlbmRpbmdcblx0KiBhaGVhZCBvZiBpdC5cblx0Ki9cblx0Y2FuUnVuKG11dGF0aW9uKSB7XG5cdFx0Y29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG5cdFx0aWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0Y29uc3QgZmlyc3RQZW5kaW5nTXV0YXRpb24gPSB0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKT8uZmluZCgobSkgPT4gbS5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiKTtcblx0XHRcdHJldHVybiAhZmlyc3RQZW5kaW5nTXV0YXRpb24gfHwgZmlyc3RQZW5kaW5nTXV0YXRpb24gPT09IG11dGF0aW9uO1xuXHRcdH0gZWxzZSByZXR1cm4gdHJ1ZTtcblx0fVxuXHQvKipcblx0KiBDb250aW51ZXMgdGhlIG5leHQgcGF1c2VkIG11dGF0aW9uIGluIHRoZSBzYW1lIGBzY29wZWAgYWZ0ZXIgYSBtdXRhdGlvbiBmaW5pc2hlcy5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdGhhdCBmaW5pc2hlZC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIHRoZSBuZXh0IHBhdXNlZCBtdXRhdGlvbiBpbiB0aGUgc2FtZSBzY29wZSBoYXMgY29udGludWVkLFxuXHQqIG9yIGltbWVkaWF0ZWx5IGlmIHRoZXJlIGlzIG5vbmUuXG5cdCovXG5cdHJ1bk5leHQobXV0YXRpb24pIHtcblx0XHRjb25zdCBzY29wZSA9IHNjb3BlRm9yKG11dGF0aW9uKTtcblx0XHRpZiAodHlwZW9mIHNjb3BlID09PSBcInN0cmluZ1wiKSByZXR1cm4gKHRoaXMuI3Njb3Blcy5nZXQoc2NvcGUpPy5maW5kKChtKSA9PiBtICE9PSBtdXRhdGlvbiAmJiBtLnN0YXRlLmlzUGF1c2VkKSk/LmNvbnRpbnVlKCkgPz8gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0ZWxzZSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdH1cblx0LyoqXG5cdCogUmVtb3ZlcyBhbGwgbXV0YXRpb25zIGFuZCBjbGVhcnMgdGhlaXIgZ2FyYmFnZSBjb2xsZWN0aW9uIHRpbWVycy5cblx0KiBNdXRhdGlvbnMgdGhhdCBhcmUgYWxyZWFkeSBydW5uaW5nIGNvbnRpbnVlIHRvIGV4ZWN1dGUuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcblx0KlxuXHQqIG11dGF0aW9uQ2FjaGUuY2xlYXIoKVxuXHQqIGBgYFxuXHQqL1xuXHRjbGVhcigpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdGNvbnN0IG11dGF0aW9ucyA9IHRoaXMuZ2V0QWxsKCk7XG5cdFx0XHR0aGlzLiNtdXRhdGlvbnMuY2xlYXIoKTtcblx0XHRcdHRoaXMuI3Njb3Blcy5jbGVhcigpO1xuXHRcdFx0bXV0YXRpb25zLmZvckVhY2goKG11dGF0aW9uKSA9PiBtdXRhdGlvbi5kZXN0cm95KCkpO1xuXHRcdFx0bXV0YXRpb25zLmZvckVhY2goKG11dGF0aW9uKSA9PiB7XG5cdFx0XHRcdHRoaXMubm90aWZ5KHtcblx0XHRcdFx0XHR0eXBlOiBcInJlbW92ZWRcIixcblx0XHRcdFx0XHRtdXRhdGlvblxuXHRcdFx0XHR9KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYWxsIG11dGF0aW9ucyB3aXRoaW4gdGhlIGNhY2hlLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IGEgbXV0YXRpb24gaW4gcmFyZSBzY2VuYXJpb3MuXG5cdCogQHJldHVybnMgRXZlcnkgbXV0YXRpb24gaW4gdGhlIGNhY2hlLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG5cdCpcblx0KiBjb25zdCBtdXRhdGlvbnMgPSBtdXRhdGlvbkNhY2hlLmdldEFsbCgpXG5cdCogYGBgXG5cdCovXG5cdGdldEFsbCgpIHtcblx0XHRyZXR1cm4gQXJyYXkuZnJvbSh0aGlzLiNtdXRhdGlvbnMpO1xuXHR9XG5cdC8qKlxuXHQqIEEgc2xpZ2h0bHkgbW9yZSBhZHZhbmNlZCBtZXRob2QgdGhhdCBjYW4gYmUgdXNlZCB0byBnZXQgYW4gZXhpc3RpbmcgbXV0YXRpb24gaW5zdGFuY2UgZnJvbVxuXHQqIHRoZSBjYWNoZS4gSWYgdGhlIG11dGF0aW9uIGRvZXMgbm90IGV4aXN0LCBgdW5kZWZpbmVkYCBpcyByZXR1cm5lZC5cblx0KlxuXHQqIFRoaXMgaXMgbm90IHR5cGljYWxseSBuZWVkZWQgZm9yIG1vc3QgYXBwbGljYXRpb25zLCBidXQgY2FuIGNvbWUgaW4gaGFuZHkgd2hlbiBuZWVkaW5nIG1vcmVcblx0KiBpbmZvcm1hdGlvbiBhYm91dCBhIG11dGF0aW9uIGluIHJhcmUgc2NlbmFyaW9zLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdG8gbWF0Y2guIGBleGFjdGAgZGVmYXVsdHMgdG8gYHRydWVgLlxuXHQqIEByZXR1cm5zIFRoZSBmaXJzdCBtYXRjaGluZyBtdXRhdGlvbiwgb3IgYHVuZGVmaW5lZGAuXG5cdCogQHNlZSB7QGxpbmsgTXV0YXRpb25DYWNoZSNmaW5kQWxsfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG5cdCpcblx0KiBjb25zdCBtdXRhdGlvbiA9IG11dGF0aW9uQ2FjaGUuZmluZCh7IG11dGF0aW9uS2V5OiBbJ2FkZFBvc3QnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRmaW5kKGZpbHRlcnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRGaWx0ZXJzID0ge1xuXHRcdFx0ZXhhY3Q6IHRydWUsXG5cdFx0XHQuLi5maWx0ZXJzXG5cdFx0fTtcblx0XHRyZXR1cm4gdGhpcy5nZXRBbGwoKS5maW5kKChtdXRhdGlvbikgPT4gbWF0Y2hNdXRhdGlvbihkZWZhdWx0ZWRGaWx0ZXJzLCBtdXRhdGlvbikpO1xuXHR9XG5cdC8qKlxuXHQqIEFuIGV2ZW4gbW9yZSBhZHZhbmNlZCBtZXRob2QgdGhhdCBjYW4gYmUgdXNlZCB0byBnZXQgZXhpc3RpbmcgbXV0YXRpb24gaW5zdGFuY2VzIGZyb20gdGhlXG5cdCogY2FjaGUgdGhhdCBtYXRjaCB0aGUgZ2l2ZW4gZmlsdGVycy4gSWYgbm8gbXV0YXRpb25zIG1hdGNoLCBhbiBlbXB0eSBhcnJheSBpcyByZXR1cm5lZC5cblx0KlxuXHQqIFRoaXMgaXMgbm90IHR5cGljYWxseSBuZWVkZWQgZm9yIG1vc3QgYXBwbGljYXRpb25zLCBidXQgY2FuIGNvbWUgaW4gaGFuZHkgd2hlbiBuZWVkaW5nIG1vcmVcblx0KiBpbmZvcm1hdGlvbiBhYm91dCBtdXRhdGlvbnMgaW4gcmFyZSBzY2VuYXJpb3MuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0byBtYXRjaC4gV2l0aG91dCBmaWx0ZXJzLCBldmVyeSBtdXRhdGlvbiBpcyByZXR1cm5lZC5cblx0KiBAcmV0dXJucyBUaGUgbWF0Y2hpbmcgbXV0YXRpb25zLlxuXHQqIEBzZWUge0BsaW5rIE11dGF0aW9uQ2FjaGUjZmluZH1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuXHQqXG5cdCogY29uc3QgbXV0YXRpb25zID0gbXV0YXRpb25DYWNoZS5maW5kQWxsKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0pXG5cdCogYGBgXG5cdCovXG5cdGZpbmRBbGwoZmlsdGVycyA9IHt9KSB7XG5cdFx0cmV0dXJuIHRoaXMuZ2V0QWxsKCkuZmlsdGVyKChtdXRhdGlvbikgPT4gbWF0Y2hNdXRhdGlvbihmaWx0ZXJzLCBtdXRhdGlvbikpO1xuXHR9XG5cdC8qKlxuXHQqIE5vdGlmaWVzIGV2ZXJ5IGNhY2hlIGxpc3RlbmVyIG9mIGFuIGV2ZW50LCBpbiBvbmUgYmF0Y2guXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIGV2ZW50IC0gVGhlIGV2ZW50IHBhc3NlZCB0byBldmVyeSBsaXN0ZW5lci5cblx0Ki9cblx0bm90aWZ5KGV2ZW50KSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0XHRsaXN0ZW5lcihldmVudCk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBDb250aW51ZXMgZXZlcnkgcGF1c2VkIG11dGF0aW9uLCBlLmcuIHdoZW4gdGhlIGFwcCBjb21lcyBiYWNrIG9ubGluZS5cblx0KiBAaW50ZXJuYWxcblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIGV2ZXJ5IHBhdXNlZCBtdXRhdGlvbiBoYXMgY29udGludWVkIGFuZCBzZXR0bGVkLlxuXHQqL1xuXHRyZXN1bWVQYXVzZWRNdXRhdGlvbnMoKSB7XG5cdFx0Y29uc3QgcGF1c2VkTXV0YXRpb25zID0gdGhpcy5nZXRBbGwoKS5maWx0ZXIoKHgpID0+IHguc3RhdGUuaXNQYXVzZWQpO1xuXHRcdHJldHVybiBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IFByb21pc2UuYWxsKHBhdXNlZE11dGF0aW9ucy5tYXAoKG11dGF0aW9uKSA9PiBtdXRhdGlvbi5jb250aW51ZSgpLmNhdGNoKG5vb3ApKSkpO1xuXHR9XG59O1xuLyoqXG4qIFJldHVybnMgdGhlIHNjb3BlIGlkIG9mIGEgbXV0YXRpb24sIHVzZWQgdG8gcnVuIG11dGF0aW9ucyB3aXRoIHRoZSBzYW1lIHNjb3BlIG9uZSBhZnRlciBhbm90aGVyLlxuKiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gcmVhZCB0aGUgc2NvcGUgb2YuXG4qIEByZXR1cm5zIFRoZSBtdXRhdGlvbidzIGBzY29wZS5pZGAsIG9yIGB1bmRlZmluZWRgIGlmIGl0IGhhcyBubyBzY29wZS5cbiovXG5mdW5jdGlvbiBzY29wZUZvcihtdXRhdGlvbikge1xuXHRyZXR1cm4gbXV0YXRpb24ub3B0aW9ucy5zY29wZT8uaWQ7XG59XG5leHBvcnQgeyBNdXRhdGlvbkNhY2hlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW11dGF0aW9uQ2FjaGUuanMubWFwIiwiaW1wb3J0IHsgZ2V0RGVmYXVsdFN0YXRlIH0gZnJvbSBcIi4vbXV0YXRpb24uanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbmltcG9ydCB7IGhhc2hLZXksIHNoYWxsb3dFcXVhbE9iamVjdHMgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuLy8gc3JjL211dGF0aW9uT2JzZXJ2ZXIudHNcbi8qKlxuKiBPYnNlcnZlcyBhIHNpbmdsZSBtdXRhdGlvbiBhbmQgZGVyaXZlcyBhIGBNdXRhdGlvbk9ic2VydmVyUmVzdWx0YCBmcm9tIGl0LlxuKiBBIGZyYW1ld29yayBob29rIGxpa2UgYHVzZU11dGF0aW9uYCBjcmVhdGVzIG9uZSBgTXV0YXRpb25PYnNlcnZlcmAgcGVyIGhvb2tcbiogY2FsbCwga2VlcHMgaXQgc3RhYmxlIGFjcm9zcyByZS1yZW5kZXJzLCBjYWxscyBgc2V0T3B0aW9uc2Agd2hlbiB0aGUgb3B0aW9uc1xuKiBwYXNzZWQgdG8gdGhlIGhvb2sgY2hhbmdlLCBzdWJzY3JpYmVzIHRvIGl0IHRvIHJlLXJlbmRlciBvbiB1cGRhdGVzLCBhbmRcbiogcmVhZHMgYGdldEN1cnJlbnRSZXN1bHQoKWAgZm9yIHRoZSB2YWx1ZSB0byByZXR1cm4uIENhbGxpbmcgYG11dGF0ZSgpYFxuKiBidWlsZHMgYSBuZXcgdW5kZXJseWluZyBgTXV0YXRpb25gIGluIHRoZSBgTXV0YXRpb25DYWNoZWAgYW5kIGV4ZWN1dGVzIGl0LlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKHF1ZXJ5Q2xpZW50LCB7XG4qICAgbXV0YXRpb25GbjogKHZhcmlhYmxlczogeyB0aXRsZTogc3RyaW5nIH0pID0+IGFkZFBvc3QodmFyaWFibGVzKSxcbiogfSlcbiogYGBgXG4qL1xudmFyIE11dGF0aW9uT2JzZXJ2ZXIgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG5cdCNjbGllbnQ7XG5cdCNjdXJyZW50UmVzdWx0ID0gdm9pZCAwO1xuXHQjY3VycmVudE11dGF0aW9uO1xuXHQjbXV0YXRlT3B0aW9ucztcblx0Y29uc3RydWN0b3IoY2xpZW50LCBvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNjbGllbnQgPSBjbGllbnQ7XG5cdFx0dGhpcy5zZXRPcHRpb25zKG9wdGlvbnMpO1xuXHRcdHRoaXMuYmluZE1ldGhvZHMoKTtcblx0XHR0aGlzLiN1cGRhdGVSZXN1bHQoKTtcblx0fVxuXHQvKipcblx0KiBCaW5kcyB0aGUgbWV0aG9kcyBvZiB0aGUgcmVzdWx0IChgbXV0YXRlYCBhbmQgYHJlc2V0YCkgdG8gdGhlIG9ic2VydmVyLCBzbyB0aGV5IGtlZXAgd29ya2luZyB3aGVuXG5cdCogZGVzdHJ1Y3R1cmVkIGZyb20gaXQuXG5cdCovXG5cdGJpbmRNZXRob2RzKCkge1xuXHRcdHRoaXMubXV0YXRlID0gdGhpcy5tdXRhdGUuYmluZCh0aGlzKTtcblx0XHR0aGlzLnJlc2V0ID0gdGhpcy5yZXNldC5iaW5kKHRoaXMpO1xuXHR9XG5cdC8qKlxuXHQqIFVwZGF0ZXMgdGhlIG9ic2VydmVyJ3Mgb3B0aW9ucy5cblx0KlxuXHQqIElmIHRoZSBuZXcgYG11dGF0aW9uS2V5YCBkaWZmZXJzIGZyb20gdGhlIHByZXZpb3VzIG9uZSAoYW5kIGJvdGggd2VyZVxuXHQqIGRlZmluZWQpLCB0aGUgb2JzZXJ2ZXIgaXMgcmVzZXQsIGRldGFjaGluZyBpdCBmcm9tIHRoZSBtdXRhdGlvbiBpdCB3YXNcblx0KiBvYnNlcnZpbmcuIE90aGVyd2lzZSwgaWYgdGhlIGN1cnJlbnRseSBvYnNlcnZlZCBtdXRhdGlvbiBpcyBzdGlsbFxuXHQqIGBwZW5kaW5nYCwgaXRzIG9wdGlvbnMgYXJlIHVwZGF0ZWQgaW4gcGxhY2UgYXMgd2VsbC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBuZXcgbXV0YXRpb24gb2JzZXJ2ZXIgb3B0aW9ucy4gVGhleSBhcmUgZGVmYXVsdGVkIHdpdGgge0BsaW5rXG5cdCogUXVlcnlDbGllbnQjZGVmYXVsdE11dGF0aW9uT3B0aW9uc30gYmVmb3JlIGJlaW5nIGFwcGxpZWQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIG9ic2VydmVyLnNldE9wdGlvbnMoe1xuXHQqICAgbXV0YXRpb25GbjogKHZhcmlhYmxlczogeyB0aXRsZTogc3RyaW5nIH0pID0+IGFkZFBvc3QodmFyaWFibGVzKSxcblx0KiAgIG9uU3VjY2VzczogKGRhdGEpID0+IGNvbnNvbGUubG9nKGRhdGEpLFxuXHQqIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldE9wdGlvbnMob3B0aW9ucykge1xuXHRcdGNvbnN0IHByZXZPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdHRoaXMub3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0TXV0YXRpb25PcHRpb25zKG9wdGlvbnMpO1xuXHRcdGlmICghc2hhbGxvd0VxdWFsT2JqZWN0cyh0aGlzLm9wdGlvbnMsIHByZXZPcHRpb25zKSkgdGhpcy4jY2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKS5ub3RpZnkoe1xuXHRcdFx0dHlwZTogXCJvYnNlcnZlck9wdGlvbnNVcGRhdGVkXCIsXG5cdFx0XHRtdXRhdGlvbjogdGhpcy4jY3VycmVudE11dGF0aW9uLFxuXHRcdFx0b2JzZXJ2ZXI6IHRoaXNcblx0XHR9KTtcblx0XHRpZiAocHJldk9wdGlvbnM/Lm11dGF0aW9uS2V5ICYmIHRoaXMub3B0aW9ucy5tdXRhdGlvbktleSAmJiBoYXNoS2V5KHByZXZPcHRpb25zLm11dGF0aW9uS2V5KSAhPT0gaGFzaEtleSh0aGlzLm9wdGlvbnMubXV0YXRpb25LZXkpKSB0aGlzLnJlc2V0KCk7XG5cdFx0ZWxzZSBpZiAodGhpcy4jY3VycmVudE11dGF0aW9uPy5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiKSB0aGlzLiNjdXJyZW50TXV0YXRpb24uc2V0T3B0aW9ucyh0aGlzLm9wdGlvbnMpO1xuXHR9XG5cdG9uU3Vic2NyaWJlKCkge1xuXHRcdGlmICh0aGlzLmxpc3RlbmVycy5zaXplID09PSAxICYmIHRoaXMuI2N1cnJlbnRNdXRhdGlvbikge1xuXHRcdFx0dGhpcy4jY3VycmVudE11dGF0aW9uLmFkZE9ic2VydmVyKHRoaXMpO1xuXHRcdFx0dGhpcy4jdXBkYXRlUmVzdWx0KCk7XG5cdFx0fVxuXHR9XG5cdG9uVW5zdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSB0aGlzLiNjdXJyZW50TXV0YXRpb24/LnJlbW92ZU9ic2VydmVyKHRoaXMpO1xuXHR9XG5cdC8qKlxuXHQqIFVwZGF0ZXMgdGhlIG9ic2VydmVyJ3MgcmVzdWx0IHdoZW4gdGhlIG9ic2VydmVkIG11dGF0aW9uIGNoYW5nZXMsIGFuZCBub3RpZmllcyBpdHMgbGlzdGVuZXJzLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBhY3Rpb24gLSBUaGUgYWN0aW9uIHRoYXQgdXBkYXRlZCB0aGUgb2JzZXJ2ZWQgbXV0YXRpb24sIHBhc3NlZCBvbiB0byB0aGUgb2JzZXJ2ZXInc1xuXHQqIGNhbGxiYWNrcy5cblx0Ki9cblx0b25NdXRhdGlvblVwZGF0ZShhY3Rpb24pIHtcblx0XHR0aGlzLiN1cGRhdGVSZXN1bHQoKTtcblx0XHR0aGlzLiNub3RpZnkoYWN0aW9uKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBvYnNlcnZlcidzIGN1cnJlbnQgcmVzdWx0LCBkZXJpdmVkIGZyb20gdGhlIG9ic2VydmVkXG5cdCogbXV0YXRpb24ncyBzdGF0ZSAob3IgdGhlIGRlZmF1bHQsIGBpZGxlYCBzdGF0ZSBpZiBubyBtdXRhdGlvbiBoYXMgYmVlblxuXHQqIGJ1aWx0IHlldCwgZS5nLiBiZWZvcmUgdGhlIGZpcnN0IGBtdXRhdGUoKWAgY2FsbCBvciBhZnRlciBgcmVzZXQoKWApLlxuXHQqIEByZXR1cm5zIFRoZSBvYnNlcnZlcidzIGxhdGVzdCByZXN1bHQuXG5cdCovXG5cdGdldEN1cnJlbnRSZXN1bHQoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG5cdH1cblx0LyoqXG5cdCogRGV0YWNoZXMgdGhlIG9ic2VydmVyIGZyb20gdGhlIG11dGF0aW9uIGl0IGlzIGN1cnJlbnRseSBvYnNlcnZpbmcgKGlmXG5cdCogYW55KSBhbmQgcmVzZXRzIHRoZSBvYnNlcnZlZCByZXN1bHQgYmFjayB0byBpdHMgZGVmYXVsdCwgYGlkbGVgIHN0YXRlLlxuXHQqXG5cdCogVGhpcyBkb2VzIG5vdCBjYW5jZWwgYW4gaW4tZmxpZ2h0IG11dGF0aW9uOyB0aGUgbXV0YXRpb24gaXRzZWxmIGtlZXBzXG5cdCogcnVubmluZyB0byBjb21wbGV0aW9uIGFuZCBpdHMgb3duIGNhbGxiYWNrcyBzdGlsbCBmaXJlLCBidXQgdGhpc1xuXHQqIG9ic2VydmVyIHN0b3BzIHJlZmxlY3RpbmcgaXRzIHN0YXRlIGFuZCBhIHN1YnNlcXVlbnQgYG11dGF0ZSgpYCBjYWxsXG5cdCogd2lsbCBidWlsZCBhIGJyYW5kIG5ldyBtdXRhdGlvbi5cblx0KiBAc2VlIHtAbGluayBNdXRhdGlvbk9ic2VydmVyI211dGF0ZX1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogb2JzZXJ2ZXIucmVzZXQoKVxuXHQqIGBgYFxuXHQqL1xuXHRyZXNldCgpIHtcblx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24/LnJlbW92ZU9ic2VydmVyKHRoaXMpO1xuXHRcdHRoaXMuI2N1cnJlbnRNdXRhdGlvbiA9IHZvaWQgMDtcblx0XHR0aGlzLiN1cGRhdGVSZXN1bHQoKTtcblx0XHR0aGlzLiNub3RpZnkoKTtcblx0fVxuXHQvKipcblx0KiBCdWlsZHMgYSBuZXcgYE11dGF0aW9uYCBpbiB0aGUgYE11dGF0aW9uQ2FjaGVgIHVzaW5nIHRoZSBvYnNlcnZlcidzXG5cdCogY3VycmVudCBvcHRpb25zLCBkZXRhY2hlcyB0aGlzIG9ic2VydmVyIGZyb20gYW55IHByZXZpb3VzbHkgb2JzZXJ2ZWRcblx0KiBtdXRhdGlvbiwgYXR0YWNoZXMgaXQgdG8gdGhlIG5ldyBvbmUsIGFuZCBleGVjdXRlcyBpdCB3aXRoIHRoZSBnaXZlblxuXHQqIHZhcmlhYmxlcy5cblx0KlxuXHQqIFRoZSBvcHRpb25hbCBwZXItY2FsbCBgb3B0aW9uc2AgKGBvblN1Y2Nlc3NgL2BvbkVycm9yYC9gb25TZXR0bGVkYCkgYXJlXG5cdCogaW52b2tlZCBvbmNlIHRoZSBtdXRhdGlvbiBzZXR0bGVzLCBpbiBhZGRpdGlvbiB0byBhbnkgY2FsbGJhY2tzIGRlZmluZWRcblx0KiBvbiB0aGUgb2JzZXJ2ZXIncyBvd24gb3B0aW9ucy5cblx0KiBAcGFyYW0gdmFyaWFibGVzIC0gVGhlIHZhcmlhYmxlcyBwYXNzZWQgdG8gdGhlIGBtdXRhdGlvbkZuYC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFBlci1jYWxsIGBvblN1Y2Nlc3NgLCBgb25FcnJvcmAsIGFuZCBgb25TZXR0bGVkYCBjYWxsYmFja3MuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgbXV0YXRpb24ncyBkYXRhLCBvciByZWplY3RzIHdpdGggaXRzIGVycm9yLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBvYnNlcnZlci5tdXRhdGUoXG5cdCogICB7IHRpdGxlOiAnTmV3IHBvc3QnIH0sXG5cdCogICB7IG9uU3VjY2VzczogKGRhdGEpID0+IGNvbnNvbGUubG9nKGRhdGEpIH0sXG5cdCogKVxuXHQqIGBgYFxuXHQqL1xuXHRtdXRhdGUodmFyaWFibGVzLCBvcHRpb25zKSB7XG5cdFx0dGhpcy4jbXV0YXRlT3B0aW9ucyA9IG9wdGlvbnM7XG5cdFx0dGhpcy4jY3VycmVudE11dGF0aW9uPy5yZW1vdmVPYnNlcnZlcih0aGlzKTtcblx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24gPSB0aGlzLiNjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpLmJ1aWxkKHRoaXMuI2NsaWVudCwgdGhpcy5vcHRpb25zKTtcblx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24uYWRkT2JzZXJ2ZXIodGhpcyk7XG5cdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRNdXRhdGlvbi5leGVjdXRlKHZhcmlhYmxlcyk7XG5cdH1cblx0I3VwZGF0ZVJlc3VsdCgpIHtcblx0XHRjb25zdCBzdGF0ZSA9IHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8uc3RhdGUgPz8gZ2V0RGVmYXVsdFN0YXRlKCk7XG5cdFx0dGhpcy4jY3VycmVudFJlc3VsdCA9IHtcblx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0aXNQZW5kaW5nOiBzdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiLFxuXHRcdFx0aXNTdWNjZXNzOiBzdGF0ZS5zdGF0dXMgPT09IFwic3VjY2Vzc1wiLFxuXHRcdFx0aXNFcnJvcjogc3RhdGUuc3RhdHVzID09PSBcImVycm9yXCIsXG5cdFx0XHRpc0lkbGU6IHN0YXRlLnN0YXR1cyA9PT0gXCJpZGxlXCIsXG5cdFx0XHRtdXRhdGU6IHRoaXMubXV0YXRlLFxuXHRcdFx0cmVzZXQ6IHRoaXMucmVzZXRcblx0XHR9O1xuXHR9XG5cdCNub3RpZnkoYWN0aW9uKSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRjb25zdCBtdXRhdGVPcHRpb25zID0gdGhpcy4jbXV0YXRlT3B0aW9ucztcblx0XHRcdGlmIChtdXRhdGVPcHRpb25zICYmIHRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcblx0XHRcdFx0Y29uc3QgdmFyaWFibGVzID0gdGhpcy4jY3VycmVudFJlc3VsdC52YXJpYWJsZXM7XG5cdFx0XHRcdGNvbnN0IG9uTXV0YXRlUmVzdWx0ID0gdGhpcy4jY3VycmVudFJlc3VsdC5jb250ZXh0O1xuXHRcdFx0XHRjb25zdCBjb250ZXh0ID0ge1xuXHRcdFx0XHRcdGNsaWVudDogdGhpcy4jY2xpZW50LFxuXHRcdFx0XHRcdG1ldGE6IHRoaXMub3B0aW9ucy5tZXRhLFxuXHRcdFx0XHRcdG11dGF0aW9uS2V5OiB0aGlzLm9wdGlvbnMubXV0YXRpb25LZXlcblx0XHRcdFx0fTtcblx0XHRcdFx0aWYgKGFjdGlvbj8udHlwZSA9PT0gXCJzdWNjZXNzXCIpIHtcblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0bXV0YXRlT3B0aW9ucy5vblN1Y2Nlc3M/LihhY3Rpb24uZGF0YSwgdmFyaWFibGVzLCBvbk11dGF0ZVJlc3VsdCwgY29udGV4dCk7XG5cdFx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdFx0UHJvbWlzZS5yZWplY3QoZSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRtdXRhdGVPcHRpb25zLm9uU2V0dGxlZD8uKGFjdGlvbi5kYXRhLCBudWxsLCB2YXJpYWJsZXMsIG9uTXV0YXRlUmVzdWx0LCBjb250ZXh0KTtcblx0XHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSBpZiAoYWN0aW9uPy50eXBlID09PSBcImVycm9yXCIpIHtcblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0bXV0YXRlT3B0aW9ucy5vbkVycm9yPy4oYWN0aW9uLmVycm9yLCB2YXJpYWJsZXMsIG9uTXV0YXRlUmVzdWx0LCBjb250ZXh0KTtcblx0XHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdG11dGF0ZU9wdGlvbnMub25TZXR0bGVkPy4odm9pZCAwLCBhY3Rpb24uZXJyb3IsIHZhcmlhYmxlcywgb25NdXRhdGVSZXN1bHQsIGNvbnRleHQpO1xuXHRcdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0dGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdFx0bGlzdGVuZXIodGhpcy4jY3VycmVudFJlc3VsdCk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbmV4cG9ydCB7IE11dGF0aW9uT2JzZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb25PYnNlcnZlci5qcy5tYXAiLCJpbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgUXVlcnlPYnNlcnZlciB9IGZyb20gXCIuL3F1ZXJ5T2JzZXJ2ZXIuanNcIjtcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuaW1wb3J0IHsgcmVwbGFjZUVxdWFsRGVlcCwgc2hhbGxvd0VxdWFsT2JqZWN0cyB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyBzcmMvcXVlcmllc09ic2VydmVyLnRzXG4vKipcbiogUmV0dXJucyB0aGUgaXRlbXMgb2YgYGFycmF5MWAgdGhhdCBhcmUgbm90IGluIGBhcnJheTJgLlxuKiBAcGFyYW0gYXJyYXkxIC0gVGhlIGl0ZW1zIHRvIGZpbHRlci5cbiogQHBhcmFtIGFycmF5MiAtIFRoZSBpdGVtcyB0byBleGNsdWRlLlxuKiBAcmV0dXJucyBBIG5ldyBhcnJheSB3aXRoIHRoZSBpdGVtcyBvZiBgYXJyYXkxYCB0aGF0IGFyZSBub3QgaW4gYGFycmF5MmAuXG4qL1xuZnVuY3Rpb24gZGlmZmVyZW5jZShhcnJheTEsIGFycmF5Mikge1xuXHRjb25zdCBleGNsdWRlU2V0ID0gbmV3IFNldChhcnJheTIpO1xuXHRyZXR1cm4gYXJyYXkxLmZpbHRlcigoeCkgPT4gIWV4Y2x1ZGVTZXQuaGFzKHgpKTtcbn1cbi8qKlxuKiBBIGBRdWVyaWVzT2JzZXJ2ZXJgIHdhdGNoZXMgYW4gYXJyYXkgb2YgcXVlcmllcyBhdCBvbmNlLCBleHBvc2luZyB0aGVtIGFzXG4qIGEgc2luZ2xlIGFycmF5IG9mIGBRdWVyeU9ic2VydmVyUmVzdWx0YHMgKG9yLCB3aGVuIGEgYGNvbWJpbmVgIG9wdGlvbiBpc1xuKiBnaXZlbiwgYXMgYSBjb21iaW5lZCB2YWx1ZSBkZXJpdmVkIGZyb20gdGhhdCBhcnJheSkuIEl0IG1hbmFnZXMgb25lXG4qIGludGVybmFsIGBRdWVyeU9ic2VydmVyYCBwZXIgcXVlcnksIGFuZCBpcyB0aGUgcHJpbWl0aXZlIHRoYXQgZnJhbWV3b3JrXG4qIGFkYXB0ZXJzIChlLmcuIGB1c2VRdWVyaWVzYCkgYnVpbGQgdGhlaXIgaG9va3Mgb24gdG9wIG9mLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBvYnNlcnZlciA9IG5ldyBRdWVyaWVzT2JzZXJ2ZXIocXVlcnlDbGllbnQsIFtcbiogICB7IHF1ZXJ5S2V5OiBbJ3Bvc3QnLCAxXSwgcXVlcnlGbjogZmV0Y2hQb3N0IH0sXG4qICAgeyBxdWVyeUtleTogWydwb3N0JywgMl0sIHF1ZXJ5Rm46IGZldGNoUG9zdCB9LFxuKiBdKVxuKlxuKiBjb25zdCB1bnN1YnNjcmliZSA9IG9ic2VydmVyLnN1YnNjcmliZSgocmVzdWx0KSA9PiB7XG4qICAgY29uc29sZS5sb2cocmVzdWx0KVxuKiB9KVxuKiBgYGBcbiovXG52YXIgUXVlcmllc09ic2VydmVyID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuXHQjY2xpZW50O1xuXHQjcmVzdWx0O1xuXHQjcXVlcmllcztcblx0I29wdGlvbnM7XG5cdCNvYnNlcnZlcnM7XG5cdCNjb21iaW5lZFJlc3VsdDtcblx0I2xhc3RDb21iaW5lO1xuXHQjbGFzdFJlc3VsdDtcblx0I2xhc3RRdWVyeUhhc2hlcztcblx0I29ic2VydmVyTWF0Y2hlcyA9IFtdO1xuXHRjb25zdHJ1Y3RvcihjbGllbnQsIHF1ZXJpZXMsIG9wdGlvbnMpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI2NsaWVudCA9IGNsaWVudDtcblx0XHR0aGlzLiNvcHRpb25zID0gb3B0aW9ucztcblx0XHR0aGlzLiNxdWVyaWVzID0gW107XG5cdFx0dGhpcy4jb2JzZXJ2ZXJzID0gW107XG5cdFx0dGhpcy4jcmVzdWx0ID0gW107XG5cdFx0dGhpcy5zZXRRdWVyaWVzKHF1ZXJpZXMpO1xuXHR9XG5cdG9uU3Vic2NyaWJlKCkge1xuXHRcdGlmICh0aGlzLmxpc3RlbmVycy5zaXplID09PSAxKSB0aGlzLiNvYnNlcnZlcnMuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHRoaXMuI3N1YnNjcmliZVRvKG9ic2VydmVyKSk7XG5cdH1cblx0b25VbnN1YnNjcmliZSgpIHtcblx0XHRpZiAoIXRoaXMubGlzdGVuZXJzLnNpemUpIHRoaXMuZGVzdHJveSgpO1xuXHR9XG5cdC8qKlxuXHQqIFN0b3BzIG9ic2VydmluZyBhbGwgcXVlcmllczogY2xlYXJzIGFsbCBsaXN0ZW5lcnMgYW5kIGRlc3Ryb3lzIGV2ZXJ5XG5cdCogdW5kZXJseWluZyBgUXVlcnlPYnNlcnZlcmAgdGhpcyBvYnNlcnZlciBtYW5hZ2VzLlxuXHQqL1xuXHRkZXN0cm95KCkge1xuXHRcdHRoaXMubGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHR0aGlzLiNvYnNlcnZlcnMuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdG9ic2VydmVyLmRlc3Ryb3koKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXBsYWNlcyB0aGUgc2V0IG9mIHF1ZXJpZXMgYmVpbmcgb2JzZXJ2ZWQuIEV4aXN0aW5nIGBRdWVyeU9ic2VydmVyYHNcblx0KiBhcmUgcmV1c2VkIGZvciBxdWVyaWVzIHRoYXQgbWF0Y2ggYW4gYWxyZWFkeS1vYnNlcnZlZCBxdWVyeSBoYXNoO1xuXHQqIG9ic2VydmVycyBmb3IgcXVlcmllcyB0aGF0IGFyZSBubyBsb25nZXIgcHJlc2VudCBhcmUgZGVzdHJveWVkLCBhbmQgbmV3XG5cdCogb2JzZXJ2ZXJzIGFyZSBjcmVhdGVkIGFuZCBzdWJzY3JpYmVkIHRvIGZvciBuZXdseSBhZGRlZCBxdWVyaWVzLlxuXHQqIEBwYXJhbSBxdWVyaWVzIC0gVGhlIG9wdGlvbnMgb2YgdGhlIHF1ZXJpZXMgdG8gb2JzZXJ2ZS5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFJlcGxhY2VzIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMsIGUuZy4gaXRzIGBjb21iaW5lYCBmdW5jdGlvbi5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogb2JzZXJ2ZXIuc2V0UXVlcmllcyhbXG5cdCogICB7IHF1ZXJ5S2V5OiBbJ3Bvc3QnLCAxXSwgcXVlcnlGbjogZmV0Y2hQb3N0IH0sXG5cdCogICB7IHF1ZXJ5S2V5OiBbJ3Bvc3QnLCAzXSwgcXVlcnlGbjogZmV0Y2hQb3N0IH0sXG5cdCogXSlcblx0KiBgYGBcblx0Ki9cblx0c2V0UXVlcmllcyhxdWVyaWVzLCBvcHRpb25zKSB7XG5cdFx0dGhpcy4jcXVlcmllcyA9IHF1ZXJpZXM7XG5cdFx0dGhpcy4jb3B0aW9ucyA9IG9wdGlvbnM7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0Y29uc3QgcXVlcnlIYXNoZXMgPSBxdWVyaWVzLm1hcCgocXVlcnkpID0+IHRoaXMuI2NsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKHF1ZXJ5KS5xdWVyeUhhc2gpO1xuXHRcdFx0aWYgKG5ldyBTZXQocXVlcnlIYXNoZXMpLnNpemUgIT09IHF1ZXJ5SGFzaGVzLmxlbmd0aCkgY29uc29sZS53YXJuKFwiW1F1ZXJpZXNPYnNlcnZlcl06IER1cGxpY2F0ZSBRdWVyaWVzIGZvdW5kLiBUaGlzIG1pZ2h0IHJlc3VsdCBpbiB1bmV4cGVjdGVkIGJlaGF2aW9yLlwiKTtcblx0XHR9XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRjb25zdCBwcmV2T2JzZXJ2ZXJzID0gdGhpcy4jb2JzZXJ2ZXJzO1xuXHRcdFx0Y29uc3QgbmV3T2JzZXJ2ZXJNYXRjaGVzID0gdGhpcy4jZmluZE1hdGNoaW5nT2JzZXJ2ZXJzKHRoaXMuI3F1ZXJpZXMpO1xuXHRcdFx0bmV3T2JzZXJ2ZXJNYXRjaGVzLmZvckVhY2goKG1hdGNoKSA9PiBtYXRjaC5vYnNlcnZlci5zZXRPcHRpb25zKG1hdGNoLmRlZmF1bHRlZFF1ZXJ5T3B0aW9ucykpO1xuXHRcdFx0Y29uc3QgbmV3T2JzZXJ2ZXJzID0gbmV3T2JzZXJ2ZXJNYXRjaGVzLm1hcCgobWF0Y2gpID0+IG1hdGNoLm9ic2VydmVyKTtcblx0XHRcdGNvbnN0IG5ld1Jlc3VsdCA9IG5ld09ic2VydmVycy5tYXAoKG9ic2VydmVyKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCkpO1xuXHRcdFx0Y29uc3QgaGFzTGVuZ3RoQ2hhbmdlID0gcHJldk9ic2VydmVycy5sZW5ndGggIT09IG5ld09ic2VydmVycy5sZW5ndGg7XG5cdFx0XHRjb25zdCBoYXNJbmRleENoYW5nZSA9IG5ld09ic2VydmVycy5zb21lKChvYnNlcnZlciwgaW5kZXgpID0+IG9ic2VydmVyICE9PSBwcmV2T2JzZXJ2ZXJzW2luZGV4XSk7XG5cdFx0XHRjb25zdCBoYXNTdHJ1Y3R1cmFsQ2hhbmdlID0gaGFzTGVuZ3RoQ2hhbmdlIHx8IGhhc0luZGV4Q2hhbmdlO1xuXHRcdFx0Y29uc3QgaGFzUmVzdWx0Q2hhbmdlID0gaGFzU3RydWN0dXJhbENoYW5nZSA/IHRydWUgOiBuZXdSZXN1bHQuc29tZSgocmVzdWx0LCBpbmRleCkgPT4ge1xuXHRcdFx0XHRjb25zdCBwcmV2ID0gdGhpcy4jcmVzdWx0W2luZGV4XTtcblx0XHRcdFx0cmV0dXJuICFwcmV2IHx8ICFzaGFsbG93RXF1YWxPYmplY3RzKHJlc3VsdCwgcHJldik7XG5cdFx0XHR9KTtcblx0XHRcdGlmICghaGFzU3RydWN0dXJhbENoYW5nZSAmJiAhaGFzUmVzdWx0Q2hhbmdlKSByZXR1cm47XG5cdFx0XHRpZiAoaGFzU3RydWN0dXJhbENoYW5nZSkge1xuXHRcdFx0XHR0aGlzLiNvYnNlcnZlck1hdGNoZXMgPSBuZXdPYnNlcnZlck1hdGNoZXM7XG5cdFx0XHRcdHRoaXMuI29ic2VydmVycyA9IG5ld09ic2VydmVycztcblx0XHRcdH1cblx0XHRcdHRoaXMuI3Jlc3VsdCA9IG5ld1Jlc3VsdDtcblx0XHRcdGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkgcmV0dXJuO1xuXHRcdFx0aWYgKGhhc1N0cnVjdHVyYWxDaGFuZ2UpIHtcblx0XHRcdFx0ZGlmZmVyZW5jZShwcmV2T2JzZXJ2ZXJzLCBuZXdPYnNlcnZlcnMpLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRcdFx0b2JzZXJ2ZXIuZGVzdHJveSgpO1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0ZGlmZmVyZW5jZShuZXdPYnNlcnZlcnMsIHByZXZPYnNlcnZlcnMpLmZvckVhY2goKG9ic2VydmVyKSA9PiB0aGlzLiNzdWJzY3JpYmVUbyhvYnNlcnZlcikpO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy4jbm90aWZ5KCk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbW9zdCByZWNlbnRseSBjb21wdXRlZCBhcnJheSBvZiBgUXVlcnlPYnNlcnZlclJlc3VsdGBzLCBvbmVcblx0KiBwZXIgb2JzZXJ2ZWQgcXVlcnksIGluIHRoZSBzYW1lIG9yZGVyIGFzIHRoZSBxdWVyaWVzIHBhc3NlZCB0byB0aGVcblx0KiBjb25zdHJ1Y3RvciBvciBgc2V0UXVlcmllc2AuXG5cdCogQHJldHVybnMgVGhlIGN1cnJlbnQgcmVzdWx0cy5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcmVzdWx0cyA9IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuXHQqIGNvbnN0IGRhdGEgPSByZXN1bHRzLm1hcCgocmVzdWx0KSA9PiByZXN1bHQuZGF0YSlcblx0KiBgYGBcblx0Ki9cblx0Z2V0Q3VycmVudFJlc3VsdCgpIHtcblx0XHRyZXR1cm4gdGhpcy4jcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIHVuZGVybHlpbmcgYFF1ZXJ5YCBpbnN0YW5jZXMgY3VycmVudGx5IGJlaW5nIG9ic2VydmVkLCBpblxuXHQqIHRoZSBzYW1lIG9yZGVyIGFzIHRoZSBxdWVyaWVzIHBhc3NlZCB0byB0aGUgY29uc3RydWN0b3Igb3IgYHNldFF1ZXJpZXNgLlxuXHQqIEByZXR1cm5zIFRoZSBvYnNlcnZlZCBxdWVyaWVzLlxuXHQqL1xuXHRnZXRRdWVyaWVzKCkge1xuXHRcdHJldHVybiB0aGlzLiNvYnNlcnZlcnMubWFwKChvYnNlcnZlcikgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFF1ZXJ5KCkpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIHVuZGVybHlpbmcgYFF1ZXJ5T2JzZXJ2ZXJgIGluc3RhbmNlcyB0aGlzIG9ic2VydmVyIG1hbmFnZXMsXG5cdCogaW4gdGhlIHNhbWUgb3JkZXIgYXMgdGhlIHF1ZXJpZXMgcGFzc2VkIHRvIHRoZSBjb25zdHJ1Y3RvciBvclxuXHQqIGBzZXRRdWVyaWVzYC5cblx0KiBAcmV0dXJucyBUaGUgbWFuYWdlZCBxdWVyeSBvYnNlcnZlcnMuXG5cdCovXG5cdGdldE9ic2VydmVycygpIHtcblx0XHRyZXR1cm4gdGhpcy4jb2JzZXJ2ZXJzO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBgUXVlcmllc09ic2VydmVyYCBjb3VudGVycGFydCBvZiB7QGxpbmsgUXVlcnlPYnNlcnZlciNnZXRPcHRpbWlzdGljUmVzdWx0fSDigJQgY29tcHV0ZXNcblx0KiB0aGUgcmVzdWx0IGZvciB0aGUgZ2l2ZW4gKGFscmVhZHktZGVmYXVsdGVkKSBxdWVyaWVzIHJpZ2h0IG5vdywgc3luY2hyb25vdXNseS4gQ2FsbGVkIGJ5XG5cdCogZnJhbWV3b3JrIGFkYXB0ZXJzIChlLmcuIGB1c2VRdWVyaWVzYCkgYWhlYWQgb2Ygc3Vic2NyaWJpbmcsIHJldHVybmluZyBhIHR1cGxlIG9mIHRoZSByYXdcblx0KiBwZXItcXVlcnkgcmVzdWx0cywgYSBmdW5jdGlvbiB0byBjb21wdXRlIHRoZSBjb21iaW5lZCByZXN1bHQgZnJvbSB0aGVtLCBhbmQgYSBmdW5jdGlvbiB0b1xuXHQqIHdyYXAgdGhlIHJlc3VsdHMgZm9yIHByb3BlcnR5LWFjY2VzcyB0cmFja2luZy4gV2hlbiB0aGUgcXVlcmllcyBtYXRjaCB0aGUgb2JzZXJ2ZWQgb25lcywgdGhlXG5cdCogcmVzdWx0cyBhbHNvIGJlY29tZSB0aGUgY3VycmVudCByZXN1bHQsIHNvIGEgbGF0ZXIgYHNldFF1ZXJpZXNgIGNhbGwgd2l0aCB0aGUgc2FtZSBxdWVyaWVzXG5cdCogZG9lcyBub3Qgbm90aWZ5IHRoZSBsaXN0ZW5lcnMgYWJvdXQgdGhlbS5cblx0KiBAcGFyYW0gcXVlcmllcyAtIFRoZSBkZWZhdWx0ZWQgb3B0aW9ucyBvZiB0aGUgcXVlcmllcyB0byBjb21wdXRlIHRoZSByZXN1bHQgZm9yLlxuXHQqIEBwYXJhbSBjb21iaW5lIC0gVGhlIGBjb21iaW5lYCBmdW5jdGlvbiB1c2VkIGJ5IHRoZSByZXR1cm5lZCBgY29tYmluZVJlc3VsdGAsIGlmIGFueS5cblx0KiBAcmV0dXJucyBBIHR1cGxlIG9mIHRoZSBwZXItcXVlcnkgcmVzdWx0cywgYSBmdW5jdGlvbiB0aGF0IGNvbXB1dGVzIHRoZSBjb21iaW5lZCByZXN1bHQsIGFuZCBhXG5cdCogZnVuY3Rpb24gdGhhdCByZXR1cm5zIHRoZSByZXN1bHRzIHdyYXBwZWQgZm9yIHByb3BlcnR5LWFjY2VzcyB0cmFja2luZy5cblx0Ki9cblx0Z2V0T3B0aW1pc3RpY1Jlc3VsdChxdWVyaWVzLCBjb21iaW5lKSB7XG5cdFx0Y29uc3QgbWF0Y2hlcyA9IHRoaXMuI2ZpbmRNYXRjaGluZ09ic2VydmVycyhxdWVyaWVzKTtcblx0XHRjb25zdCByZXN1bHQgPSBtYXRjaGVzLm1hcCgobWF0Y2gpID0+IG1hdGNoLm9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQobWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zKSk7XG5cdFx0aWYgKG1hdGNoZXMubGVuZ3RoID09PSB0aGlzLiNvYnNlcnZlcnMubGVuZ3RoICYmIG1hdGNoZXMuc29tZSgobWF0Y2gsIGluZGV4KSA9PiBtYXRjaC5vYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCkgIT09IHRoaXMuI3Jlc3VsdFtpbmRleF0pICYmIG1hdGNoZXMuZXZlcnkoKG1hdGNoLCBpbmRleCkgPT4gbWF0Y2gub2JzZXJ2ZXIgPT09IHRoaXMuI29ic2VydmVyc1tpbmRleF0pKSB0aGlzLiNyZXN1bHQgPSBtYXRjaGVzLm1hcCgobWF0Y2gpID0+IG1hdGNoLm9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSk7XG5cdFx0Y29uc3QgcXVlcnlIYXNoZXMgPSBtYXRjaGVzLm1hcCgobWF0Y2gpID0+IG1hdGNoLmRlZmF1bHRlZFF1ZXJ5T3B0aW9ucy5xdWVyeUhhc2gpO1xuXHRcdHJldHVybiBbXG5cdFx0XHRyZXN1bHQsXG5cdFx0XHQocikgPT4ge1xuXHRcdFx0XHRyZXR1cm4gdGhpcy4jY29tYmluZVJlc3VsdChyID8/IHJlc3VsdCwgY29tYmluZSwgcXVlcnlIYXNoZXMpO1xuXHRcdFx0fSxcblx0XHRcdCgpID0+IHtcblx0XHRcdFx0cmV0dXJuIHRoaXMuI3RyYWNrUmVzdWx0KHJlc3VsdCwgbWF0Y2hlcyk7XG5cdFx0XHR9XG5cdFx0XTtcblx0fVxuXHQjdHJhY2tSZXN1bHQocmVzdWx0LCBtYXRjaGVzKSB7XG5cdFx0Y29uc3QgdHJhY2tlZFByb3BzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRyZXR1cm4gbWF0Y2hlcy5tYXAoKG1hdGNoLCBpbmRleCkgPT4ge1xuXHRcdFx0Y29uc3Qgb2JzZXJ2ZXJSZXN1bHQgPSByZXN1bHRbaW5kZXhdO1xuXHRcdFx0cmV0dXJuICFtYXRjaC5kZWZhdWx0ZWRRdWVyeU9wdGlvbnMubm90aWZ5T25DaGFuZ2VQcm9wcyA/IG1hdGNoLm9ic2VydmVyLnRyYWNrUmVzdWx0KG9ic2VydmVyUmVzdWx0LCAoYWNjZXNzZWRQcm9wKSA9PiB7XG5cdFx0XHRcdGlmICghdHJhY2tlZFByb3BzLmhhcyhhY2Nlc3NlZFByb3ApKSB7XG5cdFx0XHRcdFx0dHJhY2tlZFByb3BzLmFkZChhY2Nlc3NlZFByb3ApO1xuXHRcdFx0XHRcdG1hdGNoZXMuZm9yRWFjaCgobSkgPT4ge1xuXHRcdFx0XHRcdFx0bS5vYnNlcnZlci50cmFja1Byb3AoYWNjZXNzZWRQcm9wKTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fVxuXHRcdFx0fSkgOiBvYnNlcnZlclJlc3VsdDtcblx0XHR9KTtcblx0fVxuXHQjY29tYmluZVJlc3VsdChpbnB1dCwgY29tYmluZSwgcXVlcnlIYXNoZXMpIHtcblx0XHRpZiAoY29tYmluZSkge1xuXHRcdFx0Y29uc3QgbGFzdEhhc2hlcyA9IHRoaXMuI2xhc3RRdWVyeUhhc2hlcztcblx0XHRcdGNvbnN0IHF1ZXJ5SGFzaGVzQ2hhbmdlZCA9IHF1ZXJ5SGFzaGVzICE9PSB2b2lkIDAgJiYgbGFzdEhhc2hlcyAhPT0gdm9pZCAwICYmIChsYXN0SGFzaGVzLmxlbmd0aCAhPT0gcXVlcnlIYXNoZXMubGVuZ3RoIHx8IHF1ZXJ5SGFzaGVzLnNvbWUoKGhhc2gsIGkpID0+IGhhc2ggIT09IGxhc3RIYXNoZXNbaV0pKTtcblx0XHRcdGlmICh0aGlzLiNyZXN1bHQgIT09IHRoaXMuI2xhc3RSZXN1bHQgfHwgcXVlcnlIYXNoZXNDaGFuZ2VkIHx8IGNvbWJpbmUgIT09IHRoaXMuI2xhc3RDb21iaW5lKSB7XG5cdFx0XHRcdHRoaXMuI2xhc3RDb21iaW5lID0gY29tYmluZTtcblx0XHRcdFx0dGhpcy4jbGFzdFJlc3VsdCA9IHRoaXMuI3Jlc3VsdDtcblx0XHRcdFx0aWYgKHF1ZXJ5SGFzaGVzICE9PSB2b2lkIDApIHRoaXMuI2xhc3RRdWVyeUhhc2hlcyA9IHF1ZXJ5SGFzaGVzO1xuXHRcdFx0XHR0aGlzLiNjb21iaW5lZFJlc3VsdCA9IHJlcGxhY2VFcXVhbERlZXAodGhpcy4jY29tYmluZWRSZXN1bHQsIGNvbWJpbmUoaW5wdXQpKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiB0aGlzLiNjb21iaW5lZFJlc3VsdDtcblx0XHR9XG5cdFx0cmV0dXJuIGlucHV0O1xuXHR9XG5cdCNzaG91bGRTa2lwQ29tYmluZSgpIHtcblx0XHRyZXR1cm4gIXRoaXMuI29wdGlvbnM/LmNvbWJpbmUgfHwgdGhpcy4jb2JzZXJ2ZXJzLnNvbWUoKG9ic2VydmVyLCBpbmRleCkgPT4ge1xuXHRcdFx0cmV0dXJuIG9ic2VydmVyLm9wdGlvbnMuc3VzcGVuc2UgJiYgdGhpcy4jcmVzdWx0W2luZGV4XT8uZGF0YSA9PT0gdm9pZCAwO1xuXHRcdH0pO1xuXHR9XG5cdCNmaW5kTWF0Y2hpbmdPYnNlcnZlcnMocXVlcmllcykge1xuXHRcdGNvbnN0IHByZXZPYnNlcnZlcnNNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMuI29ic2VydmVycy5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0Y29uc3Qga2V5ID0gb2JzZXJ2ZXIub3B0aW9ucy5xdWVyeUhhc2g7XG5cdFx0XHRpZiAoIWtleSkgcmV0dXJuO1xuXHRcdFx0Y29uc3QgcHJldmlvdXNPYnNlcnZlcnMgPSBwcmV2T2JzZXJ2ZXJzTWFwLmdldChrZXkpO1xuXHRcdFx0aWYgKHByZXZpb3VzT2JzZXJ2ZXJzKSBwcmV2aW91c09ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcblx0XHRcdGVsc2UgcHJldk9ic2VydmVyc01hcC5zZXQoa2V5LCBbb2JzZXJ2ZXJdKTtcblx0XHR9KTtcblx0XHRjb25zdCBvYnNlcnZlcnMgPSBbXTtcblx0XHRxdWVyaWVzLmZvckVhY2goKG9wdGlvbnMpID0+IHtcblx0XHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcblx0XHRcdGNvbnN0IG9ic2VydmVyID0gcHJldk9ic2VydmVyc01hcC5nZXQoZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2gpPy5zaGlmdCgpID8/IG5ldyBRdWVyeU9ic2VydmVyKHRoaXMuI2NsaWVudCwgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0XHRvYnNlcnZlcnMucHVzaCh7XG5cdFx0XHRcdGRlZmF1bHRlZFF1ZXJ5T3B0aW9uczogZGVmYXVsdGVkT3B0aW9ucyxcblx0XHRcdFx0b2JzZXJ2ZXJcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdHJldHVybiBvYnNlcnZlcnM7XG5cdH1cblx0I3N1YnNjcmliZVRvKG9ic2VydmVyKSB7XG5cdFx0b2JzZXJ2ZXIuc3Vic2NyaWJlKChyZXN1bHQpID0+IHtcblx0XHRcdHRoaXMuI29uVXBkYXRlKG9ic2VydmVyLCByZXN1bHQpO1xuXHRcdH0pO1xuXHR9XG5cdCNvblVwZGF0ZShvYnNlcnZlciwgcmVzdWx0KSB7XG5cdFx0Y29uc3QgaW5kZXggPSB0aGlzLiNvYnNlcnZlcnMuaW5kZXhPZihvYnNlcnZlcik7XG5cdFx0aWYgKGluZGV4ICE9PSAtMSkge1xuXHRcdFx0dGhpcy4jcmVzdWx0ID0gdGhpcy4jcmVzdWx0LnNsaWNlKCk7XG5cdFx0XHR0aGlzLiNyZXN1bHRbaW5kZXhdID0gcmVzdWx0O1xuXHRcdFx0dGhpcy4jbm90aWZ5KCk7XG5cdFx0fVxuXHR9XG5cdCNub3RpZnkoKSB7XG5cdFx0aWYgKHRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcblx0XHRcdGNvbnN0IHNob3VsZFNraXBDb21iaW5lID0gdGhpcy4jc2hvdWxkU2tpcENvbWJpbmUoKTtcblx0XHRcdGNvbnN0IHByZXZpb3VzUmVzdWx0ID0gdGhpcy4jY29tYmluZWRSZXN1bHQ7XG5cdFx0XHRjb25zdCBuZXdSZXN1bHQgPSBzaG91bGRTa2lwQ29tYmluZSA/IHByZXZpb3VzUmVzdWx0IDogdGhpcy4jY29tYmluZVJlc3VsdCh0aGlzLiN0cmFja1Jlc3VsdCh0aGlzLiNyZXN1bHQsIHRoaXMuI29ic2VydmVyTWF0Y2hlcyksIHRoaXMuI29wdGlvbnM/LmNvbWJpbmUsIHRoaXMuI29ic2VydmVyTWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiBtYXRjaC5kZWZhdWx0ZWRRdWVyeU9wdGlvbnMucXVlcnlIYXNoKSk7XG5cdFx0XHRpZiAoc2hvdWxkU2tpcENvbWJpbmUgfHwgcHJldmlvdXNSZXN1bHQgIT09IG5ld1Jlc3VsdCkgbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdFx0bGlzdGVuZXIodGhpcy4jcmVzdWx0KTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cbn07XG5leHBvcnQgeyBRdWVyaWVzT2JzZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcmllc09ic2VydmVyLmpzLm1hcCIsImltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBRdWVyeSB9IGZyb20gXCIuL3F1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbmltcG9ydCB7IGhhc2hRdWVyeUtleUJ5T3B0aW9ucywgbWF0Y2hRdWVyeSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyBzcmMvcXVlcnlDYWNoZS50c1xuLyoqXG4qIFRoZSBgUXVlcnlDYWNoZWAgaXMgdGhlIHN0b3JhZ2UgbWVjaGFuaXNtIGZvciBUYW5TdGFjayBRdWVyeS4gSXQgc3RvcmVzIGFsbCB0aGUgZGF0YSwgbWV0YVxuKiBpbmZvcm1hdGlvbiwgYW5kIHN0YXRlIG9mIHRoZSBxdWVyaWVzIGl0IGNvbnRhaW5zLlxuKlxuKiBOb3JtYWxseSwgeW91IHdpbGwgbm90IGludGVyYWN0IHdpdGggdGhlIGBRdWVyeUNhY2hlYCBkaXJlY3RseSBhbmQgaW5zdGVhZCB1c2UgYSBgUXVlcnlDbGllbnRgXG4qIGZvciBhIHNwZWNpZmljIGNhY2hlLiBZb3UgY2FuIHN1YnNjcmliZSB0byBpdCAoaW5oZXJpdGVkIGZyb20gYFN1YnNjcmliYWJsZWApIHRvIGJlIGluZm9ybWVkIG9mXG4qIHNhZmUva25vd24gdXBkYXRlcyB0byB0aGUgY2FjaGUsIHN1Y2ggYXMgcXVlcmllcyBiZWluZyBhZGRlZCwgcmVtb3ZlZCwgb3IgdXBkYXRlZCDigJQgdXBkYXRlcyBtYWRlXG4qIG91dHNpZGUgb2YgdGhlIGNhY2hlJ3Mgb3duIHRyYWNrZWQgbWVjaGFuaXNtcyAoZS5nLiBtdXRhdGluZyBhIHF1ZXJ5J3Mgc3RhdGUgb2JqZWN0IGRpcmVjdGx5KSBkb1xuKiBub3Qgbm90aWZ5IHN1YnNjcmliZXJzLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCB1bnN1YnNjcmliZSA9IHF1ZXJ5Q2FjaGUuc3Vic2NyaWJlKChldmVudCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKGV2ZW50LnR5cGUsIGV2ZW50LnF1ZXJ5KVxuKiB9KVxuKiBgYGBcbiovXG52YXIgUXVlcnlDYWNoZSA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I3F1ZXJpZXM7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZyA9IHt9KSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZztcblx0XHR0aGlzLiNxdWVyaWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBleGlzdGluZyBgUXVlcnlgIGluc3RhbmNlIGZvciB0aGUgZ2l2ZW4gb3B0aW9ucycgYHF1ZXJ5S2V5YC9gcXVlcnlIYXNoYCwgb3Jcblx0KiBidWlsZHMgYW5kIGFkZHMgYSBuZXcgb25lIHRvIHRoZSBjYWNoZSBpZiBub25lIGV4aXN0cyB5ZXQuIFVzZWQgYnkgZnJhbWV3b3JrIGFkYXB0ZXJzIGFuZFxuXHQqIHBsdWdpbnMgKGUuZy4gYnJvYWRjYXN0L3BlcnNpc3RlbmNlKSB0aGF0IG5lZWQgdG8gZ2V0LW9yLWNyZWF0ZSBhIGBRdWVyeWAgZGlyZWN0bHksIGJ5cGFzc2luZ1xuXHQqIHRoZSByZWFjdGl2ZSBgUXVlcnlPYnNlcnZlcmAgbWFjaGluZXJ5LlxuXHQqIEBwYXJhbSBjbGllbnQgLSBUaGUgY2xpZW50IHRoZSBxdWVyeSBiZWxvbmdzIHRvLCB1c2VkIHRvIGRlZmF1bHQgaXRzIG9wdGlvbnMuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucywgaW5jbHVkaW5nIHRoZSBgcXVlcnlLZXlgLiBBIG5ldyBxdWVyeSBpcyBjcmVhdGVkIHdpdGggdGhlXG5cdCogb3B0aW9ucyBkZWZhdWx0ZWQgYnkge0BsaW5rIFF1ZXJ5Q2xpZW50I2RlZmF1bHRRdWVyeU9wdGlvbnN9LlxuXHQqIEBwYXJhbSBzdGF0ZSAtIFRoZSBpbml0aWFsIHN0YXRlIG9mIGEgbmV3bHkgY3JlYXRlZCBxdWVyeSwgZS5nLiB3aGVuIGh5ZHJhdGluZy4gSWdub3JlZCBpZiB0aGVcblx0KiBxdWVyeSBhbHJlYWR5IGV4aXN0cy5cblx0KiBAcmV0dXJucyBUaGUgZXhpc3Rpbmcgb3IgbmV3bHkgY3JlYXRlZCBxdWVyeS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqXG5cdCogY29uc3QgcXVlcnkgPSBxdWVyeUNhY2hlLmJ1aWxkKHF1ZXJ5Q2xpZW50LCB7XG5cdCogICBxdWVyeUtleTogWydwb3N0cyddLFxuXHQqICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRidWlsZChjbGllbnQsIG9wdGlvbnMsIHN0YXRlKSB7XG5cdFx0Y29uc3QgcXVlcnlLZXkgPSBvcHRpb25zLnF1ZXJ5S2V5O1xuXHRcdGNvbnN0IHF1ZXJ5SGFzaCA9IG9wdGlvbnMucXVlcnlIYXNoID8/IGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgb3B0aW9ucyk7XG5cdFx0bGV0IHF1ZXJ5ID0gdGhpcy5nZXQocXVlcnlIYXNoKTtcblx0XHRpZiAoIXF1ZXJ5KSB7XG5cdFx0XHRxdWVyeSA9IG5ldyBRdWVyeSh7XG5cdFx0XHRcdGNsaWVudCxcblx0XHRcdFx0cXVlcnlLZXksXG5cdFx0XHRcdHF1ZXJ5SGFzaCxcblx0XHRcdFx0b3B0aW9uczogY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyksXG5cdFx0XHRcdHN0YXRlLFxuXHRcdFx0XHRkZWZhdWx0T3B0aW9uczogY2xpZW50LmdldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXkpXG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuYWRkKHF1ZXJ5KTtcblx0XHR9XG5cdFx0cmV0dXJuIHF1ZXJ5O1xuXHR9XG5cdC8qKlxuXHQqIEFkZHMgYSBxdWVyeSB0byB0aGUgY2FjaGUuXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGFkZC4gSWYgYSBxdWVyeSB3aXRoIHRoZSBzYW1lIGhhc2ggaXMgYWxyZWFkeSBjYWNoZWQsIG5vdGhpbmdcblx0KiBoYXBwZW5zLlxuXHQqL1xuXHRhZGQocXVlcnkpIHtcblx0XHRpZiAoIXRoaXMuI3F1ZXJpZXMuaGFzKHF1ZXJ5LnF1ZXJ5SGFzaCkpIHtcblx0XHRcdHRoaXMuI3F1ZXJpZXMuc2V0KHF1ZXJ5LnF1ZXJ5SGFzaCwgcXVlcnkpO1xuXHRcdFx0dGhpcy5ub3RpZnkoe1xuXHRcdFx0XHR0eXBlOiBcImFkZGVkXCIsXG5cdFx0XHRcdHF1ZXJ5XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogRGVzdHJveXMgdGhlIGdpdmVuIGBRdWVyeWAgYW5kIHJlbW92ZXMgaXQgZnJvbSB0aGUgY2FjaGUsIG5vdGlmeWluZyBzdWJzY3JpYmVycyB3aXRoIGFcblx0KiBgJ3JlbW92ZWQnYCBldmVudC4gQSBuby1vcCBpZiB0aGUgcXVlcnkgaXMgbm8gbG9uZ2VyIHRoZSBvbmUgY3VycmVudGx5IHN0b3JlZCB1bmRlciBpdHMgaGFzaFxuXHQqIChlLmcuIGl0IHdhcyBhbHJlYWR5IHJlcGxhY2VkKS4gVXNlZCBieSBwbHVnaW5zIChlLmcuIHRoZSBicm9hZGNhc3QgY2xpZW50KSB0aGF0IG1pcnJvclxuXHQqIHJlbW92YWxzIGFjcm9zcyBgUXVlcnlDYWNoZWAgaW5zdGFuY2VzLlxuXHQqIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0byByZW1vdmUuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KiBjb25zdCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuZmluZCh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcblx0KlxuXHQqIGlmIChxdWVyeSkge1xuXHQqICAgcXVlcnlDYWNoZS5yZW1vdmUocXVlcnkpXG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRyZW1vdmUocXVlcnkpIHtcblx0XHRpZiAodGhpcy4jcXVlcmllcy5nZXQocXVlcnkucXVlcnlIYXNoKSA9PT0gcXVlcnkpIHtcblx0XHRcdHF1ZXJ5LmRlc3Ryb3koKTtcblx0XHRcdHRoaXMuI3F1ZXJpZXMuZGVsZXRlKHF1ZXJ5LnF1ZXJ5SGFzaCk7XG5cdFx0XHR0aGlzLm5vdGlmeSh7XG5cdFx0XHRcdHR5cGU6IFwicmVtb3ZlZFwiLFxuXHRcdFx0XHRxdWVyeVxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIFJlbW92ZXMgYWxsIHF1ZXJpZXMgZnJvbSB0aGUgY2FjaGUuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KlxuXHQqIHF1ZXJ5Q2FjaGUuY2xlYXIoKVxuXHQqIGBgYFxuXHQqL1xuXHRjbGVhcigpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0dGhpcy5yZW1vdmUocXVlcnkpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgYFF1ZXJ5YCBpbnN0YW5jZSBzdG9yZWQgdW5kZXIgdGhlIGdpdmVuIGBxdWVyeUhhc2hgLCBvciBgdW5kZWZpbmVkYCBpZiBub25lXG5cdCogZXhpc3RzLiBVbmxpa2Uge0BsaW5rIFF1ZXJ5Q2FjaGUjZmluZH0sIHRoaXMgbG9va3MgdXAgYnkgdGhlIGFscmVhZHktY29tcHV0ZWQgaGFzaCByYXRoZXJcblx0KiB0aGFuIGJ5IGBRdWVyeUZpbHRlcnNgLiBVc2VkIGJ5IHBsdWdpbnMgKGUuZy4gYnJvYWRjYXN0L2h5ZHJhdGlvbikgdGhhdCBhbHJlYWR5IGhhdmUgYSBoYXNoXG5cdCogdG8gbG9vayB1cCBkaXJlY3RseS5cblx0KiBAcGFyYW0gcXVlcnlIYXNoIC0gVGhlIGhhc2ggb2YgdGhlIHF1ZXJ5IHRvIGxvb2sgdXAuXG5cdCogQHJldHVybnMgVGhlIHF1ZXJ5IHN0b3JlZCB1bmRlciB0aGUgaGFzaCwgb3IgYHVuZGVmaW5lZGAuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KiBjb25zdCBxdWVyeUhhc2ggPSBoYXNoS2V5KFsncG9zdHMnXSlcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5ID0gcXVlcnlDYWNoZS5nZXQocXVlcnlIYXNoKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXQocXVlcnlIYXNoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJpZXMuZ2V0KHF1ZXJ5SGFzaCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBhbGwgcXVlcmllcyB3aXRoaW4gdGhlIGNhY2hlLlxuXHQqIEByZXR1cm5zIEV2ZXJ5IHF1ZXJ5IGluIHRoZSBjYWNoZS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqXG5cdCogY29uc3QgcXVlcmllcyA9IHF1ZXJ5Q2FjaGUuZ2V0QWxsKClcblx0KiBgYGBcblx0Ki9cblx0Z2V0QWxsKCkge1xuXHRcdHJldHVybiBbLi4udGhpcy4jcXVlcmllcy52YWx1ZXMoKV07XG5cdH1cblx0LyoqXG5cdCogQSBzbGlnaHRseSBtb3JlIGFkdmFuY2VkIG1ldGhvZCB0aGF0IGNhbiBiZSB1c2VkIHRvIGdldCBhbiBleGlzdGluZyBxdWVyeSBpbnN0YW5jZSBmcm9tIHRoZVxuXHQqIGNhY2hlLiBUaGlzIGluc3RhbmNlIG5vdCBvbmx5IGNvbnRhaW5zIGFsbCB0aGUgc3RhdGUgZm9yIHRoZSBxdWVyeSwgYnV0IGFsbCBvZiB0aGUgaW5zdGFuY2VzLFxuXHQqIGFuZCB1bmRlcmx5aW5nIGd1dHMgb2YgdGhlIHF1ZXJ5IGFzIHdlbGwuIElmIHRoZSBxdWVyeSBkb2VzIG5vdCBleGlzdCwgYHVuZGVmaW5lZGAgaXNcblx0KiByZXR1cm5lZC5cblx0KlxuXHQqIFRoaXMgaXMgbm90IHR5cGljYWxseSBuZWVkZWQgZm9yIG1vc3QgYXBwbGljYXRpb25zLCBidXQgY2FuIGNvbWUgaW4gaGFuZHkgd2hlbiBuZWVkaW5nIG1vcmVcblx0KiBpbmZvcm1hdGlvbiBhYm91dCBhIHF1ZXJ5IGluIHJhcmUgc2NlbmFyaW9zIChlLmcuIGxvb2tpbmcgYXQgYHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXRgIHRvXG5cdCogZGVjaWRlIHdoZXRoZXIgYSBxdWVyeSBpcyBmcmVzaCBlbm91Z2ggdG8gYmUgdXNlZCBhcyBhbiBpbml0aWFsIHZhbHVlKS5cblx0KiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRvIG1hdGNoLCBpbmNsdWRpbmcgdGhlIHJlcXVpcmVkIGBxdWVyeUtleWAuIGBleGFjdGAgZGVmYXVsdHMgdG9cblx0KiBgdHJ1ZWAuXG5cdCogQHJldHVybnMgVGhlIGZpcnN0IG1hdGNoaW5nIHF1ZXJ5LCBvciBgdW5kZWZpbmVkYC5cblx0KiBAc2VlIHtAbGluayBRdWVyeUNhY2hlI2ZpbmRBbGx9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5ID0gcXVlcnlDYWNoZS5maW5kKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRmaW5kKGZpbHRlcnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRGaWx0ZXJzID0ge1xuXHRcdFx0ZXhhY3Q6IHRydWUsXG5cdFx0XHQuLi5maWx0ZXJzXG5cdFx0fTtcblx0XHRyZXR1cm4gdGhpcy5nZXRBbGwoKS5maW5kKChxdWVyeSkgPT4gbWF0Y2hRdWVyeShkZWZhdWx0ZWRGaWx0ZXJzLCBxdWVyeSkpO1xuXHR9XG5cdC8qKlxuXHQqIEFuIGV2ZW4gbW9yZSBhZHZhbmNlZCBtZXRob2QgdGhhdCBjYW4gYmUgdXNlZCB0byBnZXQgZXhpc3RpbmcgcXVlcnkgaW5zdGFuY2VzIGZyb20gdGhlIGNhY2hlXG5cdCogdGhhdCBwYXJ0aWFsbHkgbWF0Y2ggYSBxdWVyeSBrZXkuIElmIG5vIHF1ZXJpZXMgbWF0Y2gsIGFuIGVtcHR5IGFycmF5IGlzIHJldHVybmVkLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IHF1ZXJpZXMgaW4gcmFyZSBzY2VuYXJpb3MuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0byBtYXRjaC4gV2l0aG91dCBmaWx0ZXJzLCBldmVyeSBxdWVyeSBpcyByZXR1cm5lZC5cblx0KiBAcmV0dXJucyBUaGUgbWF0Y2hpbmcgcXVlcmllcy5cblx0KiBAc2VlIHtAbGluayBRdWVyeUNhY2hlI2ZpbmR9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KlxuXHQqIGNvbnN0IHF1ZXJpZXMgPSBxdWVyeUNhY2hlLmZpbmRBbGwoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG5cdCogYGBgXG5cdCovXG5cdGZpbmRBbGwoZmlsdGVycyA9IHt9KSB7XG5cdFx0Y29uc3QgcXVlcmllcyA9IHRoaXMuZ2V0QWxsKCk7XG5cdFx0cmV0dXJuIE9iamVjdC5rZXlzKGZpbHRlcnMpLmxlbmd0aCA+IDAgPyBxdWVyaWVzLmZpbHRlcigocXVlcnkpID0+IG1hdGNoUXVlcnkoZmlsdGVycywgcXVlcnkpKSA6IHF1ZXJpZXM7XG5cdH1cblx0LyoqXG5cdCogTm90aWZpZXMgZXZlcnkgY2FjaGUgbGlzdGVuZXIgb2YgYW4gZXZlbnQsIGluIG9uZSBiYXRjaC5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gZXZlbnQgLSBUaGUgZXZlbnQgcGFzc2VkIHRvIGV2ZXJ5IGxpc3RlbmVyLlxuXHQqL1xuXHRub3RpZnkoZXZlbnQpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdGxpc3RlbmVyKGV2ZW50KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIENhbGxzIHtAbGluayBRdWVyeSNvbkZvY3VzfSBvbiBldmVyeSBjYWNoZWQgcXVlcnksIGluIG9uZSBiYXRjaC5cblx0KiBAaW50ZXJuYWxcblx0Ki9cblx0b25Gb2N1cygpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkub25Gb2N1cygpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogQ2FsbHMge0BsaW5rIFF1ZXJ5I29uT25saW5lfSBvbiBldmVyeSBjYWNoZWQgcXVlcnksIGluIG9uZSBiYXRjaC5cblx0KiBAaW50ZXJuYWxcblx0Ki9cblx0b25PbmxpbmUoKSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLmdldEFsbCgpLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG5cdFx0XHRcdHF1ZXJ5Lm9uT25saW5lKCk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbmV4cG9ydCB7IFF1ZXJ5Q2FjaGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnlDYWNoZS5qcy5tYXAiLCJpbXBvcnQgeyBmb2N1c01hbmFnZXIgfSBmcm9tIFwiLi9mb2N1c01hbmFnZXIuanNcIjtcbmltcG9ydCB7IE11dGF0aW9uQ2FjaGUgfSBmcm9tIFwiLi9tdXRhdGlvbkNhY2hlLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgb25saW5lTWFuYWdlciB9IGZyb20gXCIuL29ubGluZU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IFF1ZXJ5Q2FjaGUgfSBmcm9tIFwiLi9xdWVyeUNhY2hlLmpzXCI7XG5pbXBvcnQgeyBmdW5jdGlvbmFsVXBkYXRlLCBoYXNoS2V5LCBoYXNoUXVlcnlLZXlCeU9wdGlvbnMsIG5vb3AsIHBhcnRpYWxNYXRjaEtleSwgcmVzb2x2ZVF1ZXJ5VmFsdWUsIHNraXBUb2tlbiB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyBzcmMvcXVlcnlDbGllbnQudHNcbi8qKlxuKiBgUXVlcnlDbGllbnRgIGlzIHVzZWQgdG8gaW50ZXJhY3Qgd2l0aCBhIGNhY2hlIG9mIHF1ZXJpZXMgYW5kIG11dGF0aW9ucy4gSXQgb3ducyBhXG4qIGBRdWVyeUNhY2hlYCBhbmQgYSBgTXV0YXRpb25DYWNoZWAgKGNyZWF0aW5nIGRlZmF1bHQgb25lcyBpZiBub25lIGFyZSBwYXNzZWQgaW4pIGFuZCBob2xkc1xuKiB0aGUgZGVmYXVsdCBvcHRpb25zIHRoYXQgYXJlIGFwcGxpZWQgdG8gcXVlcmllcyBhbmQgbXV0YXRpb25zIGNyZWF0ZWQgdGhyb3VnaCBpdC5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoe1xuKiAgIGRlZmF1bHRPcHRpb25zOiB7XG4qICAgICBxdWVyaWVzOiB7XG4qICAgICAgIHN0YWxlVGltZTogSW5maW5pdHksXG4qICAgICB9LFxuKiAgIH0sXG4qIH0pXG4qXG4qIGF3YWl0IHF1ZXJ5Q2xpZW50LnF1ZXJ5KHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgcXVlcnlGbjogZmV0Y2hQb3N0cyB9KVxuKiBgYGBcbiovXG52YXIgUXVlcnlDbGllbnQgPSBjbGFzcyB7XG5cdCNxdWVyeUNhY2hlO1xuXHQjbXV0YXRpb25DYWNoZTtcblx0I2RlZmF1bHRPcHRpb25zO1xuXHQjcXVlcnlEZWZhdWx0cztcblx0I211dGF0aW9uRGVmYXVsdHM7XG5cdCNtb3VudENvdW50O1xuXHQjdW5zdWJzY3JpYmVGb2N1cztcblx0I3Vuc3Vic2NyaWJlT25saW5lO1xuXHRjb25zdHJ1Y3Rvcihjb25maWcgPSB7fSkge1xuXHRcdHRoaXMuI3F1ZXJ5Q2FjaGUgPSBjb25maWcucXVlcnlDYWNoZSB8fCBuZXcgUXVlcnlDYWNoZSgpO1xuXHRcdHRoaXMuI211dGF0aW9uQ2FjaGUgPSBjb25maWcubXV0YXRpb25DYWNoZSB8fCBuZXcgTXV0YXRpb25DYWNoZSgpO1xuXHRcdHRoaXMuI2RlZmF1bHRPcHRpb25zID0gY29uZmlnLmRlZmF1bHRPcHRpb25zIHx8IHt9O1xuXHRcdHRoaXMuI3F1ZXJ5RGVmYXVsdHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMuI211dGF0aW9uRGVmYXVsdHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMuI21vdW50Q291bnQgPSAwO1xuXHR9XG5cdC8qKlxuXHQqIENhbGxlZCBieSBhIGZyYW1ld29yayBhZGFwdGVyJ3MgYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgLWVxdWl2YWxlbnQgd2hlbiBpdCBtb3VudHMsIHRvIHN0YXJ0XG5cdCogbGlzdGVuaW5nIGZvciBmb2N1cy9vbmxpbmUgZXZlbnRzIGFuZCByZXN1bWUgcGF1c2VkIG11dGF0aW9ucy4gUmVmLWNvdW50ZWQgdmlhIGFuIGludGVybmFsXG5cdCogbW91bnQgY291bnQsIHNvIG5lc3RlZCBvciBtdWx0aXBsZSBwcm92aWRlcnMgc2hhcmluZyB0aGUgc2FtZSBgUXVlcnlDbGllbnRgIGRvbid0IHRlYXIgZG93blxuXHQqIHRoZSBzaGFyZWQgbGlzdGVuZXJzIHVudGlsIHRoZSBsYXN0IG9uZSB1bm1vdW50cy5cblx0Ki9cblx0bW91bnQoKSB7XG5cdFx0dGhpcy4jbW91bnRDb3VudCsrO1xuXHRcdGlmICh0aGlzLiNtb3VudENvdW50ICE9PSAxKSByZXR1cm47XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVGb2N1cyA9IGZvY3VzTWFuYWdlci5zdWJzY3JpYmUoYXN5bmMgKGZvY3VzZWQpID0+IHtcblx0XHRcdGlmIChmb2N1c2VkKSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMucmVzdW1lUGF1c2VkTXV0YXRpb25zKCk7XG5cdFx0XHRcdHRoaXMuI3F1ZXJ5Q2FjaGUub25Gb2N1cygpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlT25saW5lID0gb25saW5lTWFuYWdlci5zdWJzY3JpYmUoYXN5bmMgKG9ubGluZSkgPT4ge1xuXHRcdFx0aWYgKG9ubGluZSkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLnJlc3VtZVBhdXNlZE11dGF0aW9ucygpO1xuXHRcdFx0XHR0aGlzLiNxdWVyeUNhY2hlLm9uT25saW5lKCk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogVGhlIGludmVyc2Ugb2Yge0BsaW5rIFF1ZXJ5Q2xpZW50I21vdW50fSDigJQgY2FsbGVkIGJ5IGEgZnJhbWV3b3JrIGFkYXB0ZXInc1xuXHQqIGBRdWVyeUNsaWVudFByb3ZpZGVyYC1lcXVpdmFsZW50IHdoZW4gaXQgdW5tb3VudHMuIE9ubHkgdGVhcnMgZG93biB0aGUgZm9jdXMvb25saW5lXG5cdCogbGlzdGVuZXJzIG9uY2UgdGhlIG1vdW50IGNvdW50IHJldHVybnMgdG8gYDBgLlxuXHQqL1xuXHR1bm1vdW50KCkge1xuXHRcdHRoaXMuI21vdW50Q291bnQtLTtcblx0XHRpZiAodGhpcy4jbW91bnRDb3VudCAhPT0gMCkgcmV0dXJuO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlRm9jdXM/LigpO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlRm9jdXMgPSB2b2lkIDA7XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVPbmxpbmU/LigpO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlT25saW5lID0gdm9pZCAwO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG51bWJlciBvZiBxdWVyaWVzIGluIHRoZSBjYWNoZSB0aGF0IGFyZSBjdXJyZW50bHkgZmV0Y2hpbmcsIG9wdGlvbmFsbHlcblx0KiBtYXRjaGluZyBhIHNldCBvZiBmaWx0ZXJzLiBUaGlzIGluY2x1ZGVzIGJhY2tncm91bmQtZmV0Y2hpbmcsIGxvYWRpbmcgbmV3IHBhZ2VzLCBhbmRcblx0KiBsb2FkaW5nIG1vcmUgaW5maW5pdGUgcXVlcnkgcmVzdWx0cy5cblx0KiBAcGFyYW0gZmlsdGVycyAtIE5hcnJvd3MgZG93biB3aGljaCBmZXRjaGluZyBxdWVyaWVzIGFyZSBjb3VudGVkLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5XG5cdCogZmV0Y2hpbmcgcXVlcnkgaXMgY291bnRlZC5cblx0KiBAcmV0dXJucyBUaGUgbnVtYmVyIG9mIG1hdGNoaW5nIHF1ZXJpZXMgd2hvc2UgYGZldGNoU3RhdHVzYCBpcyBgJ2ZldGNoaW5nJ2AuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGlmIChxdWVyeUNsaWVudC5pc0ZldGNoaW5nKCkpIHtcblx0KiAgIGNvbnNvbGUubG9nKCdBdCBsZWFzdCBvbmUgcXVlcnkgaXMgZmV0Y2hpbmchJylcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGlzRmV0Y2hpbmcoZmlsdGVycykge1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoe1xuXHRcdFx0Li4uZmlsdGVycyxcblx0XHRcdGZldGNoU3RhdHVzOiBcImZldGNoaW5nXCJcblx0XHR9KS5sZW5ndGg7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbnVtYmVyIG9mIG11dGF0aW9ucyBpbiB0aGUgY2FjaGUgdGhhdCBhcmUgY3VycmVudGx5IHBlbmRpbmcsIG9wdGlvbmFsbHlcblx0KiBtYXRjaGluZyBhIHNldCBvZiBmaWx0ZXJzLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gTmFycm93cyBkb3duIHdoaWNoIHBlbmRpbmcgbXV0YXRpb25zIGFyZSBjb3VudGVkLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5XG5cdCogcGVuZGluZyBtdXRhdGlvbiBpcyBjb3VudGVkLlxuXHQqIEByZXR1cm5zIFRoZSBudW1iZXIgb2YgbWF0Y2hpbmcgbXV0YXRpb25zIHdob3NlIGBzdGF0dXNgIGlzIGAncGVuZGluZydgLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpZiAocXVlcnlDbGllbnQuaXNNdXRhdGluZygpKSB7XG5cdCogICBjb25zb2xlLmxvZygnQXQgbGVhc3Qgb25lIG11dGF0aW9uIGlzIHBlbmRpbmchJylcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGlzTXV0YXRpbmcoZmlsdGVycykge1xuXHRcdHJldHVybiB0aGlzLiNtdXRhdGlvbkNhY2hlLmZpbmRBbGwoe1xuXHRcdFx0Li4uZmlsdGVycyxcblx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCJcblx0XHR9KS5sZW5ndGg7XG5cdH1cblx0LyoqXG5cdCogSW1wZXJhdGl2ZSAobm9uLXJlYWN0aXZlKSB3YXkgdG8gcmV0cmlldmUgZGF0YSBmb3IgYSBRdWVyeUtleS5cblx0KiBTaG91bGQgb25seSBiZSB1c2VkIGluIGNhbGxiYWNrcyBvciBmdW5jdGlvbnMgd2hlcmUgcmVhZGluZyB0aGUgbGF0ZXN0IGRhdGEgaXMgbmVjZXNzYXJ5LCBlLmcuIGZvciBvcHRpbWlzdGljIHVwZGF0ZXMuXG5cdCpcblx0KiBIaW50OiBEbyBub3QgdXNlIHRoaXMgZnVuY3Rpb24gaW5zaWRlIGEgY29tcG9uZW50LCBiZWNhdXNlIGl0IHdvbid0IHJlY2VpdmUgdXBkYXRlcy5cblx0KiBVc2UgYHVzZVF1ZXJ5YCB0byBjcmVhdGUgYSBgUXVlcnlPYnNlcnZlcmAgdGhhdCBzdWJzY3JpYmVzIHRvIGNoYW5nZXMuXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSBvZiB0aGUgcXVlcnkgdG8gcmVhZC5cblx0KiBAcmV0dXJucyBUaGUgY2FjaGVkIGRhdGEgZm9yIHRoZSBxdWVyeSwgb3IgYHVuZGVmaW5lZGAgaWYgbm8gcXVlcnkgd2l0aCB0aGlzIGtleSBoYXMgYmVlbiBvYnNlcnZlZCB5ZXQuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0UXVlcmllc0RhdGF9XG5cdCovXG5cdGdldFF1ZXJ5RGF0YShxdWVyeUtleSkge1xuXHRcdGNvbnN0IG9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMoeyBxdWVyeUtleSB9KTtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5nZXQob3B0aW9ucy5xdWVyeUhhc2gpPy5zdGF0ZS5kYXRhO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGNhY2hlZCBkYXRhIG9mIGEgcXVlcnksIG9yIGZldGNoZXMgaXQgaWYgdGhlcmUgaXMgbm9uZS4gV2l0aCBgcmV2YWxpZGF0ZUlmU3RhbGVgLFxuXHQqIHN0YWxlIGNhY2hlZCBkYXRhIGlzIGFsc28gcmVmZXRjaGVkIGluIHRoZSBiYWNrZ3JvdW5kLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIHF1ZXJ5IG9wdGlvbnMuIElmIHRoZSBxdWVyeSBoYXMgbm8gY2FjaGVkIGRhdGEgeWV0LCBpdCBpcyBmZXRjaGVkIHdpdGhcblx0KiB0aGVzZSBvcHRpb25zLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIHRoZSBjYWNoZWQgZGF0YSwgb3IgdG8gdGhlIGZldGNoZWQgZGF0YSBpZiBub3RoaW5nIHdhc1xuXHQqIGNhY2hlZCB5ZXQuXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LnF1ZXJ5KHsgLi4ub3B0aW9ucywgc3RhbGVUaW1lOiAnc3RhdGljJyB9KSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZW5zdXJlUXVlcnlEYXRhKG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRjb25zdCBjYWNoZWREYXRhID0gcXVlcnkuc3RhdGUuZGF0YTtcblx0XHRpZiAoY2FjaGVkRGF0YSA9PT0gdm9pZCAwKSByZXR1cm4gdGhpcy5mZXRjaFF1ZXJ5KG9wdGlvbnMpO1xuXHRcdGlmIChvcHRpb25zLnJldmFsaWRhdGVJZlN0YWxlICYmIHF1ZXJ5LmlzU3RhbGVCeVRpbWUocmVzb2x2ZVF1ZXJ5VmFsdWUoZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSkpIHRoaXMucHJlZmV0Y2hRdWVyeShkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGNhY2hlZERhdGEpO1xuXHR9XG5cdC8qKlxuXHQqIEltcGVyYXRpdmUgKG5vbi1yZWFjdGl2ZSkgd2F5IHRvIHJldHJpZXZlIHRoZSBjYWNoZWQgZGF0YSBvZiBtdWx0aXBsZSBxdWVyaWVzIGF0IG9uY2UuXG5cdCogT25seSBxdWVyaWVzIG1hdGNoaW5nIHRoZSBnaXZlbiBmaWx0ZXJzIGFyZSByZXR1cm5lZDsgaWYgbm9uZSBtYXRjaCwgYW4gZW1wdHkgYXJyYXkgaXNcblx0KiByZXR1cm5lZC5cblx0KlxuXHQqIEJlY2F1c2UgdGhlIG1hdGNoZWQgcXVlcmllcyBjYW4gaG9sZCBkYXRhIG9mIGRpZmZlcmVudCBzaGFwZXMgKGUuZy4gYSBicm9hZCBmaWx0ZXIgY2FuIG1hdGNoXG5cdCogcXVlcmllcyB3aXRoIHVucmVsYXRlZCBkYXRhIHR5cGVzKSwgdGhlIGBUUXVlcnlGbkRhdGFgIGdlbmVyaWMgZGVmYXVsdHMgdG8gYHVua25vd25gIHJhdGhlclxuXHQqIHRoYW4gYmVpbmcgaW5mZXJyZWQuIFBhc3NpbmcgYSBtb3JlIHNwZWNpZmljIHR5cGUgaXMgYSBjb252ZW5pZW5jZSBmb3IgY2FsbCBzaXRlcyB0aGF0IGtub3dcblx0KiBldmVyeSBtYXRjaGVkIHF1ZXJ5IGhvbGRzIHRoZSBzYW1lIHNoYXBlIOKAlCBpdCBpcyBub3QgY2hlY2tlZCBhZ2FpbnN0IHRoZSBhY3R1YWwgY2FjaGVcblx0KiBjb250ZW50cy5cblx0KiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRoYXQgc2VsZWN0IHdoaWNoIHF1ZXJpZXMgdG8gcmVhZC5cblx0KiBAcmV0dXJucyBBbiBhcnJheSBvZiBxdWVyeSBrZXkgYW5kIGRhdGEgcGFpcnMuIFRoZSBkYXRhIGlzIGB1bmRlZmluZWRgIGZvciBhIHF1ZXJ5IHdpdGggbm8gY2FjaGVkIGRhdGEuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0UXVlcnlEYXRhfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBkYXRhID0gcXVlcnlDbGllbnQuZ2V0UXVlcmllc0RhdGEoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG5cdCogYGBgXG5cdCovXG5cdGdldFF1ZXJpZXNEYXRhKGZpbHRlcnMpIHtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLm1hcCgoeyBxdWVyeUtleSwgc3RhdGUgfSkgPT4ge1xuXHRcdFx0cmV0dXJuIFtxdWVyeUtleSwgc3RhdGUuZGF0YV07XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogU3luY2hyb25vdXMgd2F5IHRvIGltbWVkaWF0ZWx5IHVwZGF0ZSBhIHF1ZXJ5J3MgY2FjaGVkIGRhdGEuIElmIHRoZSB1cGRhdGVyIChvciB0aGUgdmFsdWVcblx0KiBwYXNzZWQpIHJlc29sdmVzIHRvIGB1bmRlZmluZWRgLCB0aGUgY2FjaGUgaXMgbGVmdCB1bnRvdWNoZWQgYW5kIG5vIHF1ZXJ5IGlzIGNyZWF0ZWQ7XG5cdCogb3RoZXJ3aXNlLCBpZiB0aGUgcXVlcnkgZG9lcyBub3QgZXhpc3QgeWV0LCBpdCB3aWxsIGJlIGNyZWF0ZWQuIFRvIHVwZGF0ZSBtdWx0aXBsZSBxdWVyaWVzXG5cdCogYXQgb25jZSBieSBwYXJ0aWFsbHkgbWF0Y2hpbmcgcXVlcnkga2V5cywgdXNlIHtAbGluayBRdWVyeUNsaWVudCNzZXRRdWVyaWVzRGF0YX0gaW5zdGVhZC5cblx0KlxuXHQqIFVwZGF0ZXMgbXVzdCBiZSBwZXJmb3JtZWQgaW1tdXRhYmx5OiBkbyBub3QgbXV0YXRlIGBvbGREYXRhYCwgb3IgZGF0YSBwcmV2aW91c2x5IHJldHJpZXZlZFxuXHQqIHZpYSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0UXVlcnlEYXRhfSwgaW4gcGxhY2UuXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSB0byBzZXQgZGF0YSBmb3IuXG5cdCogQHBhcmFtIHVwZGF0ZXIgLSBFaXRoZXIgdGhlIG5ldyBkYXRhLCBvciBhIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgdGhlIGN1cnJlbnQgZGF0YSAod2hpY2hcblx0KiBtYXkgYmUgYHVuZGVmaW5lZGApIGFuZCByZXR1cm5zIHRoZSBuZXcgZGF0YS5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFNldCBgdXBkYXRlZEF0YCB0byBvdmVycmlkZSB0aGUgdGltZXN0YW1wIHRoZSB3cml0dGVuIGRhdGEgaXMgcmVjb3JkZWQgd2l0aC5cblx0KiBAcmV0dXJucyBUaGUgZGF0YSB0aGF0IHdhcyB3cml0dGVuLCBvciBgdW5kZWZpbmVkYCBpZiB0aGUgdXBkYXRlciByZXR1cm5lZCBgdW5kZWZpbmVkYCDigJQgaW4gdGhhdCBjYXNlXG5cdCogdGhlIHdyaXRlIGlzIHNraXBwZWQgYW5kIHRoZSBjYWNoZSBpcyBsZWZ0IHVuY2hhbmdlZC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKFsncG9zdHMnXSwgbmV3UG9zdHMpXG5cdCpcblx0KiAvLyBPciwgdXNpbmcgYW4gdXBkYXRlciBmdW5jdGlvbiB0aGF0IHJlY2VpdmVzIHRoZSBjdXJyZW50IGRhdGE6XG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKFsncG9zdHMnXSwgKG9sZFBvc3RzKSA9PiBbLi4ub2xkUG9zdHMsIG5ld1Bvc3RdKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRRdWVyeURhdGEocXVlcnlLZXksIHVwZGF0ZXIsIG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKHsgcXVlcnlLZXkgfSk7XG5cdFx0Y29uc3QgcHJldkRhdGEgPSB0aGlzLiNxdWVyeUNhY2hlLmdldChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCk/LnN0YXRlLmRhdGE7XG5cdFx0Y29uc3QgZGF0YSA9IGZ1bmN0aW9uYWxVcGRhdGUodXBkYXRlciwgcHJldkRhdGEpO1xuXHRcdGlmIChkYXRhID09PSB2b2lkIDApIHJldHVybjtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKS5zZXREYXRhKGRhdGEsIHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRtYW51YWw6IHRydWVcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBTeW5jaHJvbm91cyB3YXkgdG8gaW1tZWRpYXRlbHkgdXBkYXRlIHRoZSBjYWNoZWQgZGF0YSBvZiBtdWx0aXBsZSBxdWVyaWVzIGF0IG9uY2UsIHVzaW5nXG5cdCogZmlsdGVycyBvciBwYXJ0aWFsIHF1ZXJ5IGtleSBtYXRjaGluZy4gT25seSBxdWVyaWVzIHRoYXQgYWxyZWFkeSBleGlzdCBhbmQgbWF0Y2ggdGhlIGdpdmVuXG5cdCogZmlsdGVycyBhcmUgdXBkYXRlZDsgbm8gbmV3IGNhY2hlIGVudHJpZXMgYXJlIGNyZWF0ZWQuIEludGVybmFsbHkgdGhpcyBjYWxsc1xuXHQqIHtAbGluayBRdWVyeUNsaWVudCNzZXRRdWVyeURhdGF9IGZvciBlYWNoIG1hdGNoaW5nIHF1ZXJ5LlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdGhhdCBzZWxlY3Qgd2hpY2ggZXhpc3RpbmcgcXVlcmllcyB0byB1cGRhdGUuXG5cdCogQHBhcmFtIHVwZGF0ZXIgLSBFaXRoZXIgdGhlIG5ldyBkYXRhLCBvciBhIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgZWFjaCBtYXRjaGVkIHF1ZXJ5J3MgY3VycmVudFxuXHQqIGRhdGEgKHdoaWNoIG1heSBiZSBgdW5kZWZpbmVkYCkgYW5kIHJldHVybnMgdGhlIG5ldyBkYXRhLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gU2V0IGB1cGRhdGVkQXRgIHRvIG92ZXJyaWRlIHRoZSB0aW1lc3RhbXAgdGhlIHdyaXR0ZW4gZGF0YSBpcyByZWNvcmRlZCB3aXRoLlxuXHQqIEByZXR1cm5zIE9uZSBgW3F1ZXJ5S2V5LCBkYXRhXWAgdHVwbGUgcGVyIG1hdGNoZWQgcXVlcnksIGluIHRoZSBzYW1lIHNoYXBlIGFuZCB3aXRoIHRoZSBzYW1lXG5cdCogYHVuZGVmaW5lZGAgY2FzZSBhcyB7QGxpbmsgUXVlcnlDbGllbnQjc2V0UXVlcnlEYXRhfS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcmllc0RhdGEoeyBxdWVyeUtleTogWydwb3N0cyddIH0sIChvbGRQb3N0cykgPT5cblx0KiAgIG9sZFBvc3RzID8gb2xkUG9zdHMuZmlsdGVyKChwb3N0KSA9PiBwb3N0LmlkICE9PSBkZWxldGVkSWQpIDogb2xkUG9zdHMsXG5cdCogKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRRdWVyaWVzRGF0YShmaWx0ZXJzLCB1cGRhdGVyLCBvcHRpb25zKSB7XG5cdFx0cmV0dXJuIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLm1hcCgoeyBxdWVyeUtleSB9KSA9PiBbcXVlcnlLZXksIHRoaXMuc2V0UXVlcnlEYXRhKHF1ZXJ5S2V5LCB1cGRhdGVyLCBvcHRpb25zKV0pKTtcblx0fVxuXHQvKipcblx0KiBJbXBlcmF0aXZlIChub24tcmVhY3RpdmUpIHdheSB0byByZXRyaWV2ZSBhbiBleGlzdGluZyBxdWVyeSdzIHN0YXRlLiBJZiB0aGUgcXVlcnkgZG9lcyBub3Rcblx0KiBleGlzdCwgYHVuZGVmaW5lZGAgaXMgcmV0dXJuZWQuXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSBvZiB0aGUgcXVlcnkgdG8gcmVhZC5cblx0KiBAcmV0dXJucyBUaGUgcXVlcnkncyBzdGF0ZSwgb3IgYHVuZGVmaW5lZGAgaWYgbm8gcXVlcnkgd2l0aCB0aGlzIGtleSBleGlzdHMuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHN0YXRlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlTdGF0ZShbJ3Bvc3RzJ10pXG5cdCogY29uc29sZS5sb2coc3RhdGU/LmRhdGFVcGRhdGVkQXQpXG5cdCogYGBgXG5cdCovXG5cdGdldFF1ZXJ5U3RhdGUocXVlcnlLZXkpIHtcblx0XHRjb25zdCBvcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKHsgcXVlcnlLZXkgfSk7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJ5Q2FjaGUuZ2V0KG9wdGlvbnMucXVlcnlIYXNoKT8uc3RhdGU7XG5cdH1cblx0LyoqXG5cdCogUmVtb3ZlcyBxdWVyaWVzIGZyb20gdGhlIGNhY2hlIHRoYXQgbWF0Y2ggdGhlIGdpdmVuIGZpbHRlcnMuIFVubGlrZVxuXHQqIHtAbGluayBRdWVyeUNsaWVudCNpbnZhbGlkYXRlUXVlcmllc30gb3Ige0BsaW5rIFF1ZXJ5Q2xpZW50I3JlZmV0Y2hRdWVyaWVzfSwgdGhpcyByZW1vdmVzXG5cdCogbWF0Y2hpbmcgcXVlcmllcyBmcm9tIHRoZSBjYWNoZSBpbnN0ZWFkIG9mIHJlZmV0Y2hpbmcgdGhlbS4gV2l0aG91dCBmaWx0ZXJzLCBldmVyeSBxdWVyeSBpblxuXHQqIHRoZSBjYWNoZSBpcyByZW1vdmVkLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdGhhdCBzZWxlY3Qgd2hpY2ggcXVlcmllcyB0byByZW1vdmUuIFdpdGhvdXQgZmlsdGVycywgZXZlcnkgcXVlcnlcblx0KiBpcyByZW1vdmVkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeUNsaWVudC5yZW1vdmVRdWVyaWVzKHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgZXhhY3Q6IHRydWUgfSlcblx0KiBgYGBcblx0Ki9cblx0cmVtb3ZlUXVlcmllcyhmaWx0ZXJzKSB7XG5cdFx0Y29uc3QgcXVlcnlDYWNoZSA9IHRoaXMuI3F1ZXJ5Q2FjaGU7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnlDYWNoZS5yZW1vdmUocXVlcnkpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmVzZXRzIHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMgYmFjayB0byB0aGVpciBpbml0aWFsIHN0YXRlIChlLmcuIGFueVxuXHQqIGBpbml0aWFsRGF0YWApLCBub3RpZnlpbmcgc3Vic2NyaWJlcnMgcmF0aGVyIHRoYW4gcmVtb3ZpbmcgdGhlbS4gQWN0aXZlIHF1ZXJpZXMgYW1vbmcgdGhlXG5cdCogbWF0Y2hlZCBzZXQgYXJlIHRoZW4gcmVmZXRjaGVkLCBhbmQgdGhlIHJldHVybmVkIHByb21pc2UgcmVzb2x2ZXMgb25jZSB0aGF0IHJlZmV0Y2ggc2V0dGxlcy5cblx0KiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRoYXQgc2VsZWN0IHdoaWNoIHF1ZXJpZXMgdG8gcmVzZXQuIFdpdGhvdXQgZmlsdGVycywgZXZlcnkgcXVlcnlcblx0KiBpcyByZXNldC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFBhc3NlZCB0byB0aGUgcmVmZXRjaCBvZiB0aGUgYWN0aXZlIG1hdGNoZWQgcXVlcmllcywgZS5nLiBgY2FuY2VsUmVmZXRjaGAgYW5kXG5cdCogYHRocm93T25FcnJvcmAuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgcmVmZXRjaCBvZiB0aGUgYWN0aXZlIG1hdGNoZWQgcXVlcmllcyBzZXR0bGVzLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5yZXNldFF1ZXJpZXMoeyBxdWVyeUtleTogWydwb3N0cyddLCBleGFjdDogdHJ1ZSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRyZXNldFF1ZXJpZXMoZmlsdGVycywgb3B0aW9ucykge1xuXHRcdGNvbnN0IHF1ZXJ5Q2FjaGUgPSB0aGlzLiNxdWVyeUNhY2hlO1xuXHRcdHJldHVybiBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdGNvbnN0IG1hdGNoZWQgPSBxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycyk7XG5cdFx0XHRjb25zdCBxdWVyaWVzVG9SZWZldGNoID0gbmV3IFNldChtYXRjaGVkKTtcblx0XHRcdG1hdGNoZWQuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkucmVzZXQoKTtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIHRoaXMucmVmZXRjaFF1ZXJpZXMoe1xuXHRcdFx0XHR0eXBlOiBcImFjdGl2ZVwiLFxuXHRcdFx0XHRwcmVkaWNhdGU6IChxdWVyeSkgPT4gcXVlcmllc1RvUmVmZXRjaC5oYXMocXVlcnkpXG5cdFx0XHR9LCBvcHRpb25zKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBDYW5jZWxzIG91dGdvaW5nIGZldGNoZXMgZm9yIHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMuIE1vc3QgdXNlZnVsIHdoZW4gcGVyZm9ybWluZ1xuXHQqIG9wdGltaXN0aWMgdXBkYXRlcywgc2luY2UgYW55IG91dGdvaW5nIHJlZmV0Y2ggdGhhdCByZXNvbHZlcyBhZnRlcndhcmRzIHdvdWxkIG90aGVyd2lzZVxuXHQqIG92ZXJ3cml0ZSB0aGUgb3B0aW1pc3RpYyB1cGRhdGUuIEJ5IGRlZmF1bHQgKGByZXZlcnQ6IHRydWVgKSwgYSBjYW5jZWxsZWQgcXVlcnkncyBkYXRhIGlzXG5cdCogcmV2ZXJ0ZWQgdG8gaXRzIHN0YXRlIGJlZm9yZSB0aGUgb3V0Z29pbmcgZmV0Y2ggc3RhcnRlZC5cblx0KlxuXHQqIFRoZSByZXR1cm5lZCBwcm9taXNlIG5ldmVyIHJlamVjdHMsIGV2ZW4gaWYgaW5kaXZpZHVhbCBjYW5jZWxsYXRpb25zIGZhaWwuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0aGF0IHNlbGVjdCB3aGljaCBxdWVyaWVzIHRvIGNhbmNlbC4gV2l0aG91dCBmaWx0ZXJzLCBldmVyeSBxdWVyeVxuXHQqIGlzIGNhbmNlbGxlZC5cblx0KiBAcGFyYW0gY2FuY2VsT3B0aW9ucyAtIFBhc3NlZCB0byBlYWNoIG1hdGNoZWQgcXVlcnkncyBjYW5jZWxsYXRpb24uIGByZXZlcnRgIGRlZmF1bHRzIHRvXG5cdCogYHRydWVgLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIG9uY2UgZXZlcnkgY2FuY2VsbGF0aW9uIGhhcyBzZXR0bGVkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5jYW5jZWxRdWVyaWVzKHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgZXhhY3Q6IHRydWUgfSlcblx0KiBgYGBcblx0Ki9cblx0Y2FuY2VsUXVlcmllcyhmaWx0ZXJzLCBjYW5jZWxPcHRpb25zID0ge30pIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRDYW5jZWxPcHRpb25zID0ge1xuXHRcdFx0cmV2ZXJ0OiB0cnVlLFxuXHRcdFx0Li4uY2FuY2VsT3B0aW9uc1xuXHRcdH07XG5cdFx0Y29uc3QgcHJvbWlzZXMgPSBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5tYXAoKHF1ZXJ5KSA9PiBxdWVyeS5jYW5jZWwoZGVmYXVsdGVkQ2FuY2VsT3B0aW9ucykpKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5hbGwocHJvbWlzZXMpLnRoZW4obm9vcCkuY2F0Y2gobm9vcCk7XG5cdH1cblx0LyoqXG5cdCogTWFya3MgcXVlcmllcyBtYXRjaGluZyB0aGUgZ2l2ZW4gZmlsdGVycyBhcyBpbnZhbGlkYXRlZC4gVW5saWtlXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I3JlbW92ZVF1ZXJpZXN9LCBpbnZhbGlkYXRlZCBxdWVyaWVzIHN0YXkgaW4gdGhlIGNhY2hlLlxuXHQqXG5cdCogVW5sZXNzIGBmaWx0ZXJzLnJlZmV0Y2hUeXBlYCBpcyBgJ25vbmUnYCwgbWF0Y2hpbmcgcXVlcmllcyBhcmUgdGhlbiByZWZldGNoZWQgdmlhXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I3JlZmV0Y2hRdWVyaWVzfSwgdXNpbmcgYGZpbHRlcnMucmVmZXRjaFR5cGVgIGlmIHNldCwgb3RoZXJ3aXNlXG5cdCogYGZpbHRlcnMudHlwZWAsIG90aGVyd2lzZSBgJ2FjdGl2ZSdgLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdGhhdCBzZWxlY3Qgd2hpY2ggcXVlcmllcyB0byBpbnZhbGlkYXRlLCBwbHVzIGByZWZldGNoVHlwZWAgdG9cblx0KiBjb250cm9sIHdoaWNoIG9mIHRoZW0gdG8gcmVmZXRjaCBhZnRlcndhcmRzLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5IGlzIGludmFsaWRhdGVkLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gUGFzc2VkIHRvIHtAbGluayBRdWVyeUNsaWVudCNyZWZldGNoUXVlcmllc30sIGUuZy4gYGNhbmNlbFJlZmV0Y2hgIGFuZFxuXHQqIGB0aHJvd09uRXJyb3JgLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIG9uY2UgdGhlIHJlZmV0Y2ggc2V0dGxlcywgb3IgaW1tZWRpYXRlbHkgaWYgYHJlZmV0Y2hUeXBlYCBpc1xuXHQqIGAnbm9uZSdgLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sIHJlZmV0Y2hUeXBlOiAnYWN0aXZlJyB9KVxuXHQqIGBgYFxuXHQqL1xuXHRpbnZhbGlkYXRlUXVlcmllcyhmaWx0ZXJzLCBvcHRpb25zID0ge30pIHtcblx0XHRyZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkuaW52YWxpZGF0ZSgpO1xuXHRcdFx0fSk7XG5cdFx0XHRpZiAoZmlsdGVycz8ucmVmZXRjaFR5cGUgPT09IFwibm9uZVwiKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0XHRyZXR1cm4gdGhpcy5yZWZldGNoUXVlcmllcyh7XG5cdFx0XHRcdC4uLmZpbHRlcnMsXG5cdFx0XHRcdHR5cGU6IGZpbHRlcnM/LnJlZmV0Y2hUeXBlID8/IGZpbHRlcnM/LnR5cGUgPz8gXCJhY3RpdmVcIlxuXHRcdFx0fSwgb3B0aW9ucyk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmVmZXRjaGVzIHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMsIHJlZ2FyZGxlc3Mgb2Ygd2hldGhlciB0aGV5IGFyZSBzdGFsZS4gV2l0aG91dFxuXHQqIGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5IGluIHRoZSBjYWNoZSBpcyByZWZldGNoZWQuIFF1ZXJpZXMgdGhhdCBhcmUgZGlzYWJsZWQsIG9yIHN0YXRpYyAob25seVxuXHQqIGhhdmUgb2JzZXJ2ZXJzIHdpdGggYSBzdGF0aWMgYHN0YWxlVGltZWApLCBhcmUgbmV2ZXIgcmVmZXRjaGVkLlxuXHQqXG5cdCogQnkgZGVmYXVsdCAoYGNhbmNlbFJlZmV0Y2g6IHRydWVgKSwgYSBjdXJyZW50bHkgcnVubmluZyBmZXRjaCBpcyBjYW5jZWxsZWQgYmVmb3JlIHRoZSBuZXdcblx0KiBvbmUgc3RhcnRzLiBUaGUgcmV0dXJuZWQgcHJvbWlzZSBkb2VzIG5vdCByZWplY3Qgb24gaW5kaXZpZHVhbCBxdWVyeSBmYWlsdXJlcyB1bmxlc3Ncblx0KiBgdGhyb3dPbkVycm9yYCBpcyBgdHJ1ZWAuXG5cdCpcblx0KiBJbml0aWFsbHkgcGF1c2VkIGZldGNoZXMgZG8gbm90IGRlbGF5IHRoZSByZXR1cm5lZCBwcm9taXNlLiBUaGVpciBsYXRlciBlcnJvcnMgYXJlIGhhbmRsZWRcblx0KiBldmVuIHdoZW4gYHRocm93T25FcnJvcmAgaXMgYHRydWVgLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdGhhdCBzZWxlY3Qgd2hpY2ggcXVlcmllcyB0byByZWZldGNoLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5XG5cdCogaW4gdGhlIGNhY2hlIGlzIGluY2x1ZGVkLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gU2V0IGBjYW5jZWxSZWZldGNoYCB0byBgZmFsc2VgIHRvIGtlZXAgYSBydW5uaW5nIGZldGNoIGluc3RlYWQgb2YgY2FuY2VsbGluZ1xuXHQqIGl0LCBhbmQgYHRocm93T25FcnJvcmAgdG8gYHRydWVgIHRvIHJlamVjdCB3aGVuIGEgcmVmZXRjaCB0aGF0IHdhcyBub3QgaW5pdGlhbGx5IHBhdXNlZCBmYWlscy5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIGFsbCBtYXRjaGluZyByZWZldGNoZXMgdGhhdCB3ZXJlIG5vdCBpbml0aWFsbHkgcGF1c2VkXG5cdCogaGF2ZSBzZXR0bGVkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiAvLyByZWZldGNoIGFsbCBhY3RpdmUgcXVlcmllcyBwYXJ0aWFsbHkgbWF0Y2hpbmcgYSBxdWVyeSBrZXk6XG5cdCogYXdhaXQgcXVlcnlDbGllbnQucmVmZXRjaFF1ZXJpZXMoeyBxdWVyeUtleTogWydwb3N0cyddLCB0eXBlOiAnYWN0aXZlJyB9KVxuXHQqIGBgYFxuXHQqL1xuXHRyZWZldGNoUXVlcmllcyhmaWx0ZXJzLCBvcHRpb25zID0ge30pIHtcblx0XHRjb25zdCBmZXRjaE9wdGlvbnMgPSB7XG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0Y2FuY2VsUmVmZXRjaDogb3B0aW9ucy5jYW5jZWxSZWZldGNoID8/IHRydWVcblx0XHR9O1xuXHRcdGNvbnN0IHByb21pc2VzID0gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykuZmlsdGVyKChxdWVyeSkgPT4gIXF1ZXJ5LmlzRGlzYWJsZWQoKSAmJiAhcXVlcnkuaXNTdGF0aWMoKSkubWFwKChxdWVyeSkgPT4ge1xuXHRcdFx0bGV0IHByb21pc2UgPSBxdWVyeS5mZXRjaCh2b2lkIDAsIGZldGNoT3B0aW9ucyk7XG5cdFx0XHRjb25zdCBpc1BhdXNlZCA9IHF1ZXJ5LnN0YXRlLmZldGNoU3RhdHVzID09PSBcInBhdXNlZFwiO1xuXHRcdFx0aWYgKCFmZXRjaE9wdGlvbnMudGhyb3dPbkVycm9yIHx8IGlzUGF1c2VkKSBwcm9taXNlID0gcHJvbWlzZS5jYXRjaChub29wKTtcblx0XHRcdHJldHVybiBpc1BhdXNlZCA/IFByb21pc2UucmVzb2x2ZSgpIDogcHJvbWlzZTtcblx0XHR9KSk7XG5cdFx0cmV0dXJuIFByb21pc2UuYWxsKHByb21pc2VzKS50aGVuKG5vb3ApO1xuXHR9XG5cdC8qKlxuXHQqIEFzeW5jaHJvbm91cyBtZXRob2QgdG8gZmV0Y2ggYW5kIGNhY2hlIGEgcXVlcnksIHJlc29sdmluZyB3aXRoIHRoZSBkYXRhIG9yIHRocm93aW5nIHdpdGhcblx0KiB0aGUgZXJyb3IuXG5cdCpcblx0KiBJZiB0aGUgcXVlcnkgYWxyZWFkeSBleGlzdHMgaW4gdGhlIGNhY2hlIGFuZCBpdHMgZGF0YSBpcyBub3Qgc3RhbGUgKHBlciB0aGUgZ2l2ZW5cblx0KiBgc3RhbGVUaW1lYCksIHRoZSBjYWNoZWQgZGF0YSBpcyByZXR1cm5lZCB3aXRob3V0IGZldGNoaW5nLiBPdGhlcndpc2UsIHRoZSBxdWVyeSBpcyBmZXRjaGVkXG5cdCogYW5kIHRoZSBwcm9taXNlIHJlc29sdmVzIG9uY2UgdGhlIGZldGNoIHNldHRsZXMuIElmIGEgYHNlbGVjdGAgZnVuY3Rpb24gaXMgcHJvdmlkZWQsIGl0IGlzXG5cdCogYXBwbGllZCB0byB0aGUgZGF0YSBpbiBib3RoIGNhc2VzIChjYWNoZWQgb3IgZnJlc2hseSBmZXRjaGVkKSBiZWZvcmUgaXQgaXMgcmV0dXJuZWQuXG5cdCpcblx0KiBVbmxpa2UgYSByZWFjdGl2ZSBvYnNlcnZlciwgcmV0cmllcyBhcmUgZGlzYWJsZWQgYnkgZGVmYXVsdCBoZXJlIChgcmV0cnk6IGZhbHNlYCkgdW5sZXNzXG5cdCogZXhwbGljaXRseSBjb25maWd1cmVkLCBzaW5jZSB0aGVyZSBpcyBubyBjb21wb25lbnQgdG8gY2F0Y2ggYSB0aHJvd24gZXJyb3IgYW5kIHJldHJ5IHRocm91Z2hcblx0KiByZS1yZW5kZXIuXG5cdCpcblx0KiBUaGUgYWNjZXB0ZWQgb3B0aW9ucyBhcmUgYFF1ZXJ5T2JzZXJ2ZXJPcHRpb25zYCBtaW51cyB0aGUgZmllbGRzIHRoYXQgb25seSBtYWtlIHNlbnNlIGZvciBhXG5cdCogcmVhY3RpdmUgb2JzZXJ2ZXIg4oCUIGBlbmFibGVkYCwgYHJlZmV0Y2hJbnRlcnZhbGAsIGByZWZldGNoSW50ZXJ2YWxJbkJhY2tncm91bmRgLFxuXHQqIGByZWZldGNoT25XaW5kb3dGb2N1c2AsIGByZWZldGNoT25SZWNvbm5lY3RgLCBgcmVmZXRjaE9uTW91bnRgLCBgcmV0cnlPbk1vdW50YCxcblx0KiBgbm90aWZ5T25DaGFuZ2VQcm9wc2AsIGB0aHJvd09uRXJyb3JgLCBgc3VzcGVuc2VgLCBhbmQgYHBsYWNlaG9sZGVyRGF0YWAgYXJlIG5vdCBwYXJ0IG9mIHRoaXNcblx0KiBtZXRob2QncyBvcHRpb25zLlxuXHQqXG5cdCogVGhpcyBtZXRob2QgcmVwbGFjZXMgdGhlIGRlcHJlY2F0ZWQgYGZldGNoUXVlcnlgLCBhbmQg4oCUIGNvbWJpbmVkIHdpdGhcblx0KiBgeyBzdGFsZVRpbWU6ICdzdGF0aWMnIH1gIOKAlCB0aGUgZGVwcmVjYXRlZCBgZW5zdXJlUXVlcnlEYXRhYC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zLCBpbmNsdWRpbmcgdGhlIGBxdWVyeUtleWAgYW5kIHRoZSBgcXVlcnlGbmAgdXNlZCBpZiB0aGVcblx0KiBxdWVyeSBuZWVkcyB0byBmZXRjaC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB0byB0aGUgZGF0YSwgb3IgdG8gdGhlIHJlc3VsdCBvZiBgc2VsZWN0YCBpZiBwcm92aWRlZC4gSXRcblx0KiByZWplY3RzIHdpdGggdGhlIGVycm9yIGZyb20gdGhlIGZldGNoIG9yIGZyb20gYHNlbGVjdGAuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHRyeSB7XG5cdCogICBjb25zdCBkYXRhID0gYXdhaXQgcXVlcnlDbGllbnQucXVlcnkoeyBxdWVyeUtleSwgcXVlcnlGbiwgc3RhbGVUaW1lOiAxMDAwMCB9KVxuXHQqIH0gY2F0Y2ggKGVycm9yKSB7XG5cdCogICBjb25zb2xlLmxvZyhlcnJvcilcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGFzeW5jIHF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnJldHJ5ID09PSB2b2lkIDApIGRlZmF1bHRlZE9wdGlvbnMucmV0cnkgPSBmYWxzZTtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuYnVpbGQodGhpcywgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0Y29uc3QgcXVlcnlEYXRhID0gcXVlcnkuaXNTdGFsZUJ5VGltZShyZXNvbHZlUXVlcnlWYWx1ZShkZWZhdWx0ZWRPcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpKSA/IGF3YWl0IHF1ZXJ5LmZldGNoKGRlZmF1bHRlZE9wdGlvbnMpIDogcXVlcnkuc3RhdGUuZGF0YTtcblx0XHRjb25zdCBzZWxlY3QgPSBkZWZhdWx0ZWRPcHRpb25zLnNlbGVjdDtcblx0XHRpZiAoc2VsZWN0KSByZXR1cm4gc2VsZWN0KHF1ZXJ5RGF0YSk7XG5cdFx0cmV0dXJuIHF1ZXJ5RGF0YTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIGFuZCBjYWNoZXMgYSBxdWVyeSwgb3IgcmV0dXJucyBpdHMgY2FjaGVkIGRhdGEgaWYgaXQgaXNuJ3Qgc3RhbGUuIFVubGlrZSBpbiBvYnNlcnZlcnMsXG5cdCogdGhlIGZldGNoIGlzbid0IHJldHJpZWQgdW5sZXNzIGByZXRyeWAgaXMgc2V0LlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIHF1ZXJ5IG9wdGlvbnMsIGluY2x1ZGluZyB0aGUgYHF1ZXJ5S2V5YCBhbmQgdGhlIGBxdWVyeUZuYCB1c2VkIGlmIHRoZVxuXHQqIHF1ZXJ5IG5lZWRzIHRvIGZldGNoLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIHRoZSBjYWNoZWQgb3IgZmV0Y2hlZCBkYXRhLCBvciByZWplY3RzIHdpdGggdGhlIGZldGNoXG5cdCogZXJyb3IuXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LnF1ZXJ5KG9wdGlvbnMpIGluc3RlYWQuIFRoaXMgbWV0aG9kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmV4dCBtYWpvciB2ZXJzaW9uLlxuXHQqL1xuXHRmZXRjaFF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnJldHJ5ID09PSB2b2lkIDApIGRlZmF1bHRlZE9wdGlvbnMucmV0cnkgPSBmYWxzZTtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuYnVpbGQodGhpcywgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0cmV0dXJuIHF1ZXJ5LmlzU3RhbGVCeVRpbWUocmVzb2x2ZVF1ZXJ5VmFsdWUoZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSkgPyBxdWVyeS5mZXRjaChkZWZhdWx0ZWRPcHRpb25zKSA6IFByb21pc2UucmVzb2x2ZShxdWVyeS5zdGF0ZS5kYXRhKTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIGFuZCBjYWNoZXMgYSBxdWVyeSBsaWtlIHtAbGluayBRdWVyeUNsaWVudCNmZXRjaFF1ZXJ5fSwgYnV0IGlnbm9yZXMgdGhlIHJlc3VsdCBhbmQgYW55XG5cdCogZXJyb3IuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucywgaW5jbHVkaW5nIHRoZSBgcXVlcnlLZXlgIGFuZCB0aGUgYHF1ZXJ5Rm5gIHVzZWQgaWYgdGhlXG5cdCogcXVlcnkgbmVlZHMgdG8gZmV0Y2guXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgZmV0Y2ggc2V0dGxlcy4gSXQgbmV2ZXIgcmVqZWN0cy5cblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQucXVlcnkob3B0aW9ucykgaW5zdGVhZC4gWW91IGNhbiBzd2FsbG93IGVycm9ycyB3aXRoIGAuY2F0Y2gobm9vcClgLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0cHJlZmV0Y2hRdWVyeShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2hRdWVyeShvcHRpb25zKS50aGVuKG5vb3ApLmNhdGNoKG5vb3ApO1xuXHR9XG5cdC8qKlxuXHQqIEFzeW5jaHJvbm91cyBtZXRob2QgdG8gZmV0Y2ggYW5kIGNhY2hlIGFuIGluZmluaXRlIHF1ZXJ5LCByZXNvbHZpbmcgd2l0aCBhblxuXHQqIHtAbGluayBJbmZpbml0ZURhdGF9IG9iamVjdCBvciB0aHJvd2luZyB3aXRoIHRoZSBlcnJvci5cblx0KlxuXHQqIFJlcXVpcmVzIGBpbml0aWFsUGFnZVBhcmFtYCBhbmQgYGdldE5leHRQYWdlUGFyYW1gLiBVc2UgYHBhZ2VzYCB0byBzcGVjaWZ5IGhvdyBtYW55XG5cdCogcGFnZXMgdG8gZmV0Y2guIElmIHlvdSBvbWl0IGBwYWdlc2AsIHRoZSBjbGllbnQgZmV0Y2hlcyB1cCB0byB0aGUgbnVtYmVyIG9mIGNhY2hlZFxuXHQqIHBhZ2VzLCBvciBvbmUgcGFnZSBpZiB0aGUgY2FjaGUgaGFzIG5vIHBhZ2VzLlxuXHQqXG5cdCogVGhpcyBtZXRob2QgcmVwbGFjZXMgdGhlIGRlcHJlY2F0ZWQgYGZldGNoSW5maW5pdGVRdWVyeWAsIGFuZCDigJQgY29tYmluZWQgd2l0aFxuXHQqIGB7IHN0YWxlVGltZTogJ3N0YXRpYycgfWAg4oCUIHRoZSBkZXByZWNhdGVkIGBlbnN1cmVJbmZpbml0ZVF1ZXJ5RGF0YWAuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgdG8gZmV0Y2ggYW5kIHRoZSBvcHRpb25zIHRoYXQgY29udHJvbCB3aGljaCBwYWdlcyB0byBmZXRjaC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB0byB0aGUge0BsaW5rIEluZmluaXRlRGF0YX0sIG9yIHRvIHRoZSByZXN1bHQgb2YgYHNlbGVjdGAgaWZcblx0KiBwcm92aWRlZC4gSXQgcmVqZWN0cyB3aXRoIHRoZSBlcnJvciBmcm9tIHRoZSBmZXRjaCBvciBmcm9tIGBzZWxlY3RgLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiB0cnkge1xuXHQqICAgY29uc3QgZGF0YSA9IGF3YWl0IHF1ZXJ5Q2xpZW50LmluZmluaXRlUXVlcnkoe1xuXHQqICAgICBxdWVyeUtleSxcblx0KiAgICAgcXVlcnlGbixcblx0KiAgICAgaW5pdGlhbFBhZ2VQYXJhbTogMCxcblx0KiAgICAgZ2V0TmV4dFBhZ2VQYXJhbTogKGxhc3RQYWdlKSA9PiBsYXN0UGFnZS5uZXh0Q3Vyc29yLFxuXHQqICAgfSlcblx0KiAgIGNvbnNvbGUubG9nKGRhdGEucGFnZXMpXG5cdCogfSBjYXRjaCAoZXJyb3IpIHtcblx0KiAgIGNvbnNvbGUubG9nKGVycm9yKVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0aW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG5cdFx0b3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcblx0XHRyZXR1cm4gdGhpcy5xdWVyeShvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIGFuZCBjYWNoZXMgYW4gaW5maW5pdGUgcXVlcnksIG9yIHJldHVybnMgaXRzIGNhY2hlZCBkYXRhIGlmIGl0IGlzbid0IHN0YWxlLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMsIGluY2x1ZGluZyBgaW5pdGlhbFBhZ2VQYXJhbWAgYW5kIGBnZXROZXh0UGFnZVBhcmFtYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB0byB0aGUgY2FjaGVkIG9yIGZldGNoZWQge0BsaW5rIEluZmluaXRlRGF0YX0sIG9yIHJlamVjdHMgd2l0aFxuXHQqIHRoZSBmZXRjaCBlcnJvci5cblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeShvcHRpb25zKSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuXHRcdHJldHVybiB0aGlzLmZldGNoUXVlcnkob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyBhbmQgY2FjaGVzIGFuIGluZmluaXRlIHF1ZXJ5IGxpa2Uge0BsaW5rIFF1ZXJ5Q2xpZW50I2ZldGNoSW5maW5pdGVRdWVyeX0sIGJ1dCBpZ25vcmVzXG5cdCogdGhlIHJlc3VsdCBhbmQgYW55IGVycm9yLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMsIGluY2x1ZGluZyBgaW5pdGlhbFBhZ2VQYXJhbWAgYW5kIGBnZXROZXh0UGFnZVBhcmFtYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIHRoZSBmZXRjaCBzZXR0bGVzLiBJdCBuZXZlciByZWplY3RzLlxuXHQqIEBkZXByZWNhdGVkIFVzZSBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIGluc3RlYWQuIFlvdSBjYW4gc3dhbGxvdyBlcnJvcnMgd2l0aCBgLmNhdGNoKG5vb3ApYC4gVGhpcyBtZXRob2Qgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uXG5cdCovXG5cdHByZWZldGNoSW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpLnRoZW4obm9vcCkuY2F0Y2gobm9vcCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgY2FjaGVkIGRhdGEgb2YgYW4gaW5maW5pdGUgcXVlcnksIG9yIGZldGNoZXMgaXQgaWYgdGhlcmUgaXMgbm9uZS4gV2l0aFxuXHQqIGByZXZhbGlkYXRlSWZTdGFsZWAsIHN0YWxlIGNhY2hlZCBkYXRhIGlzIGFsc28gcmVmZXRjaGVkIGluIHRoZSBiYWNrZ3JvdW5kLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMsIGluY2x1ZGluZyBgaW5pdGlhbFBhZ2VQYXJhbWAgYW5kIGBnZXROZXh0UGFnZVBhcmFtYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB0byB0aGUgY2FjaGVkIHtAbGluayBJbmZpbml0ZURhdGF9LCBvciB0byB0aGUgZmV0Y2hlZCBkYXRhIGlmXG5cdCogbm90aGluZyB3YXMgY2FjaGVkIHlldC5cblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeSh7IC4uLm9wdGlvbnMsIHN0YWxlVGltZTogJ3N0YXRpYycgfSkgaW5zdGVhZC4gVGhpcyBtZXRob2Qgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uXG5cdCovXG5cdGVuc3VyZUluZmluaXRlUXVlcnlEYXRhKG9wdGlvbnMpIHtcblx0XHRvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuXHRcdHJldHVybiB0aGlzLmVuc3VyZVF1ZXJ5RGF0YShvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBSZXN1bWVzIG11dGF0aW9ucyB0aGF0IHdlcmUgcGF1c2VkIGJlY2F1c2UgdGhlcmUgd2FzIG5vIG5ldHdvcmsgY29ubmVjdGlvbi4gRG9lcyBub3RoaW5nXG5cdCogKHJlc29sdmluZyBpbW1lZGlhdGVseSkgaWYgdGhlIGNsaWVudCBpcyBjdXJyZW50bHkgb2ZmbGluZS5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIHRoZSByZXN1bWVkIG11dGF0aW9ucyBoYXZlIHNldHRsZWQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogYXdhaXQgcXVlcnlDbGllbnQucmVzdW1lUGF1c2VkTXV0YXRpb25zKClcblx0KiBgYGBcblx0Ki9cblx0cmVzdW1lUGF1c2VkTXV0YXRpb25zKCkge1xuXHRcdGlmIChvbmxpbmVNYW5hZ2VyLmlzT25saW5lKCkpIHJldHVybiB0aGlzLiNtdXRhdGlvbkNhY2hlLnJlc3VtZVBhdXNlZE11dGF0aW9ucygpO1xuXHRcdHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBxdWVyeSBjYWNoZSB0aGlzIGNsaWVudCBpcyBjb25uZWN0ZWQgdG8uXG5cdCogQHJldHVybnMgVGhlIHtAbGluayBRdWVyeUNhY2hlfSBpbnN0YW5jZS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcblx0KiBjb25zdCBxdWVyeUNhY2hlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlDYWNoZSgpXG5cdCogY29uc3QgcXVlcmllcyA9IHF1ZXJ5Q2FjaGUuZmluZEFsbCh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcblx0KiBgYGBcblx0Ki9cblx0Z2V0UXVlcnlDYWNoZSgpIHtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBtdXRhdGlvbiBjYWNoZSB0aGlzIGNsaWVudCBpcyBjb25uZWN0ZWQgdG8uXG5cdCogQHJldHVybnMgVGhlIHtAbGluayBNdXRhdGlvbkNhY2hlfSBpbnN0YW5jZS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcblx0KiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG5cdCogY29uc3QgbXV0YXRpb25zID0gbXV0YXRpb25DYWNoZS5maW5kQWxsKHsgc3RhdHVzOiAncGVuZGluZycgfSlcblx0KiBgYGBcblx0Ki9cblx0Z2V0TXV0YXRpb25DYWNoZSgpIHtcblx0XHRyZXR1cm4gdGhpcy4jbXV0YXRpb25DYWNoZTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBkZWZhdWx0IG9wdGlvbnMgdGhhdCB3ZXJlIHNldCB3aGVuIGNyZWF0aW5nIHRoZSBjbGllbnQsIG9yIHZpYVxuXHQqIHtAbGluayBRdWVyeUNsaWVudCNzZXREZWZhdWx0T3B0aW9uc30uXG5cdCogQHJldHVybnMgVGhlIGNsaWVudCdzIGN1cnJlbnQgZGVmYXVsdCBvcHRpb25zLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGNvbnN0IGRlZmF1bHRPcHRpb25zID0gcXVlcnlDbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXREZWZhdWx0T3B0aW9ucygpIHtcblx0XHRyZXR1cm4gdGhpcy4jZGVmYXVsdE9wdGlvbnM7XG5cdH1cblx0LyoqXG5cdCogRHluYW1pY2FsbHkgc2V0cyB0aGUgZGVmYXVsdCBvcHRpb25zIGZvciB0aGlzIGNsaWVudCwgb3ZlcndyaXRpbmcgYW55IHByZXZpb3VzbHkgZGVmaW5lZFxuXHQqIGRlZmF1bHQgb3B0aW9ucy5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBuZXcgZGVmYXVsdCBvcHRpb25zIGZvciBxdWVyaWVzIGFuZCBtdXRhdGlvbnMuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0RGVmYXVsdE9wdGlvbnN9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogcXVlcnlDbGllbnQuc2V0RGVmYXVsdE9wdGlvbnMoe1xuXHQqICAgcXVlcmllczoge1xuXHQqICAgICBzdGFsZVRpbWU6IEluZmluaXR5LFxuXHQqICAgfSxcblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXREZWZhdWx0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0dGhpcy4jZGVmYXVsdE9wdGlvbnMgPSBvcHRpb25zO1xuXHR9XG5cdC8qKlxuXHQqIFNldHMgZGVmYXVsdCBvcHRpb25zIGZvciBxdWVyaWVzIHdob3NlIHF1ZXJ5IGtleSBwYXJ0aWFsbHkgbWF0Y2hlcyB0aGUgZ2l2ZW4gYHF1ZXJ5S2V5YC5cblx0KlxuXHQqIElmIHNldmVyYWwgcmVnaXN0ZXJlZCBxdWVyeSBkZWZhdWx0cyBtYXRjaCBhIGdpdmVuIHF1ZXJ5IGtleSwgdGhleSBhcmUgbWVyZ2VkIHRvZ2V0aGVyIGluXG5cdCogcmVnaXN0cmF0aW9uIG9yZGVyIGJ5IHtAbGluayBRdWVyeUNsaWVudCNnZXRRdWVyeURlZmF1bHRzfSwgc28gcmVnaXN0ZXIgZGVmYXVsdHMgZnJvbSB0aGVcblx0KiBtb3N0IGdlbmVyaWMga2V5IHRvIHRoZSBsZWFzdCBnZW5lcmljIG9uZSDigJQgbW9yZSBzcGVjaWZpYyBkZWZhdWx0cyBzaG91bGQgYmUgcmVnaXN0ZXJlZFxuXHQqIGFmdGVyIG1vcmUgZ2VuZXJpYyBvbmVzIHNvIHRoZXkgdGFrZSBwcmVjZWRlbmNlLlxuXHQqIEBwYXJhbSBxdWVyeUtleSAtIFRoZSBxdWVyeSBrZXkgdGhhdCBxdWVyeSBrZXlzIGFyZSBwYXJ0aWFsbHkgbWF0Y2hlZCBhZ2FpbnN0LlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGRlZmF1bHQgb3B0aW9ucyBhcHBsaWVkIHRvIG1hdGNoaW5nIHF1ZXJpZXMuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGVmYXVsdHMoWydwb3N0cyddLCB7IHF1ZXJ5Rm46IGZldGNoUG9zdHMgfSlcblx0KlxuXHQqIGF3YWl0IHF1ZXJ5Q2xpZW50LnF1ZXJ5KHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRRdWVyeURlZmF1bHRzKHF1ZXJ5S2V5LCBvcHRpb25zKSB7XG5cdFx0dGhpcy4jcXVlcnlEZWZhdWx0cy5zZXQoaGFzaEtleShxdWVyeUtleSksIHtcblx0XHRcdHF1ZXJ5S2V5LFxuXHRcdFx0ZGVmYXVsdE9wdGlvbnM6IG9wdGlvbnNcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBkZWZhdWx0IG9wdGlvbnMgcmVnaXN0ZXJlZCBmb3IgcXVlcmllcyB3aG9zZSBxdWVyeSBrZXkgcGFydGlhbGx5IG1hdGNoZXMgdGhlXG5cdCogZ2l2ZW4gYHF1ZXJ5S2V5YCwgdmlhIHtAbGluayBRdWVyeUNsaWVudCNzZXRRdWVyeURlZmF1bHRzfS4gSWYgbXVsdGlwbGUgcmVnaXN0ZXJlZCBkZWZhdWx0c1xuXHQqIG1hdGNoLCB0aGV5IGFyZSBtZXJnZWQgdG9nZXRoZXIgaW4gcmVnaXN0cmF0aW9uIG9yZGVyLlxuXHQqIEBwYXJhbSBxdWVyeUtleSAtIFRoZSBxdWVyeSBrZXkgdG8gbG9vayB1cCByZWdpc3RlcmVkIGRlZmF1bHRzIGZvci5cblx0KiBAcmV0dXJucyBUaGUgbWVyZ2VkIGRlZmF1bHQgb3B0aW9ucyBvZiBldmVyeSByZWdpc3RyYXRpb24gdGhhdCBtYXRjaGVzLCBvciBhbiBlbXB0eSBvYmplY3QgaWZcblx0KiBub25lIG1hdGNoLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBkZWZhdWx0T3B0aW9ucyA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5RGVmYXVsdHMoWydwb3N0cyddKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRRdWVyeURlZmF1bHRzKHF1ZXJ5S2V5KSB7XG5cdFx0Y29uc3QgZGVmYXVsdHMgPSBbLi4udGhpcy4jcXVlcnlEZWZhdWx0cy52YWx1ZXMoKV07XG5cdFx0Y29uc3QgcmVzdWx0ID0ge307XG5cdFx0ZGVmYXVsdHMuZm9yRWFjaCgocXVlcnlEZWZhdWx0KSA9PiB7XG5cdFx0XHRpZiAocGFydGlhbE1hdGNoS2V5KHF1ZXJ5S2V5LCBxdWVyeURlZmF1bHQucXVlcnlLZXkpKSBPYmplY3QuYXNzaWduKHJlc3VsdCwgcXVlcnlEZWZhdWx0LmRlZmF1bHRPcHRpb25zKTtcblx0XHR9KTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFNldHMgZGVmYXVsdCBvcHRpb25zIGZvciBtdXRhdGlvbnMgd2hvc2UgbXV0YXRpb24ga2V5IHBhcnRpYWxseSBtYXRjaGVzIHRoZSBnaXZlblxuXHQqIGBtdXRhdGlvbktleWAuIEFzIHdpdGgge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldFF1ZXJ5RGVmYXVsdHN9LCB0aGUgb3JkZXIgb2YgcmVnaXN0cmF0aW9uXG5cdCogbWF0dGVycyB3aGVuIHNldmVyYWwgcmVnaXN0ZXJlZCBkZWZhdWx0cyBtYXRjaCB0aGUgc2FtZSBtdXRhdGlvbiBrZXkuXG5cdCogQHBhcmFtIG11dGF0aW9uS2V5IC0gVGhlIG11dGF0aW9uIGtleSB0aGF0IG11dGF0aW9uIGtleXMgYXJlIHBhcnRpYWxseSBtYXRjaGVkIGFnYWluc3QuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgZGVmYXVsdCBvcHRpb25zIGFwcGxpZWQgdG8gbWF0Y2hpbmcgbXV0YXRpb25zLlxuXHQqIEBzZWUge0BsaW5rIFF1ZXJ5Q2xpZW50I2dldE11dGF0aW9uRGVmYXVsdHN9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHF1ZXJ5Q2xpZW50LnNldE11dGF0aW9uRGVmYXVsdHMoWydhZGRQb3N0J10sIHsgbXV0YXRpb25GbjogYWRkUG9zdCB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRNdXRhdGlvbkRlZmF1bHRzKG11dGF0aW9uS2V5LCBvcHRpb25zKSB7XG5cdFx0dGhpcy4jbXV0YXRpb25EZWZhdWx0cy5zZXQoaGFzaEtleShtdXRhdGlvbktleSksIHtcblx0XHRcdG11dGF0aW9uS2V5LFxuXHRcdFx0ZGVmYXVsdE9wdGlvbnM6IG9wdGlvbnNcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBkZWZhdWx0IG9wdGlvbnMgcmVnaXN0ZXJlZCBmb3IgbXV0YXRpb25zIHdob3NlIG11dGF0aW9uIGtleSBwYXJ0aWFsbHkgbWF0Y2hlc1xuXHQqIHRoZSBnaXZlbiBgbXV0YXRpb25LZXlgLCB2aWEge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldE11dGF0aW9uRGVmYXVsdHN9LiBJZiBtdWx0aXBsZSByZWdpc3RlcmVkXG5cdCogZGVmYXVsdHMgbWF0Y2gsIHRoZXkgYXJlIG1lcmdlZCB0b2dldGhlciBpbiByZWdpc3RyYXRpb24gb3JkZXIuXG5cdCogQHBhcmFtIG11dGF0aW9uS2V5IC0gVGhlIG11dGF0aW9uIGtleSB0byBsb29rIHVwIHJlZ2lzdGVyZWQgZGVmYXVsdHMgZm9yLlxuXHQqIEByZXR1cm5zIFRoZSBtZXJnZWQgZGVmYXVsdCBvcHRpb25zIG9mIGV2ZXJ5IHJlZ2lzdHJhdGlvbiB0aGF0IG1hdGNoZXMsIG9yIGFuIGVtcHR5IG9iamVjdCBpZlxuXHQqIG5vbmUgbWF0Y2guXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IGRlZmF1bHRPcHRpb25zID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25EZWZhdWx0cyhbJ2FkZFBvc3QnXSlcblx0KiBgYGBcblx0Ki9cblx0Z2V0TXV0YXRpb25EZWZhdWx0cyhtdXRhdGlvbktleSkge1xuXHRcdGNvbnN0IGRlZmF1bHRzID0gWy4uLnRoaXMuI211dGF0aW9uRGVmYXVsdHMudmFsdWVzKCldO1xuXHRcdGNvbnN0IHJlc3VsdCA9IHt9O1xuXHRcdGRlZmF1bHRzLmZvckVhY2goKHF1ZXJ5RGVmYXVsdCkgPT4ge1xuXHRcdFx0aWYgKHBhcnRpYWxNYXRjaEtleShtdXRhdGlvbktleSwgcXVlcnlEZWZhdWx0Lm11dGF0aW9uS2V5KSkgT2JqZWN0LmFzc2lnbihyZXN1bHQsIHF1ZXJ5RGVmYXVsdC5kZWZhdWx0T3B0aW9ucyk7XG5cdFx0fSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxuXHQvKipcblx0KiBDYWxsZWQgYnkgZnJhbWV3b3JrIGFkYXB0ZXJzIChlLmcuIGluc2lkZSBgdXNlUXVlcnlgKSB0byByZXNvbHZlIHRoZSBvcHRpb25zIHBhc3NlZCBieSB0aGVcblx0KiBjYWxsZXIgaW50byB0aGVpciBmaW5hbCwgZGVmYXVsdGVkIGZvcm06IG1lcmdpbmcgdGhlIGNsaWVudCdzIG93biBgZGVmYXVsdE9wdGlvbnMucXVlcmllc2AsXG5cdCogdGhlbiBgcXVlcnlDbGllbnQuc2V0UXVlcnlEZWZhdWx0c2AgZm9yIHRoZSBnaXZlbiBgcXVlcnlLZXlgLCB0aGVuIHRoZSBjYWxsZXIncyBvcHRpb25zIG9uXG5cdCogdG9wLiBBIG5vLW9wIGlmIHRoZSBvcHRpb25zIGFyZSBhbHJlYWR5IGRlZmF1bHRlZCAoYF9kZWZhdWx0ZWQ6IHRydWVgKS5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zIHBhc3NlZCBieSB0aGUgY2FsbGVyLlxuXHQqIEByZXR1cm5zIFRoZSBkZWZhdWx0ZWQgb3B0aW9ucywgd2l0aCBgcXVlcnlIYXNoYCBhbmQgZGVwZW5kZW50IGRlZmF1bHRzIChlLmcuXG5cdCogYHJlZmV0Y2hPblJlY29ubmVjdGApIGZpbGxlZCBpbi5cblx0Ki9cblx0ZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0aWYgKG9wdGlvbnMuX2RlZmF1bHRlZCkgcmV0dXJuIG9wdGlvbnM7XG5cdFx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHtcblx0XHRcdC4uLnRoaXMuI2RlZmF1bHRPcHRpb25zLnF1ZXJpZXMsXG5cdFx0XHQuLi50aGlzLmdldFF1ZXJ5RGVmYXVsdHMob3B0aW9ucy5xdWVyeUtleSksXG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0X2RlZmF1bHRlZDogdHJ1ZVxuXHRcdH07XG5cdFx0aWYgKCFkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCkgZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2ggPSBoYXNoUXVlcnlLZXlCeU9wdGlvbnMoZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUtleSwgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0aWYgKGRlZmF1bHRlZE9wdGlvbnMucmVmZXRjaE9uUmVjb25uZWN0ID09PSB2b2lkIDApIGRlZmF1bHRlZE9wdGlvbnMucmVmZXRjaE9uUmVjb25uZWN0ID0gZGVmYXVsdGVkT3B0aW9ucy5uZXR3b3JrTW9kZSAhPT0gXCJhbHdheXNcIjtcblx0XHRpZiAoZGVmYXVsdGVkT3B0aW9ucy50aHJvd09uRXJyb3IgPT09IHZvaWQgMCkgZGVmYXVsdGVkT3B0aW9ucy50aHJvd09uRXJyb3IgPSAhIWRlZmF1bHRlZE9wdGlvbnMuc3VzcGVuc2U7XG5cdFx0aWYgKCFkZWZhdWx0ZWRPcHRpb25zLm5ldHdvcmtNb2RlICYmIGRlZmF1bHRlZE9wdGlvbnMucGVyc2lzdGVyKSBkZWZhdWx0ZWRPcHRpb25zLm5ldHdvcmtNb2RlID0gXCJvZmZsaW5lRmlyc3RcIjtcblx0XHRpZiAoZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4pIGRlZmF1bHRlZE9wdGlvbnMuZW5hYmxlZCA9IGZhbHNlO1xuXHRcdHJldHVybiBkZWZhdWx0ZWRPcHRpb25zO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBtdXRhdGlvbiBjb3VudGVycGFydCBvZiB7QGxpbmsgUXVlcnlDbGllbnQjZGVmYXVsdFF1ZXJ5T3B0aW9uc30uIENhbGxlZCBieSBmcmFtZXdvcmtcblx0KiBhZGFwdGVycyAoZS5nLiBpbnNpZGUgYHVzZU11dGF0aW9uYCkgdG8gbWVyZ2UgdGhlIGNsaWVudCdzIGBkZWZhdWx0T3B0aW9ucy5tdXRhdGlvbnNgLCB0aGVuXG5cdCogYHF1ZXJ5Q2xpZW50LnNldE11dGF0aW9uRGVmYXVsdHNgIGZvciB0aGUgZ2l2ZW4gYG11dGF0aW9uS2V5YCwgdGhlbiB0aGUgY2FsbGVyJ3Mgb3B0aW9ucyBvblxuXHQqIHRvcC4gQSBuby1vcCBpZiB0aGUgb3B0aW9ucyBhcmUgYWxyZWFkeSBkZWZhdWx0ZWQgKGBfZGVmYXVsdGVkOiB0cnVlYCkuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgbXV0YXRpb24gb3B0aW9ucyBwYXNzZWQgYnkgdGhlIGNhbGxlci5cblx0KiBAcmV0dXJucyBUaGUgZGVmYXVsdGVkIG9wdGlvbnMuXG5cdCovXG5cdGRlZmF1bHRNdXRhdGlvbk9wdGlvbnMob3B0aW9ucykge1xuXHRcdGlmIChvcHRpb25zPy5fZGVmYXVsdGVkKSByZXR1cm4gb3B0aW9ucztcblx0XHRyZXR1cm4ge1xuXHRcdFx0Li4udGhpcy4jZGVmYXVsdE9wdGlvbnMubXV0YXRpb25zLFxuXHRcdFx0Li4ub3B0aW9ucz8ubXV0YXRpb25LZXkgJiYgdGhpcy5nZXRNdXRhdGlvbkRlZmF1bHRzKG9wdGlvbnMubXV0YXRpb25LZXkpLFxuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdF9kZWZhdWx0ZWQ6IHRydWVcblx0XHR9O1xuXHR9XG5cdC8qKlxuXHQqIENsZWFycyBib3RoIHRoZSBxdWVyeSBjYWNoZSBhbmQgdGhlIG11dGF0aW9uIGNhY2hlIHRoaXMgY2xpZW50IGlzIGNvbm5lY3RlZCB0by5cblx0KiBUaGlzIGNsZWFycyB0aGVpciBnYXJiYWdlIGNvbGxlY3Rpb24gdGltZXJzIGFuZCBjYW5jZWxzIGluLWZsaWdodCBxdWVyeSBmZXRjaGVzLlxuXHQqIFJ1bm5pbmcgbXV0YXRpb25zIGNvbnRpbnVlIHRvIGV4ZWN1dGUuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogcXVlcnlDbGllbnQuY2xlYXIoKVxuXHQqIGBgYFxuXHQqL1xuXHRjbGVhcigpIHtcblx0XHR0aGlzLiNxdWVyeUNhY2hlLmNsZWFyKCk7XG5cdFx0dGhpcy4jbXV0YXRpb25DYWNoZS5jbGVhcigpO1xuXHR9XG59O1xuZXhwb3J0IHsgUXVlcnlDbGllbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnlDbGllbnQuanMubWFwIiwiaW1wb3J0IHsgYWRkQ29uc3VtZUF3YXJlU2lnbmFsLCBmZXRjaFNpZ25hbCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyBzcmMvc3RyZWFtZWRRdWVyeS50c1xuLyoqXG4qIFRoaXMgaXMgYSBoZWxwZXIgZnVuY3Rpb24gdG8gY3JlYXRlIGEgcXVlcnkgZnVuY3Rpb24gdGhhdCBzdHJlYW1zIGRhdGEgZnJvbSBhbiBBc3luY0l0ZXJhYmxlLlxuKiBEYXRhIHdpbGwgYmUgYW4gQXJyYXkgb2YgYWxsIHRoZSBjaHVua3MgcmVjZWl2ZWQuXG4qIFRoZSBxdWVyeSB3aWxsIGJlIGluIGEgJ3BlbmRpbmcnIHN0YXRlIHVudGlsIHRoZSBmaXJzdCBjaHVuayBvZiBkYXRhIGlzIHJlY2VpdmVkLCBidXQgd2lsbCBnbyB0byAnc3VjY2VzcycgYWZ0ZXIgdGhhdC5cbiogVGhlIHF1ZXJ5IHdpbGwgc3RheSBpbiBmZXRjaFN0YXR1cyAnZmV0Y2hpbmcnIHVudGlsIHRoZSBzdHJlYW0gZW5kcy5cbiogRXhwbGljaXQgY2FuY2VsbGF0aW9uIHN0b3BzIGZ1cnRoZXIgY2FjaGUgdXBkYXRlcywgZXZlbiBpZiBgc3RyZWFtRm5gIGRvZXMgbm90IHJlYWQgYHNpZ25hbGAuXG4qIElmIGBzdHJlYW1GbmAgZG9lcyBub3QgcmVhZCBgc2lnbmFsYCwgdGhlIHN0cmVhbSBjb250aW51ZXMgYWZ0ZXIgdGhlIGxhc3Qgb2JzZXJ2ZXIgdW5zdWJzY3JpYmVzLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBgc3RyZWFtRm5gIHRoYXQgcmV0dXJucyBhbiBBc3luY0l0ZXJhYmxlIHRvIHN0cmVhbSBkYXRhIGZyb20sIGFuZCB0aGUgb3B0aW9uYWxcbiogYHJlZmV0Y2hNb2RlYCwgYHJlZHVjZXJgLCBhbmQgYGluaXRpYWxWYWx1ZWAgb3B0aW9ucy5cbiogQHJldHVybnMgQSBxdWVyeSBmdW5jdGlvbiB0byBwYXNzIGFzIGBxdWVyeUZuYC5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogYXdhaXQgcXVlcnlDbGllbnQucXVlcnkoe1xuKiAgIHF1ZXJ5S2V5OiBbJ2RhdGEnXSxcbiogICBxdWVyeUZuOiBzdHJlYW1lZFF1ZXJ5KHtcbiogICAgIHN0cmVhbUZuOiBmZXRjaERhdGFJbkNodW5rcyxcbiogICB9KSxcbiogfSlcbiogYGBgXG4qL1xuZnVuY3Rpb24gc3RyZWFtZWRRdWVyeSh7IHN0cmVhbUZuLCByZWZldGNoTW9kZSA9IFwicmVzZXRcIiwgcmVkdWNlciA9IChpdGVtcywgY2h1bmspID0+IFsuLi5pdGVtcywgY2h1bmtdLCBpbml0aWFsVmFsdWUgPSBbXSB9KSB7XG5cdHJldHVybiBhc3luYyAoY29udGV4dCkgPT4ge1xuXHRcdGNvbnN0IHNpZ25hbCA9IGNvbnRleHRbZmV0Y2hTaWduYWxdO1xuXHRcdGlmIChzaWduYWw/LmFib3J0ZWQpIHJldHVybiBpbml0aWFsVmFsdWU7XG5cdFx0Y29uc3QgcXVlcnkgPSBjb250ZXh0LmNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZmluZCh7XG5cdFx0XHRxdWVyeUtleTogY29udGV4dC5xdWVyeUtleSxcblx0XHRcdGV4YWN0OiB0cnVlXG5cdFx0fSk7XG5cdFx0Y29uc3QgaXNSZWZldGNoID0gISFxdWVyeSAmJiBxdWVyeS5pc0ZldGNoZWQoKTtcblx0XHRpZiAoaXNSZWZldGNoICYmIHJlZmV0Y2hNb2RlID09PSBcInJlc2V0XCIpIHF1ZXJ5LnNldFN0YXRlKHtcblx0XHRcdC4uLnF1ZXJ5LnJlc2V0U3RhdGUsXG5cdFx0XHRmZXRjaFN0YXR1czogXCJmZXRjaGluZ1wiXG5cdFx0fSk7XG5cdFx0bGV0IHJlc3VsdCA9IGluaXRpYWxWYWx1ZTtcblx0XHRsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG5cdFx0Y29uc3Qgc3RyZWFtRm5Db250ZXh0ID0gYWRkQ29uc3VtZUF3YXJlU2lnbmFsKHtcblx0XHRcdGNsaWVudDogY29udGV4dC5jbGllbnQsXG5cdFx0XHRtZXRhOiBjb250ZXh0Lm1ldGEsXG5cdFx0XHRxdWVyeUtleTogY29udGV4dC5xdWVyeUtleSxcblx0XHRcdHBhZ2VQYXJhbTogY29udGV4dC5wYWdlUGFyYW0sXG5cdFx0XHRkaXJlY3Rpb246IGNvbnRleHQuZGlyZWN0aW9uXG5cdFx0fSwgKCkgPT4gY29udGV4dC5zaWduYWwsICgpID0+IGNhbmNlbGxlZCA9IHRydWUsIHNpZ25hbCk7XG5cdFx0Y29uc3QgaXNTdHJlYW1JbmFjdGl2ZSA9ICgpID0+IGNhbmNlbGxlZCB8fCBzaWduYWw/LmFib3J0ZWQgPT09IHRydWU7XG5cdFx0Y29uc3Qgc3RyZWFtID0gYXdhaXQgc3RyZWFtRm4oc3RyZWFtRm5Db250ZXh0KTtcblx0XHRjb25zdCBpc1JlcGxhY2VSZWZldGNoID0gaXNSZWZldGNoICYmIHJlZmV0Y2hNb2RlID09PSBcInJlcGxhY2VcIjtcblx0XHRmb3IgYXdhaXQgKGNvbnN0IGNodW5rIG9mIHN0cmVhbSkge1xuXHRcdFx0aWYgKGlzU3RyZWFtSW5hY3RpdmUoKSkgYnJlYWs7XG5cdFx0XHRpZiAoaXNSZXBsYWNlUmVmZXRjaCkgcmVzdWx0ID0gcmVkdWNlcihyZXN1bHQsIGNodW5rKTtcblx0XHRcdGVsc2UgY29udGV4dC5jbGllbnQuc2V0UXVlcnlEYXRhKGNvbnRleHQucXVlcnlLZXksIChwcmV2KSA9PiByZWR1Y2VyKHByZXYgPT09IHZvaWQgMCA/IGluaXRpYWxWYWx1ZSA6IHByZXYsIGNodW5rKSk7XG5cdFx0fVxuXHRcdGlmIChpc1JlcGxhY2VSZWZldGNoICYmICFpc1N0cmVhbUluYWN0aXZlKCkpIGNvbnRleHQuY2xpZW50LnNldFF1ZXJ5RGF0YShjb250ZXh0LnF1ZXJ5S2V5LCByZXN1bHQpO1xuXHRcdGNvbnN0IGRhdGEgPSBjb250ZXh0LmNsaWVudC5nZXRRdWVyeURhdGEoY29udGV4dC5xdWVyeUtleSk7XG5cdFx0cmV0dXJuIGRhdGEgPT09IHZvaWQgMCA/IGluaXRpYWxWYWx1ZSA6IGRhdGE7XG5cdH07XG59XG5leHBvcnQgeyBzdHJlYW1lZFF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN0cmVhbWVkUXVlcnkuanMubWFwIiwiLy8gc3JjL3R5cGVzLnRzXG4vKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuY29uc3QgZGF0YVRhZ1N5bWJvbCA9IFN5bWJvbCgpO1xuY29uc3QgZGF0YVRhZ0Vycm9yU3ltYm9sID0gU3ltYm9sKCk7XG5jb25zdCB1bnNldE1hcmtlciA9IFN5bWJvbCgpO1xuZXhwb3J0IHsgZGF0YVRhZ0Vycm9yU3ltYm9sLCBkYXRhVGFnU3ltYm9sLCB1bnNldE1hcmtlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD10eXBlcy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHNob3VsZFRocm93RXJyb3IgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuLy8gc3JjL2Vycm9yQm91bmRhcnlVdGlscy50c1xuLyoqXG4qIFR1cm5zIG9mZiBgcmV0cnlPbk1vdW50YCBmb3IgYSBxdWVyeSB0aGF0IHRocm93cyBpdHMgZXJyb3JzICh3aXRoIGBzdXNwZW5zZWAgb3IgYHRocm93T25FcnJvcmApLFxuKiB1bmxlc3MgdGhlIGVycm9yIGJvdW5kYXJ5IGhhcyBiZWVuIHJlc2V0LCBzbyBhIHJlbW91bnQgZG9lc24ndCByZXRyeSB0aGUgZmFpbGVkIHF1ZXJ5IGJlZm9yZSB0aGVcbiogdXNlciByZXNldHMgdGhlIGJvdW5kYXJ5LiBNdXRhdGVzIHRoZSBvcHRpb25zLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBkZWZhdWx0ZWQgcXVlcnkgb3B0aW9ucyB0byBhZGp1c3QuXG4qIEBwYXJhbSBlcnJvclJlc2V0Qm91bmRhcnkgLSBUaGUgdmFsdWUgb2YgdGhlIG5lYXJlc3QgYFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5YC5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5LCB1c2VkIHRvIGV2YWx1YXRlIGEgYHRocm93T25FcnJvcmAgZnVuY3Rpb24gYWdhaW5zdCBpdHMgZXJyb3IuXG4qL1xuY29uc3QgZW5zdXJlUHJldmVudEVycm9yQm91bmRhcnlSZXRyeSA9IChvcHRpb25zLCBlcnJvclJlc2V0Qm91bmRhcnksIHF1ZXJ5KSA9PiB7XG5cdGNvbnN0IHRocm93T25FcnJvciA9IHF1ZXJ5Py5zdGF0ZS5zdGF0dXMgPT09IFwiZXJyb3JcIiAmJiB0eXBlb2Ygb3B0aW9ucy50aHJvd09uRXJyb3IgPT09IFwiZnVuY3Rpb25cIiA/IHNob3VsZFRocm93RXJyb3Iob3B0aW9ucy50aHJvd09uRXJyb3IsIFtxdWVyeS5zdGF0ZS5lcnJvciwgcXVlcnldKSA6IG9wdGlvbnMudGhyb3dPbkVycm9yO1xuXHRpZiAob3B0aW9ucy5zdXNwZW5zZSB8fCB0aHJvd09uRXJyb3IpIHtcblx0XHRpZiAoIWVycm9yUmVzZXRCb3VuZGFyeS5pc1Jlc2V0KCkpIG9wdGlvbnMucmV0cnlPbk1vdW50ID0gZmFsc2U7XG5cdH1cbn07XG4vKipcbiogQ2xlYXJzIHRoZSByZXNldCBzdGF0ZSBvZiB0aGUgZXJyb3IgYm91bmRhcnkgYWZ0ZXIgdGhlIGNvbXBvbmVudCBtb3VudHMsIHNvIGxhdGVyIGVycm9ycyBhcmVcbiogdGhyb3duIHRvIHRoZSBib3VuZGFyeSBhZ2Fpbi5cbiogQHBhcmFtIGVycm9yUmVzZXRCb3VuZGFyeSAtIFRoZSB2YWx1ZSBvZiB0aGUgbmVhcmVzdCBgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlgLlxuKi9cbmNvbnN0IHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5ID0gKGVycm9yUmVzZXRCb3VuZGFyeSkgPT4ge1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGVycm9yUmVzZXRCb3VuZGFyeS5jbGVhclJlc2V0KCk7XG5cdH0sIFtlcnJvclJlc2V0Qm91bmRhcnldKTtcbn07XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgdGhlIHF1ZXJ5IGVycm9yIHNob3VsZCBiZSB0aHJvd24gdG8gdGhlIG5lYXJlc3QgZXJyb3IgYm91bmRhcnk6IHRoZSBxdWVyeSBlcnJvcmVkXG4qIGFuZCBpc24ndCBmZXRjaGluZywgdGhlIGJvdW5kYXJ5IGhhc24ndCBiZWVuIHJlc2V0LCBhbmQgZWl0aGVyIGBzdXNwZW5zZWAgaXMgZW5hYmxlZCB3aXRoIG5vIGRhdGFcbiogb3IgYHRocm93T25FcnJvcmAgc2F5cyBzby5cbiogQHBhcmFtIHBhcmFtcyAtIFRoZSBvYnNlcnZlciBgcmVzdWx0YCwgdGhlIGBlcnJvclJlc2V0Qm91bmRhcnlgLCB0aGUgYHRocm93T25FcnJvcmAgb3B0aW9uLCB0aGVcbiogYHF1ZXJ5YCwgYW5kIHRoZSBgc3VzcGVuc2VgIG9wdGlvbi5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBlcnJvciBzaG91bGQgYmUgdGhyb3duLlxuKi9cbmNvbnN0IGdldEhhc0Vycm9yID0gKHsgcmVzdWx0LCBlcnJvclJlc2V0Qm91bmRhcnksIHRocm93T25FcnJvciwgcXVlcnksIHN1c3BlbnNlIH0pID0+IHtcblx0cmV0dXJuIHJlc3VsdC5pc0Vycm9yICYmICFlcnJvclJlc2V0Qm91bmRhcnkuaXNSZXNldCgpICYmICFyZXN1bHQuaXNGZXRjaGluZyAmJiBxdWVyeSAmJiAoc3VzcGVuc2UgJiYgcmVzdWx0LmRhdGEgPT09IHZvaWQgMCB8fCBzaG91bGRUaHJvd0Vycm9yKHRocm93T25FcnJvciwgW3Jlc3VsdC5lcnJvciwgcXVlcnldKSk7XG59O1xuZXhwb3J0IHsgZW5zdXJlUHJldmVudEVycm9yQm91bmRhcnlSZXRyeSwgZ2V0SGFzRXJyb3IsIHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVycm9yQm91bmRhcnlVdGlscy5qcy5tYXAiLCIvLyBzcmMvc3VzcGVuc2UudHNcbi8qKlxuKiBUaGUgZGVmYXVsdCBgdGhyb3dPbkVycm9yYCBvZiB0aGUgc3VzcGVuc2UgaG9va3M6IHRocm93cyB0aGUgZXJyb3IgdG8gdGhlIG5lYXJlc3QgZXJyb3IgYm91bmRhcnlcbiogb25seSBpZiB0aGUgcXVlcnkgaGFzIG5vIGRhdGEgdG8gc2hvdy5cbiogQHBhcmFtIF9lcnJvciAtIFRoZSBlcnJvciBvZiB0aGUgcXVlcnkuIFVudXNlZC5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRoYXQgZXJyb3JlZC5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBoYXMgbm8gZGF0YS5cbiovXG5jb25zdCBkZWZhdWx0VGhyb3dPbkVycm9yID0gKF9lcnJvciwgcXVlcnkpID0+IHF1ZXJ5LnN0YXRlLmRhdGEgPT09IHZvaWQgMDtcbi8qKlxuKiBSYWlzZXMgYHN0YWxlVGltZWAgYW5kIGEgbnVtZXJpYyBgZ2NUaW1lYCB0byBhdCBsZWFzdCAxMDAwbXMgd2hlbiBgc3VzcGVuc2VgIGlzIGVuYWJsZWQsIHNvIGFcbiogY29tcG9uZW50IHRoYXQgcmVtb3VudHMgYWZ0ZXIgc3VzcGVuZGluZyBkb2Vzbid0IHJlZmV0Y2ggcmlnaHQgYXdheSBvciBmaW5kIHRoZSBxdWVyeSBnYXJiYWdlXG4qIGNvbGxlY3RlZC4gQSBgJ3N0YXRpYydgIGBzdGFsZVRpbWVgIGlzIGtlcHQgYXMgaXMuIE11dGF0ZXMgdGhlIG9wdGlvbnMuXG4qIEBwYXJhbSBkZWZhdWx0ZWRPcHRpb25zIC0gVGhlIGRlZmF1bHRlZCBxdWVyeSBvcHRpb25zIHRvIGFkanVzdC5cbiovXG5jb25zdCBlbnN1cmVTdXNwZW5zZVRpbWVycyA9IChkZWZhdWx0ZWRPcHRpb25zKSA9PiB7XG5cdGlmIChkZWZhdWx0ZWRPcHRpb25zLnN1c3BlbnNlKSB7XG5cdFx0Y29uc3QgTUlOX1NVU1BFTlNFX1RJTUVfTVMgPSAxZTM7XG5cdFx0Y29uc3QgY2xhbXAgPSAodmFsdWUpID0+IHZhbHVlID09PSBcInN0YXRpY1wiID8gdmFsdWUgOiBNYXRoLm1heCh2YWx1ZSA/PyBNSU5fU1VTUEVOU0VfVElNRV9NUywgTUlOX1NVU1BFTlNFX1RJTUVfTVMpO1xuXHRcdGNvbnN0IG9yaWdpbmFsU3RhbGVUaW1lID0gZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWU7XG5cdFx0ZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUgPSB0eXBlb2Ygb3JpZ2luYWxTdGFsZVRpbWUgPT09IFwiZnVuY3Rpb25cIiA/ICguLi5hcmdzKSA9PiBjbGFtcChvcmlnaW5hbFN0YWxlVGltZSguLi5hcmdzKSkgOiBjbGFtcChvcmlnaW5hbFN0YWxlVGltZSk7XG5cdFx0aWYgKHR5cGVvZiBkZWZhdWx0ZWRPcHRpb25zLmdjVGltZSA9PT0gXCJudW1iZXJcIikgZGVmYXVsdGVkT3B0aW9ucy5nY1RpbWUgPSBNYXRoLm1heChkZWZhdWx0ZWRPcHRpb25zLmdjVGltZSwgTUlOX1NVU1BFTlNFX1RJTUVfTVMpO1xuXHR9XG59O1xuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgc2hvdWxkIHN1c3BlbmQ6IGBzdXNwZW5zZWAgaXMgZW5hYmxlZCBhbmQgdGhlIHJlc3VsdCBpcyBzdGlsbCBgcGVuZGluZ2AuXG4qIEBwYXJhbSBkZWZhdWx0ZWRPcHRpb25zIC0gVGhlIGRlZmF1bHRlZCBxdWVyeSBvcHRpb25zLCBpZiBhbnkuXG4qIEBwYXJhbSByZXN1bHQgLSBUaGUgY3VycmVudCByZXN1bHQgb2YgdGhlIG9ic2VydmVyLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIGNvbXBvbmVudCBzaG91bGQgc3VzcGVuZC5cbiovXG5jb25zdCBzaG91bGRTdXNwZW5kID0gKGRlZmF1bHRlZE9wdGlvbnMsIHJlc3VsdCkgPT4gZGVmYXVsdGVkT3B0aW9ucz8uc3VzcGVuc2UgJiYgcmVzdWx0LmlzUGVuZGluZztcbi8qKlxuKiBGZXRjaGVzIHRoZSBxdWVyeSBmb3IgYSBzdXNwZW5kaW5nIGNvbXBvbmVudCwgd2l0aG91dCBhZmZlY3RpbmcgdGhlIG9ic2VydmVyJ3Mgb3duIHJlc3VsdC4gSWZcbiogdGhlIGZldGNoIGZhaWxzLCB0aGUgcmVzZXQgc3RhdGUgb2YgdGhlIGVycm9yIGJvdW5kYXJ5IGlzIGNsZWFyZWQsIHNvIHRoZSBlcnJvciBpcyB0aHJvd24gdG8gaXQuXG4qIEBwYXJhbSBkZWZhdWx0ZWRPcHRpb25zIC0gVGhlIGRlZmF1bHRlZCBxdWVyeSBvcHRpb25zIHRvIGZldGNoIHdpdGguXG4qIEBwYXJhbSBvYnNlcnZlciAtIFRoZSBvYnNlcnZlciBvZiB0aGUgcXVlcnkuXG4qIEBwYXJhbSBlcnJvclJlc2V0Qm91bmRhcnkgLSBUaGUgdmFsdWUgb2YgdGhlIG5lYXJlc3QgYFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5YC5cbiogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgZmV0Y2ggc2V0dGxlcy4gSXQgbmV2ZXIgcmVqZWN0cy5cbiovXG5jb25zdCBmZXRjaE9wdGltaXN0aWMgPSAoZGVmYXVsdGVkT3B0aW9ucywgb2JzZXJ2ZXIsIGVycm9yUmVzZXRCb3VuZGFyeSkgPT4gb2JzZXJ2ZXIuZmV0Y2hPcHRpbWlzdGljKGRlZmF1bHRlZE9wdGlvbnMpLmNhdGNoKCgpID0+IHtcblx0ZXJyb3JSZXNldEJvdW5kYXJ5LmNsZWFyUmVzZXQoKTtcbn0pO1xuZXhwb3J0IHsgZGVmYXVsdFRocm93T25FcnJvciwgZW5zdXJlU3VzcGVuc2VUaW1lcnMsIGZldGNoT3B0aW1pc3RpYywgc2hvdWxkU3VzcGVuZCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdXNwZW5zZS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUlzUmVzdG9yaW5nIH0gZnJvbSBcIi4vSXNSZXN0b3JpbmdQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSB9IGZyb20gXCIuL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5LCBnZXRIYXNFcnJvciwgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkgfSBmcm9tIFwiLi9lcnJvckJvdW5kYXJ5VXRpbHMuanNcIjtcbmltcG9ydCB7IGVuc3VyZVN1c3BlbnNlVGltZXJzLCBmZXRjaE9wdGltaXN0aWMsIHNob3VsZFN1c3BlbmQgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0IHsgUXVlcmllc09ic2VydmVyLCBRdWVyeU9ic2VydmVyLCBub29wLCBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbi8vIHNyYy91c2VRdWVyaWVzLnRzXG4vKipcbiogVGhlIGB1c2VRdWVyaWVzYCBob29rIGNhbiBiZSB1c2VkIHRvIGZldGNoIGEgdmFyaWFibGUgbnVtYmVyIG9mIHF1ZXJpZXMuXG4qXG4qIFRoZSBgcXVlcmllc2Aga2V5IGFjY2VwdHMgYW4gYXJyYXkgd2l0aCBxdWVyeSBvcHRpb24gb2JqZWN0cyBtb3N0bHkgaWRlbnRpY2FsIHRvIGB1c2VRdWVyeWAg4oCUIHRoZSB0b3AtbGV2ZWxcbiogYHN1YnNjcmliZWRgIG9wdGlvbiBpc24ndCBhY2NlcHRlZCBwZXIgcXVlcnkgKHNlZSBgcGxhY2Vob2xkZXJEYXRhYCBiZWxvdyBmb3IgYW5vdGhlciBkaWZmZXJlbmNlKS4gQSBjdXN0b21cbiogYFF1ZXJ5Q2xpZW50YCBpcyBzdXBwbGllZCBvbmNlLCBhcyBgdXNlUXVlcmllc2AnIG93biB0b3AtbGV2ZWwgc2Vjb25kIGFyZ3VtZW50LCByYXRoZXIgdGhhbiBwZXIgcXVlcnkuXG4qXG4qIEhhdmluZyB0aGUgc2FtZSBxdWVyeSBrZXkgbW9yZSB0aGFuIG9uY2UgaW4gdGhlIGFycmF5IG9mIHF1ZXJ5IG9iamVjdHMgbWF5IGNhdXNlIHNvbWUgZGF0YSB0byBiZSBzaGFyZWRcbiogYmV0d2VlbiBxdWVyaWVzLiBUbyBhdm9pZCB0aGlzLCBjb25zaWRlciBkZS1kdXBsaWNhdGluZyB0aGUgcXVlcmllcyBhbmQgbWFwIHRoZSByZXN1bHRzIGJhY2sgdG8gdGhlIGRlc2lyZWRcbiogc3RydWN0dXJlLlxuKlxuKiBUaGUgYGNvbWJpbmVgIG9wdGlvbiBjYW4gYmUgdXNlZCB0byBjb21iaW5lIHRoZSByZXN1bHRzIG9mIHRoZSBxdWVyaWVzIGludG8gYSBzaW5nbGUgdmFsdWUuIFRoZSByZXN1bHQgd2lsbFxuKiBiZSBzdHJ1Y3R1cmFsbHkgc2hhcmVkIHRvIGJlIGFzIHJlZmVyZW50aWFsbHkgc3RhYmxlIGFzIHBvc3NpYmxlLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBgcXVlcmllc2AgYXJyYXkgdG8gcnVuLCBhbmQgdGhlIG9wdGlvbmFsIGBjb21iaW5lYCBhbmQgYHN1YnNjcmliZWRgIG9wdGlvbnMuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHByb3ZpZGUgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3QgY29udGV4dFxuKiB3aWxsIGJlIHVzZWQuXG4qIEByZXR1cm5zIFRoZSBjb21iaW5lZCByZXN1bHQuIFdpdGhvdXQgYGNvbWJpbmVgLCB0aGlzIGlzIGFuIGFycmF5IHdpdGggYWxsIHRoZSBxdWVyeSByZXN1bHRzLCBpbiB0aGUgc2FtZVxuKiBvcmRlciBhcyB0aGUgaW5wdXQuIFdoZW4gYGNvbWJpbmVgIGlzIHByb3ZpZGVkLCB0aGlzIGlzIHRoZSB2YWx1ZSByZXR1cm5lZCBieSBgY29tYmluZWAgaW5zdGVhZC5cbiogQHRocm93cyB7RXJyb3J9IFRoZSBlcnJvciBvZiB0aGUgZmlyc3QgcXVlcnkgdGhhdCBzaG91bGQgYmUgdGhyb3duIHRvIHRoZSBuZWFyZXN0IGVycm9yIGJvdW5kYXJ5IChzZWVcbiogYHRocm93T25FcnJvcmApLiBXaGlsZSBzdXNwZW5kaW5nLCBpdCB0aHJvd3MgYSBwcm9taXNlIGluc3RlYWQuXG4qIEByZW1hcmtzIFRoZSBgY29tYmluZWAgZnVuY3Rpb24gb25seSByZS1ydW5zIGlmIGl0IGNoYW5nZWQgcmVmZXJlbnRpYWxseSwgb3IgaWYgYW55IG9mIHRoZSBxdWVyeSByZXN1bHRzXG4qIGNoYW5nZWQuIEFuIGlubGluZWQgYGNvbWJpbmVgIGZ1bmN0aW9uLCBhcyBzaG93biBpbiB0aGUgZXhhbXBsZSBiZWxvdywgdGhlcmVmb3JlIHJ1bnMgb24gZXZlcnkgcmVuZGVyIOKAlCB3cmFwXG4qIGl0IGluIGB1c2VDYWxsYmFja2AsIG9yIGV4dHJhY3QgaXQgdG8gYSBzdGFibGUgZnVuY3Rpb24gcmVmZXJlbmNlIGlmIGl0IGRvZXNuJ3QgaGF2ZSBhbnkgZGVwZW5kZW5jaWVzLCB0b1xuKiBhdm9pZCB0aGF0LlxuKlxuKiBVbmxpa2UgYHVzZVF1ZXJ5YCwgYHVzZVF1ZXJpZXNgIGNhbm5vdCBpbmZlciB0aGUgYGRhdGFgIGFyZ3VtZW50IG9mIGFuIF9pbmxpbmVfIGBzZWxlY3RgIGZyb20gaXRzIHNpYmxpbmdcbiogYHF1ZXJ5Rm5gLiBCZWNhdXNlIGB1c2VRdWVyaWVzYCBpbmZlcnMgdGhlIHR5cGUgb2YgdGhlIHdob2xlIGBxdWVyaWVzYCBhcnJheSBhdCBvbmNlLCB0aGUgYHNlbGVjdGAgcGFyYW1ldGVyXG4qIG9mIGEgcXVlcnkgb2JqZWN0IHdyaXR0ZW4gaW5saW5lIGNhbm5vdCBiZSBjb250ZXh0dWFsbHkgdHlwZWQgZnJvbSB0aGF0IHNhbWUgb2JqZWN0J3MgYHF1ZXJ5Rm5gLCBzbyBpdCBmYWxsc1xuKiBiYWNrIHRvIGB1bmtub3duYCDigJQgYSBba25vd24gVHlwZVNjcmlwdCBsaW1pdGF0aW9uXShodHRwczovL2dpdGh1Yi5jb20vVGFuU3RhY2svcXVlcnkvaXNzdWVzLzY1NTYpLiBBbm5vdGF0ZVxuKiB0aGUgYHNlbGVjdGAgcGFyYW1ldGVyIGV4cGxpY2l0bHksIG9yIGRlZmluZSB0aGUgcXVlcnkgd2l0aCB7QGxpbmsgcXVlcnlPcHRpb25zfSwgd2hpY2ggcmVzb2x2ZXMgaXRzIHR5cGVzIGluXG4qIGEgc2luZ2xlIG9iamVjdCBfYmVmb3JlXyBpdCByZWFjaGVzIGB1c2VRdWVyaWVzYCwgdG8gd29yayBhcm91bmQgdGhpcyDigJQgc2VlIHRoZSBleGFtcGxlIGJlbG93LiBUaGUgc2FtZVxuKiBsaW1pdGF0aW9uIGFwcGxpZXMgdG8ge0BsaW5rIHVzZVN1c3BlbnNlUXVlcmllc30uXG4qXG4qIGBwbGFjZWhvbGRlckRhdGFgIGlzIHN1cHBvcnRlZCBoZXJlIHRvbywgYnV0IHVubGlrZSBgdXNlUXVlcnlgLCBpdCBkb2Vzbid0IHJlY2VpdmUgaW5mb3JtYXRpb24gZnJvbVxuKiBwcmV2aW91c2x5IHJlbmRlcmVkIHF1ZXJpZXMsIGJlY2F1c2UgdGhlIG51bWJlciBvZiBxdWVyaWVzIGNhbiBkaWZmZXIgYmV0d2VlbiByZW5kZXJzLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlUXVlcmllcyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHMoeyBpZHMgfTogeyBpZHM6IEFycmF5PG51bWJlcj4gfSkge1xuKiAgIGNvbnN0IHBvc3RRdWVyaWVzID0gdXNlUXVlcmllcyh7XG4qICAgICBxdWVyaWVzOiBpZHMubWFwKChpZCkgPT4gKHtcbiogICAgICAgcXVlcnlLZXk6IFsncG9zdCcsIGlkXSxcbiogICAgICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KGlkKSxcbiogICAgICAgc3RhbGVUaW1lOiBJbmZpbml0eSxcbiogICAgIH0pKSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8dWw+XG4qICAgICAgIHtwb3N0UXVlcmllcy5tYXAoKHF1ZXJ5LCBpbmRleCkgPT4ge1xuKiAgICAgICAgIGlmIChxdWVyeS5pc1BlbmRpbmcpIHJldHVybiA8bGkga2V5PXtpZHNbaW5kZXhdfT5Mb2FkaW5nLi4uPC9saT5cbiogICAgICAgICBpZiAocXVlcnkuaXNFcnJvcikgcmV0dXJuIDxsaSBrZXk9e2lkc1tpbmRleF19PkVycm9yOiB7cXVlcnkuZXJyb3IubWVzc2FnZX08L2xpPlxuKiAgICAgICAgIHJldHVybiA8bGkga2V5PXtpZHNbaW5kZXhdfT57cXVlcnkuZGF0YS50aXRsZX08L2xpPlxuKiAgICAgICB9KX1cbiogICAgIDwvdWw+XG4qICAgKVxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBDb21iaW5pbmcgcmVzdWx0cyBpbnRvIGEgc2luZ2xlIHZhbHVlOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlUXVlcmllcyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHMoeyBpZHMgfTogeyBpZHM6IEFycmF5PG51bWJlcj4gfSkge1xuKiAgIGNvbnN0IHsgZGF0YSwgaXNQZW5kaW5nLCBpc0Vycm9yIH0gPSB1c2VRdWVyaWVzKHtcbiogICAgIHF1ZXJpZXM6IGlkcy5tYXAoKGlkKSA9PiAoe1xuKiAgICAgICBxdWVyeUtleTogWydwb3N0JywgaWRdLFxuKiAgICAgICBxdWVyeUZuOiAoKSA9PiBmZXRjaFBvc3QoaWQpLFxuKiAgICAgfSkpLFxuKiAgICAgY29tYmluZTogKHBvc3RRdWVyaWVzKSA9PiB7XG4qICAgICAgIHJldHVybiB7XG4qICAgICAgICAgZGF0YTogcG9zdFF1ZXJpZXMubWFwKChxdWVyeSkgPT4gcXVlcnkuZGF0YSksXG4qICAgICAgICAgaXNQZW5kaW5nOiBwb3N0UXVlcmllcy5zb21lKChxdWVyeSkgPT4gcXVlcnkuaXNQZW5kaW5nKSxcbiogICAgICAgICBpc0Vycm9yOiBwb3N0UXVlcmllcy5zb21lKChxdWVyeSkgPT4gcXVlcnkuaXNFcnJvciksXG4qICAgICAgIH1cbiogICAgIH0sXG4qICAgfSlcbipcbiogICBpZiAoaXNQZW5kaW5nKSByZXR1cm4gJ0xvYWRpbmcuLi4nXG4qICAgaWYgKGlzRXJyb3IpIHJldHVybiAnRXJyb3IgbG9hZGluZyBwb3N0cydcbipcbiogICByZXR1cm4gKFxuKiAgICAgPHVsPlxuKiAgICAgICB7ZGF0YS5tYXAoKHBvc3QpID0+IChcbiogICAgICAgICA8bGkga2V5PXtwb3N0Py5pZH0+e3Bvc3Q/LnRpdGxlfTwvbGk+XG4qICAgICAgICkpfVxuKiAgICAgPC91bD5cbiogICApXG4qIH1cbiogYGBgXG4qIEBleGFtcGxlXG4qIFR5cGluZyBgc2VsZWN0YCB2aWEge0BsaW5rIHF1ZXJ5T3B0aW9uc30uIE5vdGUgdGhhdCBzcHJlYWRpbmcgYSBgcXVlcnlPcHRpb25zYCByZXN1bHQgYW5kIG92ZXJyaWRpbmdcbiogYHNlbGVjdGAgaW5saW5lIHN0aWxsIGZhbGxzIGJhY2sgdG8gYHVua25vd25gIOKAlCB3cmFwIHRoZSBzcHJlYWQgaW4gYHF1ZXJ5T3B0aW9uc2AgYWdhaW4gc28gdGhlIG92ZXJyaWRlIGlzXG4qIHJlc29sdmVkIGJlZm9yZSBpdCByZWFjaGVzIGB1c2VRdWVyaWVzYDpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHF1ZXJ5T3B0aW9ucywgdXNlUXVlcmllcyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogY29uc3QgcG9zdE9wdGlvbnMgPSAoaWQ6IG51bWJlcikgPT5cbiogICBxdWVyeU9wdGlvbnMoe1xuKiAgICAgcXVlcnlLZXk6IFsncG9zdCcsIGlkXSxcbiogICAgIHF1ZXJ5Rm46ICgpID0+IGZldGNoUG9zdChpZCksXG4qICAgfSlcbipcbiogZnVuY3Rpb24gUG9zdFRpdGxlKHsgaWQgfTogeyBpZDogbnVtYmVyIH0pIHtcbiogICBjb25zdCBbeyBkYXRhOiBicm9rZW4gfV0gPSB1c2VRdWVyaWVzKHtcbiogICAgIHF1ZXJpZXM6IFtcbiogICAgICAge1xuKiAgICAgICAgIC4uLnBvc3RPcHRpb25zKGlkKSxcbiogICAgICAgICAvLyDinYwgYGRhdGFgIGlzIGB1bmtub3duYCBoZXJlXG4qICAgICAgICAgc2VsZWN0OiAoZGF0YSkgPT4gZGF0YS50aXRsZSxcbiogICAgICAgfSxcbiogICAgIF0sXG4qICAgfSlcbipcbiogICBjb25zdCBbeyBkYXRhOiBmaXhlZCB9XSA9IHVzZVF1ZXJpZXMoe1xuKiAgICAgcXVlcmllczogW1xuKiAgICAgICBxdWVyeU9wdGlvbnMoe1xuKiAgICAgICAgIC4uLnBvc3RPcHRpb25zKGlkKSxcbiogICAgICAgICAvLyDinIUgYGRhdGFgIGlzIGBQb3N0YFxuKiAgICAgICAgIHNlbGVjdDogKGRhdGEpID0+IGRhdGEudGl0bGUsXG4qICAgICAgIH0pLFxuKiAgICAgXSxcbiogICB9KVxuKlxuKiAgIHJldHVybiA8aDE+e2ZpeGVkfTwvaDE+XG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlUXVlcmllcyh7IHF1ZXJpZXMsIC4uLm9wdGlvbnMgfSwgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRjb25zdCBpc1Jlc3RvcmluZyA9IHVzZUlzUmVzdG9yaW5nKCk7XG5cdGNvbnN0IGVycm9yUmVzZXRCb3VuZGFyeSA9IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5KCk7XG5cdGNvbnN0IHN1YnNjcmliZWQgPSBvcHRpb25zLnN1YnNjcmliZWQgIT09IGZhbHNlO1xuXHRjb25zdCBkZWZhdWx0ZWRRdWVyaWVzID0gUmVhY3QudXNlTWVtbygoKSA9PiBxdWVyaWVzLm1hcCgob3B0cykgPT4ge1xuXHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSBjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRzKTtcblx0XHRkZWZhdWx0ZWRPcHRpb25zLl9vcHRpbWlzdGljUmVzdWx0cyA9IGlzUmVzdG9yaW5nID8gXCJpc1Jlc3RvcmluZ1wiIDogc3Vic2NyaWJlZCA/IFwib3B0aW1pc3RpY1wiIDogdm9pZCAwO1xuXHRcdHJldHVybiBkZWZhdWx0ZWRPcHRpb25zO1xuXHR9KSwgW1xuXHRcdHF1ZXJpZXMsXG5cdFx0Y2xpZW50LFxuXHRcdGlzUmVzdG9yaW5nLFxuXHRcdHN1YnNjcmliZWRcblx0XSk7XG5cdGRlZmF1bHRlZFF1ZXJpZXMuZm9yRWFjaCgocXVlcnlPcHRpb25zKSA9PiB7XG5cdFx0ZW5zdXJlU3VzcGVuc2VUaW1lcnMocXVlcnlPcHRpb25zKTtcblx0XHRjb25zdCBxdWVyeSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZ2V0KHF1ZXJ5T3B0aW9ucy5xdWVyeUhhc2gpO1xuXHRcdGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnkocXVlcnlPcHRpb25zLCBlcnJvclJlc2V0Qm91bmRhcnksIHF1ZXJ5KTtcblx0fSk7XG5cdHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5KGVycm9yUmVzZXRCb3VuZGFyeSk7XG5cdGNvbnN0IFtvYnNlcnZlcl0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBuZXcgUXVlcmllc09ic2VydmVyKGNsaWVudCwgZGVmYXVsdGVkUXVlcmllcywgb3B0aW9ucykpO1xuXHRjb25zdCBbb3B0aW1pc3RpY1Jlc3VsdCwgZ2V0Q29tYmluZWRSZXN1bHQsIHRyYWNrUmVzdWx0XSA9IG9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQoZGVmYXVsdGVkUXVlcmllcywgb3B0aW9ucy5jb21iaW5lKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRvYnNlcnZlci5zZXRRdWVyaWVzKGRlZmF1bHRlZFF1ZXJpZXMsIG9wdGlvbnMpO1xuXHR9LCBbXG5cdFx0ZGVmYXVsdGVkUXVlcmllcyxcblx0XHRvcHRpb25zLFxuXHRcdG9ic2VydmVyXG5cdF0pO1xuXHRjb25zdCBzaG91bGRTdWJzY3JpYmUgPSAhaXNSZXN0b3JpbmcgJiYgc3Vic2NyaWJlZDtcblx0UmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoUmVhY3QudXNlQ2FsbGJhY2soKG9uU3RvcmVDaGFuZ2UpID0+IHNob3VsZFN1YnNjcmliZSA/IG9ic2VydmVyLnN1YnNjcmliZShub3RpZnlNYW5hZ2VyLmJhdGNoQ2FsbHMob25TdG9yZUNoYW5nZSkpIDogbm9vcCwgW29ic2VydmVyLCBzaG91bGRTdWJzY3JpYmVdKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpLCAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCkpO1xuXHRjb25zdCBzdXNwZW5zZVByb21pc2VzID0gb3B0aW1pc3RpY1Jlc3VsdC5zb21lKChyZXN1bHQsIGluZGV4KSA9PiBzaG91bGRTdXNwZW5kKGRlZmF1bHRlZFF1ZXJpZXNbaW5kZXhdLCByZXN1bHQpKSA/IG9wdGltaXN0aWNSZXN1bHQuZmxhdE1hcCgocmVzdWx0LCBpbmRleCkgPT4ge1xuXHRcdGNvbnN0IG9wdHMgPSBkZWZhdWx0ZWRRdWVyaWVzW2luZGV4XTtcblx0XHRpZiAob3B0cyAmJiBzaG91bGRTdXNwZW5kKG9wdHMsIHJlc3VsdCkpIHtcblx0XHRcdGNvbnN0IHF1ZXJ5T2JzZXJ2ZXIgPSBuZXcgUXVlcnlPYnNlcnZlcihjbGllbnQsIG9wdHMpO1xuXHRcdFx0cmV0dXJuIGZldGNoT3B0aW1pc3RpYyhvcHRzLCBxdWVyeU9ic2VydmVyLCBlcnJvclJlc2V0Qm91bmRhcnkpO1xuXHRcdH1cblx0XHRyZXR1cm4gW107XG5cdH0pIDogW107XG5cdGlmIChzdXNwZW5zZVByb21pc2VzLmxlbmd0aCA+IDApIHRocm93IFByb21pc2UuYWxsKHN1c3BlbnNlUHJvbWlzZXMpO1xuXHRjb25zdCBmaXJzdFNpbmdsZVJlc3VsdFdoaWNoU2hvdWxkVGhyb3cgPSBvcHRpbWlzdGljUmVzdWx0LmZpbmQoKHJlc3VsdCwgaW5kZXgpID0+IHtcblx0XHRjb25zdCBxdWVyeSA9IGRlZmF1bHRlZFF1ZXJpZXNbaW5kZXhdO1xuXHRcdHJldHVybiBxdWVyeSAmJiBnZXRIYXNFcnJvcih7XG5cdFx0XHRyZXN1bHQsXG5cdFx0XHRlcnJvclJlc2V0Qm91bmRhcnksXG5cdFx0XHR0aHJvd09uRXJyb3I6IHF1ZXJ5LnRocm93T25FcnJvcixcblx0XHRcdHF1ZXJ5OiBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldChxdWVyeS5xdWVyeUhhc2gpLFxuXHRcdFx0c3VzcGVuc2U6IHF1ZXJ5LnN1c3BlbnNlXG5cdFx0fSk7XG5cdH0pO1xuXHRpZiAoZmlyc3RTaW5nbGVSZXN1bHRXaGljaFNob3VsZFRocm93KSB0aHJvdyBmaXJzdFNpbmdsZVJlc3VsdFdoaWNoU2hvdWxkVGhyb3cuZXJyb3I7XG5cdHJldHVybiBnZXRDb21iaW5lZFJlc3VsdCh0cmFja1Jlc3VsdCgpKTtcbn1cbmV4cG9ydCB7IHVzZVF1ZXJpZXMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlUXVlcmllcy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUlzUmVzdG9yaW5nIH0gZnJvbSBcIi4vSXNSZXN0b3JpbmdQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSB9IGZyb20gXCIuL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5LCBnZXRIYXNFcnJvciwgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkgfSBmcm9tIFwiLi9lcnJvckJvdW5kYXJ5VXRpbHMuanNcIjtcbmltcG9ydCB7IGVuc3VyZVN1c3BlbnNlVGltZXJzLCBmZXRjaE9wdGltaXN0aWMsIHNob3VsZFN1c3BlbmQgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0IHsgbm9vcCwgbm90aWZ5TWFuYWdlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG4vLyBzcmMvdXNlQmFzZVF1ZXJ5LnRzXG4vKipcbiogQmFzZSBpbXBsZW1lbnRhdGlvbiBzaGFyZWQgYnkgYHVzZVF1ZXJ5YCwgYHVzZUluZmluaXRlUXVlcnlgLCBgdXNlU3VzcGVuc2VRdWVyeWAsIGFuZFxuKiBgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5YC5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb3B0aW9ucyBwYXNzZWQgdG8gdGhlIGNhbGxpbmcgaG9vay5cbiogQHBhcmFtIE9ic2VydmVyIC0gVGhlIG9ic2VydmVyIGNsYXNzIGZyb20gcXVlcnktY29yZSAoYFF1ZXJ5T2JzZXJ2ZXJgIG9yXG4qIGBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXJgKS5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0XG4qIGNvbnRleHQgd2lsbCBiZSB1c2VkLlxuKiBAcmV0dXJucyBUaGUgcXVlcnkgcmVzdWx0LCB0cmFja2luZyB3aGljaCBwcm9wZXJ0aWVzIGFyZSByZWFkIHVubGVzcyBgbm90aWZ5T25DaGFuZ2VQcm9wc2AgaXNcbiogc2V0LlxuKiBAdGhyb3dzIHtFcnJvcn0gSWYgYG9wdGlvbnNgIGlzIG5vdCBhbiBvYmplY3QgKG91dHNpZGUgcHJvZHVjdGlvbiksIG9yIHRoZSBxdWVyeSBlcnJvciB3aGVuIGl0IHNob3VsZCBiZVxuKiB0aHJvd24gdG8gdGhlIG5lYXJlc3QgZXJyb3IgYm91bmRhcnkgKHNlZSBgdGhyb3dPbkVycm9yYCkuIFdoaWxlIHN1c3BlbmRpbmcsIGl0IHRocm93cyBhIHByb21pc2UgaW5zdGVhZC5cbiovXG5mdW5jdGlvbiB1c2VCYXNlUXVlcnkob3B0aW9ucywgT2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAodHlwZW9mIG9wdGlvbnMgIT09IFwib2JqZWN0XCIgfHwgQXJyYXkuaXNBcnJheShvcHRpb25zKSkgdGhyb3cgbmV3IEVycm9yKFwiQmFkIGFyZ3VtZW50IHR5cGUuIFN0YXJ0aW5nIHdpdGggdjUsIG9ubHkgdGhlIFxcXCJPYmplY3RcXFwiIGZvcm0gaXMgYWxsb3dlZCB3aGVuIGNhbGxpbmcgcXVlcnkgcmVsYXRlZCBmdW5jdGlvbnMuIFBsZWFzZSB1c2UgdGhlIGVycm9yIHN0YWNrIHRvIGZpbmQgdGhlIGN1bHByaXQgY2FsbC4gTW9yZSBpbmZvIGhlcmU6IGh0dHBzOi8vdGFuc3RhY2suY29tL3F1ZXJ5L2xhdGVzdC9kb2NzL3JlYWN0L2d1aWRlcy9taWdyYXRpbmctdG8tdjUjc3VwcG9ydHMtYS1zaW5nbGUtc2lnbmF0dXJlLW9uZS1vYmplY3RcIik7XG5cdH1cblx0Y29uc3QgaXNSZXN0b3JpbmcgPSB1c2VJc1Jlc3RvcmluZygpO1xuXHRjb25zdCBlcnJvclJlc2V0Qm91bmRhcnkgPSB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSgpO1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSBjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcblx0Y29uc3QgcXVlcnkgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCk7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAoIWRlZmF1bHRlZE9wdGlvbnMucXVlcnlGbikgY29uc29sZS5lcnJvcihgWyR7ZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2h9XTogTm8gcXVlcnlGbiB3YXMgcGFzc2VkIGFzIGFuIG9wdGlvbiwgYW5kIG5vIGRlZmF1bHQgcXVlcnlGbiB3YXMgZm91bmQuIFRoZSBxdWVyeUZuIHBhcmFtZXRlciBpcyBvbmx5IG9wdGlvbmFsIHdoZW4gdXNpbmcgYSBkZWZhdWx0IHF1ZXJ5Rm4uIE1vcmUgaW5mbyBoZXJlOiBodHRwczovL3RhbnN0YWNrLmNvbS9xdWVyeS9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvZ3VpZGVzL2RlZmF1bHQtcXVlcnktZnVuY3Rpb25gKTtcblx0fVxuXHRjb25zdCBzdWJzY3JpYmVkID0gb3B0aW9ucy5zdWJzY3JpYmVkICE9PSBmYWxzZTtcblx0ZGVmYXVsdGVkT3B0aW9ucy5fb3B0aW1pc3RpY1Jlc3VsdHMgPSBpc1Jlc3RvcmluZyA/IFwiaXNSZXN0b3JpbmdcIiA6IHN1YnNjcmliZWQgPyBcIm9wdGltaXN0aWNcIiA6IHZvaWQgMDtcblx0ZW5zdXJlU3VzcGVuc2VUaW1lcnMoZGVmYXVsdGVkT3B0aW9ucyk7XG5cdGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnkoZGVmYXVsdGVkT3B0aW9ucywgZXJyb3JSZXNldEJvdW5kYXJ5LCBxdWVyeSk7XG5cdHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5KGVycm9yUmVzZXRCb3VuZGFyeSk7XG5cdGNvbnN0IFtvYnNlcnZlcl0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBuZXcgT2JzZXJ2ZXIoY2xpZW50LCBkZWZhdWx0ZWRPcHRpb25zKSk7XG5cdGNvbnN0IHJlc3VsdCA9IG9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQoZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0b2JzZXJ2ZXIuc2V0T3B0aW9ucyhkZWZhdWx0ZWRPcHRpb25zKTtcblx0fSwgW2RlZmF1bHRlZE9wdGlvbnMsIG9ic2VydmVyXSk7XG5cdGNvbnN0IHNob3VsZFN1YnNjcmliZSA9ICFpc1Jlc3RvcmluZyAmJiBzdWJzY3JpYmVkO1xuXHRSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShSZWFjdC51c2VDYWxsYmFjaygob25TdG9yZUNoYW5nZSkgPT4ge1xuXHRcdGNvbnN0IHVuc3Vic2NyaWJlID0gc2hvdWxkU3Vic2NyaWJlID8gb2JzZXJ2ZXIuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSkgOiBub29wO1xuXHRcdG9ic2VydmVyLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdHJldHVybiB1bnN1YnNjcmliZTtcblx0fSwgW29ic2VydmVyLCBzaG91bGRTdWJzY3JpYmVdKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpLCAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCkpO1xuXHRpZiAoc2hvdWxkU3VzcGVuZChkZWZhdWx0ZWRPcHRpb25zLCByZXN1bHQpKSB0aHJvdyBmZXRjaE9wdGltaXN0aWMoZGVmYXVsdGVkT3B0aW9ucywgb2JzZXJ2ZXIsIGVycm9yUmVzZXRCb3VuZGFyeSk7XG5cdGlmIChnZXRIYXNFcnJvcih7XG5cdFx0cmVzdWx0LFxuXHRcdGVycm9yUmVzZXRCb3VuZGFyeSxcblx0XHR0aHJvd09uRXJyb3I6IGRlZmF1bHRlZE9wdGlvbnMudGhyb3dPbkVycm9yLFxuXHRcdHF1ZXJ5LFxuXHRcdHN1c3BlbnNlOiBkZWZhdWx0ZWRPcHRpb25zLnN1c3BlbnNlXG5cdH0pKSB0aHJvdyByZXN1bHQuZXJyb3I7XG5cdHJldHVybiAhZGVmYXVsdGVkT3B0aW9ucy5ub3RpZnlPbkNoYW5nZVByb3BzID8gb2JzZXJ2ZXIudHJhY2tSZXN1bHQocmVzdWx0KSA6IHJlc3VsdDtcbn1cbmV4cG9ydCB7IHVzZUJhc2VRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VCYXNlUXVlcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VCYXNlUXVlcnkgfSBmcm9tIFwiLi91c2VCYXNlUXVlcnkuanNcIjtcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vIHNyYy91c2VRdWVyeS50c1xuZnVuY3Rpb24gdXNlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0cmV0dXJuIHVzZUJhc2VRdWVyeShvcHRpb25zLCBRdWVyeU9ic2VydmVyLCBxdWVyeUNsaWVudCk7XG59XG5leHBvcnQgeyB1c2VRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IGRlZmF1bHRUaHJvd09uRXJyb3IgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBRdWVyeU9ic2VydmVyLCBza2lwVG9rZW4gfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vIHNyYy91c2VTdXNwZW5zZVF1ZXJ5LnRzXG4vKipcbiogVGhlIG9wdGlvbnMgZm9yIGB1c2VTdXNwZW5zZVF1ZXJ5YCBhcmUgdGhlIHNhbWUgYXMgZm9yIGB1c2VRdWVyeWAsIGV4Y2VwdCBmb3IgYHRocm93T25FcnJvcmAsIGBlbmFibGVkYCwgYW5kXG4qIGBwbGFjZWhvbGRlckRhdGFgIOKAlCBhbmQgYHF1ZXJ5Rm5gIG1heSBub3QgYmUgYHNraXBUb2tlbmAsIHNpbmNlIFN1c3BlbnNlIGhvb2tzIGNhbid0IHJlbmRlciBhIFwiZGlzYWJsZWRcIiBzdGF0ZS5cbipcbiogQ2F2ZWF0OiBjYW5jZWxsYXRpb24gZG9lcyBub3Qgd29yay5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUge0BsaW5rIFVzZVN1c3BlbnNlUXVlcnlPcHRpb25zfSB0byB1c2Ug4oCUIHRoZSBzYW1lIG9wdGlvbnMgYXMgYHVzZVF1ZXJ5YCwgbWludXMgdGhlIG9uZXMgbGlzdGVkIGFib3ZlLlxuKiBAcGFyYW0gcXVlcnlDbGllbnQgLSBVc2UgdGhpcyB0byB1c2UgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3QgY29udGV4dCB3aWxsXG4qIGJlIHVzZWQuXG4qIEByZXR1cm5zIFRoZSBzYW1lIG9iamVjdCBhcyBgdXNlUXVlcnlgLCBleGNlcHQgdGhhdCBgZGF0YWAgaXMgZ3VhcmFudGVlZCB0byBiZSBkZWZpbmVkLCBgaXNQbGFjZWhvbGRlckRhdGFgXG4qIGlzIG1pc3NpbmcsIGFuZCBgc3RhdHVzYCBpcyBlaXRoZXIgYHN1Y2Nlc3NgIG9yIGBlcnJvcmAgKHdpdGggdGhlIGRlcml2ZWQgZmxhZ3Mgc2V0IGFjY29yZGluZ2x5KS5cbiogQHJlbWFya3MgTXVsdGlwbGUgYHVzZVN1c3BlbnNlUXVlcnlgIGNhbGxzIGluIHRoZSBzYW1lIGNvbXBvbmVudCBzdXNwZW5kIHNlcmlhbGx5LCBjYXVzaW5nIGEgcmVxdWVzdFxuKiB3YXRlcmZhbGwg4oCUIGVhY2ggb25lIGJsb2NrcyByZW5kZXJpbmcgdW50aWwgaXQgcmVzb2x2ZXMsIHNvIHRoZSBuZXh0IGRvZXNuJ3QgZXZlbiBzdGFydCBmZXRjaGluZyB1bnRpbCB0aGVuLlxuKiBVc2Uge0BsaW5rIHVzZVN1c3BlbnNlUXVlcmllc30gaW5zdGVhZCB3aGVuIHlvdSBoYXZlIG1vcmUgdGhhbiBvbmUgc3VzcGVuc2VmdWwgcXVlcnkgaW4gYSBjb21wb25lbnQsIHNvIHRoZXlcbiogZmV0Y2ggaW4gcGFyYWxsZWwuXG4qIEBleGFtcGxlXG4qIFRoZSBxdWVyeSBlcnJvciBpcyB0aHJvd24gaWYgdGhlIGZldGNoIGZhaWxzIGFuZCBubyBjYWNoZWQgZGF0YSBleGlzdHMgeWV0LCBzbyBhbiBlcnJvciBib3VuZGFyeSBpc1xuKiByZXF1aXJlZCBhcm91bmQgYDxTdXNwZW5zZT5gLiBBIGZhaWxlZCBiYWNrZ3JvdW5kIHJlZmV0Y2ggaW5zdGVhZCBjb250aW51ZXMgdG8gcmVuZGVyIHRoZSBjYWNoZWQgZGF0YS5cbiogVXNlIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeX0gdG8gbGV0IHRoZSB1c2VyIHJldHJ5IGFmdGVyIHN1Y2ggYW4gZXJyb3I6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBTdXNwZW5zZSB9IGZyb20gJ3JlYWN0J1xuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCB1c2VTdXNwZW5zZVF1ZXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQb3N0cygpIHtcbiogICAvLyBgZGF0YWAgaXMgZ3VhcmFudGVlZCB0byBiZSBkZWZpbmVkIGhlcmUg4oCUIG5vIGBpc1BlbmRpbmdgIGNoZWNrIG5lZWRlZC5cbiogICBjb25zdCB7IGRhdGEsIGlzRmV0Y2hpbmcgfSA9IHVzZVN1c3BlbnNlUXVlcnkoe1xuKiAgICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICAgIHF1ZXJ5Rm46IGZldGNoUG9zdHMsXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPGRpdj5cbiogICAgICAgPGgxPlBvc3RzIHtpc0ZldGNoaW5nID8gJyhyZWZyZXNoaW5nLi4uKScgOiBudWxsfTwvaDE+XG4qICAgICAgIDx1bD5cbiogICAgICAgICB7ZGF0YS5tYXAoKHBvc3QpID0+IChcbiogICAgICAgICAgIDxsaSBrZXk9e3Bvc3QuaWR9Pntwb3N0LnRpdGxlfTwvbGk+XG4qICAgICAgICAgKSl9XG4qICAgICAgIDwvdWw+XG4qICAgICA8L2Rpdj5cbiogICApXG4qIH1cbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiAoXG4qICAgICA8UXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgICAgIHsoeyByZXNldCB9KSA9PiAoXG4qICAgICAgICAgPEVycm9yQm91bmRhcnlcbiogICAgICAgICAgIG9uUmVzZXQ9e3Jlc2V0fVxuKiAgICAgICAgICAgZmFsbGJhY2tSZW5kZXI9eyh7IHJlc2V0RXJyb3JCb3VuZGFyeSB9KSA9PiAoXG4qICAgICAgICAgICAgIDxkaXY+XG4qICAgICAgICAgICAgICAgVGhlcmUgd2FzIGFuIGVycm9yIVxuKiAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVzZXRFcnJvckJvdW5kYXJ5KCl9PlRyeSBhZ2FpbjwvYnV0dG9uPlxuKiAgICAgICAgICAgICA8L2Rpdj5cbiogICAgICAgICAgICl9XG4qICAgICAgICAgPlxuKiAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwb3N0cy4uLjwvaDE+fT5cbiogICAgICAgICAgICAgPFBvc3RzIC8+XG4qICAgICAgICAgICA8L1N1c3BlbnNlPlxuKiAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiogICAgICAgKX1cbiogICAgIDwvUXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVN1c3BlbnNlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGlmIChvcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikgY29uc29sZS5lcnJvcihcInNraXBUb2tlbiBpcyBub3QgYWxsb3dlZCBmb3IgdXNlU3VzcGVuc2VRdWVyeVwiKTtcblx0fVxuXHRyZXR1cm4gdXNlQmFzZVF1ZXJ5KHtcblx0XHQuLi5vcHRpb25zLFxuXHRcdGVuYWJsZWQ6IHRydWUsXG5cdFx0c3VzcGVuc2U6IHRydWUsXG5cdFx0dGhyb3dPbkVycm9yOiBkZWZhdWx0VGhyb3dPbkVycm9yLFxuXHRcdHBsYWNlaG9sZGVyRGF0YTogdm9pZCAwXG5cdH0sIFF1ZXJ5T2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KTtcbn1cbmV4cG9ydCB7IHVzZVN1c3BlbnNlUXVlcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlU3VzcGVuc2VRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IGRlZmF1bHRUaHJvd09uRXJyb3IgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIsIHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL3VzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS50c1xuLyoqXG4qIFRoZSBvcHRpb25zIGZvciBgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5YCBhcmUgdGhlIHNhbWUgYXMgZm9yIGB1c2VJbmZpbml0ZVF1ZXJ5YCwgZXhjZXB0IGZvciBgdGhyb3dPbkVycm9yYCxcbiogYGVuYWJsZWRgLCBhbmQgYHBsYWNlaG9sZGVyRGF0YWAuXG4qXG4qIENhdmVhdDogY2FuY2VsbGF0aW9uIGRvZXMgbm90IHdvcmsuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIHtAbGluayBVc2VTdXNwZW5zZUluZmluaXRlUXVlcnlPcHRpb25zfSB0byB1c2Ug4oCUIHRoZSBzYW1lIG9wdGlvbnMgYXMgYHVzZUluZmluaXRlUXVlcnlgLCBtaW51cyB0aGUgb25lcyBsaXN0ZWQgYWJvdmUuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIHNhbWUgb2JqZWN0IGFzIGB1c2VJbmZpbml0ZVF1ZXJ5YCwgZXhjZXB0IHRoYXQgYGRhdGFgIGlzIGd1YXJhbnRlZWQgdG8gYmUgZGVmaW5lZCxcbiogYGlzUGxhY2Vob2xkZXJEYXRhYCBpcyBtaXNzaW5nLCBhbmQgYHN0YXR1c2AgaXMgZWl0aGVyIGBzdWNjZXNzYCBvciBgZXJyb3JgICh3aXRoIHRoZSBkZXJpdmVkIGZsYWdzIHNldFxuKiBhY2NvcmRpbmdseSkuXG4qIEByZW1hcmtzIE11bHRpcGxlIHN1c3BlbnNlZnVsIHF1ZXJ5IGNhbGxzIGluIHRoZSBzYW1lIGNvbXBvbmVudCBzdXNwZW5kIHNlcmlhbGx5LCBjYXVzaW5nIGEgcmVxdWVzdFxuKiB3YXRlcmZhbGwg4oCUIGVhY2ggb25lIGJsb2NrcyByZW5kZXJpbmcgdW50aWwgaXQgcmVzb2x2ZXMsIHNvIHRoZSBuZXh0IGRvZXNuJ3QgZXZlbiBzdGFydCBmZXRjaGluZyB1bnRpbFxuKiB0aGVuLiBUaGVyZSdzIG5vIHdheSB0byBwYXJhbGxlbGl6ZSBtdWx0aXBsZSBpbmZpbml0ZSBxdWVyaWVzIHVuZGVyIFN1c3BlbnNlLiBBbHNvIGtlZXAgaW4gbWluZCB0aGF0XG4qIGltcGVyYXRpdmUgZmV0Y2ggY2FsbHMsIHN1Y2ggYXMgYGZldGNoTmV4dFBhZ2VgLCBtYXkgaW50ZXJmZXJlIHdpdGggdGhlIGRlZmF1bHQgcmVmZXRjaCBiZWhhdmlvcixcbiogcmVzdWx0aW5nIGluIG91dGRhdGVkIGRhdGEuIE1ha2Ugc3VyZSB0byBjYWxsIHRoZXNlIGZ1bmN0aW9ucyBvbmx5IGluIHJlc3BvbnNlIHRvIHVzZXIgYWN0aW9ucywgb3IgYWRkXG4qIGNvbmRpdGlvbnMgbGlrZSBgaGFzTmV4dFBhZ2UgJiYgIWlzRmV0Y2hpbmdgLlxuKiBAc2VlIHtAbGluayB1c2VJbmZpbml0ZVF1ZXJ5fSBmb3IgdGhlIG5vbi1TdXNwZW5zZSB2ZXJzaW9uIG9mIHRoaXMgaG9vay5cbiogQGV4YW1wbGVcbiogVGhlIHF1ZXJ5IGVycm9yIGlzIHRocm93biBpZiBhIGZldGNoIGZhaWxzIGFuZCBubyBjYWNoZWQgZGF0YSBleGlzdHMgeWV0LCBzbyBhbiBlcnJvciBib3VuZGFyeSBpc1xuKiByZXF1aXJlZCBhcm91bmQgYDxTdXNwZW5zZT5gLiBBIGZhaWxlZCBiYWNrZ3JvdW5kIHJlZmV0Y2ggaW5zdGVhZCBjb250aW51ZXMgdG8gcmVuZGVyIHRoZSBjYWNoZWQgZGF0YS5cbiogVXNlIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeX0gdG8gbGV0IHRoZSB1c2VyIHJldHJ5IGFmdGVyIHN1Y2ggYW4gZXJyb3I6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBTdXNwZW5zZSB9IGZyb20gJ3JlYWN0J1xuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7XG4qICAgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnksXG4qICAgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LFxuKiB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUHJvamVjdHMoKSB7XG4qICAgLy8gYGRhdGFgIGlzIGd1YXJhbnRlZWQgdG8gYmUgZGVmaW5lZCBoZXJlIOKAlCBubyBgaXNQZW5kaW5nYCBjaGVjayBuZWVkZWQuXG4qICAgY29uc3QgeyBkYXRhLCBmZXRjaE5leHRQYWdlLCBoYXNOZXh0UGFnZSwgaXNGZXRjaGluZywgaXNGZXRjaGluZ05leHRQYWdlIH0gPVxuKiAgICAgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5KHtcbiogICAgICAgcXVlcnlLZXk6IFsncHJvamVjdHMnXSxcbiogICAgICAgcXVlcnlGbjogKHsgcGFnZVBhcmFtIH0pID0+IGZldGNoUHJvamVjdHMocGFnZVBhcmFtKSxcbiogICAgICAgaW5pdGlhbFBhZ2VQYXJhbTogMCxcbiogICAgICAgZ2V0TmV4dFBhZ2VQYXJhbTogKGxhc3RQYWdlKSA9PiBsYXN0UGFnZS5uZXh0SWQsXG4qICAgICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8ZGl2PlxuKiAgICAgICA8dWw+XG4qICAgICAgICAge2RhdGEucGFnZXMubWFwKChwYWdlKSA9PlxuKiAgICAgICAgICAgcGFnZS5wcm9qZWN0cy5tYXAoKHByb2plY3QpID0+IDxsaSBrZXk9e3Byb2plY3QuaWR9Pntwcm9qZWN0Lm5hbWV9PC9saT4pLFxuKiAgICAgICAgICl9XG4qICAgICAgIDwvdWw+XG4qICAgICAgIDxidXR0b25cbiogICAgICAgICBvbkNsaWNrPXsoKSA9PiBmZXRjaE5leHRQYWdlKCl9XG4qICAgICAgICAgZGlzYWJsZWQ9eyFoYXNOZXh0UGFnZSB8fCBpc0ZldGNoaW5nfVxuKiAgICAgICA+XG4qICAgICAgICAge2lzRmV0Y2hpbmdOZXh0UGFnZVxuKiAgICAgICAgICAgPyAnTG9hZGluZyBtb3JlLi4uJ1xuKiAgICAgICAgICAgOiBoYXNOZXh0UGFnZVxuKiAgICAgICAgICAgICA/ICdMb2FkIE1vcmUnXG4qICAgICAgICAgICAgIDogJ05vdGhpbmcgbW9yZSB0byBsb2FkJ31cbiogICAgICAgPC9idXR0b24+XG4qICAgICA8L2Rpdj5cbiogICApXG4qIH1cbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiAoXG4qICAgICA8UXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgICAgIHsoeyByZXNldCB9KSA9PiAoXG4qICAgICAgICAgPEVycm9yQm91bmRhcnlcbiogICAgICAgICAgIG9uUmVzZXQ9e3Jlc2V0fVxuKiAgICAgICAgICAgZmFsbGJhY2tSZW5kZXI9eyh7IHJlc2V0RXJyb3JCb3VuZGFyeSB9KSA9PiAoXG4qICAgICAgICAgICAgIDxkaXY+XG4qICAgICAgICAgICAgICAgVGhlcmUgd2FzIGFuIGVycm9yIVxuKiAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVzZXRFcnJvckJvdW5kYXJ5KCl9PlRyeSBhZ2FpbjwvYnV0dG9uPlxuKiAgICAgICAgICAgICA8L2Rpdj5cbiogICAgICAgICAgICl9XG4qICAgICAgICAgPlxuKiAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwcm9qZWN0cy4uLjwvaDE+fT5cbiogICAgICAgICAgICAgPFByb2plY3RzIC8+XG4qICAgICAgICAgICA8L1N1c3BlbnNlPlxuKiAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiogICAgICAgKX1cbiogICAgIDwvUXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0aWYgKG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSBjb25zb2xlLmVycm9yKFwic2tpcFRva2VuIGlzIG5vdCBhbGxvd2VkIGZvciB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnlcIik7XG5cdH1cblx0cmV0dXJuIHVzZUJhc2VRdWVyeSh7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRlbmFibGVkOiB0cnVlLFxuXHRcdHN1c3BlbnNlOiB0cnVlLFxuXHRcdHRocm93T25FcnJvcjogZGVmYXVsdFRocm93T25FcnJvcixcblx0XHRwbGFjZWhvbGRlckRhdGE6IHZvaWQgMFxuXHR9LCBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KTtcbn1cbmV4cG9ydCB7IHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VTdXNwZW5zZUluZmluaXRlUXVlcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyBkZWZhdWx0VGhyb3dPbkVycm9yIH0gZnJvbSBcIi4vc3VzcGVuc2UuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VRdWVyaWVzLmpzXCI7XG5pbXBvcnQgeyBza2lwVG9rZW4gfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vIHNyYy91c2VTdXNwZW5zZVF1ZXJpZXMudHNcbmZ1bmN0aW9uIHVzZVN1c3BlbnNlUXVlcmllcyhvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRyZXR1cm4gdXNlUXVlcmllcyh7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRxdWVyaWVzOiBvcHRpb25zLnF1ZXJpZXMubWFwKChxdWVyeSkgPT4ge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAocXVlcnkucXVlcnlGbiA9PT0gc2tpcFRva2VuKSBjb25zb2xlLmVycm9yKFwic2tpcFRva2VuIGlzIG5vdCBhbGxvd2VkIGZvciB1c2VTdXNwZW5zZVF1ZXJpZXNcIik7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5xdWVyeSxcblx0XHRcdFx0c3VzcGVuc2U6IHRydWUsXG5cdFx0XHRcdHRocm93T25FcnJvcjogZGVmYXVsdFRocm93T25FcnJvcixcblx0XHRcdFx0ZW5hYmxlZDogdHJ1ZSxcblx0XHRcdFx0cGxhY2Vob2xkZXJEYXRhOiB2b2lkIDBcblx0XHRcdH07XG5cdFx0fSlcblx0fSwgcXVlcnlDbGllbnQpO1xufVxuZXhwb3J0IHsgdXNlU3VzcGVuc2VRdWVyaWVzIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVN1c3BlbnNlUXVlcmllcy5qcy5tYXAiLCJpbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IG5vb3AgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vIHNyYy91c2VQcmVmZXRjaFF1ZXJ5LnRzeFxuLyoqXG4qIGB1c2VQcmVmZXRjaFF1ZXJ5YCBkb2VzIG5vdCByZXR1cm4gYW55dGhpbmcsIGl0IHNob3VsZCBiZSB1c2VkIGp1c3QgdG8gZmlyZSBhIHByZWZldGNoIGR1cmluZyByZW5kZXIsIGJlZm9yZVxuKiBhIHN1c3BlbnNlIGJvdW5kYXJ5IHRoYXQgd3JhcHMgYSBjb21wb25lbnQgdGhhdCB1c2VzIGB1c2VTdXNwZW5zZVF1ZXJ5YC4gWW91IGNhbiBwYXNzIGV2ZXJ5dGhpbmcgdG9cbiogYHVzZVByZWZldGNoUXVlcnlgIHRoYXQgeW91IGNhbiBwYXNzIHRvIGBxdWVyeUNsaWVudC5xdWVyeWAsIHRob3VnaCBgcXVlcnlLZXlgIGlzIGFsd2F5cyByZXF1aXJlZCwgYW5kXG4qIGBxdWVyeUZuYCBpcyByZXF1aXJlZCB1bmxlc3MgYSBkZWZhdWx0IHF1ZXJ5IGZ1bmN0aW9uIGhhcyBiZWVuIGRlZmluZWQuXG4qXG4qIFRoZSBwcmVmZXRjaCBpcyBza2lwcGVkIGlmIHRoZSBxdWVyeSBhbHJlYWR5IGhhcyBhbnkgY2FjaGVkIHN0YXRlIOKAlCBpbmNsdWRpbmcgYSBgcGVuZGluZ2AvYGVycm9yYCBzdGF0ZSBsZWZ0XG4qIG92ZXIgZnJvbSBhIHByZXZpb3VzIGF0dGVtcHQg4oCUIHNvIGNhbGxpbmcgdGhpcyBvbiBldmVyeSByZW5kZXIgaXMgY2hlYXAgYW5kIHdvbid0IHJlZmV0Y2ggZGF0YSB0aGF0J3NcbiogYWxyZWFkeSB0aGVyZSBvciBhbHJlYWR5IGluIGZsaWdodC5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUge0BsaW5rIFVzZVByZWZldGNoUXVlcnlPcHRpb25zfSB0byB1c2Ug4oCUIGV2ZXJ5dGhpbmcgeW91IGNhbiBwYXNzIHRvIGBxdWVyeUNsaWVudC5xdWVyeWAuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IFN1c3BlbnNlIH0gZnJvbSAncmVhY3QnXG4qIGltcG9ydCB7IHVzZVByZWZldGNoUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFwcCgpIHtcbiogICAvLyBGaXJlIHRoZSBwcmVmZXRjaCBkdXJpbmcgcmVuZGVyLCBiZWZvcmUgdGhlIHN1c3BlbnNlIGJvdW5kYXJ5IGJlbG93LlxuKiAgIHVzZVByZWZldGNoUXVlcnkoe1xuKiAgICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICAgIHF1ZXJ5Rm46IGZldGNoUG9zdHMsXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwb3N0cy4uLjwvaDE+fT5cbiogICAgICAgPFBvc3RzIC8+XG4qICAgICA8L1N1c3BlbnNlPlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VQcmVmZXRjaFF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0aWYgKCFjbGllbnQuZ2V0UXVlcnlTdGF0ZShvcHRpb25zLnF1ZXJ5S2V5KSkgY2xpZW50LnF1ZXJ5KG9wdGlvbnMpLmNhdGNoKG5vb3ApO1xufVxuZXhwb3J0IHsgdXNlUHJlZmV0Y2hRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VQcmVmZXRjaFF1ZXJ5LmpzLm1hcCIsImltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgbm9vcCB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL3VzZVByZWZldGNoSW5maW5pdGVRdWVyeS50c3hcbi8qKlxuKiBgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5YCBkb2VzIG5vdCByZXR1cm4gYW55dGhpbmcsIGl0IHNob3VsZCBiZSB1c2VkIGp1c3QgdG8gZmlyZSBhIHByZWZldGNoIGR1cmluZyByZW5kZXIsXG4qIGJlZm9yZSBhIHN1c3BlbnNlIGJvdW5kYXJ5IHRoYXQgd3JhcHMgYSBjb21wb25lbnQgdGhhdCB1c2VzIGB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnlgLiBZb3UgY2FuIHBhc3NcbiogZXZlcnl0aGluZyB0byBgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5YCB0aGF0IHlvdSBjYW4gcGFzcyB0byBgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeWAsIHRob3VnaFxuKiBgcXVlcnlLZXlgLCBgaW5pdGlhbFBhZ2VQYXJhbWAsIGFuZCBgZ2V0TmV4dFBhZ2VQYXJhbWAgYXJlIGFsd2F5cyByZXF1aXJlZCwgYW5kIGBxdWVyeUZuYCBpcyByZXF1aXJlZCB1bmxlc3NcbiogYSBkZWZhdWx0IHF1ZXJ5IGZ1bmN0aW9uIGhhcyBiZWVuIGRlZmluZWQuXG4qXG4qIGBnZXROZXh0UGFnZVBhcmFtYCByZWNlaXZlcyBib3RoIHRoZSBsYXN0IHBhZ2Ugb2YgdGhlIGluZmluaXRlIGxpc3Qgb2YgZGF0YSBhbmQgdGhlIGZ1bGwgYXJyYXkgb2YgYWxsIHBhZ2VzLFxuKiBhcyB3ZWxsIGFzIHBhZ2VQYXJhbSBpbmZvcm1hdGlvbiwgYW5kIHNob3VsZCByZXR1cm4gYSBzaW5nbGUgdmFyaWFibGUgdGhhdCB3aWxsIGJlIHBhc3NlZCB0byB5b3VyIHF1ZXJ5XG4qIGZ1bmN0aW9uIGFzIGBjb250ZXh0LnBhZ2VQYXJhbWAuIFJldHVybiBgdW5kZWZpbmVkYCBvciBgbnVsbGAgdG8gaW5kaWNhdGUgdGhlcmUgaXMgbm8gbmV4dCBwYWdlIGF2YWlsYWJsZS5cbipcbiogVGhlIHByZWZldGNoIGlzIHNraXBwZWQgaWYgdGhlIHF1ZXJ5IGFscmVhZHkgaGFzIGFueSBjYWNoZWQgc3RhdGUg4oCUIGluY2x1ZGluZyBhIGBwZW5kaW5nYC9gZXJyb3JgIHN0YXRlIGxlZnRcbiogb3ZlciBmcm9tIGEgcHJldmlvdXMgYXR0ZW1wdCDigJQgc28gY2FsbGluZyB0aGlzIG9uIGV2ZXJ5IHJlbmRlciBpcyBjaGVhcCBhbmQgd29uJ3QgcmVmZXRjaCBkYXRhIHRoYXQnc1xuKiBhbHJlYWR5IHRoZXJlIG9yIGFscmVhZHkgaW4gZmxpZ2h0LlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSB7QGxpbmsgVXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5T3B0aW9uc30gdG8gdXNlIOKAlCBldmVyeXRoaW5nIHlvdSBjYW4gcGFzcyB0byBgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeWAuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IFN1c3BlbnNlIH0gZnJvbSAncmVhY3QnXG4qIGltcG9ydCB7IGluZmluaXRlUXVlcnlPcHRpb25zLCB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGNvbnN0IHByb2plY3RzT3B0aW9ucyA9IGluZmluaXRlUXVlcnlPcHRpb25zKHtcbiogICBxdWVyeUtleTogWydwcm9qZWN0cyddLFxuKiAgIHF1ZXJ5Rm46ICh7IHBhZ2VQYXJhbSB9KSA9PiBmZXRjaFByb2plY3RzKHBhZ2VQYXJhbSksXG4qICAgaW5pdGlhbFBhZ2VQYXJhbTogMCxcbiogICBnZXROZXh0UGFnZVBhcmFtOiAobGFzdFBhZ2UpID0+IGxhc3RQYWdlLm5leHRJZCxcbiogfSlcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIC8vIEZpcmUgdGhlIHByZWZldGNoIGR1cmluZyByZW5kZXIsIGJlZm9yZSB0aGUgc3VzcGVuc2UgYm91bmRhcnkgYmVsb3cuXG4qICAgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5KHByb2plY3RzT3B0aW9ucylcbipcbiogICByZXR1cm4gKFxuKiAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwcm9qZWN0cy4uLjwvaDE+fT5cbiogICAgICAgPFByb2plY3RzIC8+XG4qICAgICA8L1N1c3BlbnNlPlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRpZiAoIWNsaWVudC5nZXRRdWVyeVN0YXRlKG9wdGlvbnMucXVlcnlLZXkpKSBjbGllbnQuaW5maW5pdGVRdWVyeShvcHRpb25zKS5jYXRjaChub29wKTtcbn1cbmV4cG9ydCB7IHVzZVByZWZldGNoSW5maW5pdGVRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanMubWFwIiwiLy8gc3JjL3F1ZXJ5T3B0aW9ucy50c1xuZnVuY3Rpb24gcXVlcnlPcHRpb25zKG9wdGlvbnMpIHtcblx0cmV0dXJuIG9wdGlvbnM7XG59XG5leHBvcnQgeyBxdWVyeU9wdGlvbnMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnlPcHRpb25zLmpzLm1hcCIsIi8vIHNyYy9pbmZpbml0ZVF1ZXJ5T3B0aW9ucy50c1xuZnVuY3Rpb24gaW5maW5pdGVRdWVyeU9wdGlvbnMob3B0aW9ucykge1xuXHRyZXR1cm4gb3B0aW9ucztcbn1cbmV4cG9ydCB7IGluZmluaXRlUXVlcnlPcHRpb25zIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZmluaXRlUXVlcnlPcHRpb25zLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyBoeWRyYXRlIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbi8vIHNyYy9IeWRyYXRpb25Cb3VuZGFyeS50c3hcbi8qKlxuKiBgSHlkcmF0aW9uQm91bmRhcnlgIGFkZHMgYSBwcmV2aW91c2x5IGRlaHlkcmF0ZWQgc3RhdGUgaW50byB0aGUgYHF1ZXJ5Q2xpZW50YCB0aGF0IHdvdWxkIGJlIHJldHVybmVkIGJ5XG4qIGB1c2VRdWVyeUNsaWVudCgpYC4gSWYgdGhlIGNsaWVudCBhbHJlYWR5IGNvbnRhaW5zIGRhdGEsIHRoZSBuZXcgcXVlcmllcyB3aWxsIGJlIGludGVsbGlnZW50bHkgbWVyZ2VkIGJhc2VkIG9uXG4qIHVwZGF0ZSB0aW1lc3RhbXAuXG4qXG4qIE5vdGU6IE9ubHkgYHF1ZXJpZXNgIGNhbiBiZSBkZWh5ZHJhdGVkIHdpdGggYW4gYEh5ZHJhdGlvbkJvdW5kYXJ5YC5cbiogQHBhcmFtIHByb3BzIC0gVGhlIGRlaHlkcmF0ZWQgYHN0YXRlYCB0byBoeWRyYXRlLCB0aGUgaHlkcmF0ZSBgb3B0aW9uc2AsIGFuIG9wdGlvbmFsIGN1c3RvbVxuKiBgcXVlcnlDbGllbnRgLCBhbmQgdGhlIGBjaGlsZHJlbmAgdG8gcmVuZGVyLlxuKiBAcmV0dXJucyBUaGUgcHJvdmlkZWQgYGNoaWxkcmVuYCwgcmVuZGVyZWQgdW5jb25kaXRpb25hbGx5LiBOZXcgcXVlcmllcyBpbiBgc3RhdGVgIGFyZSBoeWRyYXRlZCBpbnRvIHRoZVxuKiBjYWNoZSBkdXJpbmcgcmVuZGVyOyBmb3IgcXVlcmllcyBhbHJlYWR5IGluIHRoZSBjYWNoZSwgb25seSBuZXdlciBkZWh5ZHJhdGVkIGRhdGEgaXMgaHlkcmF0ZWQsIGluIGFuIGVmZmVjdFxuKiBhZnRlciBjb21taXQuXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBIeWRyYXRpb25Cb3VuZGFyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiA8SHlkcmF0aW9uQm91bmRhcnkgc3RhdGU9e2RlaHlkcmF0ZWRTdGF0ZX0+Li4uPC9IeWRyYXRpb25Cb3VuZGFyeT5cbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogU2VydmVyLXNpZGUgcHJlZmV0Y2ggaGFuZGVkIG9mZiB0byB0aGUgY2xpZW50IHZpYSBgZGVoeWRyYXRlYDpcbiogYGBgdHN4XG4qIGltcG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5LCBkZWh5ZHJhdGUsIG5vb3AgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGFzeW5jIGZ1bmN0aW9uIFNlcnZlckNvbXBvbmVudCgpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IGdldFF1ZXJ5Q2xpZW50KClcbipcbiogICBhd2FpdCBxdWVyeUNsaWVudFxuKiAgICAgLnF1ZXJ5KHtcbiogICAgICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICAgICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcbiogICAgIH0pXG4qICAgICAuY2F0Y2gobm9vcClcbipcbiogICByZXR1cm4gKFxuKiAgICAgPEh5ZHJhdGlvbkJvdW5kYXJ5IHN0YXRlPXtkZWh5ZHJhdGUocXVlcnlDbGllbnQpfT5cbiogICAgICAgPFBvc3RzIC8+XG4qICAgICA8L0h5ZHJhdGlvbkJvdW5kYXJ5PlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5jb25zdCBIeWRyYXRpb25Cb3VuZGFyeSA9ICh7IGNoaWxkcmVuLCBvcHRpb25zID0ge30sIHN0YXRlLCBxdWVyeUNsaWVudCB9KSA9PiB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0Y29uc3Qgb3B0aW9uc1JlZiA9IFJlYWN0LnVzZVJlZihvcHRpb25zKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRvcHRpb25zUmVmLmN1cnJlbnQgPSBvcHRpb25zO1xuXHR9KTtcblx0Y29uc3QgaHlkcmF0aW9uUXVldWUgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcblx0XHRpZiAoc3RhdGUpIHtcblx0XHRcdGlmICh0eXBlb2Ygc3RhdGUgIT09IFwib2JqZWN0XCIpIHJldHVybjtcblx0XHRcdGNvbnN0IHF1ZXJ5Q2FjaGUgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuXHRcdFx0Y29uc3QgcXVlcmllcyA9IHN0YXRlLnF1ZXJpZXMgfHwgW107XG5cdFx0XHRjb25zdCBuZXdRdWVyaWVzID0gW107XG5cdFx0XHRjb25zdCBleGlzdGluZ1F1ZXJpZXMgPSBbXTtcblx0XHRcdGZvciAoY29uc3QgZGVoeWRyYXRlZFF1ZXJ5IG9mIHF1ZXJpZXMpIHtcblx0XHRcdFx0Y29uc3QgZXhpc3RpbmdRdWVyeSA9IHF1ZXJ5Q2FjaGUuZ2V0KGRlaHlkcmF0ZWRRdWVyeS5xdWVyeUhhc2gpO1xuXHRcdFx0XHRpZiAoIWV4aXN0aW5nUXVlcnkpIG5ld1F1ZXJpZXMucHVzaChkZWh5ZHJhdGVkUXVlcnkpO1xuXHRcdFx0XHRlbHNlIGlmIChkZWh5ZHJhdGVkUXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCA+IGV4aXN0aW5nUXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCB8fCBkZWh5ZHJhdGVkUXVlcnkucHJvbWlzZSAmJiBleGlzdGluZ1F1ZXJ5LnN0YXRlLnN0YXR1cyAhPT0gXCJwZW5kaW5nXCIgJiYgZXhpc3RpbmdRdWVyeS5zdGF0ZS5mZXRjaFN0YXR1cyAhPT0gXCJmZXRjaGluZ1wiICYmIGRlaHlkcmF0ZWRRdWVyeS5kZWh5ZHJhdGVkQXQgPiBleGlzdGluZ1F1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQpIGV4aXN0aW5nUXVlcmllcy5wdXNoKGRlaHlkcmF0ZWRRdWVyeSk7XG5cdFx0XHR9XG5cdFx0XHRpZiAobmV3UXVlcmllcy5sZW5ndGggPiAwKSBoeWRyYXRlKGNsaWVudCwgeyBxdWVyaWVzOiBuZXdRdWVyaWVzIH0sIG9wdGlvbnNSZWYuY3VycmVudCk7XG5cdFx0XHRpZiAoZXhpc3RpbmdRdWVyaWVzLmxlbmd0aCA+IDApIHJldHVybiBleGlzdGluZ1F1ZXJpZXM7XG5cdFx0fVxuXHR9LCBbY2xpZW50LCBzdGF0ZV0pO1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGlmIChoeWRyYXRpb25RdWV1ZSkgaHlkcmF0ZShjbGllbnQsIHsgcXVlcmllczogaHlkcmF0aW9uUXVldWUgfSwgb3B0aW9uc1JlZi5jdXJyZW50KTtcblx0fSwgW2NsaWVudCwgaHlkcmF0aW9uUXVldWVdKTtcblx0cmV0dXJuIGNoaWxkcmVuO1xufTtcbmV4cG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUh5ZHJhdGlvbkJvdW5kYXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbi8vIHNyYy91c2VJc0ZldGNoaW5nLnRzXG4vKipcbiogVGhlIGB1c2VJc0ZldGNoaW5nYCBob29rIHJldHVybnMgdGhlIGBudW1iZXJgIG9mIHRoZSBxdWVyaWVzIHRoYXQgeW91ciBhcHBsaWNhdGlvbiBpcyBsb2FkaW5nIG9yIGZldGNoaW5nIGluXG4qIHRoZSBiYWNrZ3JvdW5kICh1c2VmdWwgZm9yIGFwcC13aWRlIGxvYWRpbmcgaW5kaWNhdG9ycykuXG4qIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIHtAbGluayBRdWVyeUZpbHRlcnN9IHRvIG5hcnJvdyBkb3duIHRoZSBtYXRjaGVkIHF1ZXJpZXMuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgV2lsbCBiZSB0aGUgYG51bWJlcmAgb2YgdGhlIHF1ZXJpZXMgdGhhdCB5b3VyIGFwcGxpY2F0aW9uIGlzIGN1cnJlbnRseSBsb2FkaW5nIG9yIGZldGNoaW5nIGluIHRoZVxuKiBiYWNrZ3JvdW5kLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlSXNGZXRjaGluZyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHNGZXRjaGluZ0luZGljYXRvcigpIHtcbiogICAvLyBIb3cgbWFueSBxdWVyaWVzIG1hdGNoaW5nIHRoZSBwb3N0cyBwcmVmaXggYXJlIGZldGNoaW5nP1xuKiAgIGNvbnN0IGlzRmV0Y2hpbmdQb3N0cyA9IHVzZUlzRmV0Y2hpbmcoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG4qXG4qICAgcmV0dXJuIGlzRmV0Y2hpbmdQb3N0cyA/IDxzcGFuPlJlZnJlc2hpbmcgcG9zdHMuLi48L3NwYW4+IDogbnVsbFxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBBIGdsb2JhbCBsb2FkaW5nIGluZGljYXRvciBmb3IgYW55IHF1ZXJ5IGZldGNoaW5nIGluIHRoZSBiYWNrZ3JvdW5kLCBub3QganVzdCB0aGUgb25lcyBvbiBzY3JlZW46XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VJc0ZldGNoaW5nIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBHbG9iYWxMb2FkaW5nSW5kaWNhdG9yKCkge1xuKiAgIGNvbnN0IGlzRmV0Y2hpbmcgPSB1c2VJc0ZldGNoaW5nKClcbipcbiogICByZXR1cm4gaXNGZXRjaGluZyA/IChcbiogICAgIDxkaXY+UXVlcmllcyBhcmUgZmV0Y2hpbmcgaW4gdGhlIGJhY2tncm91bmQuLi48L2Rpdj5cbiogICApIDogbnVsbFxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZUlzRmV0Y2hpbmcoZmlsdGVycywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRjb25zdCBxdWVyeUNhY2hlID0gY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKTtcblx0cmV0dXJuIFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiBxdWVyeUNhY2hlLnN1YnNjcmliZShub3RpZnlNYW5hZ2VyLmJhdGNoQ2FsbHMob25TdG9yZUNoYW5nZSkpLCBbcXVlcnlDYWNoZV0pLCAoKSA9PiBjbGllbnQuaXNGZXRjaGluZyhmaWx0ZXJzKSwgKCkgPT4gY2xpZW50LmlzRmV0Y2hpbmcoZmlsdGVycykpO1xufVxuZXhwb3J0IHsgdXNlSXNGZXRjaGluZyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VJc0ZldGNoaW5nLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyLCByZXBsYWNlRXF1YWxEZWVwIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbi8vIHNyYy91c2VNdXRhdGlvblN0YXRlLnRzXG4vKipcbiogVGhlIGB1c2VJc011dGF0aW5nYCBob29rIHJldHVybnMgdGhlIGBudW1iZXJgIG9mIG11dGF0aW9ucyB0aGF0IHlvdXIgYXBwbGljYXRpb24gY3VycmVudGx5IGhhcyBgcGVuZGluZ2BcbiogKHVzZWZ1bCBmb3IgYXBwLXdpZGUgbG9hZGluZyBpbmRpY2F0b3JzKS5cbiogQHBhcmFtIGZpbHRlcnMgLSBUaGUge0BsaW5rIE11dGF0aW9uRmlsdGVyc30gdG8gbmFycm93IGRvd24gdGhlIG1hdGNoZWQgbXV0YXRpb25zLlxuKiBAcGFyYW0gcXVlcnlDbGllbnQgLSBVc2UgdGhpcyB0byB1c2UgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3QgY29udGV4dCB3aWxsXG4qIGJlIHVzZWQuXG4qIEByZXR1cm5zIFdpbGwgYmUgdGhlIGBudW1iZXJgIG9mIHRoZSBtdXRhdGlvbnMgdGhhdCB5b3VyIGFwcGxpY2F0aW9uIGN1cnJlbnRseSBoYXMgYHBlbmRpbmdgLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlSXNNdXRhdGluZyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHNNdXRhdGluZ0luZGljYXRvcigpIHtcbiogICAvLyBIb3cgbWFueSBtdXRhdGlvbnMgbWF0Y2hpbmcgdGhlIHBvc3RzIHByZWZpeCBhcmUgaW4gcHJvZ3Jlc3M/XG4qICAgY29uc3QgaXNNdXRhdGluZ1Bvc3RzID0gdXNlSXNNdXRhdGluZyh7IG11dGF0aW9uS2V5OiBbJ3Bvc3RzJ10gfSlcbipcbiogICByZXR1cm4gaXNNdXRhdGluZ1Bvc3RzID8gPHNwYW4+U2F2aW5nIHBvc3RzLi4uPC9zcGFuPiA6IG51bGxcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VJc011dGF0aW5nKGZpbHRlcnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0cmV0dXJuIHVzZU11dGF0aW9uU3RhdGUoeyBmaWx0ZXJzOiB7XG5cdFx0Li4uZmlsdGVycyxcblx0XHRzdGF0dXM6IFwicGVuZGluZ1wiXG5cdH0gfSwgY2xpZW50KS5sZW5ndGg7XG59XG4vKipcbiogQ3JlYXRlcyBzbmFwc2hvdCBnZXR0ZXJzIHRoYXQgc2hhcmUgZXF1YWwgc2VsZWN0ZWQgcmVzdWx0cyBhY3Jvc3MgcmVuZGVycy5cbiogQSBuZXcgZ2V0dGVyIGlzIGNyZWF0ZWQgb24gZWFjaCByZW5kZXIuIEVhY2ggZ2V0dGVyIGNhY2hlcyBpdHMgc25hcHNob3QgdW50aWwgdGhlIG1hdGNoaW5nIG11dGF0aW9uc1xuKiBvciB0aGVpciBzdGF0ZXMgY2hhbmdlLlxuKiBAcmV0dXJucyBBIGZhY3RvcnkgZm9yIHNuYXBzaG90IGdldHRlcnMgd2l0aCBhIHNoYXJlZCByZXN1bHQgY2FjaGUuXG4qL1xuZnVuY3Rpb24gY3JlYXRlU25hcHNob3RGYWN0b3J5KCkge1xuXHRsZXQgcHJldmlvdXNSZXN1bHQ7XG5cdHJldHVybiAobXV0YXRpb25DYWNoZSwgb3B0aW9ucykgPT4ge1xuXHRcdGxldCBpbnB1dHMgPSBbXTtcblx0XHRsZXQgc25hcHNob3Q7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdGNvbnN0IG11dGF0aW9ucyA9IG11dGF0aW9uQ2FjaGUuZmluZEFsbChvcHRpb25zLmZpbHRlcnMpO1xuXHRcdFx0Y29uc3QgbmV4dElucHV0cyA9IG11dGF0aW9ucy5mbGF0TWFwKChtdXRhdGlvbikgPT4gW211dGF0aW9uLCBtdXRhdGlvbi5zdGF0ZV0pO1xuXHRcdFx0aWYgKCFzbmFwc2hvdCB8fCBuZXh0SW5wdXRzLmxlbmd0aCAhPT0gaW5wdXRzLmxlbmd0aCB8fCBuZXh0SW5wdXRzLnNvbWUoKGlucHV0LCBpbmRleCkgPT4gIU9iamVjdC5pcyhpbnB1dCwgaW5wdXRzW2luZGV4XSkpKSB7XG5cdFx0XHRcdGlucHV0cyA9IG5leHRJbnB1dHM7XG5cdFx0XHRcdHNuYXBzaG90ID0gcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c1Jlc3VsdCwgbXV0YXRpb25zLm1hcCgobXV0YXRpb24pID0+IG9wdGlvbnMuc2VsZWN0ID8gb3B0aW9ucy5zZWxlY3QobXV0YXRpb24pIDogbXV0YXRpb24uc3RhdGUpKTtcblx0XHRcdFx0cHJldmlvdXNSZXN1bHQgPSBzbmFwc2hvdDtcblx0XHRcdH1cblx0XHRcdHJldHVybiBzbmFwc2hvdDtcblx0XHR9O1xuXHR9O1xufVxuLyoqXG4qIGB1c2VNdXRhdGlvblN0YXRlYCBpcyBhIGhvb2sgdGhhdCBnaXZlcyB5b3UgYWNjZXNzIHRvIGFsbCBtdXRhdGlvbnMgaW4gdGhlIGBNdXRhdGlvbkNhY2hlYC4gWW91IGNhbiBwYXNzXG4qIGBmaWx0ZXJzYCAoe0BsaW5rIE11dGF0aW9uRmlsdGVyc30pIHRvIG5hcnJvdyBkb3duIHlvdXIgbXV0YXRpb25zLCBhbmQgYHNlbGVjdGAgdG8gdHJhbnNmb3JtIHRoZSBtdXRhdGlvblxuKiBzdGF0ZS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgYGZpbHRlcnNgIHRvIG5hcnJvdyBkb3duIG1hdGNoZWQgbXV0YXRpb25zLCBhbmQgYW4gb3B0aW9uYWwgYHNlbGVjdGAgdG8gdHJhbnNmb3JtIHRoZVxuKiBtdXRhdGlvbiBzdGF0ZS5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBXaWxsIGJlIGFuIEFycmF5IG9mIHdoYXRldmVyIGBzZWxlY3RgIHJldHVybnMgZm9yIGVhY2ggbWF0Y2hpbmcgbXV0YXRpb24uXG4qIEBleGFtcGxlXG4qIEdldCBhbGwgdmFyaWFibGVzIG9mIGFsbCBydW5uaW5nIG11dGF0aW9uczpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uU3RhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIFBlbmRpbmdQb3N0cygpIHtcbiogICBjb25zdCBwZW5kaW5nVmFyaWFibGVzID0gdXNlTXV0YXRpb25TdGF0ZSh7XG4qICAgICBmaWx0ZXJzOiB7IHN0YXR1czogJ3BlbmRpbmcnIH0sXG4qICAgICBzZWxlY3Q6IChtdXRhdGlvbikgPT4gbXV0YXRpb24uc3RhdGUudmFyaWFibGVzLFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIDw+e3BlbmRpbmdWYXJpYWJsZXMubGVuZ3RofSBwb3N0cyBzYXZpbmcuLi48Lz5cbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogR2V0IGFsbCBkYXRhIGZvciBzcGVjaWZpYyBtdXRhdGlvbnMgdmlhIHRoZSBgbXV0YXRpb25LZXlgOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZU11dGF0aW9uU3RhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGNvbnN0IG11dGF0aW9uS2V5ID0gWydwb3N0cyddXG4qXG4qIGZ1bmN0aW9uIFBvc3RzKCkge1xuKiAgIC8vIFNvbWUgbXV0YXRpb24gdGhhdCB3ZSB3YW50IHRvIGdldCB0aGUgc3RhdGUgZm9yXG4qICAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4qICAgICBtdXRhdGlvbktleSxcbiogICAgIG11dGF0aW9uRm46IGNyZWF0ZVBvc3RzLFxuKiAgIH0pXG4qXG4qICAgY29uc3Qgc2F2ZWRQb3N0cyA9IHVzZU11dGF0aW9uU3RhdGUoe1xuKiAgICAgLy8gdGhpcyBtdXRhdGlvbiBrZXkgbmVlZHMgdG8gbWF0Y2ggdGhlIG11dGF0aW9uIGtleSBvZiB0aGUgZ2l2ZW4gbXV0YXRpb24gKHNlZSBhYm92ZSlcbiogICAgIGZpbHRlcnM6IHsgbXV0YXRpb25LZXksIHN0YXR1czogJ3N1Y2Nlc3MnIH0sXG4qICAgICBzZWxlY3Q6IChtdXRhdGlvbikgPT4gbXV0YXRpb24uc3RhdGUuZGF0YSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG11dGF0aW9uLm11dGF0ZShbJ05ldyBQb3N0J10pfT5cbiogICAgICAgQ3JlYXRlIHBvc3QgKHtzYXZlZFBvc3RzLmxlbmd0aH0gc2F2ZWQgc28gZmFyKVxuKiAgICAgPC9idXR0b24+XG4qICAgKVxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBBY2Nlc3MgdGhlIGxhdGVzdCBzdWNjZXNzZnVsIG11dGF0aW9uIGRhdGEgdmlhIHRoZSBgbXV0YXRpb25LZXlgLiBFYWNoIGludm9jYXRpb24gb2YgYG11dGF0ZWAgYWRkcyBhIG5ld1xuKiBlbnRyeSB0byB0aGUgbXV0YXRpb24gY2FjaGUgZm9yIGBnY1RpbWVgIG1pbGxpc2Vjb25kcyDigJQgd2l0aCB0aGUgYHN0YXR1czogJ3N1Y2Nlc3MnYCBmaWx0ZXIgYmVsb3csIGNoZWNrIHRoZVxuKiBsYXN0IGl0ZW0gdGhhdCBgdXNlTXV0YXRpb25TdGF0ZWAgcmV0dXJucyB0byBnZXQgdGhlIGxhdGVzdCBzdWNjZXNzZnVsIGludm9jYXRpb246XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvblN0YXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBMYXRlc3RQb3N0KCkge1xuKiAgIGNvbnN0IHNhdmVkUG9zdHMgPSB1c2VNdXRhdGlvblN0YXRlKHtcbiogICAgIGZpbHRlcnM6IHsgbXV0YXRpb25LZXk6IFsncG9zdHMnXSwgc3RhdHVzOiAnc3VjY2VzcycgfSxcbiogICAgIHNlbGVjdDogKG11dGF0aW9uKSA9PiBtdXRhdGlvbi5zdGF0ZS5kYXRhLFxuKiAgIH0pXG4qXG4qICAgY29uc3QgbGF0ZXN0U2F2ZWRQb3N0ID0gc2F2ZWRQb3N0c1tzYXZlZFBvc3RzLmxlbmd0aCAtIDFdXG4qXG4qICAgcmV0dXJuIDw+e2xhdGVzdFNhdmVkUG9zdCA/ICdTYXZlZCcgOiAnTm90aGluZyBzYXZlZCB5ZXQnfTwvPlxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZU11dGF0aW9uU3RhdGUob3B0aW9ucyA9IHt9LCBxdWVyeUNsaWVudCkge1xuXHRjb25zdCBtdXRhdGlvbkNhY2hlID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpLmdldE11dGF0aW9uQ2FjaGUoKTtcblx0Y29uc3QgW2NyZWF0ZVNuYXBzaG90XSA9IFJlYWN0LnVzZVN0YXRlKCgpID0+IGNyZWF0ZVNuYXBzaG90RmFjdG9yeSgpKTtcblx0Y29uc3QgZ2V0U25hcHNob3QgPSBjcmVhdGVTbmFwc2hvdChtdXRhdGlvbkNhY2hlLCBvcHRpb25zKTtcblx0cmV0dXJuIFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiBtdXRhdGlvbkNhY2hlLnN1YnNjcmliZShub3RpZnlNYW5hZ2VyLmJhdGNoQ2FsbHMob25TdG9yZUNoYW5nZSkpLCBbbXV0YXRpb25DYWNoZV0pLCBnZXRTbmFwc2hvdCwgZ2V0U25hcHNob3QpO1xufVxuZXhwb3J0IHsgdXNlSXNNdXRhdGluZywgdXNlTXV0YXRpb25TdGF0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VNdXRhdGlvblN0YXRlLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyBNdXRhdGlvbk9ic2VydmVyLCBub29wLCBub3RpZnlNYW5hZ2VyLCBzaG91bGRUaHJvd0Vycm9yIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbi8vIHNyYy91c2VNdXRhdGlvbi50c1xuLyoqXG4qIFVubGlrZSBxdWVyaWVzLCBtdXRhdGlvbnMgYXJlIHR5cGljYWxseSB1c2VkIHRvIGNyZWF0ZS91cGRhdGUvZGVsZXRlIGRhdGEgb3IgcGVyZm9ybSBzZXJ2ZXIgc2lkZS1lZmZlY3RzLlxuKiBgdXNlTXV0YXRpb25gIGlzIHRoZSBob29rIGZvciB0aGF0LlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSB7QGxpbmsgVXNlTXV0YXRpb25PcHRpb25zfSB0byB1c2Ug4oCUIGV2ZXJ5dGhpbmcgeW91IGNhbiBwYXNzIHRvIGB1c2VNdXRhdGlvbmAuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgYG11dGF0ZWAvYG11dGF0ZUFzeW5jYCBhbHNvIGFjY2VwdCBwZXItY2FsbCBgb25TdWNjZXNzYC9gb25FcnJvcmAvYG9uU2V0dGxlZGAgY2FsbGJhY2tzIGFzIGEgc2Vjb25kXG4qIGFyZ3VtZW50LCB1c2VmdWwgZm9yIHRyaWdnZXJpbmcgY2FsbC1zaXRlIHNpZGUgZWZmZWN0cyAoZS5nLiBuYXZpZ2F0aW9uKSB3aXRob3V0IGNvdXBsaW5nIHRoZW0gdG8gdGhlIHNoYXJlZFxuKiBtdXRhdGlvbiBkZWZpbml0aW9uLiBIb29rLWxldmVsIGNhbGxiYWNrcyAocGFzc2VkIHRvIGBvcHRpb25zYCkgZmlyZSBmb3IgZXZlcnkgbXV0YXRpb247IHBlci1jYWxsIGNhbGxiYWNrc1xuKiBmaXJlIG9ubHkgZm9yIHRoZSBsYXRlc3QgY2FsbCB5b3UndmUgbWFkZSwgYW5kIG9ubHkgd2hpbGUgdGhlIGNvbXBvbmVudCBpcyBzdGlsbCBtb3VudGVkIOKAlCB1bm1vdW50aW5nIGJlZm9yZVxuKiB0aGUgbXV0YXRpb24gc2V0dGxlcyByZW1vdmVzIHRoZSBzdWJzY3JpcHRpb24gYW5kIHByZXZlbnRzIHRoZW0gZnJvbSBmaXJpbmcuXG4qIEB0aHJvd3Mge0Vycm9yfSBUaGUgbXV0YXRpb24gZXJyb3IsIHdoZW4gYHRocm93T25FcnJvcmAgaXMgYHRydWVgIG9yIHJldHVybnMgYHRydWVgIGZvciBpdCwgc28gdGhhdCBpdCBpc1xuKiB0aHJvd24gdG8gdGhlIG5lYXJlc3QgZXJyb3IgYm91bmRhcnkuXG4qIEBzZWUge0BsaW5rIG11dGF0aW9uT3B0aW9uc30gdG8gc2hhcmUgdGhlc2Ugb3B0aW9ucyBhY3Jvc3MgbXVsdGlwbGUgYHVzZU11dGF0aW9uYCBjYWxsIHNpdGVzLCBvciB0byBsb29rXG4qIHRoZSBtdXRhdGlvbiB1cCBlbHNld2hlcmUgdmlhIGl0cyBgbXV0YXRpb25LZXlgIChlLmcuIHdpdGggYHVzZU11dGF0aW9uU3RhdGVgKS5cbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQWRkVG9kbygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8YnV0dG9uXG4qICAgICAgIG9uQ2xpY2s9eygpID0+XG4qICAgICAgICAgYWRkTXV0YXRpb24ubXV0YXRlKCdJdGVtJywge1xuKiAgICAgICAgICAgb25FcnJvcjogKGVycm9yKSA9PiBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gYWRkIGl0ZW06JywgZXJyb3IpLFxuKiAgICAgICAgIH0pXG4qICAgICAgIH1cbiogICAgID5cbiogICAgICAgQWRkXG4qICAgICA8L2J1dHRvbj5cbiogICApXG4qIH1cbiogYGBgXG4qIEBleGFtcGxlXG4qIFJlbmRlcmluZyB0aGUgbXV0YXRpb24ncyBvd24gc3RhdGUsIHJhdGhlciB0aGFuIGp1c3QgZmlyaW5nIGl0IG9mZjpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQWRkVG9kbygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8ZGl2PlxuKiAgICAgICB7YWRkTXV0YXRpb24uaXNQZW5kaW5nID8gKFxuKiAgICAgICAgICdBZGRpbmcgdG9kby4uLidcbiogICAgICAgKSA6IChcbiogICAgICAgICA8PlxuKiAgICAgICAgICAge2FkZE11dGF0aW9uLmlzRXJyb3IgPyAoXG4qICAgICAgICAgICAgIDxkaXY+QW4gZXJyb3Igb2NjdXJyZWQ6IHthZGRNdXRhdGlvbi5lcnJvci5tZXNzYWdlfTwvZGl2PlxuKiAgICAgICAgICAgKSA6IG51bGx9XG4qICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGFkZE11dGF0aW9uLm11dGF0ZSgnSXRlbScpfT5BZGQ8L2J1dHRvbj5cbiogICAgICAgICA8Lz5cbiogICAgICAgKX1cbiogICAgIDwvZGl2PlxuKiAgIClcbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogT3B0aW1pc3RpYyB1cGRhdGUgdmlhIGBvbk11dGF0ZWAsIHJvbGxpbmcgYmFjayBvbiBgb25FcnJvcmA6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFkZFRvZG8oKSB7XG4qICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4qXG4qICAgY29uc3QgYWRkTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4qICAgICBtdXRhdGlvbkZuOiBhZGRUb2RvLFxuKiAgICAgb25NdXRhdGU6IGFzeW5jIChuZXdUb2RvKSA9PiB7XG4qICAgICAgIGF3YWl0IHF1ZXJ5Q2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleTogWyd0b2RvcyddIH0pXG4qICAgICAgIGNvbnN0IHByZXZpb3VzVG9kb3MgPSBxdWVyeUNsaWVudC5nZXRRdWVyeURhdGE8QXJyYXk8c3RyaW5nPj4oWyd0b2RvcyddKVxuKlxuKiAgICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGE8QXJyYXk8c3RyaW5nPj4oWyd0b2RvcyddLCAob2xkKSA9PiBbXG4qICAgICAgICAgLi4uKG9sZCA/PyBbXSksXG4qICAgICAgICAgbmV3VG9kbyxcbiogICAgICAgXSlcbipcbiogICAgICAgLy8gUGFzc2VkIHRvIGBvbkVycm9yYCBhcyBgb25NdXRhdGVSZXN1bHRgIGlmIHRoZSBtdXRhdGlvbiBmYWlscy5cbiogICAgICAgcmV0dXJuIHsgcHJldmlvdXNUb2RvcyB9XG4qICAgICB9LFxuKiAgICAgb25FcnJvcjogKF9lcnIsIF9uZXdUb2RvLCBvbk11dGF0ZVJlc3VsdCkgPT4ge1xuKiAgICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEoWyd0b2RvcyddLCBvbk11dGF0ZVJlc3VsdD8ucHJldmlvdXNUb2RvcylcbiogICAgIH0sXG4qICAgICBvblNldHRsZWQ6ICgpID0+IHtcbiogICAgICAgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWyd0b2RvcyddIH0pXG4qICAgICB9LFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gYWRkTXV0YXRpb24ubXV0YXRlKCdJdGVtJyl9PkFkZDwvYnV0dG9uPlxuKiAgIClcbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogQ2FsbGJhY2tzIHBhc3NlZCBwZXIgY2FsbCB0byBgbXV0YXRlYCBvbmx5IGZpcmUgZm9yIHRoZSBsYXN0IGNhbGwg4oCUIGBtdXRhdGVBc3luY2AgZ2l2ZXMgeW91IGFcbiogcHJvbWlzZSBwZXIgY2FsbCBpbnN0ZWFkLCBzbyB5b3UgY2FuIHdhaXQgZm9yIGFsbCBvZiB0aGVtIHdoZW4gdGhleSBzdWNjZWVkOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBZGRUb2RvcygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFkZEFsbCh0b2RvczogQXJyYXk8c3RyaW5nPikge1xuKiAgICAgdHJ5IHtcbiogICAgICAgYXdhaXQgUHJvbWlzZS5hbGwodG9kb3MubWFwKCh0b2RvKSA9PiBhZGRNdXRhdGlvbi5tdXRhdGVBc3luYyh0b2RvKSkpXG4qICAgICB9IGNhdGNoIChlcnJvcikge1xuKiAgICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gYWRkIHRvZG9zOicsIGVycm9yKVxuKiAgICAgfVxuKiAgIH1cbipcbiogICByZXR1cm4gKFxuKiAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBZGRBbGwoWydUb2RvIDEnLCAnVG9kbyAyJywgJ1RvZG8gMyddKX0+XG4qICAgICAgIEFkZCBhbGxcbiogICAgIDwvYnV0dG9uPlxuKiAgIClcbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogSWYgc29tZSBvZiB0aGUgbXV0YXRpb25zIGFib3ZlIGNhbiBmYWlsIGluZGVwZW5kZW50bHkgb2YgdGhlIG90aGVycywgYW5kIHlvdSB3YW50IHRvIGtub3cgd2hpY2ggb25lc1xuKiBkaWQg4oCUIHJhdGhlciB0aGFuIGxvc2luZyB0aGF0IGluZm9ybWF0aW9uIHRoZSBtb21lbnQgdGhlIGZpcnN0IG9uZSByZWplY3RzIOKAlCBzd2FwIGBQcm9taXNlLmFsbGAgZm9yXG4qIGBQcm9taXNlLmFsbFNldHRsZWRgOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBZGRUb2RvcygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFkZEFsbCh0b2RvczogQXJyYXk8c3RyaW5nPikge1xuKiAgICAgY29uc3QgYWRkUmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsU2V0dGxlZChcbiogICAgICAgdG9kb3MubWFwKCh0b2RvKSA9PiBhZGRNdXRhdGlvbi5tdXRhdGVBc3luYyh0b2RvKSksXG4qICAgICApXG4qXG4qICAgICBhZGRSZXN1bHRzLmZvckVhY2goKGFkZFJlc3VsdCwgaW5kZXgpID0+IHtcbiogICAgICAgaWYgKGFkZFJlc3VsdC5zdGF0dXMgPT09ICdyZWplY3RlZCcpIHtcbiogICAgICAgICBjb25zb2xlLmVycm9yKGBGYWlsZWQgdG8gYWRkIFwiJHt0b2Rvc1tpbmRleF19XCI6YCwgYWRkUmVzdWx0LnJlYXNvbilcbiogICAgICAgfVxuKiAgICAgfSlcbiogICB9XG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlQWRkQWxsKFsnVG9kbyAxJywgJ1RvZG8gMicsICdUb2RvIDMnXSl9PlxuKiAgICAgICBBZGQgYWxsXG4qICAgICA8L2J1dHRvbj5cbiogICApXG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlTXV0YXRpb24ob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRjb25zdCBbb2JzZXJ2ZXJdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoY2xpZW50LCBvcHRpb25zKSk7XG5cdFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0b2JzZXJ2ZXIuc2V0T3B0aW9ucyhvcHRpb25zKTtcblx0fSwgW29ic2VydmVyLCBvcHRpb25zXSk7XG5cdGNvbnN0IHJlc3VsdCA9IFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiBvYnNlcnZlci5zdWJzY3JpYmUobm90aWZ5TWFuYWdlci5iYXRjaENhbGxzKG9uU3RvcmVDaGFuZ2UpKSwgW29ic2VydmVyXSksICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpKTtcblx0Y29uc3QgbXV0YXRlID0gUmVhY3QudXNlQ2FsbGJhY2soKC4uLmFyZ3MpID0+IHtcblx0XHRvYnNlcnZlci5tdXRhdGUoYXJnc1swXSwgYXJnc1sxXSkuY2F0Y2gobm9vcCk7XG5cdH0sIFtvYnNlcnZlcl0pO1xuXHRpZiAocmVzdWx0LmVycm9yICYmIHNob3VsZFRocm93RXJyb3Iob2JzZXJ2ZXIub3B0aW9ucy50aHJvd09uRXJyb3IsIFtyZXN1bHQuZXJyb3JdKSkgdGhyb3cgcmVzdWx0LmVycm9yO1xuXHRyZXR1cm4ge1xuXHRcdC4uLnJlc3VsdCxcblx0XHRtdXRhdGUsXG5cdFx0bXV0YXRlQXN5bmM6IHJlc3VsdC5tdXRhdGVcblx0fTtcbn1cbmV4cG9ydCB7IHVzZU11dGF0aW9uIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZU11dGF0aW9uLmpzLm1hcCIsIi8vIHNyYy9tdXRhdGlvbk9wdGlvbnMudHNcbmZ1bmN0aW9uIG11dGF0aW9uT3B0aW9ucyhvcHRpb25zKSB7XG5cdHJldHVybiBvcHRpb25zO1xufVxuZXhwb3J0IHsgbXV0YXRpb25PcHRpb25zIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW11dGF0aW9uT3B0aW9ucy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUJhc2VRdWVyeSB9IGZyb20gXCIuL3VzZUJhc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgSW5maW5pdGVRdWVyeU9ic2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyBzcmMvdXNlSW5maW5pdGVRdWVyeS50c1xuZnVuY3Rpb24gdXNlSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRyZXR1cm4gdXNlQmFzZVF1ZXJ5KG9wdGlvbnMsIEluZmluaXRlUXVlcnlPYnNlcnZlciwgcXVlcnlDbGllbnQpO1xufVxuZXhwb3J0IHsgdXNlSW5maW5pdGVRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VJbmZpbml0ZVF1ZXJ5LmpzLm1hcCIsImltcG9ydCB7IHVzZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VRdWVyaWVzLmpzXCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCIuL3VzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlU3VzcGVuc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VTdXNwZW5zZVF1ZXJpZXMuanNcIjtcbmltcG9ydCB7IHVzZVByZWZldGNoUXVlcnkgfSBmcm9tIFwiLi91c2VQcmVmZXRjaFF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkgfSBmcm9tIFwiLi91c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanNcIjtcbmltcG9ydCB7IHF1ZXJ5T3B0aW9ucyB9IGZyb20gXCIuL3F1ZXJ5T3B0aW9ucy5qc1wiO1xuaW1wb3J0IHsgaW5maW5pdGVRdWVyeU9wdGlvbnMgfSBmcm9tIFwiLi9pbmZpbml0ZVF1ZXJ5T3B0aW9ucy5qc1wiO1xuaW1wb3J0IHsgUXVlcnlDbGllbnRDb250ZXh0LCBRdWVyeUNsaWVudFByb3ZpZGVyLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5IH0gZnJvbSBcIi4vSHlkcmF0aW9uQm91bmRhcnkuanNcIjtcbmltcG9ydCB7IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSB9IGZyb20gXCIuL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VJc0ZldGNoaW5nIH0gZnJvbSBcIi4vdXNlSXNGZXRjaGluZy5qc1wiO1xuaW1wb3J0IHsgdXNlSXNNdXRhdGluZywgdXNlTXV0YXRpb25TdGF0ZSB9IGZyb20gXCIuL3VzZU11dGF0aW9uU3RhdGUuanNcIjtcbmltcG9ydCB7IHVzZU11dGF0aW9uIH0gZnJvbSBcIi4vdXNlTXV0YXRpb24uanNcIjtcbmltcG9ydCB7IG11dGF0aW9uT3B0aW9ucyB9IGZyb20gXCIuL211dGF0aW9uT3B0aW9ucy5qc1wiO1xuaW1wb3J0IHsgdXNlSW5maW5pdGVRdWVyeSB9IGZyb20gXCIuL3VzZUluZmluaXRlUXVlcnkuanNcIjtcbmltcG9ydCB7IElzUmVzdG9yaW5nUHJvdmlkZXIsIHVzZUlzUmVzdG9yaW5nIH0gZnJvbSBcIi4vSXNSZXN0b3JpbmdQcm92aWRlci5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyBzcmMvaW5kZXgudHNcbi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG5leHBvcnQgeyBIeWRyYXRpb25Cb3VuZGFyeSwgSXNSZXN0b3JpbmdQcm92aWRlciwgUXVlcnlDbGllbnRDb250ZXh0LCBRdWVyeUNsaWVudFByb3ZpZGVyLCBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSwgaW5maW5pdGVRdWVyeU9wdGlvbnMsIG11dGF0aW9uT3B0aW9ucywgcXVlcnlPcHRpb25zLCB1c2VJbmZpbml0ZVF1ZXJ5LCB1c2VJc0ZldGNoaW5nLCB1c2VJc011dGF0aW5nLCB1c2VJc1Jlc3RvcmluZywgdXNlTXV0YXRpb24sIHVzZU11dGF0aW9uU3RhdGUsIHVzZVByZWZldGNoSW5maW5pdGVRdWVyeSwgdXNlUHJlZmV0Y2hRdWVyeSwgdXNlUXVlcmllcywgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50LCB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSwgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LCB1c2VTdXNwZW5zZVF1ZXJpZXMsIHVzZVN1c3BlbnNlUXVlcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIl0sIm1hcHBpbmdzIjoiOzs7O0FBR0EsSUFBTSxxQkFBQSxhQUEyQixjQUFjLEtBQUs7Ozs7Ozs7QUFPcEQsSUFBTSx1QkFBQSxhQUE2QixXQUFXLGtCQUFrQjs7Ozs7QUFLaEUsSUFBTSxzQkFBc0IsbUJBQW1COzs7Ozs7QUNSL0MsSUFBTSxxQkFBQSxhQUEyQixjQUFjLEtBQUssQ0FBQzs7Ozs7Ozs7O0FBU3JELElBQU0sa0JBQWtCLGdCQUFnQjtDQUN2QyxNQUFNLFNBQUEsYUFBZSxXQUFXLGtCQUFrQjtDQUNsRCxJQUFJLGFBQWEsT0FBTztDQUN4QixJQUFJLENBQUMsUUFBUSxNQUFNLElBQUksTUFBTSx3REFBd0Q7Q0FDckYsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUJBLElBQU0sdUJBQXVCLEVBQUUsUUFBUSxlQUFlO0NBQ3JELGFBQU0sZ0JBQWdCO0VBQ3JCLE9BQU8sTUFBTTtFQUNiLGFBQWE7R0FDWixPQUFPLFFBQVE7RUFDaEI7Q0FDRCxHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ1gsT0FBdUJBLGlCQUFBQSxHQUFBQSxtQkFBQUEsSUFBQUEsQ0FBSSxtQkFBbUIsVUFBVTtFQUN2RCxPQUFPO0VBQ1A7Q0FDRCxDQUFDO0FBQ0Y7Ozs7Ozs7QUMxQ0EsU0FBUyxjQUFjO0NBQ3RCLElBQUksVUFBVTtDQUNkLE9BQU87Ozs7RUFJTixrQkFBa0I7R0FDakIsVUFBVTtFQUNYOzs7O0VBSUEsYUFBYTtHQUNaLFVBQVU7RUFDWDs7Ozs7RUFLQSxlQUFlO0dBQ2QsT0FBTztFQUNSO0NBQ0Q7QUFDRDtBQUNBLElBQU0saUNBQUEsYUFBdUMsY0FBYyxZQUFZLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBNkJ4RSxJQUFNLG1DQUFBLGFBQXlDLFdBQVcsOEJBQThCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0N4RixJQUFNLDJCQUEyQixFQUFFLGVBQWU7Q0FDakQsTUFBTSxDQUFDLFNBQUEsYUFBZSxlQUFlLFlBQVksQ0FBQztDQUNsRCxPQUF1QkMsaUJBQUFBLEdBQUFBLG1CQUFBQSxJQUFBQSxDQUFJLCtCQUErQixVQUFVO0VBQ25FO0VBQ0EsVUFBVSxPQUFPLGFBQWEsYUFBYSxTQUFTLEtBQUssSUFBSTtDQUM5RCxDQUFDO0FBQ0Y7Ozs7Ozs7QUNoR0EsSUFBSSxlQUFlLE1BQU07Q0FDeEIsY0FBYztFQUNiLEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssSUFBSTtDQUMxQzs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxVQUFVLFVBQVU7RUFDbkIsS0FBSyxVQUFVLElBQUksUUFBUTtFQUMzQixLQUFLLFlBQVk7RUFDakIsYUFBYTtHQUNaLEtBQUssVUFBVSxPQUFPLFFBQVE7R0FDOUIsS0FBSyxjQUFjO0VBQ3BCO0NBQ0Q7Ozs7O0NBS0EsZUFBZTtFQUNkLE9BQU8sS0FBSyxVQUFVLE9BQU87Q0FDOUI7Ozs7O0NBS0EsY0FBYyxDQUFDOzs7OztDQUtmLGdCQUFnQixDQUFDO0FBQ2xCOzs7Ozs7O0FDNUNBLElBQUksZUFBZSxjQUFjLGFBQWE7Q0FDN0M7Q0FDQTtDQUNBO0NBQ0EsY0FBYztFQUNiLE1BQU07RUFDTixLQUFLLFVBQVUsWUFBWTtHQUMxQixJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sa0JBQWtCO0lBQzdELE1BQU0saUJBQWlCLFFBQVE7SUFDL0IsT0FBTyxpQkFBaUIsb0JBQW9CLFVBQVUsS0FBSztJQUMzRCxhQUFhO0tBQ1osT0FBTyxvQkFBb0Isb0JBQW9CLFFBQVE7SUFDeEQ7R0FDRDtFQUNEO0NBQ0Q7Q0FDQSxjQUFjO0VBQ2IsSUFBSSxDQUFDLEtBQUssVUFBVSxLQUFLLGlCQUFpQixLQUFLLE1BQU07Q0FDdEQ7Q0FDQSxnQkFBZ0I7RUFDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUc7R0FDekIsS0FBSyxXQUFXO0dBQ2hCLEtBQUssV0FBVyxLQUFLO0VBQ3RCO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJCQSxpQkFBaUIsT0FBTztFQUN2QixLQUFLLFNBQVM7RUFDZCxLQUFLLFdBQVc7RUFDaEIsS0FBSyxXQUFXLE9BQU8sWUFBWTtHQUNsQyxJQUFJLE9BQU8sWUFBWSxXQUFXLEtBQUssV0FBVyxPQUFPO1FBQ3BELEtBQUssUUFBUTtFQUNuQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsV0FBVyxTQUFTO0VBQ25CLElBQUksS0FBSyxhQUFhLFNBQVM7R0FDOUIsS0FBSyxXQUFXO0dBQ2hCLEtBQUssUUFBUTtFQUNkO0NBQ0Q7Ozs7Q0FJQSxVQUFVO0VBQ1QsTUFBTSxZQUFZLEtBQUssVUFBVTtFQUNqQyxLQUFLLFVBQVUsU0FBUyxhQUFhO0dBQ3BDLFNBQVMsU0FBUztFQUNuQixDQUFDO0NBQ0Y7Ozs7O0NBS0EsWUFBWTtFQUNYLElBQUksT0FBTyxLQUFLLGFBQWEsV0FBVyxPQUFPLEtBQUs7RUFDcEQsT0FBTyxXQUFXLFVBQVUsb0JBQW9CO0NBQ2pEO0FBQ0Q7Ozs7QUFJQSxJQUFNLGVBQWUsSUFBSSxhQUFhOztBQzlHdEMsSUFBTSx5QkFBeUI7Q0FDOUIsYUFBYSxVQUFVLFVBQVUsV0FBVyxVQUFVLEtBQUs7Q0FDM0QsZUFBZSxjQUFjLGFBQWEsU0FBUztDQUNuRCxjQUFjLFVBQVUsVUFBVSxZQUFZLFVBQVUsS0FBSztDQUM3RCxnQkFBZ0IsZUFBZSxjQUFjLFVBQVU7QUFDeEQ7Ozs7Ozs7Ozs7OztBQVlBLElBQUksaUJBQWlCLE1BQU07Q0FDMUIsWUFBWTtDQUNaLGtCQUFrQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQmxCLG1CQUFtQixVQUFVO0VBRTNCLElBQUksS0FBSyxtQkFBbUIsYUFBYSxLQUFLLFdBQVcsUUFBUSxNQUFNLDhHQUE4RztHQUNwTCxVQUFVLEtBQUs7R0FDZjtFQUNELENBQUM7RUFFRixLQUFLLFlBQVk7RUFDMEIsS0FBSyxrQkFBa0I7Q0FDbkU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJBLFdBQVcsVUFBVSxPQUFPO0VBQ2dCLEtBQUssa0JBQWtCO0VBQ2xFLE9BQU8sS0FBSyxVQUFVLFdBQVcsVUFBVSxLQUFLO0NBQ2pEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsYUFBYSxXQUFXO0VBQ3ZCLEtBQUssVUFBVSxhQUFhLFNBQVM7Q0FDdEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0JBLFlBQVksVUFBVSxPQUFPO0VBQ2UsS0FBSyxrQkFBa0I7RUFDbEUsT0FBTyxLQUFLLFVBQVUsWUFBWSxVQUFVLEtBQUs7Q0FDbEQ7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxjQUFjLFlBQVk7RUFDekIsS0FBSyxVQUFVLGNBQWMsVUFBVTtDQUN4QztBQUNEOzs7O0FBSUEsSUFBTSxpQkFBaUIsSUFBSSxlQUFlOzs7Ozs7Ozs7QUFTMUMsU0FBUyxxQkFBcUIsVUFBVTtDQUN2QyxXQUFXLFVBQVUsQ0FBQztBQUN2Qjs7Ozs7QUMzSkEsSUFBTUMsYUFBVyxPQUFPLFdBQVcsZUFBZSxVQUFVO0FBQzVELFNBQVMsT0FBTyxDQUFDOzs7Ozs7OztBQVFqQixTQUFTLGlCQUFpQixTQUFTLE9BQU87Q0FDekMsT0FBTyxPQUFPLFlBQVksYUFBYSxRQUFRLEtBQUssSUFBSTtBQUN6RDs7Ozs7O0FBTUEsU0FBUyxlQUFlLE9BQU87Q0FDOUIsT0FBTyxPQUFPLFVBQVUsWUFBWSxTQUFTLEtBQUssVUFBVTtBQUM3RDs7Ozs7Ozs7QUFRQSxTQUFTLGVBQWUsV0FBVyxXQUFXO0NBQzdDLE9BQU8sS0FBSyxJQUFJLGFBQWEsYUFBYSxLQUFLLEtBQUssSUFBSSxHQUFHLENBQUM7QUFDN0Q7Ozs7Ozs7O0FBUUEsU0FBUyxrQkFBa0IsT0FBTyxPQUFPO0NBQ3hDLE9BQU8sT0FBTyxVQUFVLGFBQWEsTUFBTSxLQUFLLElBQUk7QUFDckQ7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnQkEsU0FBUyxXQUFXLFNBQVMsT0FBTztDQUNuQyxNQUFNLEVBQUUsT0FBTyxPQUFPLE9BQU8sYUFBYSxXQUFXLFVBQVUsVUFBVTtDQUN6RSxJQUFJLFVBQVU7RUFDYixJQUFJLE9BQ0M7T0FBQSxNQUFNLGNBQWMsc0JBQXNCLFVBQVUsTUFBTSxPQUFPLEdBQUcsT0FBTztFQUFBLE9BQ3pFLElBQUksQ0FBQyxnQkFBZ0IsTUFBTSxVQUFVLFFBQVEsR0FBRyxPQUFPO0NBQy9EO0NBQ0EsSUFBSSxTQUFTLE9BQU87RUFDbkIsTUFBTSxXQUFXLE1BQU0sU0FBUztFQUNoQyxJQUFJLFNBQVMsWUFBWSxDQUFDLFVBQVUsT0FBTztFQUMzQyxJQUFJLFNBQVMsY0FBYyxVQUFVLE9BQU87Q0FDN0M7Q0FDQSxJQUFJLE9BQU8sVUFBVSxhQUFhLE1BQU0sUUFBUSxNQUFNLE9BQU8sT0FBTztDQUNwRSxJQUFJLGVBQWUsZ0JBQWdCLE1BQU0sTUFBTSxhQUFhLE9BQU87Q0FDbkUsSUFBSSxhQUFhLENBQUMsVUFBVSxLQUFLLEdBQUcsT0FBTztDQUMzQyxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQVMsY0FBYyxTQUFTLFVBQVU7Q0FDekMsTUFBTSxFQUFFLE9BQU8sUUFBUSxXQUFXLGdCQUFnQjtDQUNsRCxJQUFJLGFBQWE7RUFDaEIsSUFBSSxDQUFDLFNBQVMsUUFBUSxhQUFhLE9BQU87RUFDMUMsSUFBSSxPQUNDO09BQUEsUUFBUSxTQUFTLFFBQVEsV0FBVyxNQUFNLFFBQVEsV0FBVyxHQUFHLE9BQU87RUFBQSxPQUNyRSxJQUFJLENBQUMsZ0JBQWdCLFNBQVMsUUFBUSxhQUFhLFdBQVcsR0FBRyxPQUFPO0NBQ2hGO0NBQ0EsSUFBSSxVQUFVLFNBQVMsTUFBTSxXQUFXLFFBQVEsT0FBTztDQUN2RCxJQUFJLGFBQWEsQ0FBQyxVQUFVLFFBQVEsR0FBRyxPQUFPO0NBQzlDLE9BQU87QUFDUjs7Ozs7OztBQU9BLFNBQVMsc0JBQXNCLFVBQVUsU0FBUztDQUNqRCxRQUFRLFNBQVMsa0JBQWtCLFFBQUEsQ0FBUyxRQUFRO0FBQ3JEOzs7Ozs7Ozs7Ozs7QUFZQSxTQUFTLFFBQVEsVUFBVTtDQUMxQixPQUFPLEtBQUssVUFBVSxXQUFXLEdBQUcsUUFBUSxjQUFjLEdBQUcsSUFBSSxPQUFPLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxRQUFRLFFBQVE7RUFDaEgsT0FBTyxPQUFPLElBQUk7RUFDbEIsT0FBTztDQUNSLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRztBQUNiO0FBQ0EsU0FBUyxnQkFBZ0IsR0FBRyxHQUFHO0NBQzlCLElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxPQUFPLE1BQU0sT0FBTyxHQUFHLE9BQU87Q0FDbEMsSUFBSSxLQUFLLEtBQUssT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFVBQVU7RUFDN0QsSUFBSSxNQUFNLFFBQVEsQ0FBQyxNQUFNLE1BQU0sUUFBUSxDQUFDLEdBQUcsT0FBTztFQUNsRCxJQUFJLE1BQU0sUUFBUSxDQUFDLEtBQUssTUFBTSxRQUFRLENBQUMsR0FBRztHQUN6QyxJQUFJLEVBQUUsU0FBUyxFQUFFLFFBQVEsT0FBTztHQUNoQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxFQUFFLEdBQUcsT0FBTztHQUM1RSxPQUFPO0VBQ1I7RUFDQSxNQUFNLFFBQVEsT0FBTyxLQUFLLENBQUM7RUFDM0IsS0FBSyxNQUFNLE9BQU8sT0FBTyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLElBQUksR0FBRyxPQUFPO0VBQ3RFLE9BQU87Q0FDUjtDQUNBLE9BQU87QUFDUjtBQUNBLElBQU0sU0FBUyxPQUFPLFVBQVU7QUFDaEMsU0FBUyxpQkFBaUIsR0FBRyxHQUFHLFFBQVEsR0FBRztDQUMxQyxJQUFJLE1BQU0sR0FBRyxPQUFPO0NBQ3BCLElBQUksUUFBUSxLQUFLLE9BQU87Q0FDeEIsTUFBTSxRQUFRLGFBQWEsQ0FBQyxLQUFLLGFBQWEsQ0FBQztDQUMvQyxJQUFJLENBQUMsU0FBUyxFQUFFLGNBQWMsQ0FBQyxLQUFLLGNBQWMsQ0FBQyxJQUFJLE9BQU87Q0FDOUQsTUFBTSxTQUFTLFFBQVEsSUFBSSxPQUFPLEtBQUssQ0FBQyxFQUFBLENBQUc7Q0FDM0MsTUFBTSxTQUFTLFFBQVEsSUFBSSxPQUFPLEtBQUssQ0FBQztDQUN4QyxNQUFNLFFBQVEsT0FBTztDQUNyQixNQUFNLE9BQU8sUUFBUSxJQUFJLE1BQU0sS0FBSyxJQUFJLENBQUM7Q0FDekMsSUFBSSxhQUFhO0NBQ2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLEtBQUs7RUFDL0IsTUFBTSxNQUFNLFFBQVEsSUFBSSxPQUFPO0VBQy9CLE1BQU0sUUFBUSxFQUFFO0VBQ2hCLE1BQU0sUUFBUSxFQUFFO0VBQ2hCLElBQUksVUFBVSxPQUFPO0dBQ3BCLEtBQUssT0FBTztHQUNaLElBQUksUUFBUSxJQUFJLFFBQVEsT0FBTyxLQUFLLEdBQUcsR0FBRyxHQUFHO0dBQzdDO0VBQ0Q7RUFDQSxJQUFJLFVBQVUsUUFBUSxVQUFVLFFBQVEsT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFVBQVU7R0FDL0YsS0FBSyxPQUFPO0dBQ1o7RUFDRDtFQUNBLE1BQU0sSUFBSSxpQkFBaUIsT0FBTyxPQUFPLFFBQVEsQ0FBQztFQUNsRCxLQUFLLE9BQU87RUFDWixJQUFJLE1BQU0sT0FBTztDQUNsQjtDQUNBLE9BQU8sVUFBVSxTQUFTLGVBQWUsUUFBUSxJQUFJO0FBQ3REOzs7Ozs7O0FBT0EsU0FBUyxvQkFBb0IsR0FBRyxHQUFHO0NBQ2xDLElBQUksQ0FBQyxLQUFLLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLE9BQU87Q0FDbEUsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxLQUFLLEdBQUcsR0FBRyxLQUFLLEVBQUUsU0FBUyxFQUFFLE1BQU0sT0FBTztDQUN4RixPQUFPO0FBQ1I7Ozs7OztBQU1BLFNBQVMsYUFBYSxPQUFPO0NBQzVCLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBSyxNQUFNLFdBQVcsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQ3BFOzs7Ozs7O0FBT0EsU0FBUyxjQUFjLEdBQUc7Q0FDekIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsT0FBTztDQUNuQyxNQUFNLGtCQUFrQixPQUFPLGVBQWUsQ0FBQztDQUMvQyxNQUFNLE9BQU8saUJBQWlCO0NBQzlCLElBQUksU0FBUyxLQUFLLEdBQUcsT0FBTztDQUM1QixJQUFJLE9BQU8sU0FBUyxZQUFZLE9BQU87Q0FDdkMsTUFBTSxPQUFPLEtBQUs7Q0FDbEIsSUFBSSxDQUFDLG1CQUFtQixJQUFJLEdBQUcsT0FBTztDQUN0QyxJQUFJLENBQUMsS0FBSyxlQUFlLGVBQWUsR0FBRyxPQUFPO0NBQ2xELElBQUksb0JBQW9CLE9BQU8sV0FBVyxPQUFPO0NBQ2pELE9BQU87QUFDUjs7Ozs7O0FBTUEsU0FBUyxtQkFBbUIsR0FBRztDQUM5QixPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNO0FBQzlDOzs7Ozs7QUFNQSxTQUFTLE1BQU0sU0FBUztDQUN2QixPQUFPLElBQUksU0FBUyxZQUFZO0VBQy9CLGVBQWUsV0FBVyxTQUFTLE9BQU87Q0FDM0MsQ0FBQztBQUNGOzs7Ozs7Ozs7OztBQVdBLFNBQVMsWUFBWSxVQUFVLE1BQU0sU0FBUztDQUM3QyxJQUFJLE9BQU8sUUFBUSxzQkFBc0IsWUFBWSxPQUFPLFFBQVEsa0JBQWtCLFVBQVUsSUFBSTtNQUMvRixJQUFJLFFBQVEsc0JBQXNCLE9BQ0ssSUFBSTtFQUM5QyxPQUFPLGlCQUFpQixVQUFVLElBQUk7Q0FDdkMsU0FBUyxPQUFPO0VBQ2YsUUFBUSxNQUFNLDBKQUEwSixRQUFRLFVBQVUsS0FBSyxPQUFPO0VBQ3RNLE1BQU07Q0FDUDtDQUdELE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7OztBQWdCQSxTQUFTLGlCQUFpQixjQUFjO0NBQ3ZDLE9BQU87QUFDUjs7Ozs7Ozs7OztBQVVBLFNBQVMsV0FBVyxPQUFPLE1BQU0sS0FBSyxTQUFTO0NBQzlDLE1BQU0sV0FBVyxVQUFVLENBQUMsTUFBTSxHQUFHLEtBQUssSUFBSSxDQUFDLEdBQUcsT0FBTyxJQUFJO0NBQzdELElBQUksT0FBTyxTQUFTLFNBQVMsS0FBSyxPQUFPLFVBQVUsU0FBUyxNQUFNLEdBQUcsR0FBRyxJQUFJLFNBQVMsTUFBTSxDQUFDLEdBQUc7Q0FDL0YsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7O0FBYUEsSUFBTSxZQUFZLE9BQU87Ozs7Ozs7OztBQVN6QixTQUFTLGNBQWMsU0FBUyxjQUFjO0NBRTVDLElBQUksUUFBUSxZQUFZLFdBQVcsUUFBUSxNQUFNLHlHQUF5RyxRQUFRLFVBQVUsRUFBRTtDQUUvSyxJQUFJLENBQUMsUUFBUSxXQUFXLGNBQWMsZ0JBQWdCLGFBQWEsYUFBYTtDQUNoRixJQUFJLENBQUMsUUFBUSxXQUFXLFFBQVEsWUFBWSxXQUFXLGFBQWEsUUFBUSx1QkFBdUIsSUFBSSxNQUFNLHFCQUFxQixRQUFRLFVBQVUsRUFBRSxDQUFDO0NBQ3ZKLE9BQU8sUUFBUTtBQUNoQjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxTQUFTLGlCQUFpQixjQUFjLFFBQVE7Q0FDL0MsSUFBSSxPQUFPLGlCQUFpQixZQUFZLE9BQU8sYUFBYSxHQUFHLE1BQU07Q0FDckUsT0FBTyxDQUFDLENBQUM7QUFDVjtBQUNBLElBQU0sY0FBYyxPQUFPOzs7Ozs7Ozs7OztBQVczQixTQUFTLHNCQUFzQixRQUFRLFdBQVcsYUFBYSxnQkFBZ0I7Q0FDOUUsSUFBSSxXQUFXO0NBQ2YsSUFBSTtDQUNKLE9BQU8saUJBQWlCLFFBQVE7R0FDOUIsY0FBYyxFQUFFLE9BQU8sZUFBZTtFQUN2QyxRQUFRO0dBQ1AsWUFBWTtHQUNaLFdBQVc7SUFDVixXQUFXLFVBQVU7SUFDckIsSUFBSSxVQUFVLE9BQU87SUFDckIsV0FBVztJQUNYLElBQUksT0FBTyxTQUFTLFlBQVk7U0FDM0IsT0FBTyxpQkFBaUIsU0FBUyxhQUFhLEVBQUUsTUFBTSxLQUFLLENBQUM7SUFDakUsT0FBTztHQUNSO0VBQ0Q7Q0FDRCxDQUFDO0NBQ0QsT0FBTztBQUNSOztBQzdXQSxJQUFJLG1CQUFtQjs7Ozs7QUFLdkIsSUFBTSxpQkFBaUIsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQmxDLElBQU0scUJBQXFCO0NBQzFCOzs7Ozs7Q0FNQSxZQUFZLGVBQWU7RUFDMUIsYUFBYTtDQUNkO0FBQ0Q7Ozs7Ozs7OztBQ3pCQSxTQUFTLGVBQWUsU0FBUztDQUNoQyxJQUFJO0NBQ0osUUFBUSxNQUFNLFdBQVc7RUFDeEIsT0FBTztFQUNQLE9BQU87Q0FDUixHQUFHLElBQUksQ0FBQyxFQUFFLFFBQVEsSUFBSTtDQUN0QixJQUFJLFNBQVMsS0FBSyxHQUFHLE9BQU8sRUFBRSxLQUFLO0FBQ3BDOzs7Ozs7QUFNQSxTQUFTLGtCQUFrQixVQUFVO0NBQ3BDLE9BQU87RUFDTixhQUFhLFNBQVMsUUFBUTtFQUM5QixPQUFPLFNBQVM7RUFDaEIsR0FBRyxTQUFTLFFBQVEsU0FBUyxFQUFFLE9BQU8sU0FBUyxRQUFRLE1BQU07RUFDN0QsR0FBRyxTQUFTLFFBQVEsRUFBRSxNQUFNLFNBQVMsS0FBSztDQUMzQztBQUNEOzs7Ozs7Ozs7OztBQVdBLFNBQVMsaUJBQWlCLE9BQU8sZUFBZSxvQkFBb0I7Q0FDbkUsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLGFBQWEsQ0FBQyxDQUFDLE9BQU8sVUFBVTtFQUNuRSxJQUFJLHFCQUFxQixLQUFLLE1BQU0sT0FBTyxPQUFPLFFBQVEsT0FBTyxLQUFLO0VBQzNCLFFBQVEsTUFBTSwrREFBK0QsTUFBTSxVQUFVLEtBQUssTUFBTSxrREFBa0Q7RUFDck0sT0FBTyxRQUFRLHVCQUF1QixJQUFJLE1BQU0sVUFBVSxDQUFDO0NBQzVELENBQUM7Q0FDRCxTQUFTLE1BQU0sSUFBSTtDQUNuQixPQUFPO0FBQ1I7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsZUFBZSxPQUFPLGVBQWUsb0JBQW9CO0NBQ2pFLE9BQU87RUFDTixjQUFjLEtBQUssSUFBSTtFQUN2QixPQUFPO0dBQ04sR0FBRyxNQUFNO0dBQ1QsR0FBRyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxNQUFNLGdCQUFnQixjQUFjLE1BQU0sTUFBTSxJQUFJLElBQUksTUFBTSxNQUFNLEtBQUs7RUFDOUc7RUFDQSxVQUFVLE1BQU07RUFDaEIsV0FBVyxNQUFNO0VBQ2pCLEdBQUcsTUFBTSxNQUFNLFdBQVcsYUFBYSxFQUFFLFNBQVMsaUJBQWlCLE9BQU8sZUFBZSxrQkFBa0IsRUFBRTtFQUM3RyxHQUFHLE1BQU0sUUFBUSxFQUFFLE1BQU0sTUFBTSxLQUFLO0VBQ3BDLEdBQUcsTUFBTSxhQUFhLEVBQUUsV0FBVyxNQUFNLFVBQVU7Q0FDcEQ7QUFDRDs7Ozs7OztBQU9BLFNBQVMsK0JBQStCLFVBQVU7Q0FDakQsT0FBTyxTQUFTLE1BQU07QUFDdkI7Ozs7Ozs7QUFPQSxTQUFTLDRCQUE0QixPQUFPO0NBQzNDLE9BQU8sTUFBTSxNQUFNLFdBQVc7QUFDL0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUJBLFNBQVMsVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQ3hDLE1BQU0saUJBQWlCLFFBQVEsMkJBQTJCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXLDJCQUEyQjtDQUMzSCxNQUFNLFlBQVksT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsYUFBYSxlQUFlLFFBQVEsSUFBSSxDQUFDLGtCQUFrQixRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7Q0FDeEksTUFBTSxjQUFjLFFBQVEsd0JBQXdCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXLHdCQUF3QjtDQUNsSCxNQUFNLHFCQUFxQixRQUFRLHNCQUFzQixPQUFPLGtCQUFrQixDQUFDLENBQUMsV0FBVztDQUMvRixNQUFNLGdCQUFnQixRQUFRLGlCQUFpQixPQUFPLGtCQUFrQixDQUFDLENBQUMsV0FBVztDQUNyRixPQUFPO0VBQ047RUFDQSxTQUFTLE9BQU8sY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVLFlBQVksS0FBSyxJQUFJLENBQUMsZUFBZSxPQUFPLGVBQWUsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7Q0FDako7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXNCQSxTQUFTLFFBQVEsUUFBUSxpQkFBaUIsU0FBUztDQUNsRCxNQUFNLGdCQUFnQixPQUFPLGlCQUFpQjtDQUM5QyxNQUFNLGFBQWEsT0FBTyxjQUFjO0NBQ3hDLE1BQU0sa0JBQWtCLFNBQVMsZ0JBQWdCLG1CQUFtQixPQUFPLGtCQUFrQixDQUFDLENBQUMsU0FBUztDQUN4RyxnQkFBZ0IsV0FBVyxTQUFTLEVBQUUsT0FBTyxHQUFHLHNCQUFzQjtFQUNyRSxjQUFjLE1BQU0sUUFBUTtHQUMzQixHQUFHLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxTQUFTO0dBQ3ZDLEdBQUcsU0FBUyxnQkFBZ0I7R0FDNUIsR0FBRztFQUNKLEdBQUcsS0FBSztDQUNULENBQUM7Q0FDRCxnQkFBZ0IsU0FBUyxTQUFTLEVBQUUsVUFBVSxPQUFPLFdBQVcsTUFBTSxTQUFTLGNBQWMsZ0JBQWdCO0VBQzVHLE1BQU0sV0FBVyxVQUFVLGVBQWUsT0FBTyxJQUFJLEtBQUs7RUFDMUQsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLElBQUksVUFBVSxPQUFPLE1BQU07RUFDL0QsTUFBTSxPQUFPLFlBQVksS0FBSyxJQUFJLFVBQVUsa0JBQWtCLGdCQUFnQixPQUFPLElBQUk7RUFDekYsSUFBSSxRQUFRLFdBQVcsSUFBSSxTQUFTO0VBQ3BDLE1BQU0seUJBQXlCLE9BQU8sTUFBTSxXQUFXO0VBQ3ZELE1BQU0sMEJBQTBCLE9BQU8sTUFBTSxnQkFBZ0I7RUFDN0QsSUFBSSxPQUFPO0dBQ1YsTUFBTSxtQkFBbUIsWUFBWSxlQUFlLE1BQU0sTUFBTTtHQUNoRSxJQUFJLE1BQU0sZ0JBQWdCLE1BQU0sTUFBTSxpQkFBaUIsa0JBQWtCO0lBQ3hFLE1BQU0sRUFBRSxhQUFhLFVBQVUsR0FBRyxvQkFBb0I7SUFDdEQsTUFBTSxTQUFTO0tBQ2QsR0FBRztLQUNIO0tBQ0EsR0FBRyxNQUFNLFdBQVcsYUFBYSxTQUFTLEtBQUssS0FBSztNQUNuRCxRQUFRO01BQ1IsZUFBZTtNQUNmLEdBQUcsQ0FBQywyQkFBMkIsRUFBRSxhQUFhLE9BQU87S0FDdEQ7SUFDRCxDQUFDO0dBQ0Y7RUFDRCxPQUFPLFFBQVEsV0FBVyxNQUFNLFFBQVE7R0FDdkMsR0FBRyxPQUFPLGtCQUFrQixDQUFDLENBQUMsU0FBUztHQUN2QyxHQUFHLFNBQVMsZ0JBQWdCO0dBQzVCO0dBQ0E7R0FDQTtHQUNBLE9BQU87RUFDUixHQUFHO0dBQ0YsR0FBRztHQUNIO0dBQ0EsYUFBYTtHQUNiLFFBQVEsTUFBTSxXQUFXLGFBQWEsU0FBUyxLQUFLLElBQUksWUFBWSxNQUFNO0dBQzFFLEdBQUcsTUFBTSxXQUFXLGFBQWEsU0FBUyxLQUFLLEtBQUssRUFBRSxlQUFlLGFBQWE7RUFDbkYsQ0FBQztFQUNELElBQUksV0FBVyxDQUFDLFlBQVksQ0FBQywwQkFBMEIsQ0FBQywyQkFBMkIsZUFBZSxNQUFNLE1BQU0sZUFBZSxNQUFNLE1BQU0sS0FBSyxHQUFHLEVBQUUsZ0JBQWdCLFFBQVEsUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDaE8sQ0FBQztBQUNGOzs7Ozs7Ozs7O0FDeExBLFNBQVMsc0JBQXNCLE9BQU87Q0FDckMsT0FBTyxFQUFFLFVBQVUsU0FBUyxVQUFVO0VBQ3JDLE1BQU0sVUFBVSxRQUFRO0VBQ3hCLE1BQU0sWUFBWSxRQUFRLGNBQWMsTUFBTSxXQUFXO0VBQ3pELE1BQU0sV0FBVyxRQUFRLE1BQU0sTUFBTSxTQUFTLENBQUM7RUFDL0MsTUFBTSxnQkFBZ0IsUUFBUSxNQUFNLE1BQU0sY0FBYyxDQUFDO0VBQ3pELElBQUksU0FBUztHQUNaLE9BQU8sQ0FBQztHQUNSLFlBQVksQ0FBQztFQUNkO0VBQ0EsSUFBSSxjQUFjO0VBQ2xCLE1BQU0sVUFBVSxZQUFZO0dBQzNCLElBQUksWUFBWTtHQUNoQixNQUFNLGdCQUFnQjtHQUN0QixNQUFNLHFCQUFxQixXQUFXO0lBQ3JDLHNCQUFzQixjQUFjLFFBQVEsY0FBYyxZQUFZLE1BQU0sY0FBYyxZQUFZO0dBQ3ZHO0dBQ0EsTUFBTSxVQUFVLGNBQWMsUUFBUSxTQUFTLFFBQVEsWUFBWTtHQUNuRSxNQUFNLFlBQVksT0FBTyxNQUFNLE9BQU8sYUFBYTtJQUNsRCxJQUFJLFdBQVcsT0FBTyxRQUFRLE9BQU8sUUFBUSxPQUFPLE1BQU07SUFDMUQsSUFBSSxTQUFTLFFBQVEsS0FBSyxNQUFNLFFBQVEsT0FBTyxRQUFRLFFBQVEsSUFBSTtJQUNuRSxNQUFNLDZCQUE2QjtLQUNsQyxNQUFNLGlCQUFpQjtNQUN0QixRQUFRLFFBQVE7TUFDaEIsVUFBVSxRQUFRO01BQ2xCLFdBQVc7TUFDWCxXQUFXLFdBQVcsYUFBYTtNQUNuQyxNQUFNLFFBQVEsUUFBUTtLQUN2QjtLQUNBLGtCQUFrQixjQUFjO0tBQ2hDLE9BQU87SUFDUjtJQUNBLE1BQU0saUJBQWlCLHFCQUFxQjtJQUM1QyxNQUFNLE9BQU8sTUFBTSxRQUFRLGNBQWM7SUFDekMsTUFBTSxFQUFFLGFBQWEsUUFBUTtJQUM3QixPQUFPO0tBQ04sT0FBTyxXQUFXLEtBQUssT0FBTyxNQUFNLFVBQVUsUUFBUTtLQUN0RCxZQUFZLFdBQVcsS0FBSyxZQUFZLE9BQU8sVUFBVSxRQUFRO0lBQ2xFO0dBQ0Q7R0FDQSxJQUFJLGFBQWEsU0FBUyxRQUFRO0lBQ2pDLE1BQU0sV0FBVyxjQUFjO0lBQy9CLE1BQU0sY0FBYyxXQUFXLHVCQUF1QjtJQUN0RCxNQUFNLFVBQVU7S0FDZixPQUFPO0tBQ1AsWUFBWTtJQUNiO0lBQ0EsU0FBUyxNQUFNLFVBQVUsU0FBUyxZQUFZLFNBQVMsT0FBTyxHQUFHLFFBQVE7R0FDMUUsT0FBTztJQUNOLE1BQU0saUJBQWlCLFNBQVMsU0FBUztJQUN6QyxHQUFHO0tBQ0YsTUFBTSxRQUFRLGdCQUFnQixJQUFJLGNBQWMsT0FBTyxLQUFLLElBQUksUUFBUSxtQkFBbUIsY0FBYyxLQUFLLGlCQUFpQixTQUFTLE1BQU07S0FDOUksSUFBSSxjQUFjLEtBQUssU0FBUyxNQUFNO0tBQ3RDLFNBQVMsTUFBTSxVQUFVLFFBQVEsS0FBSztLQUN0QztJQUNELFNBQVMsY0FBYztHQUN4QjtHQUNBLE9BQU87RUFDUjtFQUNBLElBQUksUUFBUSxRQUFRLFdBQVcsUUFBUSxnQkFBZ0I7R0FDdEQsT0FBTyxRQUFRLFFBQVEsWUFBWSxTQUFTO0lBQzNDLFFBQVEsUUFBUTtJQUNoQixVQUFVLFFBQVE7SUFDbEIsTUFBTSxRQUFRLFFBQVE7SUFDdEIsUUFBUSxRQUFRO0dBQ2pCLEdBQUcsS0FBSztFQUNUO09BQ0ssUUFBUSxVQUFVO0NBQ3hCLEVBQUU7QUFDSDs7Ozs7OztBQU9BLFNBQVMsaUJBQWlCLFNBQVMsRUFBRSxPQUFPLGNBQWM7Q0FDekQsTUFBTSxZQUFZLE1BQU0sU0FBUztDQUNqQyxPQUFPLE1BQU0sU0FBUyxJQUFJLFFBQVEsaUJBQWlCLE1BQU0sWUFBWSxPQUFPLFdBQVcsWUFBWSxVQUFVLElBQUksS0FBSztBQUN2SDs7Ozs7Ozs7O0FBU0EsU0FBUyxxQkFBcUIsU0FBUyxFQUFFLE9BQU8sY0FBYztDQUM3RCxPQUFPLE1BQU0sU0FBUyxJQUFJLFFBQVEsdUJBQXVCLE1BQU0sSUFBSSxPQUFPLFdBQVcsSUFBSSxVQUFVLElBQUksS0FBSztBQUM3Rzs7Ozs7OztBQU9BLFNBQVMsWUFBWSxTQUFTLE1BQU07Q0FDbkMsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixPQUFPLGlCQUFpQixTQUFTLElBQUksS0FBSztBQUMzQzs7Ozs7Ozs7QUFRQSxTQUFTLGdCQUFnQixTQUFTLE1BQU07Q0FDdkMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLHNCQUFzQixPQUFPO0NBQ25ELE9BQU8scUJBQXFCLFNBQVMsSUFBSSxLQUFLO0FBQy9DOzs7Ozs7QUNuSEEsSUFBTSxtQkFBbUI7Ozs7OztBQU16QixTQUFTLHNCQUFzQjtDQUM5QixJQUFJLFFBQVEsQ0FBQztDQUNiLElBQUksZUFBZTtDQUNuQixJQUFJLFlBQVksYUFBYTtFQUM1QixTQUFTO0NBQ1Y7Q0FDQSxJQUFJLGlCQUFpQixhQUFhO0VBQ2pDLFNBQVM7Q0FDVjtDQUNBLElBQUksYUFBYTtDQUNqQixNQUFNLFlBQVksYUFBYTtFQUM5QixJQUFJLGNBQWMsTUFBTSxLQUFLLFFBQVE7T0FDaEMsaUJBQWlCO0dBQ3JCLFNBQVMsUUFBUTtFQUNsQixDQUFDO0NBQ0Y7Q0FDQSxNQUFNLGNBQWM7RUFDbkIsTUFBTSxnQkFBZ0I7RUFDdEIsUUFBUSxDQUFDO0VBQ1QsSUFBSSxjQUFjLFFBQVEsaUJBQWlCO0dBQzFDLG9CQUFvQjtJQUNuQixjQUFjLFNBQVMsYUFBYTtLQUNuQyxTQUFTLFFBQVE7SUFDbEIsQ0FBQztHQUNGLENBQUM7RUFDRixDQUFDO0NBQ0Y7Q0FDQSxPQUFPOzs7Ozs7Ozs7RUFTTixRQUFRLGFBQWE7R0FDcEIsSUFBSTtHQUNKO0dBQ0EsSUFBSTtJQUNILFNBQVMsU0FBUztHQUNuQixVQUFVO0lBQ1Q7SUFDQSxJQUFJLENBQUMsY0FBYyxNQUFNO0dBQzFCO0dBQ0EsT0FBTztFQUNSOzs7Ozs7RUFNQSxhQUFhLGFBQWE7R0FDekIsUUFBUSxHQUFHLFNBQVM7SUFDbkIsZUFBZTtLQUNkLFNBQVMsR0FBRyxJQUFJO0lBQ2pCLENBQUM7R0FDRjtFQUNEOzs7OztFQUtBOzs7Ozs7RUFNQSxvQkFBb0IsT0FBTztHQUMxQixXQUFXO0VBQ1o7Ozs7Ozs7Ozs7Ozs7O0VBY0EseUJBQXlCLE9BQU87R0FDL0IsZ0JBQWdCO0VBQ2pCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBbUJBLGVBQWUsT0FBTztHQUNyQixhQUFhO0VBQ2Q7Q0FDRDtBQUNEOzs7O0FBSUEsSUFBTSxnQkFBZ0Isb0JBQW9COzs7Ozs7QUN0SDFDLElBQUksWUFBWSxNQUFNO0NBQ3JCOzs7Ozs7Q0FNQSxVQUFVO0VBQ1QsS0FBSyxlQUFlO0NBQ3JCOzs7OztDQUtBLGFBQWE7RUFDWixLQUFLLGVBQWU7RUFDcEIsSUFBSSxlQUFlLEtBQUssTUFBTSxHQUFHLEtBQUssYUFBYSxlQUFlLGlCQUFpQjtHQUNsRixLQUFLLGVBQWU7RUFDckIsR0FBRyxLQUFLLE1BQU07Q0FDZjs7Ozs7O0NBTUEsYUFBYSxXQUFXO0VBQ3ZCLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxVQUFVLEdBQUcsY0FBYyxTQUFTLElBQUksUUFBVyxJQUFJO0NBQ3BGOzs7O0NBSUEsaUJBQWlCO0VBQ2hCLElBQUksS0FBSyxlQUFlLEtBQUssR0FBRztHQUMvQixlQUFlLGFBQWEsS0FBSyxVQUFVO0dBQzNDLEtBQUssYUFBYSxLQUFLO0VBQ3hCO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7QUNsQ0EsSUFBSSxnQkFBZ0IsY0FBYyxhQUFhO0NBQzlDLFVBQVU7Q0FDVjtDQUNBO0NBQ0EsY0FBYztFQUNiLE1BQU07RUFDTixLQUFLLFVBQVUsYUFBYTtHQUMzQixJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sa0JBQWtCO0lBQzdELE1BQU0sdUJBQXVCLFNBQVMsSUFBSTtJQUMxQyxNQUFNLHdCQUF3QixTQUFTLEtBQUs7SUFDNUMsT0FBTyxpQkFBaUIsVUFBVSxnQkFBZ0IsS0FBSztJQUN2RCxPQUFPLGlCQUFpQixXQUFXLGlCQUFpQixLQUFLO0lBQ3pELGFBQWE7S0FDWixPQUFPLG9CQUFvQixVQUFVLGNBQWM7S0FDbkQsT0FBTyxvQkFBb0IsV0FBVyxlQUFlO0lBQ3REO0dBQ0Q7RUFDRDtDQUNEO0NBQ0EsY0FBYztFQUNiLElBQUksQ0FBQyxLQUFLLFVBQVUsS0FBSyxpQkFBaUIsS0FBSyxNQUFNO0NBQ3REO0NBQ0EsZ0JBQWdCO0VBQ2YsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUFHO0dBQ3pCLEtBQUssV0FBVztHQUNoQixLQUFLLFdBQVcsS0FBSztFQUN0QjtDQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9CQSxpQkFBaUIsT0FBTztFQUN2QixLQUFLLFNBQVM7RUFDZCxLQUFLLFdBQVc7RUFDaEIsS0FBSyxXQUFXLE1BQU0sS0FBSyxVQUFVLEtBQUssSUFBSSxDQUFDO0NBQ2hEOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxVQUFVLFFBQVE7RUFDakIsSUFBSSxLQUFLLFlBQVksUUFBUTtHQUM1QixLQUFLLFVBQVU7R0FDZixLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ3BDLFNBQVMsTUFBTTtHQUNoQixDQUFDO0VBQ0Y7Q0FDRDs7Ozs7Q0FLQSxXQUFXO0VBQ1YsT0FBTyxLQUFLO0NBQ2I7QUFDRDs7OztBQUlBLElBQU0sZ0JBQWdCLElBQUksY0FBYzs7Ozs7OztBQ3RGeEMsU0FBUyxrQkFBa0IsY0FBYztDQUN4QyxPQUFPLEtBQUssSUFBSSxNQUFNLEtBQUssY0FBYyxHQUFHO0FBQzdDOzs7Ozs7QUFNQSxTQUFTLFNBQVMsYUFBYTtDQUM5QixRQUFRLGVBQWUsY0FBYyxXQUFXLGNBQWMsU0FBUyxJQUFJO0FBQzVFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUJBLElBQUksaUJBQWlCLGNBQWMsTUFBTTtDQUN4QyxZQUFZLFNBQVM7RUFDcEIsTUFBTSxnQkFBZ0I7RUFDdEIsS0FBSyxTQUFTLFNBQVM7RUFDdkIsS0FBSyxTQUFTLFNBQVM7Q0FDeEI7QUFDRDs7Ozs7OztBQU9BLFNBQVMsaUJBQWlCLE9BQU87Q0FDaEMsT0FBTyxpQkFBaUI7QUFDekI7Ozs7Ozs7Ozs7QUFVQSxTQUFTLGNBQWMsUUFBUTtDQUM5QixJQUFJLG1CQUFtQjtDQUN2QixJQUFJLGVBQWU7Q0FDbkIsSUFBSTtDQUNKLElBQUksU0FBUztDQUNiLElBQUk7Q0FDSixJQUFJO0NBQ0osTUFBTSxVQUFVLElBQUksU0FBUyxTQUFTLFdBQVc7RUFDaEQsaUJBQWlCO0VBQ2pCLGdCQUFnQjtDQUNqQixDQUFDO0NBQ0QsUUFBUSxNQUFNLElBQUk7Q0FDbEIsTUFBTSxtQkFBbUIsV0FBVztDQUNwQyxNQUFNLFVBQVUsa0JBQWtCO0VBQ2pDLElBQUksQ0FBQyxXQUFXLEdBQUc7R0FDbEIsTUFBTSxRQUFRLElBQUksZUFBZSxhQUFhO0dBQzlDLE9BQU8sS0FBSztHQUNaLE9BQU8sV0FBVyxLQUFLO0VBQ3hCO0NBQ0Q7Q0FDQSxNQUFNLG9CQUFvQjtFQUN6QixtQkFBbUI7Q0FDcEI7Q0FDQSxNQUFNLHNCQUFzQjtFQUMzQixtQkFBbUI7Q0FDcEI7Q0FDQSxNQUFNLG9CQUFvQixhQUFhLFVBQVUsTUFBTSxPQUFPLGdCQUFnQixZQUFZLGNBQWMsU0FBUyxNQUFNLE9BQU8sT0FBTztDQUNySSxNQUFNLGlCQUFpQixTQUFTLE9BQU8sV0FBVyxLQUFLLE9BQU8sT0FBTztDQUNyRSxNQUFNLFdBQVcsVUFBVTtFQUMxQixJQUFJLENBQUMsV0FBVyxHQUFHO0dBQ2xCLGFBQWE7R0FDYixTQUFTO0dBQ1QsZUFBZSxLQUFLO0VBQ3JCO0NBQ0Q7Q0FDQSxNQUFNLFVBQVUsVUFBVTtFQUN6QixJQUFJLENBQUMsV0FBVyxHQUFHO0dBQ2xCLGFBQWE7R0FDYixTQUFTO0dBQ1QsY0FBYyxLQUFLO0VBQ3BCO0NBQ0Q7Q0FDQSxNQUFNLFNBQVMsY0FBYztFQUM1QixPQUFPLElBQUksU0FBUyxvQkFBb0I7R0FDdkMsY0FBYyxVQUFVO0lBQ3ZCLElBQUksV0FBVyxLQUFLLFVBQVUsR0FBRyxnQkFBZ0IsS0FBSztHQUN2RDtHQUNBLE9BQU8sVUFBVTtFQUNsQixDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQ2IsYUFBYSxLQUFLO0dBQ2xCLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxhQUFhO0VBQ3hDLENBQUM7Q0FDRjtDQUNBLE1BQU0sWUFBWTtFQUNqQixJQUFJLFdBQVcsR0FBRztFQUNsQixJQUFJO0VBQ0osTUFBTSxpQkFBaUIsaUJBQWlCLElBQUksT0FBTyxpQkFBaUIsS0FBSztFQUN6RSxJQUFJO0dBQ0gsaUJBQWlCLGtCQUFrQixPQUFPLEdBQUc7RUFDOUMsU0FBUyxPQUFPO0dBQ2YsaUJBQWlCLFFBQVEsT0FBTyxLQUFLO0VBQ3RDO0VBQ0EsUUFBUSxRQUFRLGNBQWMsQ0FBQyxDQUFDLEtBQUssT0FBTyxDQUFDLENBQUMsT0FBTyxVQUFVO0dBQzlELElBQUksV0FBVyxHQUFHO0dBQ2xCLE1BQU0sUUFBUSxPQUFPLFVBQVUsU0FBUyxJQUFJLElBQUk7R0FDaEQsTUFBTSxhQUFhLE9BQU8sY0FBYztHQUN4QyxNQUFNLFFBQVEsT0FBTyxlQUFlLGFBQWEsV0FBVyxjQUFjLEtBQUssSUFBSTtHQUNuRixNQUFNLGNBQWMsVUFBVSxRQUFRLE9BQU8sVUFBVSxZQUFZLGVBQWUsU0FBUyxPQUFPLFVBQVUsY0FBYyxNQUFNLGNBQWMsS0FBSztHQUNuSixJQUFJLG9CQUFvQixDQUFDLGFBQWE7SUFDckMsT0FBTyxLQUFLO0lBQ1o7R0FDRDtHQUNBO0dBQ0EsT0FBTyxTQUFTLGNBQWMsS0FBSztHQUNuQyxNQUFNLEtBQUssQ0FBQyxDQUFDLFdBQVc7SUFDdkIsT0FBTyxXQUFXLEtBQUssWUFBWSxJQUFJLEtBQUssSUFBSSxNQUFNLFdBQVc7R0FDbEUsQ0FBQyxDQUFDLENBQUMsV0FBVztJQUNiLElBQUksa0JBQWtCLE9BQU8sS0FBSztTQUM3QixJQUFJO0dBQ1YsQ0FBQztFQUNGLENBQUM7Q0FDRjtDQUNBLE9BQU87RUFDTjtFQUNBLGNBQWM7RUFDZDtFQUNBLGdCQUFnQjtHQUNmLGFBQWE7R0FDYixPQUFPO0VBQ1I7RUFDQTtFQUNBO0VBQ0E7RUFDQSxhQUFhO0dBQ1osSUFBSSxTQUFTLEdBQUcsSUFBSTtRQUNmLE1BQU0sUUFBUSxDQUFDLENBQUMsS0FBSyxHQUFHO0dBQzdCLE9BQU87RUFDUjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0lBLElBQUksUUFBUSxjQUFjLFVBQVU7Q0FDbkM7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxRQUFRO0VBQ25CLE1BQU07RUFDTixLQUFLLHVCQUF1QjtFQUM1QixLQUFLLGtCQUFrQixPQUFPO0VBQzlCLEtBQUssV0FBVyxPQUFPLE9BQU87RUFDOUIsS0FBSyxZQUFZLENBQUM7RUFDbEIsS0FBSyxVQUFVLE9BQU87RUFDdEIsS0FBSyxTQUFTLEtBQUssUUFBUSxjQUFjO0VBQ3pDLEtBQUssV0FBVyxPQUFPO0VBQ3ZCLEtBQUssWUFBWSxPQUFPO0VBQ3hCLEtBQUssZ0JBQWdCQyxrQkFBZ0IsS0FBSyxPQUFPO0VBQ2pELEtBQUssUUFBUSxPQUFPLFNBQVMsS0FBSztFQUNsQyxLQUFLLFdBQVc7Q0FDakI7Ozs7O0NBS0EsSUFBSSxPQUFPO0VBQ1YsT0FBTyxLQUFLLFFBQVE7Q0FDckI7Ozs7OztDQU1BLElBQUksWUFBWTtFQUNmLE9BQU8sS0FBSztDQUNiOzs7Ozs7Q0FNQSxJQUFJLFVBQVU7RUFDYixPQUFPLEtBQUssVUFBVTtDQUN2Qjs7Ozs7OztDQU9BLFdBQVcsU0FBUztFQUNuQixLQUFLLFVBQVU7R0FDZCxHQUFHLEtBQUs7R0FDUixHQUFHO0VBQ0o7RUFDQSxJQUFJLFNBQVMsT0FBTyxLQUFLLGFBQWEsUUFBUTtFQUM5QyxLQUFLLGFBQWEsS0FBSyxRQUFRLE1BQU07RUFDckMsSUFBSSxLQUFLLFNBQVMsS0FBSyxNQUFNLFNBQVMsS0FBSyxHQUFHO0dBQzdDLE1BQU0sZUFBZUEsa0JBQWdCLEtBQUssT0FBTztHQUNqRCxJQUFJLGFBQWEsU0FBUyxLQUFLLEdBQUc7SUFDakMsS0FBSyxTQUFTLGFBQWEsYUFBYSxNQUFNLGFBQWEsYUFBYSxDQUFDO0lBQ3pFLEtBQUssZ0JBQWdCO0dBQ3RCO0VBQ0Q7Q0FDRDtDQUNBLGlCQUFpQjtFQUNoQixJQUFJLENBQUMsS0FBSyxVQUFVLFVBQVUsS0FBSyxNQUFNLGdCQUFnQixRQUFRLEtBQUssT0FBTyxPQUFPLElBQUk7Q0FDekY7Ozs7Ozs7OztDQVNBLFFBQVEsU0FBUyxTQUFTO0VBQ3pCLE1BQU0sT0FBTyxZQUFZLEtBQUssTUFBTSxNQUFNLFNBQVMsS0FBSyxPQUFPO0VBQy9ELEtBQUssVUFBVTtHQUNkO0dBQ0EsTUFBTTtHQUNOLGVBQWUsU0FBUztHQUN4QixRQUFRLFNBQVM7RUFDbEIsQ0FBQztFQUNELE9BQU87Q0FDUjs7Ozs7OztDQU9BLFNBQVMsT0FBTztFQUNmLEtBQUssVUFBVTtHQUNkLE1BQU07R0FDTjtFQUNELENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7OztDQWFBLE9BQU8sU0FBUztFQUNmLE1BQU0sVUFBVSxLQUFLLFVBQVU7RUFDL0IsS0FBSyxVQUFVLE9BQU8sT0FBTztFQUM3QixPQUFPLFVBQVUsUUFBUSxLQUFLLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxJQUFJLFFBQVEsUUFBUTtDQUNuRTs7Ozs7OztDQU9BLFVBQVU7RUFDVCxLQUFLLE9BQU8sRUFBRSxRQUFRLEtBQUssQ0FBQztFQUM1QixNQUFNLFFBQVE7Q0FDZjs7Ozs7O0NBTUEsSUFBSSxhQUFhO0VBQ2hCLE9BQU8sS0FBSztDQUNiOzs7Ozs7Q0FNQSxRQUFRO0VBQ1AsS0FBSyxRQUFRO0VBQ2IsS0FBSyxTQUFTLEtBQUssVUFBVTtDQUM5Qjs7Ozs7O0NBTUEsV0FBVztFQUNWLE9BQU8sS0FBSyxVQUFVLE1BQU0sYUFBYSxrQkFBa0IsU0FBUyxRQUFRLFNBQVMsSUFBSSxNQUFNLEtBQUs7Q0FDckc7Ozs7Ozs7Ozs7Q0FVQSxhQUFhO0VBQ1osSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQUcsT0FBTyxDQUFDLEtBQUssU0FBUztFQUN4RCxPQUFPLEtBQUssUUFBUSxZQUFZLGFBQWEsQ0FBQyxLQUFLLFVBQVU7Q0FDOUQ7Ozs7OztDQU1BLFlBQVk7RUFDWCxPQUFPLEtBQUssTUFBTSxrQkFBa0IsS0FBSyxNQUFNLG1CQUFtQjtDQUNuRTs7Ozs7O0NBTUEsV0FBVztFQUNWLElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxHQUFHLE9BQU87RUFDdkMsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQUcsT0FBTyxLQUFLLFVBQVUsTUFBTSxhQUFhLGtCQUFrQixTQUFTLFFBQVEsV0FBVyxJQUFJLE1BQU0sUUFBUTtFQUMzSSxPQUFPO0NBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLFVBQVU7RUFDVCxJQUFJLEtBQUssa0JBQWtCLElBQUksR0FBRyxPQUFPLEtBQUssVUFBVSxNQUFNLGFBQWEsU0FBUyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU87RUFDOUcsT0FBTyxLQUFLLE1BQU0sU0FBUyxLQUFLLEtBQUssS0FBSyxNQUFNO0NBQ2pEOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxjQUFjLFlBQVksR0FBRztFQUM1QixJQUFJLEtBQUssTUFBTSxTQUFTLEtBQUssR0FBRyxPQUFPO0VBQ3ZDLElBQUksY0FBYyxVQUFVLE9BQU87RUFDbkMsSUFBSSxLQUFLLE1BQU0sZUFBZSxPQUFPO0VBQ3JDLE9BQU8sQ0FBQyxlQUFlLEtBQUssTUFBTSxlQUFlLFNBQVM7Q0FDM0Q7Ozs7OztDQU1BLFVBQVU7RUFDVCxLQUFLLFVBQVUsTUFBTSxNQUFNLEVBQUUseUJBQXlCLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztFQUMxRixLQUFLLFVBQVUsU0FBUztDQUN6Qjs7Ozs7O0NBTUEsV0FBVztFQUNWLEtBQUssVUFBVSxNQUFNLE1BQU0sRUFBRSx1QkFBdUIsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLGVBQWUsTUFBTSxDQUFDO0VBQ3hGLEtBQUssVUFBVSxTQUFTO0NBQ3pCOzs7Ozs7O0NBT0EsWUFBWSxVQUFVO0VBQ3JCLElBQUksQ0FBQyxLQUFLLFVBQVUsU0FBUyxRQUFRLEdBQUc7R0FDdkMsS0FBSyxVQUFVLEtBQUssUUFBUTtHQUM1QixLQUFLLGVBQWU7R0FDcEIsS0FBSyxPQUFPLE9BQU87SUFDbEIsTUFBTTtJQUNOLE9BQU87SUFDUDtHQUNELENBQUM7RUFDRjtDQUNEOzs7Ozs7OztDQVFBLGVBQWUsVUFBVTtFQUN4QixNQUFNLFFBQVEsS0FBSyxVQUFVLFFBQVEsUUFBUTtFQUM3QyxJQUFJLFVBQVUsSUFBSTtHQUNqQixLQUFLLFVBQVUsT0FBTyxPQUFPLENBQUM7R0FDOUIsSUFBSSxDQUFDLEtBQUssVUFBVSxRQUFRO0lBQzNCLElBQUksS0FBSyxVQUFVO0tBQ2xCLElBQUksS0FBSyx3QkFBd0IsS0FBSyxNQUFNLGdCQUFnQixZQUFZLEtBQUssTUFBTSxXQUFXLFdBQVcsS0FBSyxTQUFTLE9BQU8sRUFBRSxRQUFRLEtBQUssQ0FBQztVQUN6SSxLQUFLLFNBQVMsWUFBWTtJQUNoQztJQUNBLEtBQUssb0JBQW9CO0dBQzFCO0dBQ0EsS0FBSyxPQUFPLE9BQU87SUFDbEIsTUFBTTtJQUNOLE9BQU87SUFDUDtHQUNELENBQUM7RUFDRjtDQUNEOzs7Ozs7Ozs7OztDQVdBLG9CQUFvQjtFQUNuQixPQUFPLEtBQUssVUFBVTtDQUN2Qjs7Ozs7Ozs7OztDQVVBLGFBQWE7RUFDWixJQUFJLENBQUMsS0FBSyxNQUFNLGVBQWUsS0FBSyxVQUFVLEVBQUUsTUFBTSxhQUFhLENBQUM7Q0FDckU7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxNQUFNLE1BQU0sU0FBUyxjQUFjO0VBQ2xDLElBQUksS0FBSyxNQUFNLGdCQUFnQixVQUFVLEtBQUssVUFBVSxPQUFPLE1BQU0sWUFBWTtHQUNoRixJQUFJLEtBQUssTUFBTSxTQUFTLEtBQUssS0FBSyxjQUFjLGVBQWUsS0FBSyxPQUFPLEVBQUUsUUFBUSxLQUFLLENBQUM7UUFDdEYsSUFBSSxLQUFLLFlBQVksS0FBSyxlQUFlO0lBQzdDLEtBQUssU0FBUyxjQUFjO0lBQzVCLE9BQU8sS0FBSztHQUNiO0VBQ0Q7RUFDQSxJQUFJLFNBQVMsS0FBSyxXQUFXLE9BQU87RUFDcEMsSUFBSSxDQUFDLEtBQUssUUFBUSxTQUFTO0dBQzFCLE1BQU0sV0FBVyxLQUFLLFVBQVUsTUFBTSxNQUFNLEVBQUUsUUFBUSxPQUFPO0dBQzdELElBQUksVUFBVSxLQUFLLFdBQVcsU0FBUyxPQUFPO0VBQy9DO0VBRUMsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLFFBQVEsUUFBUSxHQUFHLFFBQVEsTUFBTSxxSUFBcUk7RUFFL0wsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7RUFDNUMsTUFBTSxxQkFBcUIsV0FBVztHQUNyQyxPQUFPLGlCQUFpQixRQUFRO0tBQzlCLGNBQWM7S0FDZCxPQUFPLGdCQUFnQjtLQUN2QixZQUFZO0lBQ2I7SUFDQSxRQUFRO0tBQ1AsWUFBWTtLQUNaLFdBQVc7TUFDVixLQUFLLHVCQUF1QjtNQUM1QixPQUFPLGdCQUFnQjtLQUN4QjtJQUNEO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsTUFBTSxnQkFBZ0I7R0FDckIsTUFBTSxVQUFVLGNBQWMsS0FBSyxTQUFTLFlBQVk7R0FDeEQsTUFBTSw2QkFBNkI7SUFDbEMsTUFBTSxpQkFBaUI7S0FDdEIsUUFBUSxLQUFLO0tBQ2IsVUFBVSxLQUFLO0tBQ2YsTUFBTSxLQUFLO0lBQ1o7SUFDQSxrQkFBa0IsY0FBYztJQUNoQyxPQUFPO0dBQ1I7R0FDQSxNQUFNLGlCQUFpQixxQkFBcUI7R0FDNUMsS0FBSyx1QkFBdUI7R0FDNUIsSUFBSSxLQUFLLFFBQVEsV0FBVyxPQUFPLEtBQUssUUFBUSxVQUFVLFNBQVMsZ0JBQWdCLElBQUk7R0FDdkYsT0FBTyxRQUFRLGNBQWM7RUFDOUI7RUFDQSxNQUFNLDJCQUEyQjtHQUNoQyxNQUFNLFVBQVU7SUFDZjtJQUNBLFNBQVMsS0FBSztJQUNkLFVBQVUsS0FBSztJQUNmLFFBQVEsS0FBSztJQUNiLE9BQU8sS0FBSztJQUNaO0dBQ0Q7R0FDQSxrQkFBa0IsT0FBTztHQUN6QixPQUFPO0VBQ1I7RUFDQSxNQUFNLFVBQVUsbUJBQW1CO0VBQ25DLENBQUMsS0FBSyxlQUFlLGFBQWEsc0JBQXNCLEtBQUssUUFBUSxLQUFLLElBQUksS0FBSyxRQUFRLFNBQUEsRUFBVyxRQUFRLFNBQVMsSUFBSTtFQUMzSCxLQUFLLGVBQWUsS0FBSztFQUN6QixJQUFJLEtBQUssTUFBTSxnQkFBZ0IsVUFBVSxLQUFLLE1BQU0sY0FBYyxRQUFRLGNBQWMsTUFBTSxLQUFLLFVBQVU7R0FDNUcsTUFBTTtHQUNOLE1BQU0sUUFBUSxjQUFjO0VBQzdCLENBQUM7RUFDRCxNQUFNLFVBQVUsS0FBSyxXQUFXLGNBQWM7R0FDN0MsZ0JBQWdCLGNBQWM7R0FDOUIsSUFBSSxRQUFRO0dBQ1osV0FBVyxVQUFVO0lBQ3BCLElBQUksaUJBQWlCLGtCQUFrQixNQUFNLFFBQVEsS0FBSyxTQUFTO0tBQ2xFLEdBQUcsS0FBSztLQUNSLGFBQWE7SUFDZCxDQUFDO0lBQ0QsZ0JBQWdCLE1BQU07R0FDdkI7R0FDQSxTQUFTLGNBQWMsVUFBVTtJQUNoQyxLQUFLLFVBQVU7S0FDZCxNQUFNO0tBQ047S0FDQTtJQUNELENBQUM7R0FDRjtHQUNBLGVBQWU7SUFDZCxLQUFLLFVBQVUsRUFBRSxNQUFNLFFBQVEsQ0FBQztHQUNqQztHQUNBLGtCQUFrQjtJQUNqQixLQUFLLFVBQVUsRUFBRSxNQUFNLFdBQVcsQ0FBQztHQUNwQztHQUNBLE9BQU8sUUFBUSxRQUFRO0dBQ3ZCLFlBQVksUUFBUSxRQUFRO0dBQzVCLGFBQWEsUUFBUSxRQUFRO0dBQzdCLGNBQWM7RUFDZixDQUFDO0VBQ0QsTUFBTSxnQkFBZ0IsWUFBWTtHQUNqQyxJQUFJO0lBQ0gsTUFBTSxPQUFPLE1BQU0sUUFBUTtJQUMzQixJQUFJLFNBQVMsS0FBSyxHQUFHO0tBQ3VCLFFBQVEsTUFBTSx5SUFBeUksS0FBSyxXQUFXO0tBQ2xOLE1BQU0sSUFBSSxNQUFNLEdBQUcsS0FBSyxVQUFVLG1CQUFtQjtJQUN0RDtJQUNBLEtBQUssUUFBUSxJQUFJO0lBQ2pCLEtBQUssT0FBTyxPQUFPLFlBQVksTUFBTSxJQUFJO0lBQ3pDLEtBQUssT0FBTyxPQUFPLFlBQVksTUFBTSxLQUFLLE1BQU0sT0FBTyxJQUFJO0lBQzNELE9BQU87R0FDUixTQUFTLE9BQU87SUFDZixJQUFJLGlCQUFpQixnQkFBZ0I7S0FDcEMsSUFBSSxNQUFNLFFBQVE7TUFDakIsSUFBSSxLQUFLLGFBQWEsV0FBVyxLQUFLLGVBQWUsT0FBTyxLQUFLO01BQ2pFLE1BQU07S0FDUCxPQUFPLElBQUksTUFBTSxRQUFRO01BQ3hCLElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxHQUFHLE1BQU07TUFDdEMsT0FBTyxLQUFLLE1BQU07S0FDbkI7SUFDRDtJQUNBLEtBQUssVUFBVTtLQUNkLE1BQU07S0FDTjtJQUNELENBQUM7SUFDRCxLQUFLLE9BQU8sT0FBTyxVQUFVLE9BQU8sSUFBSTtJQUN4QyxLQUFLLE9BQU8sT0FBTyxZQUFZLEtBQUssTUFBTSxNQUFNLE9BQU8sSUFBSTtJQUMzRCxNQUFNO0dBQ1AsVUFBVTtJQUNULElBQUksS0FBSyxhQUFhLFNBQVM7S0FDOUIsS0FBSyxXQUFXLEtBQUs7S0FDckIsS0FBSyxnQkFBZ0IsS0FBSztJQUMzQjtJQUNBLEtBQUssb0JBQW9CO0dBQzFCO0VBQ0QsRUFBQSxDQUFHO0VBQ0gsS0FBSyxnQkFBZ0I7RUFDckIsUUFBUSxNQUFNO0VBQ2QsT0FBTztDQUNSO0NBQ0Esc0JBQXNCO0VBQ3JCLElBQUksS0FBSyxPQUFPLElBQUksS0FBSyxTQUFTLE1BQU0sTUFBTSxLQUFLLFdBQVc7Q0FDL0Q7Q0FDQSxVQUFVLFFBQVE7RUFDakIsTUFBTSxXQUFXLFVBQVU7R0FDMUIsUUFBUSxPQUFPLE1BQWY7SUFDQyxLQUFLLFVBQVUsT0FBTztLQUNyQixHQUFHO0tBQ0gsbUJBQW1CLE9BQU87S0FDMUIsb0JBQW9CLE9BQU87SUFDNUI7SUFDQSxLQUFLLFNBQVMsT0FBTztLQUNwQixHQUFHO0tBQ0gsYUFBYTtJQUNkO0lBQ0EsS0FBSyxZQUFZLE9BQU87S0FDdkIsR0FBRztLQUNILGFBQWE7SUFDZDtJQUNBLEtBQUssU0FBUyxPQUFPO0tBQ3BCLEdBQUc7S0FDSCxHQUFHLFdBQVcsTUFBTSxNQUFNLEtBQUssT0FBTztLQUN0QyxXQUFXLE9BQU8sUUFBUTtJQUMzQjtJQUNBLEtBQUssV0FBVztLQUNmLE1BQU0sV0FBVztNQUNoQixHQUFHO01BQ0gsR0FBRyxhQUFhLE9BQU8sTUFBTSxPQUFPLGFBQWE7TUFDakQsaUJBQWlCLE1BQU0sa0JBQWtCO01BQ3pDLEdBQUcsQ0FBQyxPQUFPLFVBQVU7T0FDcEIsYUFBYTtPQUNiLG1CQUFtQjtPQUNuQixvQkFBb0I7TUFDckI7S0FDRDtLQUNBLEtBQUssZUFBZSxPQUFPLFNBQVMsV0FBVyxLQUFLO0tBQ3BELE9BQU87SUFDUjtJQUNBLEtBQUssU0FBUztLQUNiLE1BQU0sUUFBUSxPQUFPO0tBQ3JCLE9BQU87TUFDTixHQUFHO01BQ0g7TUFDQSxrQkFBa0IsTUFBTSxtQkFBbUI7TUFDM0MsZ0JBQWdCLEtBQUssSUFBSTtNQUN6QixtQkFBbUIsTUFBTSxvQkFBb0I7TUFDN0Msb0JBQW9CO01BQ3BCLGFBQWE7TUFDYixRQUFRO01BQ1IsZUFBZTtLQUNoQjtJQUNEO0lBQ0EsS0FBSyxjQUFjLE9BQU87S0FDekIsR0FBRztLQUNILGVBQWU7SUFDaEI7SUFDQSxLQUFLLFlBQVksT0FBTztLQUN2QixHQUFHO0tBQ0gsR0FBRyxPQUFPO0lBQ1g7R0FDRDtFQUNEO0VBQ0EsS0FBSyxRQUFRLFFBQVEsS0FBSyxLQUFLO0VBQy9CLGNBQWMsWUFBWTtHQUN6QixLQUFLLFVBQVUsTUFBTSxDQUFDLENBQUMsU0FBUyxhQUFhO0lBQzVDLFNBQVMsY0FBYztHQUN4QixDQUFDO0dBQ0QsS0FBSyxPQUFPLE9BQU87SUFDbEIsT0FBTztJQUNQLE1BQU07SUFDTjtHQUNELENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDs7Ozs7Ozs7O0FBU0EsU0FBUyxXQUFXLE1BQU0sU0FBUztDQUNsQyxPQUFPO0VBQ04sbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixhQUFhLFNBQVMsUUFBUSxXQUFXLElBQUksYUFBYTtFQUMxRCxHQUFHLFNBQVMsS0FBSyxLQUFLO0dBQ3JCLE9BQU87R0FDUCxRQUFRO0VBQ1Q7Q0FDRDtBQUNEOzs7Ozs7O0FBT0EsU0FBUyxhQUFhLE1BQU0sZUFBZTtDQUMxQyxPQUFPO0VBQ047RUFDQSxlQUFlLGlCQUFpQixLQUFLLElBQUk7RUFDekMsT0FBTztFQUNQLGVBQWU7RUFDZixRQUFRO0NBQ1Q7QUFDRDs7Ozs7OztBQU9BLFNBQVNBLGtCQUFnQixTQUFTO0NBQ2pDLE1BQU0sT0FBTyxPQUFPLFFBQVEsZ0JBQWdCLGFBQWEsUUFBUSxZQUFZLElBQUksUUFBUTtDQUN6RixNQUFNLFVBQVUsU0FBUyxLQUFLO0NBQzlCLE1BQU0sdUJBQXVCLFVBQVUsT0FBTyxRQUFRLHlCQUF5QixhQUFhLFFBQVEscUJBQXFCLElBQUksUUFBUSx1QkFBdUI7Q0FDNUosT0FBTztFQUNOO0VBQ0EsaUJBQWlCO0VBQ2pCLGVBQWUsVUFBVSx3QkFBd0IsS0FBSyxJQUFJLElBQUk7RUFDOUQsT0FBTztFQUNQLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixXQUFXO0VBQ1gsZUFBZTtFQUNmLFFBQVEsVUFBVSxZQUFZO0VBQzlCLGFBQWE7Q0FDZDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqbEJBLElBQUksZ0JBQWdCLGNBQWMsYUFBYTtDQUM5QztDQUNBLGdCQUFnQixLQUFLO0NBQ3JCLDRCQUE0QixLQUFLO0NBQ2pDLGlCQUFpQixLQUFLO0NBQ3RCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLGdDQUFnQyxJQUFJLElBQUk7Q0FDeEMsWUFBWSxRQUFRLFNBQVM7RUFDNUIsTUFBTTtFQUNOLEtBQUssVUFBVTtFQUNmLEtBQUssVUFBVTtFQUNmLEtBQUssZUFBZTtFQUNwQixLQUFLLFlBQVk7RUFDakIsS0FBSyxXQUFXLE9BQU87Q0FDeEI7Ozs7O0NBS0EsY0FBYztFQUNiLEtBQUssVUFBVSxLQUFLLFFBQVEsS0FBSyxJQUFJO0NBQ3RDO0NBQ0EsY0FBYztFQUNiLElBQUksS0FBSyxVQUFVLFNBQVMsR0FBRztHQUM5QixLQUFLLGNBQWMsWUFBWSxJQUFJO0dBQ25DLElBQUksbUJBQW1CLEtBQUssZUFBZSxLQUFLLE9BQU8sR0FBRyxLQUFLLGNBQWM7UUFDeEUsS0FBSyxhQUFhO0dBQ3ZCLEtBQUssY0FBYztFQUNwQjtDQUNEO0NBQ0EsZ0JBQWdCO0VBQ2YsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUFHLEtBQUssUUFBUTtDQUN4Qzs7Ozs7OztDQU9BLHlCQUF5QjtFQUN4QixPQUFPLGNBQWMsS0FBSyxlQUFlLEtBQUssU0FBUyxLQUFLLFFBQVEsa0JBQWtCO0NBQ3ZGOzs7Ozs7O0NBT0EsMkJBQTJCO0VBQzFCLE9BQU8sY0FBYyxLQUFLLGVBQWUsS0FBSyxTQUFTLEtBQUssUUFBUSxvQkFBb0I7Q0FDekY7Ozs7OztDQU1BLFVBQVU7RUFDVCxLQUFLLDRCQUE0QixJQUFJLElBQUk7RUFDekMsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxzQkFBc0I7RUFDM0IsS0FBSyxjQUFjLGVBQWUsSUFBSTtDQUN2Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsV0FBVyxTQUFTO0VBQ25CLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLEtBQUssVUFBVSxLQUFLLFFBQVEsb0JBQW9CLE9BQU87RUFDdkQsSUFBSSxLQUFLLFFBQVEsWUFBWSxLQUFLLEtBQUssT0FBTyxLQUFLLFFBQVEsWUFBWSxhQUFhLE9BQU8sS0FBSyxRQUFRLFlBQVksY0FBYyxPQUFPLGtCQUFrQixLQUFLLFFBQVEsU0FBUyxLQUFLLGFBQWEsTUFBTSxXQUFXLE1BQU0sSUFBSSxNQUFNLHVFQUF1RTtFQUMzUyxLQUFLLGFBQWE7RUFDbEIsS0FBSyxjQUFjLFdBQVcsS0FBSyxPQUFPO0VBQzFDLElBQUksWUFBWSxjQUFjLENBQUMsb0JBQW9CLEtBQUssU0FBUyxXQUFXLEdBQUcsS0FBSyxRQUFRLGNBQWMsQ0FBQyxDQUFDLE9BQU87R0FDbEgsTUFBTTtHQUNOLE9BQU8sS0FBSztHQUNaLFVBQVU7RUFDWCxDQUFDO0VBQ0QsTUFBTSxVQUFVLEtBQUssYUFBYTtFQUNsQyxJQUFJLFdBQVcsc0JBQXNCLEtBQUssZUFBZSxXQUFXLEtBQUssU0FBUyxXQUFXLEdBQUcsS0FBSyxjQUFjO0VBQ25ILEtBQUssYUFBYTtFQUNsQixJQUFJLFlBQVksS0FBSyxrQkFBa0IsYUFBYSxrQkFBa0IsS0FBSyxRQUFRLFNBQVMsS0FBSyxhQUFhLE1BQU0sa0JBQWtCLFlBQVksU0FBUyxLQUFLLGFBQWEsS0FBSyxrQkFBa0IsS0FBSyxRQUFRLFdBQVcsS0FBSyxhQUFhLE1BQU0sa0JBQWtCLFlBQVksV0FBVyxLQUFLLGFBQWEsSUFBSSxLQUFLLG9CQUFvQjtFQUM1VSxNQUFNLHNCQUFzQixLQUFLLHdCQUF3QjtFQUN6RCxJQUFJLFlBQVksS0FBSyxrQkFBa0IsYUFBYSxrQkFBa0IsS0FBSyxRQUFRLFNBQVMsS0FBSyxhQUFhLE1BQU0sa0JBQWtCLFlBQVksU0FBUyxLQUFLLGFBQWEsS0FBSyx3QkFBd0IsS0FBSywwQkFBMEIsS0FBSyx1QkFBdUIsbUJBQW1CO0NBQ3pSOzs7Ozs7Ozs7Q0FTQSxvQkFBb0IsU0FBUztFQUM1QixNQUFNLFFBQVEsS0FBSyxRQUFRLGNBQWMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxTQUFTLE9BQU87RUFDdEUsTUFBTSxTQUFTLEtBQUssYUFBYSxPQUFPLE9BQU87RUFDL0MsSUFBSSxDQUFDLG9CQUFvQixLQUFLLGlCQUFpQixHQUFHLE1BQU0sR0FBRztHQUMxRCxLQUFLLGlCQUFpQjtHQUN0QixLQUFLLHdCQUF3QjtFQUM5QjtFQUNBLE9BQU87Q0FDUjs7Ozs7Ozs7Ozs7OztDQWFBLG1CQUFtQjtFQUNsQixPQUFPLEtBQUs7Q0FDYjs7Ozs7Ozs7OztDQVVBLFlBQVksUUFBUSxlQUFlO0VBQ2xDLE9BQU8sSUFBSSxNQUFNLFFBQVEsRUFBRSxNQUFNLFFBQVEsUUFBUTtHQUNoRCxLQUFLLFVBQVUsR0FBRztHQUNsQixnQkFBZ0IsR0FBRztHQUNuQixPQUFPLFFBQVEsSUFBSSxRQUFRLEdBQUc7RUFDL0IsRUFBRSxDQUFDO0NBQ0o7Ozs7Ozs7O0NBUUEsVUFBVSxLQUFLO0VBQ2QsS0FBSyxjQUFjLElBQUksR0FBRztDQUMzQjs7Ozs7Q0FLQSxrQkFBa0I7RUFDakIsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7Ozs7Ozs7Q0FhQSxRQUFRLEVBQUUsR0FBRyxZQUFZLENBQUMsR0FBRztFQUM1QixPQUFPLEtBQUssTUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDO0NBQ2pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsZ0JBQWdCLFNBQVM7RUFDeEIsTUFBTSxtQkFBbUIsS0FBSyxRQUFRLG9CQUFvQixPQUFPO0VBQ2pFLE1BQU0sUUFBUSxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsTUFBTSxLQUFLLFNBQVMsZ0JBQWdCO0VBQy9FLElBQUksb0JBQW9CLENBQUM7RUFDekIsSUFBSTtFQUNKLE1BQU0sZUFBZSxJQUFJLFNBQVMsWUFBWTtHQUM3QyxlQUFlO0dBQ2YsY0FBYyxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsV0FBVyxVQUFVO0lBQy9ELElBQUksTUFBTSxTQUFTLGFBQWEsTUFBTSxNQUFNLGNBQWMsTUFBTSxhQUFhLE1BQU0sTUFBTSxTQUFTLEtBQUssR0FBRztLQUN6RyxZQUFZO0tBQ1osUUFBUSxLQUFLLGFBQWEsT0FBTyxnQkFBZ0IsQ0FBQztJQUNuRDtHQUNELENBQUM7RUFDRixDQUFDO0VBQ0QsT0FBTyxRQUFRLEtBQUssQ0FBQyxNQUFNLE1BQU0sZ0JBQWdCLENBQUMsQ0FBQyxXQUFXO0dBQzdELE1BQU0sU0FBUyxLQUFLLGFBQWEsT0FBTyxnQkFBZ0I7R0FDeEQsZUFBZSxNQUFNO0dBQ3JCLE9BQU87RUFDUixDQUFDLENBQUMsQ0FBQyxjQUFjO0dBQ2hCLFlBQVk7RUFDYixDQUFDLEdBQUcsWUFBWSxDQUFDO0NBQ2xCOzs7Ozs7O0NBT0EsTUFBTSxjQUFjO0VBQ25CLE9BQU8sS0FBSyxjQUFjO0dBQ3pCLEdBQUc7R0FDSCxlQUFlLGFBQWEsaUJBQWlCO0VBQzlDLENBQUMsQ0FBQyxDQUFDLFdBQVc7R0FDYixLQUFLLGFBQWE7R0FDbEIsT0FBTyxLQUFLO0VBQ2IsQ0FBQztDQUNGO0NBQ0EsY0FBYyxjQUFjO0VBQzNCLEtBQUssYUFBYTtFQUNsQixJQUFJLFVBQVUsS0FBSyxjQUFjLE1BQU0sS0FBSyxTQUFTLFlBQVk7RUFDakUsSUFBSSxDQUFDLGNBQWMsY0FBYyxVQUFVLFFBQVEsTUFBTSxJQUFJO0VBQzdELE9BQU87Q0FDUjtDQUNBLHFCQUFxQixTQUFTO0VBQzdCLE9BQU8sQ0FBQyxTQUFTLEtBQUssa0JBQWtCLEtBQUssUUFBUSxTQUFTLEtBQUssYUFBYSxNQUFNLFNBQVMsZUFBZSxPQUFPO0NBQ3RIO0NBQ0Esc0JBQXNCO0VBQ3JCLEtBQUssbUJBQW1CO0VBQ3hCLE1BQU0sWUFBWSxrQkFBa0IsS0FBSyxRQUFRLFdBQVcsS0FBSyxhQUFhO0VBQzlFLElBQUksS0FBSyxlQUFlLFdBQVcsQ0FBQyxLQUFLLHFCQUFxQixTQUFTLEdBQUc7RUFDMUUsTUFBTSxVQUFVLGVBQWUsS0FBSyxlQUFlLGVBQWUsU0FBUyxJQUFJO0VBQy9FLEtBQUssa0JBQWtCLGVBQWUsaUJBQWlCO0dBQ3RELElBQUksQ0FBQyxLQUFLLGVBQWUsU0FBUyxLQUFLLGFBQWE7RUFDckQsR0FBRyxPQUFPO0NBQ1g7Q0FDQSwwQkFBMEI7RUFDekIsT0FBTyxrQkFBa0IsS0FBSyxRQUFRLGlCQUFpQixLQUFLLGFBQWEsS0FBSztDQUMvRTtDQUNBLHVCQUF1QixjQUFjO0VBQ3BDLEtBQUssc0JBQXNCO0VBQzNCLEtBQUssMEJBQTBCO0VBQy9CLElBQUksS0FBSyw0QkFBNEIsS0FBSyxDQUFDLEtBQUsscUJBQXFCLEtBQUssdUJBQXVCLEdBQUc7RUFDcEcsS0FBSyxxQkFBcUIsZUFBZSxrQkFBa0I7R0FDMUQsSUFBSSxLQUFLLFFBQVEsK0JBQStCLGFBQWEsVUFBVSxHQUFHLEtBQUssY0FBYztFQUM5RixHQUFHLEtBQUssdUJBQXVCO0NBQ2hDO0NBQ0EsZ0JBQWdCO0VBQ2YsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyx1QkFBdUIsS0FBSyx3QkFBd0IsQ0FBQztDQUMzRDtDQUNBLHFCQUFxQjtFQUNwQixJQUFJLEtBQUssb0JBQW9CLEtBQUssR0FBRztHQUNwQyxlQUFlLGFBQWEsS0FBSyxlQUFlO0dBQ2hELEtBQUssa0JBQWtCLEtBQUs7RUFDN0I7Q0FDRDtDQUNBLHdCQUF3QjtFQUN2QixJQUFJLEtBQUssdUJBQXVCLEtBQUssR0FBRztHQUN2QyxlQUFlLGNBQWMsS0FBSyxrQkFBa0I7R0FDcEQsS0FBSyxxQkFBcUIsS0FBSztFQUNoQztDQUNEOzs7Ozs7OztDQVFBLGFBQWEsT0FBTyxTQUFTO0VBQzVCLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0sYUFBYSxLQUFLO0VBQ3hCLE1BQU0sb0JBQW9CLEtBQUs7RUFDL0IsTUFBTSxvQkFBb0IsVUFBVSxZQUFZLE1BQU0sUUFBUSxLQUFLO0VBQ25FLE1BQU0sRUFBRSxVQUFVO0VBQ2xCLElBQUksV0FBVyxFQUFFLEdBQUcsTUFBTTtFQUMxQixJQUFJLG9CQUFvQjtFQUN4QixJQUFJO0VBQ0osSUFBSSxRQUFRLG9CQUFvQjtHQUMvQixNQUFNLFVBQVUsS0FBSyxhQUFhO0dBQ2xDLE1BQU0sZUFBZSxDQUFDLFdBQVcsbUJBQW1CLE9BQU8sT0FBTztHQUNsRSxNQUFNLGtCQUFrQixXQUFXLHNCQUFzQixPQUFPLFdBQVcsU0FBUyxXQUFXO0dBQy9GLElBQUksZ0JBQWdCLGlCQUFpQixXQUFXO0lBQy9DLEdBQUc7SUFDSCxHQUFHLFdBQVcsTUFBTSxNQUFNLE1BQU0sT0FBTztHQUN4QztHQUNBLElBQUksUUFBUSx1QkFBdUIsZUFBZSxTQUFTLGNBQWM7RUFDMUU7RUFDQSxJQUFJLEVBQUUsT0FBTyxnQkFBZ0IsV0FBVztFQUN4QyxPQUFPLFNBQVM7RUFDaEIsSUFBSSxhQUFhO0VBQ2pCLElBQUksUUFBUSxvQkFBb0IsS0FBSyxLQUFLLFNBQVMsS0FBSyxLQUFLLFdBQVcsV0FBVztHQUNsRixJQUFJO0dBQ0osTUFBTSx3QkFBd0IsWUFBWSxxQkFBcUIsUUFBUSxvQkFBb0IsbUJBQW1CO0dBQzlHLElBQUksdUJBQXVCO0lBQzFCLGtCQUFrQixXQUFXO0lBQzdCLGFBQWE7R0FDZCxPQUFPLGtCQUFrQixPQUFPLFFBQVEsb0JBQW9CLGFBQWEsUUFBUSxnQkFBZ0IsS0FBSywyQkFBMkIsTUFBTSxNQUFNLEtBQUsseUJBQXlCLElBQUksUUFBUTtHQUN2TCxJQUFJLHlCQUF5QixvQkFBb0IsS0FBSyxHQUFHO0lBQ3hELFNBQVM7SUFDVCxPQUFPLFlBQVksUUFBUSxVQUFVLENBQUMsYUFBYSxLQUFLLGVBQWUsWUFBWSxNQUFNLGlCQUFpQixPQUFPO0lBQ2pILG9CQUFvQjtHQUNyQjtFQUNEO0VBQ0EsSUFBSSxRQUFRLFVBQVUsU0FBUyxLQUFLLEtBQUssQ0FBQyxZQUFZO0dBQ3JELElBQUksU0FBUyxLQUFLLGdCQUFnQixRQUFRLFdBQVcsS0FBSyxXQUFXLE9BQU8sS0FBSztRQUM1RSxJQUFJO0lBQ1IsS0FBSyxZQUFZLFFBQVE7SUFDekIsS0FBSyxlQUFlO0lBQ3BCLE9BQU8sUUFBUSxPQUFPLElBQUk7SUFDMUIsT0FBTyxZQUFZLFlBQVksTUFBTSxNQUFNLE9BQU87SUFDbEQsS0FBSyxnQkFBZ0I7SUFDckIsS0FBSyxlQUFlO0dBQ3JCLFNBQVMsYUFBYTtJQUNyQixLQUFLLGVBQWU7R0FDckI7RUFDRCxPQUFPLElBQUksU0FBUyxLQUFLLEdBQUc7R0FDM0IsS0FBSyxlQUFlLEtBQUs7R0FDekIsS0FBSyxlQUFlO0VBQ3JCO0VBQ0EsSUFBSSxLQUFLLGNBQWM7R0FDdEIsUUFBUSxLQUFLO0dBQ2IsT0FBTyxLQUFLO0dBQ1osaUJBQWlCLFlBQVksVUFBVSxRQUFRLFdBQVcsaUJBQWlCLEtBQUssSUFBSTtHQUNwRixTQUFTO0dBQ1Qsb0JBQW9CO0VBQ3JCO0VBQ0EsTUFBTSxhQUFhLFNBQVMsZ0JBQWdCO0VBQzVDLE1BQU0sWUFBWSxXQUFXO0VBQzdCLE1BQU0sVUFBVSxXQUFXO0VBQzNCLE1BQU0sWUFBWSxhQUFhO0VBQy9CLE1BQU0sVUFBVSxTQUFTLEtBQUs7RUFDOUIsT0FBTztHQUNOO0dBQ0EsYUFBYSxTQUFTO0dBQ3RCO0dBQ0EsV0FBVyxXQUFXO0dBQ3RCO0dBQ0Esa0JBQWtCO0dBQ2xCO0dBQ0E7R0FDQSxlQUFlLFNBQVM7R0FDeEI7R0FDQTtHQUNBLGNBQWMsU0FBUztHQUN2QixlQUFlLFNBQVM7R0FDeEIsa0JBQWtCLFNBQVM7R0FDM0IsV0FBVyxNQUFNLFVBQVU7R0FDM0IscUJBQXFCLFNBQVMsa0JBQWtCLGtCQUFrQixtQkFBbUIsU0FBUyxtQkFBbUIsa0JBQWtCO0dBQ25JO0dBQ0EsY0FBYyxjQUFjLENBQUM7R0FDN0IsZ0JBQWdCLFdBQVcsQ0FBQztHQUM1QixVQUFVLFNBQVMsZ0JBQWdCO0dBQ25DO0dBQ0EsZ0JBQWdCLFdBQVc7R0FDM0IsU0FBUyxRQUFRLE9BQU8sT0FBTztHQUMvQixTQUFTLEtBQUs7R0FDZCxXQUFXLGtCQUFrQixRQUFRLFNBQVMsS0FBSyxNQUFNO0VBQzFEO0NBQ0Q7Ozs7OztDQU1BLGVBQWU7RUFDZCxNQUFNLGFBQWEsS0FBSztFQUN4QixNQUFNLGFBQWEsS0FBSyxhQUFhLEtBQUssZUFBZSxLQUFLLE9BQU87RUFDckUsS0FBSyx3QkFBd0IsS0FBSztFQUNsQyxJQUFJLEtBQUssY0FBYyxNQUFNLFNBQVMsS0FBSyxHQUFHLEtBQUssNEJBQTRCLEtBQUs7RUFDcEYsSUFBSSxvQkFBb0IsWUFBWSxVQUFVLEdBQUc7RUFDakQsS0FBSyxpQkFBaUI7RUFDdEIsTUFBTSw4QkFBOEI7R0FDbkMsSUFBSSxDQUFDLFlBQVksT0FBTztHQUN4QixNQUFNLEVBQUUsd0JBQXdCLEtBQUs7R0FDckMsTUFBTSwyQkFBMkIsT0FBTyx3QkFBd0IsYUFBYSxvQkFBb0IsSUFBSTtHQUNyRyxJQUFJLDZCQUE2QixTQUFTLENBQUMsNEJBQTRCLENBQUMsS0FBSyxjQUFjLE1BQU0sT0FBTztHQUN4RyxJQUFJLEtBQUssUUFBUSxnQkFBZ0IsS0FBSyxlQUFlLFVBQVUsV0FBVyxPQUFPLE9BQU87R0FDeEYsS0FBSyxNQUFNLE9BQU8sNEJBQTRCLEtBQUssZUFBZSxJQUFJLEtBQUssZUFBZSxTQUFTLFdBQVcsTUFBTSxPQUFPO0dBQzNILE9BQU87RUFDUjtFQUNBLE1BQU0sa0JBQWtCLHNCQUFzQjtFQUM5QyxjQUFjLFlBQVk7R0FDekIsSUFBSSxpQkFBaUIsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUN6RCxTQUFTLEtBQUssY0FBYztHQUM3QixDQUFDO0dBQ0QsS0FBSyxRQUFRLGNBQWMsQ0FBQyxDQUFDLE9BQU87SUFDbkMsT0FBTyxLQUFLO0lBQ1osTUFBTTtHQUNQLENBQUM7RUFDRixDQUFDO0NBQ0Y7Q0FDQSxlQUFlO0VBQ2QsTUFBTSxRQUFRLEtBQUssUUFBUSxjQUFjLENBQUMsQ0FBQyxNQUFNLEtBQUssU0FBUyxLQUFLLE9BQU87RUFDM0UsSUFBSSxVQUFVLEtBQUssZUFBZTtFQUNsQyxNQUFNLFlBQVksS0FBSztFQUN2QixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLDRCQUE0QixNQUFNO0VBQ3ZDLElBQUksS0FBSyxhQUFhLEdBQUc7R0FDeEIsV0FBVyxlQUFlLElBQUk7R0FDOUIsTUFBTSxZQUFZLElBQUk7RUFDdkI7Q0FDRDs7Ozs7O0NBTUEsZ0JBQWdCO0VBQ2YsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxhQUFhLEdBQUcsS0FBSyxjQUFjO0NBQzdDO0FBQ0Q7Ozs7Ozs7O0FBUUEsU0FBUyxrQkFBa0IsT0FBTyxTQUFTO0NBQzFDLE9BQU8sa0JBQWtCLFFBQVEsU0FBUyxLQUFLLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxNQUFNLE1BQU0sV0FBVyxXQUFXLGtCQUFrQixRQUFRLGNBQWMsS0FBSyxNQUFNO0FBQ3JMOzs7Ozs7OztBQVFBLFNBQVMsbUJBQW1CLE9BQU8sU0FBUztDQUMzQyxPQUFPLGtCQUFrQixPQUFPLE9BQU8sS0FBSyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUssY0FBYyxPQUFPLFNBQVMsUUFBUSxjQUFjO0FBQ2hJOzs7Ozs7Ozs7O0FBVUEsU0FBUyxjQUFjLE9BQU8sU0FBUyxPQUFPO0NBQzdDLElBQUksa0JBQWtCLFFBQVEsU0FBUyxLQUFLLE1BQU0sU0FBUyxrQkFBa0IsUUFBUSxXQUFXLEtBQUssTUFBTSxVQUFVO0VBQ3BILE1BQU0sUUFBUSxrQkFBa0IsT0FBTyxLQUFLO0VBQzVDLE9BQU8sVUFBVSxZQUFZLFVBQVUsU0FBUyxRQUFRLE9BQU8sT0FBTztDQUN2RTtDQUNBLE9BQU87QUFDUjs7Ozs7Ozs7OztBQVVBLFNBQVMsc0JBQXNCLE9BQU8sV0FBVyxTQUFTLGFBQWE7Q0FDdEUsUUFBUSxVQUFVLGFBQWEsa0JBQWtCLFlBQVksU0FBUyxLQUFLLE1BQU0sV0FBVyxDQUFDLFFBQVEsWUFBWSxNQUFNLE1BQU0sV0FBVyxZQUFZLFFBQVEsT0FBTyxPQUFPO0FBQzNLOzs7Ozs7O0FBT0EsU0FBUyxRQUFRLE9BQU8sU0FBUztDQUNoQyxPQUFPLGtCQUFrQixRQUFRLFNBQVMsS0FBSyxNQUFNLFNBQVMsTUFBTSxjQUFjLGtCQUFrQixRQUFRLFdBQVcsS0FBSyxDQUFDO0FBQzlIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xmQSxJQUFJLHdCQUF3QixjQUFjLGNBQWM7Q0FDdkQsWUFBWSxRQUFRLFNBQVM7RUFDNUIsTUFBTSxRQUFRLE9BQU87Q0FDdEI7Q0FDQSxjQUFjO0VBQ2IsTUFBTSxZQUFZO0VBQ2xCLEtBQUssZ0JBQWdCLEtBQUssY0FBYyxLQUFLLElBQUk7RUFDakQsS0FBSyxvQkFBb0IsS0FBSyxrQkFBa0IsS0FBSyxJQUFJO0NBQzFEOzs7Ozs7OztDQVFBLFdBQVcsU0FBUztFQUNuQixRQUFRLFFBQVE7RUFDaEIsTUFBTSxXQUFXLE9BQU87Q0FDekI7Ozs7Ozs7OztDQVNBLG9CQUFvQixTQUFTO0VBQzVCLFFBQVEsUUFBUTtFQUNoQixPQUFPLE1BQU0sb0JBQW9CLE9BQU87Q0FDekM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCQSxjQUFjLFNBQVM7RUFDdEIsT0FBTyxLQUFLLE1BQU07R0FDakIsR0FBRztHQUNILE1BQU0sRUFBRSxXQUFXLEVBQUUsV0FBVyxVQUFVLEVBQUU7RUFDN0MsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsa0JBQWtCLFNBQVM7RUFDMUIsT0FBTyxLQUFLLE1BQU07R0FDakIsR0FBRztHQUNILE1BQU0sRUFBRSxXQUFXLEVBQUUsV0FBVyxXQUFXLEVBQUU7RUFDOUMsQ0FBQztDQUNGO0NBQ0EsYUFBYSxPQUFPLFNBQVM7RUFDNUIsTUFBTSxFQUFFLFVBQVU7RUFDbEIsTUFBTSxlQUFlLE1BQU0sYUFBYSxPQUFPLE9BQU87RUFDdEQsTUFBTSxFQUFFLFlBQVksY0FBYyxTQUFTLG1CQUFtQjtFQUM5RCxNQUFNLGlCQUFpQixNQUFNLFdBQVcsV0FBVztFQUNuRCxNQUFNLHVCQUF1QixXQUFXLG1CQUFtQjtFQUMzRCxNQUFNLHFCQUFxQixjQUFjLG1CQUFtQjtFQUM1RCxNQUFNLDJCQUEyQixXQUFXLG1CQUFtQjtFQUMvRCxNQUFNLHlCQUF5QixjQUFjLG1CQUFtQjtFQUNoRSxPQUFPO0dBQ04sR0FBRztHQUNILGVBQWUsS0FBSztHQUNwQixtQkFBbUIsS0FBSztHQUN4QixhQUFhLFlBQVksU0FBUyxNQUFNLElBQUk7R0FDNUMsaUJBQWlCLGdCQUFnQixTQUFTLE1BQU0sSUFBSTtHQUNwRDtHQUNBO0dBQ0E7R0FDQTtHQUNBLGdCQUFnQixrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQztHQUM1RCxjQUFjLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDO0VBQ3ZEO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUdBLElBQUksV0FBVyxjQUFjLFVBQVU7Q0FDdEM7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFZLFFBQVE7RUFDbkIsTUFBTTtFQUNOLEtBQUssVUFBVSxPQUFPO0VBQ3RCLEtBQUssYUFBYSxPQUFPO0VBQ3pCLEtBQUssaUJBQWlCLE9BQU87RUFDN0IsS0FBSyxhQUFhLENBQUM7RUFDbkIsS0FBSyxRQUFRLE9BQU8sU0FBUyxnQkFBZ0I7RUFDN0MsS0FBSyxXQUFXLE9BQU8sT0FBTztFQUM5QixLQUFLLFdBQVc7Q0FDakI7Ozs7OztDQU1BLFdBQVcsU0FBUztFQUNuQixLQUFLLFVBQVU7RUFDZixLQUFLLGFBQWEsS0FBSyxRQUFRLE1BQU07Q0FDdEM7Ozs7O0NBS0EsSUFBSSxPQUFPO0VBQ1YsT0FBTyxLQUFLLFFBQVE7Q0FDckI7Ozs7Ozs7Q0FPQSxZQUFZLFVBQVU7RUFDckIsSUFBSSxDQUFDLEtBQUssV0FBVyxTQUFTLFFBQVEsR0FBRztHQUN4QyxLQUFLLFdBQVcsS0FBSyxRQUFRO0dBQzdCLEtBQUssZUFBZTtHQUNwQixLQUFLLGVBQWUsT0FBTztJQUMxQixNQUFNO0lBQ04sVUFBVTtJQUNWO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Ozs7Ozs7Q0FPQSxlQUFlLFVBQVU7RUFDeEIsS0FBSyxhQUFhLEtBQUssV0FBVyxRQUFRLE1BQU0sTUFBTSxRQUFRO0VBQzlELElBQUksS0FBSyxlQUFlLElBQUksSUFBSSxHQUFHLEtBQUssV0FBVztFQUNuRCxLQUFLLGVBQWUsT0FBTztHQUMxQixNQUFNO0dBQ04sVUFBVTtHQUNWO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsaUJBQWlCO0VBQ2hCLElBQUksQ0FBQyxLQUFLLFdBQVcsUUFBUTtHQUM1QixJQUFJLEtBQUssTUFBTSxXQUFXLFdBQVcsS0FBSyxXQUFXO1FBQ2hELEtBQUssZUFBZSxPQUFPLElBQUk7RUFDckM7Q0FDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxXQUFXO0VBQ1YsT0FBTyxLQUFLLFVBQVUsU0FBUyxNQUFNLEtBQUssTUFBTSxXQUFXLFlBQVksS0FBSyxRQUFRLEtBQUssTUFBTSxTQUFTLElBQUksUUFBUSxRQUFRO0NBQzdIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBK0JBLE1BQU0sUUFBUSxXQUFXO0VBQ3hCLE1BQU0sbUJBQW1CO0dBQ3hCLEtBQUssVUFBVSxFQUFFLE1BQU0sV0FBVyxDQUFDO0VBQ3BDO0VBQ0EsTUFBTSxvQkFBb0I7R0FDekIsUUFBUSxLQUFLO0dBQ2IsTUFBTSxLQUFLLFFBQVE7R0FDbkIsYUFBYSxLQUFLLFFBQVE7RUFDM0I7RUFDQSxNQUFNLFVBQVUsS0FBSyxXQUFXLGNBQWM7R0FDN0MsVUFBVTtJQUNULElBQUksQ0FBQyxLQUFLLFFBQVEsWUFBWSxPQUFPLFFBQVEsdUJBQXVCLElBQUksTUFBTSxxQkFBcUIsQ0FBQztJQUNwRyxPQUFPLEtBQUssUUFBUSxXQUFXLFdBQVcsaUJBQWlCO0dBQzVEO0dBQ0EsU0FBUyxjQUFjLFVBQVU7SUFDaEMsS0FBSyxVQUFVO0tBQ2QsTUFBTTtLQUNOO0tBQ0E7SUFDRCxDQUFDO0dBQ0Y7R0FDQSxlQUFlO0lBQ2QsS0FBSyxVQUFVLEVBQUUsTUFBTSxRQUFRLENBQUM7R0FDakM7R0FDQTtHQUNBLE9BQU8sS0FBSyxRQUFRLFNBQVM7R0FDN0IsWUFBWSxLQUFLLFFBQVE7R0FDekIsYUFBYSxLQUFLLFFBQVE7R0FDMUIsY0FBYyxLQUFLLGVBQWUsT0FBTyxJQUFJO0VBQzlDLENBQUM7RUFDRCxNQUFNLFdBQVcsS0FBSyxNQUFNLFdBQVc7RUFDdkMsTUFBTSxXQUFXLENBQUMsUUFBUSxTQUFTO0VBQ25DLElBQUk7R0FDSCxJQUFJLFVBQVUsV0FBVztRQUNwQjtJQUNKLEtBQUssVUFBVTtLQUNkLE1BQU07S0FDTjtLQUNBO0lBQ0QsQ0FBQztJQUNELElBQUksS0FBSyxlQUFlLE9BQU8sVUFBVSxNQUFNLEtBQUssZUFBZSxPQUFPLFNBQVMsV0FBVyxNQUFNLGlCQUFpQjtJQUNySCxNQUFNLFVBQVUsTUFBTSxLQUFLLFFBQVEsV0FBVyxXQUFXLGlCQUFpQjtJQUMxRSxJQUFJLFlBQVksS0FBSyxNQUFNLFNBQVMsS0FBSyxVQUFVO0tBQ2xELE1BQU07S0FDTjtLQUNBO0tBQ0E7SUFDRCxDQUFDO0dBQ0Y7R0FDQSxJQUFJLEtBQUssTUFBTSxZQUFZLFFBQVEsU0FBUyxHQUFHLFdBQVc7R0FDMUQsTUFBTSxPQUFPLE1BQU0sUUFBUSxNQUFNO0dBQ2pDLE1BQU0sS0FBSyxlQUFlLE9BQU8sWUFBWSxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7R0FDekcsTUFBTSxLQUFLLFFBQVEsWUFBWSxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsaUJBQWlCO0dBQ3JGLE1BQU0sS0FBSyxlQUFlLE9BQU8sWUFBWSxNQUFNLE1BQU0sS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7R0FDMUgsTUFBTSxLQUFLLFFBQVEsWUFBWSxNQUFNLE1BQU0sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDM0YsS0FBSyxVQUFVO0lBQ2QsTUFBTTtJQUNOO0dBQ0QsQ0FBQztHQUNELE9BQU87RUFDUixTQUFTLE9BQU87R0FDZixJQUFJO0lBQ0gsTUFBTSxLQUFLLGVBQWUsT0FBTyxVQUFVLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtHQUN6RyxTQUFTLEdBQUc7SUFDWCxRQUFRLE9BQU8sQ0FBQztHQUNqQjtHQUNBLElBQUk7SUFDSCxNQUFNLEtBQUssUUFBUSxVQUFVLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDckYsU0FBUyxHQUFHO0lBQ1gsUUFBUSxPQUFPLENBQUM7R0FDakI7R0FDQSxJQUFJO0lBQ0gsTUFBTSxLQUFLLGVBQWUsT0FBTyxZQUFZLEtBQUssR0FBRyxPQUFPLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTLE1BQU0saUJBQWlCO0dBQzlILFNBQVMsR0FBRztJQUNYLFFBQVEsT0FBTyxDQUFDO0dBQ2pCO0dBQ0EsSUFBSTtJQUNILE1BQU0sS0FBSyxRQUFRLFlBQVksS0FBSyxHQUFHLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDL0YsU0FBUyxHQUFHO0lBQ1gsUUFBUSxPQUFPLENBQUM7R0FDakI7R0FDQSxLQUFLLFVBQVU7SUFDZCxNQUFNO0lBQ047R0FDRCxDQUFDO0dBQ0QsTUFBTTtFQUNQLFVBQVU7R0FDVCxJQUFJLEtBQUssYUFBYSxTQUFTLEtBQUssV0FBVyxLQUFLO0dBQ3BELEtBQUssZUFBZSxRQUFRLElBQUk7RUFDakM7Q0FDRDtDQUNBLFVBQVUsUUFBUTtFQUNqQixNQUFNLFdBQVcsVUFBVTtHQUMxQixRQUFRLE9BQU8sTUFBZjtJQUNDLEtBQUssVUFBVSxPQUFPO0tBQ3JCLEdBQUc7S0FDSCxjQUFjLE9BQU87S0FDckIsZUFBZSxPQUFPO0lBQ3ZCO0lBQ0EsS0FBSyxTQUFTLE9BQU87S0FDcEIsR0FBRztLQUNILFVBQVU7SUFDWDtJQUNBLEtBQUssWUFBWSxPQUFPO0tBQ3ZCLEdBQUc7S0FDSCxVQUFVO0lBQ1g7SUFDQSxLQUFLLFdBQVcsT0FBTztLQUN0QixHQUFHO0tBQ0gsU0FBUyxPQUFPO0tBQ2hCLE1BQU0sS0FBSztLQUNYLGNBQWM7S0FDZCxlQUFlO0tBQ2YsT0FBTztLQUNQLFVBQVUsT0FBTztLQUNqQixRQUFRO0tBQ1IsV0FBVyxPQUFPO0tBQ2xCLGFBQWEsS0FBSyxJQUFJO0lBQ3ZCO0lBQ0EsS0FBSyxXQUFXLE9BQU87S0FDdEIsR0FBRztLQUNILE1BQU0sT0FBTztLQUNiLGNBQWM7S0FDZCxlQUFlO0tBQ2YsT0FBTztLQUNQLFFBQVE7S0FDUixVQUFVO0lBQ1g7SUFDQSxLQUFLLFNBQVMsT0FBTztLQUNwQixHQUFHO0tBQ0gsTUFBTSxLQUFLO0tBQ1gsT0FBTyxPQUFPO0tBQ2QsY0FBYyxNQUFNLGVBQWU7S0FDbkMsZUFBZSxPQUFPO0tBQ3RCLFVBQVU7S0FDVixRQUFRO0lBQ1Q7R0FDRDtFQUNEO0VBQ0EsS0FBSyxRQUFRLFFBQVEsS0FBSyxLQUFLO0VBQy9CLGNBQWMsWUFBWTtHQUN6QixLQUFLLFdBQVcsU0FBUyxhQUFhO0lBQ3JDLFNBQVMsaUJBQWlCLE1BQU07R0FDakMsQ0FBQztHQUNELEtBQUssZUFBZSxPQUFPO0lBQzFCLFVBQVU7SUFDVixNQUFNO0lBQ047R0FDRCxDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7Ozs7O0FBS0EsU0FBUyxrQkFBa0I7Q0FDMUIsT0FBTztFQUNOLFNBQVMsS0FBSztFQUNkLE1BQU0sS0FBSztFQUNYLE9BQU87RUFDUCxjQUFjO0VBQ2QsZUFBZTtFQUNmLFVBQVU7RUFDVixRQUFRO0VBQ1IsV0FBVyxLQUFLO0VBQ2hCLGFBQWE7Q0FDZDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7QUNyU0EsSUFBSSxnQkFBZ0IsY0FBYyxhQUFhO0NBQzlDO0NBQ0E7Q0FDQTtDQUNBLFlBQVksU0FBUyxDQUFDLEdBQUc7RUFDeEIsTUFBTTtFQUNOLEtBQUssU0FBUztFQUNkLEtBQUssNkJBQTZCLElBQUksSUFBSTtFQUMxQyxLQUFLLDBCQUEwQixJQUFJLElBQUk7RUFDdkMsS0FBSyxjQUFjO0NBQ3BCOzs7Ozs7Ozs7O0NBVUEsTUFBTSxRQUFRLFNBQVMsT0FBTztFQUM3QixNQUFNLFdBQVcsSUFBSSxTQUFTO0dBQzdCO0dBQ0EsZUFBZTtHQUNmLFlBQVksRUFBRSxLQUFLO0dBQ25CLFNBQVMsT0FBTyx1QkFBdUIsT0FBTztHQUM5QztFQUNELENBQUM7RUFDRCxLQUFLLElBQUksUUFBUTtFQUNqQixPQUFPO0NBQ1I7Ozs7OztDQU1BLElBQUksVUFBVTtFQUNiLEtBQUssV0FBVyxJQUFJLFFBQVE7RUFDNUIsTUFBTSxRQUFRLFNBQVMsUUFBUTtFQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVO0dBQzlCLE1BQU0sa0JBQWtCLEtBQUssUUFBUSxJQUFJLEtBQUs7R0FDOUMsSUFBSSxpQkFBaUIsZ0JBQWdCLEtBQUssUUFBUTtRQUM3QyxLQUFLLFFBQVEsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDO0VBQ3hDO0VBQ0EsS0FBSyxPQUFPO0dBQ1gsTUFBTTtHQUNOO0VBQ0QsQ0FBQztDQUNGOzs7Ozs7Q0FNQSxPQUFPLFVBQVU7RUFDaEIsSUFBSSxLQUFLLFdBQVcsT0FBTyxRQUFRLEdBQUc7R0FDckMsU0FBUyxRQUFRO0dBQ2pCLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtJQUM5QixNQUFNLGtCQUFrQixLQUFLLFFBQVEsSUFBSSxLQUFLO0lBQzlDLElBQUksaUJBQWlCO0tBQ3BCLElBQUksZ0JBQWdCLFNBQVMsR0FBRztNQUMvQixNQUFNLFFBQVEsZ0JBQWdCLFFBQVEsUUFBUTtNQUM5QyxJQUFJLFVBQVUsSUFBSSxnQkFBZ0IsT0FBTyxPQUFPLENBQUM7S0FDbEQsT0FBTyxJQUFJLGdCQUFnQixPQUFPLFVBQVUsS0FBSyxRQUFRLE9BQU8sS0FBSztJQUN0RTtHQUNEO0VBQ0Q7RUFDQSxLQUFLLE9BQU87R0FDWCxNQUFNO0dBQ047RUFDRCxDQUFDO0NBQ0Y7Ozs7Ozs7Q0FPQSxJQUFJLFVBQVU7RUFDYixPQUFPLEtBQUssV0FBVyxJQUFJLFFBQVE7Q0FDcEM7Ozs7Ozs7O0NBUUEsT0FBTyxVQUFVO0VBQ2hCLE1BQU0sUUFBUSxTQUFTLFFBQVE7RUFDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUM5QixNQUFNLHVCQUF1QixLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFBRSxNQUFNLE1BQU0sRUFBRSxNQUFNLFdBQVcsU0FBUztHQUM5RixPQUFPLENBQUMsd0JBQXdCLHlCQUF5QjtFQUMxRCxPQUFPLE9BQU87Q0FDZjs7Ozs7Ozs7Q0FRQSxRQUFRLFVBQVU7RUFDakIsTUFBTSxRQUFRLFNBQVMsUUFBUTtFQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVLFFBQVEsS0FBSyxRQUFRLElBQUksS0FBSyxDQUFDLEVBQUUsTUFBTSxNQUFNLE1BQU0sWUFBWSxFQUFFLE1BQU0sUUFBUSxFQUFBLEVBQUksU0FBUyxLQUFLLFFBQVEsUUFBUTtPQUMzSSxPQUFPLFFBQVEsUUFBUTtDQUM3Qjs7Ozs7Ozs7Ozs7Q0FXQSxRQUFRO0VBQ1AsY0FBYyxZQUFZO0dBQ3pCLE1BQU0sWUFBWSxLQUFLLE9BQU87R0FDOUIsS0FBSyxXQUFXLE1BQU07R0FDdEIsS0FBSyxRQUFRLE1BQU07R0FDbkIsVUFBVSxTQUFTLGFBQWEsU0FBUyxRQUFRLENBQUM7R0FDbEQsVUFBVSxTQUFTLGFBQWE7SUFDL0IsS0FBSyxPQUFPO0tBQ1gsTUFBTTtLQUNOO0lBQ0QsQ0FBQztHQUNGLENBQUM7RUFDRixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7O0NBY0EsU0FBUztFQUNSLE9BQU8sTUFBTSxLQUFLLEtBQUssVUFBVTtDQUNsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsS0FBSyxTQUFTO0VBQ2IsTUFBTSxtQkFBbUI7R0FDeEIsT0FBTztHQUNQLEdBQUc7RUFDSjtFQUNBLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxNQUFNLGFBQWEsY0FBYyxrQkFBa0IsUUFBUSxDQUFDO0NBQ2xGOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0VBQ3JCLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxRQUFRLGFBQWEsY0FBYyxTQUFTLFFBQVEsQ0FBQztDQUMzRTs7Ozs7O0NBTUEsT0FBTyxPQUFPO0VBQ2IsY0FBYyxZQUFZO0dBQ3pCLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDcEMsU0FBUyxLQUFLO0dBQ2YsQ0FBQztFQUNGLENBQUM7Q0FDRjs7Ozs7O0NBTUEsd0JBQXdCO0VBQ3ZCLE1BQU0sa0JBQWtCLEtBQUssT0FBTyxDQUFDLENBQUMsUUFBUSxNQUFNLEVBQUUsTUFBTSxRQUFRO0VBQ3BFLE9BQU8sY0FBYyxZQUFZLFFBQVEsSUFBSSxnQkFBZ0IsS0FBSyxhQUFhLFNBQVMsU0FBUyxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDO0NBQ2pIO0FBQ0Q7Ozs7OztBQU1BLFNBQVMsU0FBUyxVQUFVO0NBQzNCLE9BQU8sU0FBUyxRQUFRLE9BQU87QUFDaEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxTkEsSUFBSSxtQkFBbUIsY0FBYyxhQUFhO0NBQ2pEO0NBQ0EsaUJBQWlCLEtBQUs7Q0FDdEI7Q0FDQTtDQUNBLFlBQVksUUFBUSxTQUFTO0VBQzVCLE1BQU07RUFDTixLQUFLLFVBQVU7RUFDZixLQUFLLFdBQVcsT0FBTztFQUN2QixLQUFLLFlBQVk7RUFDakIsS0FBSyxjQUFjO0NBQ3BCOzs7OztDQUtBLGNBQWM7RUFDYixLQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssSUFBSTtFQUNuQyxLQUFLLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSTtDQUNsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLFdBQVcsU0FBUztFQUNuQixNQUFNLGNBQWMsS0FBSztFQUN6QixLQUFLLFVBQVUsS0FBSyxRQUFRLHVCQUF1QixPQUFPO0VBQzFELElBQUksQ0FBQyxvQkFBb0IsS0FBSyxTQUFTLFdBQVcsR0FBRyxLQUFLLFFBQVEsaUJBQWlCLENBQUMsQ0FBQyxPQUFPO0dBQzNGLE1BQU07R0FDTixVQUFVLEtBQUs7R0FDZixVQUFVO0VBQ1gsQ0FBQztFQUNELElBQUksYUFBYSxlQUFlLEtBQUssUUFBUSxlQUFlLFFBQVEsWUFBWSxXQUFXLE1BQU0sUUFBUSxLQUFLLFFBQVEsV0FBVyxHQUFHLEtBQUssTUFBTTtPQUMxSSxJQUFJLEtBQUssa0JBQWtCLE1BQU0sV0FBVyxXQUFXLEtBQUssaUJBQWlCLFdBQVcsS0FBSyxPQUFPO0NBQzFHO0NBQ0EsY0FBYztFQUNiLElBQUksS0FBSyxVQUFVLFNBQVMsS0FBSyxLQUFLLGtCQUFrQjtHQUN2RCxLQUFLLGlCQUFpQixZQUFZLElBQUk7R0FDdEMsS0FBSyxjQUFjO0VBQ3BCO0NBQ0Q7Q0FDQSxnQkFBZ0I7RUFDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUcsS0FBSyxrQkFBa0IsZUFBZSxJQUFJO0NBQ3JFOzs7Ozs7O0NBT0EsaUJBQWlCLFFBQVE7RUFDeEIsS0FBSyxjQUFjO0VBQ25CLEtBQUssUUFBUSxNQUFNO0NBQ3BCOzs7Ozs7O0NBT0EsbUJBQW1CO0VBQ2xCLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxRQUFRO0VBQ1AsS0FBSyxrQkFBa0IsZUFBZSxJQUFJO0VBQzFDLEtBQUssbUJBQW1CLEtBQUs7RUFDN0IsS0FBSyxjQUFjO0VBQ25CLEtBQUssUUFBUTtDQUNkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsT0FBTyxXQUFXLFNBQVM7RUFDMUIsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxrQkFBa0IsZUFBZSxJQUFJO0VBQzFDLEtBQUssbUJBQW1CLEtBQUssUUFBUSxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sS0FBSyxTQUFTLEtBQUssT0FBTztFQUN4RixLQUFLLGlCQUFpQixZQUFZLElBQUk7RUFDdEMsT0FBTyxLQUFLLGlCQUFpQixRQUFRLFNBQVM7Q0FDL0M7Q0FDQSxnQkFBZ0I7RUFDZixNQUFNLFFBQVEsS0FBSyxrQkFBa0IsU0FBUyxnQkFBZ0I7RUFDOUQsS0FBSyxpQkFBaUI7R0FDckIsR0FBRztHQUNILFdBQVcsTUFBTSxXQUFXO0dBQzVCLFdBQVcsTUFBTSxXQUFXO0dBQzVCLFNBQVMsTUFBTSxXQUFXO0dBQzFCLFFBQVEsTUFBTSxXQUFXO0dBQ3pCLFFBQVEsS0FBSztHQUNiLE9BQU8sS0FBSztFQUNiO0NBQ0Q7Q0FDQSxRQUFRLFFBQVE7RUFDZixjQUFjLFlBQVk7R0FDekIsTUFBTSxnQkFBZ0IsS0FBSztHQUMzQixJQUFJLGlCQUFpQixLQUFLLGFBQWEsR0FBRztJQUN6QyxNQUFNLFlBQVksS0FBSyxlQUFlO0lBQ3RDLE1BQU0saUJBQWlCLEtBQUssZUFBZTtJQUMzQyxNQUFNLFVBQVU7S0FDZixRQUFRLEtBQUs7S0FDYixNQUFNLEtBQUssUUFBUTtLQUNuQixhQUFhLEtBQUssUUFBUTtJQUMzQjtJQUNBLElBQUksUUFBUSxTQUFTLFdBQVc7S0FDL0IsSUFBSTtNQUNILGNBQWMsWUFBWSxPQUFPLE1BQU0sV0FBVyxnQkFBZ0IsT0FBTztLQUMxRSxTQUFTLEdBQUc7TUFDWCxRQUFRLE9BQU8sQ0FBQztLQUNqQjtLQUNBLElBQUk7TUFDSCxjQUFjLFlBQVksT0FBTyxNQUFNLE1BQU0sV0FBVyxnQkFBZ0IsT0FBTztLQUNoRixTQUFTLEdBQUc7TUFDWCxRQUFRLE9BQU8sQ0FBQztLQUNqQjtJQUNELE9BQU8sSUFBSSxRQUFRLFNBQVMsU0FBUztLQUNwQyxJQUFJO01BQ0gsY0FBYyxVQUFVLE9BQU8sT0FBTyxXQUFXLGdCQUFnQixPQUFPO0tBQ3pFLFNBQVMsR0FBRztNQUNYLFFBQVEsT0FBTyxDQUFDO0tBQ2pCO0tBQ0EsSUFBSTtNQUNILGNBQWMsWUFBWSxLQUFLLEdBQUcsT0FBTyxPQUFPLFdBQVcsZ0JBQWdCLE9BQU87S0FDbkYsU0FBUyxHQUFHO01BQ1gsUUFBUSxPQUFPLENBQUM7S0FDakI7SUFDRDtHQUNEO0dBQ0EsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNwQyxTQUFTLEtBQUssY0FBYztHQUM3QixDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7O0FDdkxBLFNBQVMsV0FBVyxRQUFRLFFBQVE7Q0FDbkMsTUFBTSxhQUFhLElBQUksSUFBSSxNQUFNO0NBQ2pDLE9BQU8sT0FBTyxRQUFRLE1BQU0sQ0FBQyxXQUFXLElBQUksQ0FBQyxDQUFDO0FBQy9DOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUJBLElBQUksa0JBQWtCLGNBQWMsYUFBYTtDQUNoRDtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxtQkFBbUIsQ0FBQztDQUNwQixZQUFZLFFBQVEsU0FBUyxTQUFTO0VBQ3JDLE1BQU07RUFDTixLQUFLLFVBQVU7RUFDZixLQUFLLFdBQVc7RUFDaEIsS0FBSyxXQUFXLENBQUM7RUFDakIsS0FBSyxhQUFhLENBQUM7RUFDbkIsS0FBSyxVQUFVLENBQUM7RUFDaEIsS0FBSyxXQUFXLE9BQU87Q0FDeEI7Q0FDQSxjQUFjO0VBQ2IsSUFBSSxLQUFLLFVBQVUsU0FBUyxHQUFHLEtBQUssV0FBVyxTQUFTLGFBQWEsS0FBSyxhQUFhLFFBQVEsQ0FBQztDQUNqRztDQUNBLGdCQUFnQjtFQUNmLElBQUksQ0FBQyxLQUFLLFVBQVUsTUFBTSxLQUFLLFFBQVE7Q0FDeEM7Ozs7O0NBS0EsVUFBVTtFQUNULEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLLFdBQVcsU0FBUyxhQUFhO0dBQ3JDLFNBQVMsUUFBUTtFQUNsQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsV0FBVyxTQUFTLFNBQVM7RUFDNUIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVztFQUMyQjtHQUMxQyxNQUFNLGNBQWMsUUFBUSxLQUFLLFVBQVUsS0FBSyxRQUFRLG9CQUFvQixLQUFLLENBQUMsQ0FBQyxTQUFTO0dBQzVGLElBQUksSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLFNBQVMsWUFBWSxRQUFRLFFBQVEsS0FBSyx1RkFBdUY7RUFDM0o7RUFDQSxjQUFjLFlBQVk7R0FDekIsTUFBTSxnQkFBZ0IsS0FBSztHQUMzQixNQUFNLHFCQUFxQixLQUFLLHVCQUF1QixLQUFLLFFBQVE7R0FDcEUsbUJBQW1CLFNBQVMsVUFBVSxNQUFNLFNBQVMsV0FBVyxNQUFNLHFCQUFxQixDQUFDO0dBQzVGLE1BQU0sZUFBZSxtQkFBbUIsS0FBSyxVQUFVLE1BQU0sUUFBUTtHQUNyRSxNQUFNLFlBQVksYUFBYSxLQUFLLGFBQWEsU0FBUyxpQkFBaUIsQ0FBQztHQUM1RSxNQUFNLGtCQUFrQixjQUFjLFdBQVcsYUFBYTtHQUM5RCxNQUFNLGlCQUFpQixhQUFhLE1BQU0sVUFBVSxVQUFVLGFBQWEsY0FBYyxNQUFNO0dBQy9GLE1BQU0sc0JBQXNCLG1CQUFtQjtHQUMvQyxNQUFNLGtCQUFrQixzQkFBc0IsT0FBTyxVQUFVLE1BQU0sUUFBUSxVQUFVO0lBQ3RGLE1BQU0sT0FBTyxLQUFLLFFBQVE7SUFDMUIsT0FBTyxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsUUFBUSxJQUFJO0dBQ2xELENBQUM7R0FDRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsaUJBQWlCO0dBQzlDLElBQUkscUJBQXFCO0lBQ3hCLEtBQUssbUJBQW1CO0lBQ3hCLEtBQUssYUFBYTtHQUNuQjtHQUNBLEtBQUssVUFBVTtHQUNmLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FBRztHQUMxQixJQUFJLHFCQUFxQjtJQUN4QixXQUFXLGVBQWUsWUFBWSxDQUFDLENBQUMsU0FBUyxhQUFhO0tBQzdELFNBQVMsUUFBUTtJQUNsQixDQUFDO0lBQ0QsV0FBVyxjQUFjLGFBQWEsQ0FBQyxDQUFDLFNBQVMsYUFBYSxLQUFLLGFBQWEsUUFBUSxDQUFDO0dBQzFGO0dBQ0EsS0FBSyxRQUFRO0VBQ2QsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Q0FZQSxtQkFBbUI7RUFDbEIsT0FBTyxLQUFLO0NBQ2I7Ozs7OztDQU1BLGFBQWE7RUFDWixPQUFPLEtBQUssV0FBVyxLQUFLLGFBQWEsU0FBUyxnQkFBZ0IsQ0FBQztDQUNwRTs7Ozs7OztDQU9BLGVBQWU7RUFDZCxPQUFPLEtBQUs7Q0FDYjs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxvQkFBb0IsU0FBUyxTQUFTO0VBQ3JDLE1BQU0sVUFBVSxLQUFLLHVCQUF1QixPQUFPO0VBQ25ELE1BQU0sU0FBUyxRQUFRLEtBQUssVUFBVSxNQUFNLFNBQVMsb0JBQW9CLE1BQU0scUJBQXFCLENBQUM7RUFDckcsSUFBSSxRQUFRLFdBQVcsS0FBSyxXQUFXLFVBQVUsUUFBUSxNQUFNLE9BQU8sVUFBVSxNQUFNLFNBQVMsaUJBQWlCLE1BQU0sS0FBSyxRQUFRLE1BQU0sS0FBSyxRQUFRLE9BQU8sT0FBTyxVQUFVLE1BQU0sYUFBYSxLQUFLLFdBQVcsTUFBTSxHQUFHLEtBQUssVUFBVSxRQUFRLEtBQUssVUFBVSxNQUFNLFNBQVMsaUJBQWlCLENBQUM7RUFDalMsTUFBTSxjQUFjLFFBQVEsS0FBSyxVQUFVLE1BQU0sc0JBQXNCLFNBQVM7RUFDaEYsT0FBTztHQUNOO0lBQ0MsTUFBTTtJQUNOLE9BQU8sS0FBSyxlQUFlLEtBQUssUUFBUSxTQUFTLFdBQVc7R0FDN0Q7U0FDTTtJQUNMLE9BQU8sS0FBSyxhQUFhLFFBQVEsT0FBTztHQUN6QztFQUNEO0NBQ0Q7Q0FDQSxhQUFhLFFBQVEsU0FBUztFQUM3QixNQUFNLCtCQUErQixJQUFJLElBQUk7RUFDN0MsT0FBTyxRQUFRLEtBQUssT0FBTyxVQUFVO0dBQ3BDLE1BQU0saUJBQWlCLE9BQU87R0FDOUIsT0FBTyxDQUFDLE1BQU0sc0JBQXNCLHNCQUFzQixNQUFNLFNBQVMsWUFBWSxpQkFBaUIsaUJBQWlCO0lBQ3RILElBQUksQ0FBQyxhQUFhLElBQUksWUFBWSxHQUFHO0tBQ3BDLGFBQWEsSUFBSSxZQUFZO0tBQzdCLFFBQVEsU0FBUyxNQUFNO01BQ3RCLEVBQUUsU0FBUyxVQUFVLFlBQVk7S0FDbEMsQ0FBQztJQUNGO0dBQ0QsQ0FBQyxJQUFJO0VBQ04sQ0FBQztDQUNGO0NBQ0EsZUFBZSxPQUFPLFNBQVMsYUFBYTtFQUMzQyxJQUFJLFNBQVM7R0FDWixNQUFNLGFBQWEsS0FBSztHQUN4QixNQUFNLHFCQUFxQixnQkFBZ0IsS0FBSyxLQUFLLGVBQWUsS0FBSyxNQUFNLFdBQVcsV0FBVyxZQUFZLFVBQVUsWUFBWSxNQUFNLE1BQU0sTUFBTSxTQUFTLFdBQVcsRUFBRTtHQUMvSyxJQUFJLEtBQUssWUFBWSxLQUFLLGVBQWUsc0JBQXNCLFlBQVksS0FBSyxjQUFjO0lBQzdGLEtBQUssZUFBZTtJQUNwQixLQUFLLGNBQWMsS0FBSztJQUN4QixJQUFJLGdCQUFnQixLQUFLLEdBQUcsS0FBSyxtQkFBbUI7SUFDcEQsS0FBSyxrQkFBa0IsaUJBQWlCLEtBQUssaUJBQWlCLFFBQVEsS0FBSyxDQUFDO0dBQzdFO0dBQ0EsT0FBTyxLQUFLO0VBQ2I7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxxQkFBcUI7RUFDcEIsT0FBTyxDQUFDLEtBQUssVUFBVSxXQUFXLEtBQUssV0FBVyxNQUFNLFVBQVUsVUFBVTtHQUMzRSxPQUFPLFNBQVMsUUFBUSxZQUFZLEtBQUssUUFBUSxNQUFNLEVBQUUsU0FBUyxLQUFLO0VBQ3hFLENBQUM7Q0FDRjtDQUNBLHVCQUF1QixTQUFTO0VBQy9CLE1BQU0sbUNBQW1DLElBQUksSUFBSTtFQUNqRCxLQUFLLFdBQVcsU0FBUyxhQUFhO0dBQ3JDLE1BQU0sTUFBTSxTQUFTLFFBQVE7R0FDN0IsSUFBSSxDQUFDLEtBQUs7R0FDVixNQUFNLG9CQUFvQixpQkFBaUIsSUFBSSxHQUFHO0dBQ2xELElBQUksbUJBQW1CLGtCQUFrQixLQUFLLFFBQVE7UUFDakQsaUJBQWlCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQztFQUMxQyxDQUFDO0VBQ0QsTUFBTSxZQUFZLENBQUM7RUFDbkIsUUFBUSxTQUFTLFlBQVk7R0FDNUIsTUFBTSxtQkFBbUIsS0FBSyxRQUFRLG9CQUFvQixPQUFPO0dBQ2pFLE1BQU0sV0FBVyxpQkFBaUIsSUFBSSxpQkFBaUIsU0FBUyxDQUFDLEVBQUUsTUFBTSxLQUFLLElBQUksY0FBYyxLQUFLLFNBQVMsZ0JBQWdCO0dBQzlILFVBQVUsS0FBSztJQUNkLHVCQUF1QjtJQUN2QjtHQUNELENBQUM7RUFDRixDQUFDO0VBQ0QsT0FBTztDQUNSO0NBQ0EsYUFBYSxVQUFVO0VBQ3RCLFNBQVMsV0FBVyxXQUFXO0dBQzlCLEtBQUssVUFBVSxVQUFVLE1BQU07RUFDaEMsQ0FBQztDQUNGO0NBQ0EsVUFBVSxVQUFVLFFBQVE7RUFDM0IsTUFBTSxRQUFRLEtBQUssV0FBVyxRQUFRLFFBQVE7RUFDOUMsSUFBSSxVQUFVLElBQUk7R0FDakIsS0FBSyxVQUFVLEtBQUssUUFBUSxNQUFNO0dBQ2xDLEtBQUssUUFBUSxTQUFTO0dBQ3RCLEtBQUssUUFBUTtFQUNkO0NBQ0Q7Q0FDQSxVQUFVO0VBQ1QsSUFBSSxLQUFLLGFBQWEsR0FBRztHQUN4QixNQUFNLG9CQUFvQixLQUFLLG1CQUFtQjtHQUNsRCxNQUFNLGlCQUFpQixLQUFLO0dBQzVCLE1BQU0sWUFBWSxvQkFBb0IsaUJBQWlCLEtBQUssZUFBZSxLQUFLLGFBQWEsS0FBSyxTQUFTLEtBQUssZ0JBQWdCLEdBQUcsS0FBSyxVQUFVLFNBQVMsS0FBSyxpQkFBaUIsS0FBSyxVQUFVLE1BQU0sc0JBQXNCLFNBQVMsQ0FBQztHQUN0TyxJQUFJLHFCQUFxQixtQkFBbUIsV0FBVyxjQUFjLFlBQVk7SUFDaEYsS0FBSyxVQUFVLFNBQVMsYUFBYTtLQUNwQyxTQUFTLEtBQUssT0FBTztJQUN0QixDQUFDO0dBQ0YsQ0FBQztFQUNGO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNU9BLElBQUksYUFBYSxjQUFjLGFBQWE7Q0FDM0M7Q0FDQSxZQUFZLFNBQVMsQ0FBQyxHQUFHO0VBQ3hCLE1BQU07RUFDTixLQUFLLFNBQVM7RUFDZCxLQUFLLDJCQUEyQixJQUFJLElBQUk7Q0FDekM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsTUFBTSxRQUFRLFNBQVMsT0FBTztFQUM3QixNQUFNLFdBQVcsUUFBUTtFQUN6QixNQUFNLFlBQVksUUFBUSxhQUFhLHNCQUFzQixVQUFVLE9BQU87RUFDOUUsSUFBSSxRQUFRLEtBQUssSUFBSSxTQUFTO0VBQzlCLElBQUksQ0FBQyxPQUFPO0dBQ1gsUUFBUSxJQUFJLE1BQU07SUFDakI7SUFDQTtJQUNBO0lBQ0EsU0FBUyxPQUFPLG9CQUFvQixPQUFPO0lBQzNDO0lBQ0EsZ0JBQWdCLE9BQU8saUJBQWlCLFFBQVE7R0FDakQsQ0FBQztHQUNELEtBQUssSUFBSSxLQUFLO0VBQ2Y7RUFDQSxPQUFPO0NBQ1I7Ozs7Ozs7Q0FPQSxJQUFJLE9BQU87RUFDVixJQUFJLENBQUMsS0FBSyxTQUFTLElBQUksTUFBTSxTQUFTLEdBQUc7R0FDeEMsS0FBSyxTQUFTLElBQUksTUFBTSxXQUFXLEtBQUs7R0FDeEMsS0FBSyxPQUFPO0lBQ1gsTUFBTTtJQUNOO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLE9BQU8sT0FBTztFQUNiLElBQUksS0FBSyxTQUFTLElBQUksTUFBTSxTQUFTLE1BQU0sT0FBTztHQUNqRCxNQUFNLFFBQVE7R0FDZCxLQUFLLFNBQVMsT0FBTyxNQUFNLFNBQVM7R0FDcEMsS0FBSyxPQUFPO0lBQ1gsTUFBTTtJQUNOO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Ozs7Ozs7Ozs7Q0FVQSxRQUFRO0VBQ1AsY0FBYyxZQUFZO0dBQ3pCLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQ2hDLEtBQUssT0FBTyxLQUFLO0dBQ2xCLENBQUM7RUFDRixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsSUFBSSxXQUFXO0VBQ2QsT0FBTyxLQUFLLFNBQVMsSUFBSSxTQUFTO0NBQ25DOzs7Ozs7Ozs7OztDQVdBLFNBQVM7RUFDUixPQUFPLENBQUMsR0FBRyxLQUFLLFNBQVMsT0FBTyxDQUFDO0NBQ2xDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsS0FBSyxTQUFTO0VBQ2IsTUFBTSxtQkFBbUI7R0FDeEIsT0FBTztHQUNQLEdBQUc7RUFDSjtFQUNBLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxNQUFNLFVBQVUsV0FBVyxrQkFBa0IsS0FBSyxDQUFDO0NBQ3pFOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0VBQ3JCLE1BQU0sVUFBVSxLQUFLLE9BQU87RUFDNUIsT0FBTyxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxJQUFJLFFBQVEsUUFBUSxVQUFVLFdBQVcsU0FBUyxLQUFLLENBQUMsSUFBSTtDQUNsRzs7Ozs7O0NBTUEsT0FBTyxPQUFPO0VBQ2IsY0FBYyxZQUFZO0dBQ3pCLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDcEMsU0FBUyxLQUFLO0dBQ2YsQ0FBQztFQUNGLENBQUM7Q0FDRjs7Ozs7Q0FLQSxVQUFVO0VBQ1QsY0FBYyxZQUFZO0dBQ3pCLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQ2hDLE1BQU0sUUFBUTtHQUNmLENBQUM7RUFDRixDQUFDO0NBQ0Y7Ozs7O0NBS0EsV0FBVztFQUNWLGNBQWMsWUFBWTtHQUN6QixLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUNoQyxNQUFNLFNBQVM7R0FDaEIsQ0FBQztFQUNGLENBQUM7Q0FDRjtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbk5BLElBQUksY0FBYyxNQUFNO0NBQ3ZCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFZLFNBQVMsQ0FBQyxHQUFHO0VBQ3hCLEtBQUssY0FBYyxPQUFPLGNBQWMsSUFBSSxXQUFXO0VBQ3ZELEtBQUssaUJBQWlCLE9BQU8saUJBQWlCLElBQUksY0FBYztFQUNoRSxLQUFLLGtCQUFrQixPQUFPLGtCQUFrQixDQUFDO0VBQ2pELEtBQUssaUNBQWlDLElBQUksSUFBSTtFQUM5QyxLQUFLLG9DQUFvQyxJQUFJLElBQUk7RUFDakQsS0FBSyxjQUFjO0NBQ3BCOzs7Ozs7O0NBT0EsUUFBUTtFQUNQLEtBQUs7RUFDTCxJQUFJLEtBQUssZ0JBQWdCLEdBQUc7RUFDNUIsS0FBSyxvQkFBb0IsYUFBYSxVQUFVLE9BQU8sWUFBWTtHQUNsRSxJQUFJLFNBQVM7SUFDWixNQUFNLEtBQUssc0JBQXNCO0lBQ2pDLEtBQUssWUFBWSxRQUFRO0dBQzFCO0VBQ0QsQ0FBQztFQUNELEtBQUsscUJBQXFCLGNBQWMsVUFBVSxPQUFPLFdBQVc7R0FDbkUsSUFBSSxRQUFRO0lBQ1gsTUFBTSxLQUFLLHNCQUFzQjtJQUNqQyxLQUFLLFlBQVksU0FBUztHQUMzQjtFQUNELENBQUM7Q0FDRjs7Ozs7O0NBTUEsVUFBVTtFQUNULEtBQUs7RUFDTCxJQUFJLEtBQUssZ0JBQWdCLEdBQUc7RUFDNUIsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxvQkFBb0IsS0FBSztFQUM5QixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLHFCQUFxQixLQUFLO0NBQ2hDOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxXQUFXLFNBQVM7RUFDbkIsT0FBTyxLQUFLLFlBQVksUUFBUTtHQUMvQixHQUFHO0dBQ0gsYUFBYTtFQUNkLENBQUMsQ0FBQyxDQUFDO0NBQ0o7Ozs7Ozs7Ozs7Ozs7O0NBY0EsV0FBVyxTQUFTO0VBQ25CLE9BQU8sS0FBSyxlQUFlLFFBQVE7R0FDbEMsR0FBRztHQUNILFFBQVE7RUFDVCxDQUFDLENBQUMsQ0FBQztDQUNKOzs7Ozs7Ozs7OztDQVdBLGFBQWEsVUFBVTtFQUN0QixNQUFNLFVBQVUsS0FBSyxvQkFBb0IsRUFBRSxTQUFTLENBQUM7RUFDckQsT0FBTyxLQUFLLFlBQVksSUFBSSxRQUFRLFNBQVMsQ0FBQyxFQUFFLE1BQU07Q0FDdkQ7Ozs7Ozs7Ozs7Q0FVQSxnQkFBZ0IsU0FBUztFQUN4QixNQUFNLG1CQUFtQixLQUFLLG9CQUFvQixPQUFPO0VBQ3pELE1BQU0sUUFBUSxLQUFLLFlBQVksTUFBTSxNQUFNLGdCQUFnQjtFQUMzRCxNQUFNLGFBQWEsTUFBTSxNQUFNO0VBQy9CLElBQUksZUFBZSxLQUFLLEdBQUcsT0FBTyxLQUFLLFdBQVcsT0FBTztFQUN6RCxJQUFJLFFBQVEscUJBQXFCLE1BQU0sY0FBYyxrQkFBa0IsaUJBQWlCLFdBQVcsS0FBSyxDQUFDLEdBQUcsS0FBSyxjQUFjLGdCQUFnQjtFQUMvSSxPQUFPLFFBQVEsUUFBUSxVQUFVO0NBQ2xDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLGVBQWUsU0FBUztFQUN2QixPQUFPLEtBQUssWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxVQUFVLFlBQVk7R0FDckUsT0FBTyxDQUFDLFVBQVUsTUFBTSxJQUFJO0VBQzdCLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F1QkEsYUFBYSxVQUFVLFNBQVMsU0FBUztFQUN4QyxNQUFNLG1CQUFtQixLQUFLLG9CQUFvQixFQUFFLFNBQVMsQ0FBQztFQUU5RCxNQUFNLE9BQU8saUJBQWlCLFNBRGIsS0FBSyxZQUFZLElBQUksaUJBQWlCLFNBQVMsQ0FBQyxFQUFFLE1BQU0sSUFDMUI7RUFDL0MsSUFBSSxTQUFTLEtBQUssR0FBRztFQUNyQixPQUFPLEtBQUssWUFBWSxNQUFNLE1BQU0sZ0JBQWdCLENBQUMsQ0FBQyxRQUFRLE1BQU07R0FDbkUsR0FBRztHQUNILFFBQVE7RUFDVCxDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsZUFBZSxTQUFTLFNBQVMsU0FBUztFQUN6QyxPQUFPLGNBQWMsWUFBWSxLQUFLLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsZUFBZSxDQUFDLFVBQVUsS0FBSyxhQUFhLFVBQVUsU0FBUyxPQUFPLENBQUMsQ0FBQyxDQUFDO0NBQ3BKOzs7Ozs7Ozs7Ozs7Q0FZQSxjQUFjLFVBQVU7RUFDdkIsTUFBTSxVQUFVLEtBQUssb0JBQW9CLEVBQUUsU0FBUyxDQUFDO0VBQ3JELE9BQU8sS0FBSyxZQUFZLElBQUksUUFBUSxTQUFTLENBQUMsRUFBRTtDQUNqRDs7Ozs7Ozs7Ozs7OztDQWFBLGNBQWMsU0FBUztFQUN0QixNQUFNLGFBQWEsS0FBSztFQUN4QixjQUFjLFlBQVk7R0FDekIsV0FBVyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUM5QyxXQUFXLE9BQU8sS0FBSztHQUN4QixDQUFDO0VBQ0YsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxhQUFhLFNBQVMsU0FBUztFQUM5QixNQUFNLGFBQWEsS0FBSztFQUN4QixPQUFPLGNBQWMsWUFBWTtHQUNoQyxNQUFNLFVBQVUsV0FBVyxRQUFRLE9BQU87R0FDMUMsTUFBTSxtQkFBbUIsSUFBSSxJQUFJLE9BQU87R0FDeEMsUUFBUSxTQUFTLFVBQVU7SUFDMUIsTUFBTSxNQUFNO0dBQ2IsQ0FBQztHQUNELE9BQU8sS0FBSyxlQUFlO0lBQzFCLE1BQU07SUFDTixZQUFZLFVBQVUsaUJBQWlCLElBQUksS0FBSztHQUNqRCxHQUFHLE9BQU87RUFDWCxDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxjQUFjLFNBQVMsZ0JBQWdCLENBQUMsR0FBRztFQUMxQyxNQUFNLHlCQUF5QjtHQUM5QixRQUFRO0dBQ1IsR0FBRztFQUNKO0VBQ0EsTUFBTSxXQUFXLGNBQWMsWUFBWSxLQUFLLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLFVBQVUsTUFBTSxPQUFPLHNCQUFzQixDQUFDLENBQUM7RUFDakksT0FBTyxRQUFRLElBQUksUUFBUSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDbkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsa0JBQWtCLFNBQVMsVUFBVSxDQUFDLEdBQUc7RUFDeEMsT0FBTyxjQUFjLFlBQVk7R0FDaEMsS0FBSyxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQ3BELE1BQU0sV0FBVztHQUNsQixDQUFDO0dBQ0QsSUFBSSxTQUFTLGdCQUFnQixRQUFRLE9BQU8sUUFBUSxRQUFRO0dBQzVELE9BQU8sS0FBSyxlQUFlO0lBQzFCLEdBQUc7SUFDSCxNQUFNLFNBQVMsZUFBZSxTQUFTLFFBQVE7R0FDaEQsR0FBRyxPQUFPO0VBQ1gsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3QkEsZUFBZSxTQUFTLFVBQVUsQ0FBQyxHQUFHO0VBQ3JDLE1BQU0sZUFBZTtHQUNwQixHQUFHO0dBQ0gsZUFBZSxRQUFRLGlCQUFpQjtFQUN6QztFQUNBLE1BQU0sV0FBVyxjQUFjLFlBQVksS0FBSyxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsUUFBUSxVQUFVLENBQUMsTUFBTSxXQUFXLEtBQUssQ0FBQyxNQUFNLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxVQUFVO0dBQ3ZKLElBQUksVUFBVSxNQUFNLE1BQU0sS0FBSyxHQUFHLFlBQVk7R0FDOUMsTUFBTSxXQUFXLE1BQU0sTUFBTSxnQkFBZ0I7R0FDN0MsSUFBSSxDQUFDLGFBQWEsZ0JBQWdCLFVBQVUsVUFBVSxRQUFRLE1BQU0sSUFBSTtHQUN4RSxPQUFPLFdBQVcsUUFBUSxRQUFRLElBQUk7RUFDdkMsQ0FBQyxDQUFDO0VBQ0YsT0FBTyxRQUFRLElBQUksUUFBUSxDQUFDLENBQUMsS0FBSyxJQUFJO0NBQ3ZDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1DQSxNQUFNLE1BQU0sU0FBUztFQUNwQixNQUFNLG1CQUFtQixLQUFLLG9CQUFvQixPQUFPO0VBQ3pELElBQUksaUJBQWlCLFVBQVUsS0FBSyxHQUFHLGlCQUFpQixRQUFRO0VBQ2hFLE1BQU0sUUFBUSxLQUFLLFlBQVksTUFBTSxNQUFNLGdCQUFnQjtFQUMzRCxNQUFNLFlBQVksTUFBTSxjQUFjLGtCQUFrQixpQkFBaUIsV0FBVyxLQUFLLENBQUMsSUFBSSxNQUFNLE1BQU0sTUFBTSxnQkFBZ0IsSUFBSSxNQUFNLE1BQU07RUFDaEosTUFBTSxTQUFTLGlCQUFpQjtFQUNoQyxJQUFJLFFBQVEsT0FBTyxPQUFPLFNBQVM7RUFDbkMsT0FBTztDQUNSOzs7Ozs7Ozs7O0NBVUEsV0FBVyxTQUFTO0VBQ25CLE1BQU0sbUJBQW1CLEtBQUssb0JBQW9CLE9BQU87RUFDekQsSUFBSSxpQkFBaUIsVUFBVSxLQUFLLEdBQUcsaUJBQWlCLFFBQVE7RUFDaEUsTUFBTSxRQUFRLEtBQUssWUFBWSxNQUFNLE1BQU0sZ0JBQWdCO0VBQzNELE9BQU8sTUFBTSxjQUFjLGtCQUFrQixpQkFBaUIsV0FBVyxLQUFLLENBQUMsSUFBSSxNQUFNLE1BQU0sZ0JBQWdCLElBQUksUUFBUSxRQUFRLE1BQU0sTUFBTSxJQUFJO0NBQ3BKOzs7Ozs7Ozs7Q0FTQSxjQUFjLFNBQVM7RUFDdEIsT0FBTyxLQUFLLFdBQVcsT0FBTyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDdEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNkJBLGNBQWMsU0FBUztFQUN0QixRQUFRLFFBQVE7RUFDaEIsT0FBTyxLQUFLLE1BQU0sT0FBTztDQUMxQjs7Ozs7Ozs7Q0FRQSxtQkFBbUIsU0FBUztFQUMzQixRQUFRLFFBQVE7RUFDaEIsT0FBTyxLQUFLLFdBQVcsT0FBTztDQUMvQjs7Ozs7Ozs7Q0FRQSxzQkFBc0IsU0FBUztFQUM5QixPQUFPLEtBQUssbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJO0NBQzlEOzs7Ozs7Ozs7Q0FTQSx3QkFBd0IsU0FBUztFQUNoQyxRQUFRLFFBQVE7RUFDaEIsT0FBTyxLQUFLLGdCQUFnQixPQUFPO0NBQ3BDOzs7Ozs7Ozs7Ozs7O0NBYUEsd0JBQXdCO0VBQ3ZCLElBQUksY0FBYyxTQUFTLEdBQUcsT0FBTyxLQUFLLGVBQWUsc0JBQXNCO0VBQy9FLE9BQU8sUUFBUSxRQUFRO0NBQ3hCOzs7Ozs7Ozs7Ozs7O0NBYUEsZ0JBQWdCO0VBQ2YsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7Ozs7Ozs7Q0FhQSxtQkFBbUI7RUFDbEIsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7Ozs7Ozs7Q0FhQSxvQkFBb0I7RUFDbkIsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxrQkFBa0IsU0FBUztFQUMxQixLQUFLLGtCQUFrQjtDQUN4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsaUJBQWlCLFVBQVUsU0FBUztFQUNuQyxLQUFLLGVBQWUsSUFBSSxRQUFRLFFBQVEsR0FBRztHQUMxQztHQUNBLGdCQUFnQjtFQUNqQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Q0FhQSxpQkFBaUIsVUFBVTtFQUMxQixNQUFNLFdBQVcsQ0FBQyxHQUFHLEtBQUssZUFBZSxPQUFPLENBQUM7RUFDakQsTUFBTSxTQUFTLENBQUM7RUFDaEIsU0FBUyxTQUFTLGlCQUFpQjtHQUNsQyxJQUFJLGdCQUFnQixVQUFVLGFBQWEsUUFBUSxHQUFHLE9BQU8sT0FBTyxRQUFRLGFBQWEsY0FBYztFQUN4RyxDQUFDO0VBQ0QsT0FBTztDQUNSOzs7Ozs7Ozs7Ozs7O0NBYUEsb0JBQW9CLGFBQWEsU0FBUztFQUN6QyxLQUFLLGtCQUFrQixJQUFJLFFBQVEsV0FBVyxHQUFHO0dBQ2hEO0dBQ0EsZ0JBQWdCO0VBQ2pCLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7OztDQWFBLG9CQUFvQixhQUFhO0VBQ2hDLE1BQU0sV0FBVyxDQUFDLEdBQUcsS0FBSyxrQkFBa0IsT0FBTyxDQUFDO0VBQ3BELE1BQU0sU0FBUyxDQUFDO0VBQ2hCLFNBQVMsU0FBUyxpQkFBaUI7R0FDbEMsSUFBSSxnQkFBZ0IsYUFBYSxhQUFhLFdBQVcsR0FBRyxPQUFPLE9BQU8sUUFBUSxhQUFhLGNBQWM7RUFDOUcsQ0FBQztFQUNELE9BQU87Q0FDUjs7Ozs7Ozs7OztDQVVBLG9CQUFvQixTQUFTO0VBQzVCLElBQUksUUFBUSxZQUFZLE9BQU87RUFDL0IsTUFBTSxtQkFBbUI7R0FDeEIsR0FBRyxLQUFLLGdCQUFnQjtHQUN4QixHQUFHLEtBQUssaUJBQWlCLFFBQVEsUUFBUTtHQUN6QyxHQUFHO0dBQ0gsWUFBWTtFQUNiO0VBQ0EsSUFBSSxDQUFDLGlCQUFpQixXQUFXLGlCQUFpQixZQUFZLHNCQUFzQixpQkFBaUIsVUFBVSxnQkFBZ0I7RUFDL0gsSUFBSSxpQkFBaUIsdUJBQXVCLEtBQUssR0FBRyxpQkFBaUIscUJBQXFCLGlCQUFpQixnQkFBZ0I7RUFDM0gsSUFBSSxpQkFBaUIsaUJBQWlCLEtBQUssR0FBRyxpQkFBaUIsZUFBZSxDQUFDLENBQUMsaUJBQWlCO0VBQ2pHLElBQUksQ0FBQyxpQkFBaUIsZUFBZSxpQkFBaUIsV0FBVyxpQkFBaUIsY0FBYztFQUNoRyxJQUFJLGlCQUFpQixZQUFZLFdBQVcsaUJBQWlCLFVBQVU7RUFDdkUsT0FBTztDQUNSOzs7Ozs7Ozs7Q0FTQSx1QkFBdUIsU0FBUztFQUMvQixJQUFJLFNBQVMsWUFBWSxPQUFPO0VBQ2hDLE9BQU87R0FDTixHQUFHLEtBQUssZ0JBQWdCO0dBQ3hCLEdBQUcsU0FBUyxlQUFlLEtBQUssb0JBQW9CLFFBQVEsV0FBVztHQUN2RSxHQUFHO0dBQ0gsWUFBWTtFQUNiO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7Q0FhQSxRQUFRO0VBQ1AsS0FBSyxZQUFZLE1BQU07RUFDdkIsS0FBSyxlQUFlLE1BQU07Q0FDM0I7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xzQkEsU0FBUyxjQUFjLEVBQUUsVUFBVSxjQUFjLFNBQVMsV0FBVyxPQUFPLFVBQVUsQ0FBQyxHQUFHLE9BQU8sS0FBSyxHQUFHLGVBQWUsQ0FBQyxLQUFLO0NBQzdILE9BQU8sT0FBTyxZQUFZO0VBQ3pCLE1BQU0sU0FBUyxRQUFRO0VBQ3ZCLElBQUksUUFBUSxTQUFTLE9BQU87RUFDNUIsTUFBTSxRQUFRLFFBQVEsT0FBTyxjQUFjLENBQUMsQ0FBQyxLQUFLO0dBQ2pELFVBQVUsUUFBUTtHQUNsQixPQUFPO0VBQ1IsQ0FBQztFQUNELE1BQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxNQUFNLFVBQVU7RUFDN0MsSUFBSSxhQUFhLGdCQUFnQixTQUFTLE1BQU0sU0FBUztHQUN4RCxHQUFHLE1BQU07R0FDVCxhQUFhO0VBQ2QsQ0FBQztFQUNELElBQUksU0FBUztFQUNiLElBQUksWUFBWTtFQUNoQixNQUFNLGtCQUFrQixzQkFBc0I7R0FDN0MsUUFBUSxRQUFRO0dBQ2hCLE1BQU0sUUFBUTtHQUNkLFVBQVUsUUFBUTtHQUNsQixXQUFXLFFBQVE7R0FDbkIsV0FBVyxRQUFRO0VBQ3BCLFNBQVMsUUFBUSxjQUFjLFlBQVksTUFBTSxNQUFNO0VBQ3ZELE1BQU0seUJBQXlCLGFBQWEsUUFBUSxZQUFZO0VBQ2hFLE1BQU0sU0FBUyxNQUFNLFNBQVMsZUFBZTtFQUM3QyxNQUFNLG1CQUFtQixhQUFhLGdCQUFnQjtFQUN0RCxXQUFXLE1BQU0sU0FBUyxRQUFRO0dBQ2pDLElBQUksaUJBQWlCLEdBQUc7R0FDeEIsSUFBSSxrQkFBa0IsU0FBUyxRQUFRLFFBQVEsS0FBSztRQUMvQyxRQUFRLE9BQU8sYUFBYSxRQUFRLFdBQVcsU0FBUyxRQUFRLFNBQVMsS0FBSyxJQUFJLGVBQWUsTUFBTSxLQUFLLENBQUM7RUFDbkg7RUFDQSxJQUFJLG9CQUFvQixDQUFDLGlCQUFpQixHQUFHLFFBQVEsT0FBTyxhQUFhLFFBQVEsVUFBVSxNQUFNO0VBQ2pHLE1BQU0sT0FBTyxRQUFRLE9BQU8sYUFBYSxRQUFRLFFBQVE7RUFDekQsT0FBTyxTQUFTLEtBQUssSUFBSSxlQUFlO0NBQ3pDO0FBQ0Q7OztBQ3REQSxJQUFNLGdCQUFnQixPQUFPO0FBQzdCLElBQU0scUJBQXFCLE9BQU87QUFDbEMsSUFBTSxjQUFjLE9BQU87Ozs7Ozs7Ozs7QUNRM0IsSUFBTSxtQ0FBbUMsU0FBUyxvQkFBb0IsVUFBVTtDQUMvRSxNQUFNLGVBQWUsT0FBTyxNQUFNLFdBQVcsV0FBVyxPQUFPLFFBQVEsaUJBQWlCLGFBQWEsaUJBQWlCLFFBQVEsY0FBYyxDQUFDLE1BQU0sTUFBTSxPQUFPLEtBQUssQ0FBQyxJQUFJLFFBQVE7Q0FDbEwsSUFBSSxRQUFRLFlBQVksY0FDbkI7TUFBQSxDQUFDLG1CQUFtQixRQUFRLEdBQUcsUUFBUSxlQUFlO0NBQUE7QUFFNUQ7Ozs7OztBQU1BLElBQU0sOEJBQThCLHVCQUF1QjtDQUMxRCxhQUFNLGdCQUFnQjtFQUNyQixtQkFBbUIsV0FBVztDQUMvQixHQUFHLENBQUMsa0JBQWtCLENBQUM7QUFDeEI7Ozs7Ozs7OztBQVNBLElBQU0sZUFBZSxFQUFFLFFBQVEsb0JBQW9CLGNBQWMsT0FBTyxlQUFlO0NBQ3RGLE9BQU8sT0FBTyxXQUFXLENBQUMsbUJBQW1CLFFBQVEsS0FBSyxDQUFDLE9BQU8sY0FBYyxVQUFVLFlBQVksT0FBTyxTQUFTLEtBQUssS0FBSyxpQkFBaUIsY0FBYyxDQUFDLE9BQU8sT0FBTyxLQUFLLENBQUM7QUFDckw7Ozs7Ozs7OztBQzlCQSxJQUFNLHVCQUF1QixRQUFRLFVBQVUsTUFBTSxNQUFNLFNBQVMsS0FBSzs7Ozs7OztBQU96RSxJQUFNLHdCQUF3QixxQkFBcUI7Q0FDbEQsSUFBSSxpQkFBaUIsVUFBVTtFQUM5QixNQUFNLHVCQUF1QjtFQUM3QixNQUFNLFNBQVMsVUFBVSxVQUFVLFdBQVcsUUFBUSxLQUFLLElBQUksU0FBUyxzQkFBc0Isb0JBQW9CO0VBQ2xILE1BQU0sb0JBQW9CLGlCQUFpQjtFQUMzQyxpQkFBaUIsWUFBWSxPQUFPLHNCQUFzQixjQUFjLEdBQUcsU0FBUyxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxJQUFJLE1BQU0saUJBQWlCO0VBQy9JLElBQUksT0FBTyxpQkFBaUIsV0FBVyxVQUFVLGlCQUFpQixTQUFTLEtBQUssSUFBSSxpQkFBaUIsUUFBUSxvQkFBb0I7Q0FDbEk7QUFDRDs7Ozs7OztBQU9BLElBQU0saUJBQWlCLGtCQUFrQixXQUFXLGtCQUFrQixZQUFZLE9BQU87Ozs7Ozs7OztBQVN6RixJQUFNLG1CQUFtQixrQkFBa0IsVUFBVSx1QkFBdUIsU0FBUyxnQkFBZ0IsZ0JBQWdCLENBQUMsQ0FBQyxZQUFZO0NBQ2xJLG1CQUFtQixXQUFXO0FBQy9CLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaUdELFNBQVMsV0FBVyxFQUFFLFNBQVMsR0FBRyxXQUFXLGFBQWE7Q0FDekQsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLGNBQWMsZUFBZTtDQUNuQyxNQUFNLHFCQUFxQiwyQkFBMkI7Q0FDdEQsTUFBTSxhQUFhLFFBQVEsZUFBZTtDQUMxQyxNQUFNLG1CQUFBLGFBQXlCLGNBQWMsUUFBUSxLQUFLLFNBQVM7RUFDbEUsTUFBTSxtQkFBbUIsT0FBTyxvQkFBb0IsSUFBSTtFQUN4RCxpQkFBaUIscUJBQXFCLGNBQWMsZ0JBQWdCLGFBQWEsZUFBZSxLQUFLO0VBQ3JHLE9BQU87Q0FDUixDQUFDLEdBQUc7RUFDSDtFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUM7Q0FDRCxpQkFBaUIsU0FBUyxpQkFBaUI7RUFDMUMscUJBQXFCLFlBQVk7RUFDakMsTUFBTSxRQUFRLE9BQU8sY0FBYyxDQUFDLENBQUMsSUFBSSxhQUFhLFNBQVM7RUFDL0QsZ0NBQWdDLGNBQWMsb0JBQW9CLEtBQUs7Q0FDeEUsQ0FBQztDQUNELDJCQUEyQixrQkFBa0I7Q0FDN0MsTUFBTSxDQUFDLFlBQUEsYUFBa0IsZUFBZSxJQUFJLGdCQUFnQixRQUFRLGtCQUFrQixPQUFPLENBQUM7Q0FDOUYsTUFBTSxDQUFDLGtCQUFrQixtQkFBbUIsZUFBZSxTQUFTLG9CQUFvQixrQkFBa0IsUUFBUSxPQUFPO0NBQ3pILGFBQU0sZ0JBQWdCO0VBQ3JCLFNBQVMsV0FBVyxrQkFBa0IsT0FBTztDQUM5QyxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELE1BQU0sa0JBQWtCLENBQUMsZUFBZTtDQUN4QyxhQUFNLHFCQUFBLGFBQTJCLGFBQWEsa0JBQWtCLGtCQUFrQixTQUFTLFVBQVUsY0FBYyxXQUFXLGFBQWEsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxVQUFVLGVBQWUsQ0FBQyxTQUFTLFNBQVMsaUJBQWlCLFNBQVMsU0FBUyxpQkFBaUIsQ0FBQztDQUN4UCxNQUFNLG1CQUFtQixpQkFBaUIsTUFBTSxRQUFRLFVBQVUsY0FBYyxpQkFBaUIsUUFBUSxNQUFNLENBQUMsSUFBSSxpQkFBaUIsU0FBUyxRQUFRLFVBQVU7RUFDL0osTUFBTSxPQUFPLGlCQUFpQjtFQUM5QixJQUFJLFFBQVEsY0FBYyxNQUFNLE1BQU0sR0FFckMsT0FBTyxnQkFBZ0IsTUFBTSxJQURILGNBQWMsUUFBUSxJQUNuQixHQUFlLGtCQUFrQjtFQUUvRCxPQUFPLENBQUM7Q0FDVCxDQUFDLElBQUksQ0FBQztDQUNOLElBQUksaUJBQWlCLFNBQVMsR0FBRyxNQUFNLFFBQVEsSUFBSSxnQkFBZ0I7Q0FDbkUsTUFBTSxvQ0FBb0MsaUJBQWlCLE1BQU0sUUFBUSxVQUFVO0VBQ2xGLE1BQU0sUUFBUSxpQkFBaUI7RUFDL0IsT0FBTyxTQUFTLFlBQVk7R0FDM0I7R0FDQTtHQUNBLGNBQWMsTUFBTTtHQUNwQixPQUFPLE9BQU8sY0FBYyxDQUFDLENBQUMsSUFBSSxNQUFNLFNBQVM7R0FDakQsVUFBVSxNQUFNO0VBQ2pCLENBQUM7Q0FDRixDQUFDO0NBQ0QsSUFBSSxtQ0FBbUMsTUFBTSxrQ0FBa0M7Q0FDL0UsT0FBTyxrQkFBa0IsWUFBWSxDQUFDO0FBQ3ZDOzs7Ozs7Ozs7Ozs7Ozs7QUN6S0EsU0FBUyxhQUFhLFNBQVMsVUFBVSxhQUFhO0NBRXBELElBQUksT0FBTyxZQUFZLFlBQVksTUFBTSxRQUFRLE9BQU8sR0FBRyxNQUFNLElBQUksTUFBTSxnU0FBZ1M7Q0FFNVcsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxxQkFBcUIsMkJBQTJCO0NBQ3RELE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxtQkFBbUIsT0FBTyxvQkFBb0IsT0FBTztDQUMzRCxNQUFNLFFBQVEsT0FBTyxjQUFjLENBQUMsQ0FBQyxJQUFJLGlCQUFpQixTQUFTO0NBRWxFLElBQUksQ0FBQyxpQkFBaUIsU0FBUyxRQUFRLE1BQU0sSUFBSSxpQkFBaUIsVUFBVSxtUEFBbVA7Q0FFaFUsTUFBTSxhQUFhLFFBQVEsZUFBZTtDQUMxQyxpQkFBaUIscUJBQXFCLGNBQWMsZ0JBQWdCLGFBQWEsZUFBZSxLQUFLO0NBQ3JHLHFCQUFxQixnQkFBZ0I7Q0FDckMsZ0NBQWdDLGtCQUFrQixvQkFBb0IsS0FBSztDQUMzRSwyQkFBMkIsa0JBQWtCO0NBQzdDLE1BQU0sQ0FBQyxZQUFBLGFBQWtCLGVBQWUsSUFBSSxTQUFTLFFBQVEsZ0JBQWdCLENBQUM7Q0FDOUUsTUFBTSxTQUFTLFNBQVMsb0JBQW9CLGdCQUFnQjtDQUM1RCxhQUFNLGdCQUFnQjtFQUNyQixTQUFTLFdBQVcsZ0JBQWdCO0NBQ3JDLEdBQUcsQ0FBQyxrQkFBa0IsUUFBUSxDQUFDO0NBQy9CLE1BQU0sa0JBQWtCLENBQUMsZUFBZTtDQUN4QyxhQUFNLHFCQUFBLGFBQTJCLGFBQWEsa0JBQWtCO0VBQy9ELE1BQU0sY0FBYyxrQkFBa0IsU0FBUyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsSUFBSTtFQUNwRyxTQUFTLGFBQWE7RUFDdEIsT0FBTztDQUNSLEdBQUcsQ0FBQyxVQUFVLGVBQWUsQ0FBQyxTQUFTLFNBQVMsaUJBQWlCLFNBQVMsU0FBUyxpQkFBaUIsQ0FBQztDQUNyRyxJQUFJLGNBQWMsa0JBQWtCLE1BQU0sR0FBRyxNQUFNLGdCQUFnQixrQkFBa0IsVUFBVSxrQkFBa0I7Q0FDakgsSUFBSSxZQUFZO0VBQ2Y7RUFDQTtFQUNBLGNBQWMsaUJBQWlCO0VBQy9CO0VBQ0EsVUFBVSxpQkFBaUI7Q0FDNUIsQ0FBQyxHQUFHLE1BQU0sT0FBTztDQUNqQixPQUFPLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLFlBQVksTUFBTSxJQUFJO0FBQy9FOztBQ3ZEQSxTQUFTLFNBQVMsU0FBUyxhQUFhO0NBQ3ZDLE9BQU8sYUFBYSxTQUFTLGVBQWUsV0FBVztBQUN4RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2dFQSxTQUFTLGlCQUFpQixTQUFTLGFBQWE7Q0FFOUMsSUFBSSxRQUFRLFlBQVksV0FBVyxRQUFRLE1BQU0sK0NBQStDO0NBRWpHLE9BQU8sYUFBYTtFQUNuQixHQUFHO0VBQ0gsU0FBUztFQUNULFVBQVU7RUFDVixjQUFjO0VBQ2QsaUJBQWlCLEtBQUs7Q0FDdkIsR0FBRyxlQUFlLFdBQVc7QUFDOUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUUEsU0FBUyx5QkFBeUIsU0FBUyxhQUFhO0NBRXRELElBQUksUUFBUSxZQUFZLFdBQVcsUUFBUSxNQUFNLHVEQUF1RDtDQUV6RyxPQUFPLGFBQWE7RUFDbkIsR0FBRztFQUNILFNBQVM7RUFDVCxVQUFVO0VBQ1YsY0FBYztFQUNkLGlCQUFpQixLQUFLO0NBQ3ZCLEdBQUcsdUJBQXVCLFdBQVc7QUFDdEM7O0FDL0ZBLFNBQVMsbUJBQW1CLFNBQVMsYUFBYTtDQUNqRCxPQUFPLFdBQVc7RUFDakIsR0FBRztFQUNILFNBQVMsUUFBUSxRQUFRLEtBQUssVUFBVTtHQUV0QyxJQUFJLE1BQU0sWUFBWSxXQUFXLFFBQVEsTUFBTSxpREFBaUQ7R0FFakcsT0FBTztJQUNOLEdBQUc7SUFDSCxVQUFVO0lBQ1YsY0FBYztJQUNkLFNBQVM7SUFDVCxpQkFBaUIsS0FBSztHQUN2QjtFQUNELENBQUM7Q0FDRixHQUFHLFdBQVc7QUFDZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2NBLFNBQVMsaUJBQWlCLFNBQVMsYUFBYTtDQUMvQyxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLElBQUksQ0FBQyxPQUFPLGNBQWMsUUFBUSxRQUFRLEdBQUcsT0FBTyxNQUFNLE9BQU8sQ0FBQyxDQUFDLE1BQU0sSUFBSTtBQUM5RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ01BLFNBQVMseUJBQXlCLFNBQVMsYUFBYTtDQUN2RCxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLElBQUksQ0FBQyxPQUFPLGNBQWMsUUFBUSxRQUFRLEdBQUcsT0FBTyxjQUFjLE9BQU8sQ0FBQyxDQUFDLE1BQU0sSUFBSTtBQUN0Rjs7QUM5Q0EsU0FBUyxhQUFhLFNBQVM7Q0FDOUIsT0FBTztBQUNSOztBQ0ZBLFNBQVMscUJBQXFCLFNBQVM7Q0FDdEMsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzRDQSxJQUFNLHFCQUFxQixFQUFFLFVBQVUsVUFBVSxDQUFDLEdBQUcsT0FBTyxrQkFBa0I7Q0FDN0UsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLGFBQUEsYUFBbUIsT0FBTyxPQUFPO0NBQ3ZDLGFBQU0sZ0JBQWdCO0VBQ3JCLFdBQVcsVUFBVTtDQUN0QixDQUFDO0NBQ0QsTUFBTSxpQkFBQSxhQUF1QixjQUFjO0VBQzFDLElBQUksT0FBTztHQUNWLElBQUksT0FBTyxVQUFVLFVBQVU7R0FDL0IsTUFBTSxhQUFhLE9BQU8sY0FBYztHQUN4QyxNQUFNLFVBQVUsTUFBTSxXQUFXLENBQUM7R0FDbEMsTUFBTSxhQUFhLENBQUM7R0FDcEIsTUFBTSxrQkFBa0IsQ0FBQztHQUN6QixLQUFLLE1BQU0sbUJBQW1CLFNBQVM7SUFDdEMsTUFBTSxnQkFBZ0IsV0FBVyxJQUFJLGdCQUFnQixTQUFTO0lBQzlELElBQUksQ0FBQyxlQUFlLFdBQVcsS0FBSyxlQUFlO1NBQzlDLElBQUksZ0JBQWdCLE1BQU0sZ0JBQWdCLGNBQWMsTUFBTSxpQkFBaUIsZ0JBQWdCLFdBQVcsY0FBYyxNQUFNLFdBQVcsYUFBYSxjQUFjLE1BQU0sZ0JBQWdCLGNBQWMsZ0JBQWdCLGVBQWUsY0FBYyxNQUFNLGVBQWUsZ0JBQWdCLEtBQUssZUFBZTtHQUNwVDtHQUNBLElBQUksV0FBVyxTQUFTLEdBQUcsUUFBUSxRQUFRLEVBQUUsU0FBUyxXQUFXLEdBQUcsV0FBVyxPQUFPO0dBQ3RGLElBQUksZ0JBQWdCLFNBQVMsR0FBRyxPQUFPO0VBQ3hDO0NBQ0QsR0FBRyxDQUFDLFFBQVEsS0FBSyxDQUFDO0NBQ2xCLGFBQU0sZ0JBQWdCO0VBQ3JCLElBQUksZ0JBQWdCLFFBQVEsUUFBUSxFQUFFLFNBQVMsZUFBZSxHQUFHLFdBQVcsT0FBTztDQUNwRixHQUFHLENBQUMsUUFBUSxjQUFjLENBQUM7Q0FDM0IsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25DQSxTQUFTLGNBQWMsU0FBUyxhQUFhO0NBQzVDLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxhQUFhLE9BQU8sY0FBYztDQUN4QyxPQUFBLGFBQWEscUJBQUEsYUFBMkIsYUFBYSxrQkFBa0IsV0FBVyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxTQUFTLE9BQU8sV0FBVyxPQUFPLFNBQVMsT0FBTyxXQUFXLE9BQU8sQ0FBQztBQUN4Tjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEJBLFNBQVMsY0FBYyxTQUFTLGFBQWE7Q0FDNUMsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxPQUFPLGlCQUFpQixFQUFFLFNBQVM7RUFDbEMsR0FBRztFQUNILFFBQVE7Q0FDVCxFQUFFLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDZDs7Ozs7OztBQU9BLFNBQVMsd0JBQXdCO0NBQ2hDLElBQUk7Q0FDSixRQUFRLGVBQWUsWUFBWTtFQUNsQyxJQUFJLFNBQVMsQ0FBQztFQUNkLElBQUk7RUFDSixhQUFhO0dBQ1osTUFBTSxZQUFZLGNBQWMsUUFBUSxRQUFRLE9BQU87R0FDdkQsTUFBTSxhQUFhLFVBQVUsU0FBUyxhQUFhLENBQUMsVUFBVSxTQUFTLEtBQUssQ0FBQztHQUM3RSxJQUFJLENBQUMsWUFBWSxXQUFXLFdBQVcsT0FBTyxVQUFVLFdBQVcsTUFBTSxPQUFPLFVBQVUsQ0FBQyxPQUFPLEdBQUcsT0FBTyxPQUFPLE1BQU0sQ0FBQyxHQUFHO0lBQzVILFNBQVM7SUFDVCxXQUFXLGlCQUFpQixnQkFBZ0IsVUFBVSxLQUFLLGFBQWEsUUFBUSxTQUFTLFFBQVEsT0FBTyxRQUFRLElBQUksU0FBUyxLQUFLLENBQUM7SUFDbkksaUJBQWlCO0dBQ2xCO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXNFQSxTQUFTLGlCQUFpQixVQUFVLENBQUMsR0FBRyxhQUFhO0NBQ3BELE1BQU0sZ0JBQWdCLGVBQWUsV0FBVyxDQUFDLENBQUMsaUJBQWlCO0NBQ25FLE1BQU0sQ0FBQyxrQkFBQSxhQUF3QixlQUFlLHNCQUFzQixDQUFDO0NBQ3JFLE1BQU0sY0FBYyxlQUFlLGVBQWUsT0FBTztDQUN6RCxPQUFBLGFBQWEscUJBQUEsYUFBMkIsYUFBYSxrQkFBa0IsY0FBYyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLGFBQWEsV0FBVztBQUNwTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM2Q0EsU0FBUyxZQUFZLFNBQVMsYUFBYTtDQUMxQyxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLE1BQU0sQ0FBQyxZQUFBLGFBQWtCLGVBQWUsSUFBSSxpQkFBaUIsUUFBUSxPQUFPLENBQUM7Q0FDN0UsYUFBTSxnQkFBZ0I7RUFDckIsU0FBUyxXQUFXLE9BQU87Q0FDNUIsR0FBRyxDQUFDLFVBQVUsT0FBTyxDQUFDO0NBQ3RCLE1BQU0sU0FBQSxhQUFlLHFCQUFBLGFBQTJCLGFBQWEsa0JBQWtCLFNBQVMsVUFBVSxjQUFjLFdBQVcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsU0FBUyxTQUFTLGlCQUFpQixTQUFTLFNBQVMsaUJBQWlCLENBQUM7Q0FDN04sTUFBTSxTQUFBLGFBQWUsYUFBYSxHQUFHLFNBQVM7RUFDN0MsU0FBUyxPQUFPLEtBQUssSUFBSSxLQUFLLEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSTtDQUM3QyxHQUFHLENBQUMsUUFBUSxDQUFDO0NBQ2IsSUFBSSxPQUFPLFNBQVMsaUJBQWlCLFNBQVMsUUFBUSxjQUFjLENBQUMsT0FBTyxLQUFLLENBQUMsR0FBRyxNQUFNLE9BQU87Q0FDbEcsT0FBTztFQUNOLEdBQUc7RUFDSDtFQUNBLGFBQWEsT0FBTztDQUNyQjtBQUNEOztBQzVMQSxTQUFTLGdCQUFnQixTQUFTO0NBQ2pDLE9BQU87QUFDUjs7QUNDQSxTQUFTLGlCQUFpQixTQUFTLGFBQWE7Q0FDL0MsT0FBTyxhQUFhLFNBQVMsdUJBQXVCLFdBQVc7QUFDaEUiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0M119