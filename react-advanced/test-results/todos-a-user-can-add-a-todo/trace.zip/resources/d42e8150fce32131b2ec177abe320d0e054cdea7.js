const StrictMode = __vite__cjsImport3_react["StrictMode"];const createRoot = __vite__cjsImport4_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import "/src/index.css";
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=37813280";
import { ReactQueryDevtools } from "/node_modules/.vite/deps/@tanstack_react-query-devtools.js?v=37813280";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=37813280";
import __vite__cjsImport4_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=37813280";
import { BrowserRouter } from "/node_modules/.vite/deps/react-router.js?v=37813280";
import { ErrorBoundary } from "/src/day3/ErrorBoundary.tsx";
import App from "/src/App.tsx";
var _jsxFileName = "/Users/luka/Documents/Work/React Course/React advanced 2026/react-advanced/src/main.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=37813280";
const queryClient = new QueryClient({ defaultOptions: { queries: { staleTime: 3e4 } } });
createRoot(document.getElementById("root"), {
	onCaughtError: () => {
		// caught by an error boundary
		// logError(error, info.componentStack)
	},
	onUncaughtError: () => {
		// no boundary caught it: the app is gone
		// logError(error, info.componentStack)
	}
}).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
	client: queryClient,
	children: [/* @__PURE__ */ _jsxDEV(ErrorBoundary, {
		fallback: (error, reset) => /* @__PURE__ */ _jsxDEV("div", {
			role: "alert",
			children: [/* @__PURE__ */ _jsxDEV("p", { children: ["Something went wrong: ", error.message] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 15
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: reset,
				children: "Try again"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 15
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 13
		}, this),
		children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 11
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 9
	}, this), /* @__PURE__ */ _jsxDEV(ReactQueryDevtools, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 40,
		columnNumber: 9
	}, this)]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 29,
	columnNumber: 7
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 28,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 27,
	columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUNQLFNBQVMsYUFBYSwyQkFBMkI7QUFDakQsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFFOUIsT0FBTyxTQUFTOzs7QUFFaEIsTUFBTSxjQUFjLElBQUksWUFBWSxFQUNsQyxnQkFBZ0IsRUFDZCxTQUFTLEVBQUUsV0FBVyxJQUFPLEVBQy9CLEVBQ0YsQ0FBQztBQUVELFdBQVcsU0FBUyxlQUFlLE1BQU0sR0FBSTtDQUMzQyxxQkFBcUI7OztDQUdyQjtDQUNBLHVCQUF1Qjs7O0NBR3ZCO0FBQ0YsQ0FBQyxDQUFDLENBQUMsT0FDRCx3QkFBQyxZQUFELFlBQ0Usd0JBQUMsZUFBRCxZQUNFLHdCQUFDLHFCQUFEO0NBQXFCLFFBQVE7V0FBN0IsQ0FDRSx3QkFBQyxlQUFEO0VBQ0UsV0FBVyxPQUFPLFVBQ2hCLHdCQUFDLE9BQUQ7R0FBSyxNQUFLO2FBQVYsQ0FDRSx3QkFBQyxLQUFELGFBQUcsMEJBQXVCLE1BQU0sT0FBVzs7OzthQUMzQyx3QkFBQyxVQUFEO0lBQVEsU0FBUztjQUFPO0dBQWlCOzs7O1dBQ3RDOzs7Ozs7WUFHUCx3QkFBQyxLQUFELENBQU07Ozs7O0NBQ087Ozs7V0FDZix3QkFBQyxvQkFBRCxDQUFxQjs7OztTQUNGOzs7OztTQUNSOzs7O1NBQ0w7Ozs7UUFDZCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJtYWluLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4vaW5kZXguY3NzJ1xuaW1wb3J0IHsgUXVlcnlDbGllbnQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBSZWFjdFF1ZXJ5RGV2dG9vbHMgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnktZGV2dG9vbHMnXG5pbXBvcnQgeyBTdHJpY3RNb2RlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCdcbmltcG9ydCB7IEJyb3dzZXJSb3V0ZXIgfSBmcm9tICdyZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAnQC9kYXkzL0Vycm9yQm91bmRhcnkudHN4J1xuXG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwLnRzeCdcblxuY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoe1xuICBkZWZhdWx0T3B0aW9uczoge1xuICAgIHF1ZXJpZXM6IHsgc3RhbGVUaW1lOiAzMF8wMDAgfSwgLy8gZGF0YSBjb3VudHMgYXMgZnJlc2ggZm9yIDMwIHNcbiAgfSxcbn0pXG5cbmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSEsIHtcbiAgb25DYXVnaHRFcnJvcjogKCkgPT4ge1xuICAgIC8vIGNhdWdodCBieSBhbiBlcnJvciBib3VuZGFyeVxuICAgIC8vIGxvZ0Vycm9yKGVycm9yLCBpbmZvLmNvbXBvbmVudFN0YWNrKVxuICB9LFxuICBvblVuY2F1Z2h0RXJyb3I6ICgpID0+IHtcbiAgICAvLyBubyBib3VuZGFyeSBjYXVnaHQgaXQ6IHRoZSBhcHAgaXMgZ29uZVxuICAgIC8vIGxvZ0Vycm9yKGVycm9yLCBpbmZvLmNvbXBvbmVudFN0YWNrKVxuICB9LFxufSkucmVuZGVyKFxuICA8U3RyaWN0TW9kZT5cbiAgICA8QnJvd3NlclJvdXRlcj5cbiAgICAgIDxRdWVyeUNsaWVudFByb3ZpZGVyIGNsaWVudD17cXVlcnlDbGllbnR9PlxuICAgICAgICA8RXJyb3JCb3VuZGFyeVxuICAgICAgICAgIGZhbGxiYWNrPXsoZXJyb3IsIHJlc2V0KSA9PiAoXG4gICAgICAgICAgICA8ZGl2IHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICA8cD5Tb21ldGhpbmcgd2VudCB3cm9uZzoge2Vycm9yLm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3Jlc2V0fT5UcnkgYWdhaW48L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgID5cbiAgICAgICAgICA8QXBwIC8+XG4gICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiAgICAgICAgPFJlYWN0UXVlcnlEZXZ0b29scyAvPlxuICAgICAgPC9RdWVyeUNsaWVudFByb3ZpZGVyPlxuICAgIDwvQnJvd3NlclJvdXRlcj5cbiAgPC9TdHJpY3RNb2RlPixcbilcbiJdfQ==