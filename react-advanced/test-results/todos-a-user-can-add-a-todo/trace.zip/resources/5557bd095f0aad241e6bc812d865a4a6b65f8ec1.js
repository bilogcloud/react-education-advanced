import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/day3/ErrorBoundary.tsx");const Component = __vite__cjsImport0_react["Component"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=37813280";
export class ErrorBoundary extends Component {
	state = { error: null };
	static getDerivedStateFromError(error) {
		return { error };
	}
	reset = () => this.setState({ error: null });
	render() {
		if (this.state.error) return this.props.fallback(this.state.error, this.reset);
		return this.props.children;
	}
}
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/day3/ErrorBoundary.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/luka/Documents/Work/React Course/React advanced 2026/react-advanced/src/day3/ErrorBoundary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/luka/Documents/Work/React Course/React advanced 2026/react-advanced/src/day3/ErrorBoundary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUM7QUFRMUMsT0FBTyxNQUFNLHNCQUFzQixVQUF3QjtDQUN6RCxRQUFlLEVBQUUsT0FBTyxLQUFLO0NBRTdCLE9BQU8seUJBQXlCLE9BQXFCO0VBQ25ELE9BQU8sRUFBRSxNQUFNO0NBQ2pCO0NBRUEsY0FBYyxLQUFLLFNBQVMsRUFBRSxPQUFPLEtBQUssQ0FBQztDQUUzQyxTQUFTO0VBQ1AsSUFBSSxLQUFLLE1BQU0sT0FDYixPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssTUFBTSxPQUFPLEtBQUssS0FBSztFQUN6RCxPQUFPLEtBQUssTUFBTTtDQUNwQjtBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkVycm9yQm91bmRhcnkudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgdHlwZSBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCdcblxudHlwZSBQcm9wcyA9IHtcbiAgZmFsbGJhY2s6IChlcnJvcjogRXJyb3IsIHJlc2V0OiAoKSA9PiB2b2lkKSA9PiBSZWFjdE5vZGVcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZVxufVxudHlwZSBTdGF0ZSA9IHsgZXJyb3I6IEVycm9yIHwgbnVsbCB9XG5cbmV4cG9ydCBjbGFzcyBFcnJvckJvdW5kYXJ5IGV4dGVuZHMgQ29tcG9uZW50PFByb3BzLCBTdGF0ZT4ge1xuICBzdGF0ZTogU3RhdGUgPSB7IGVycm9yOiBudWxsIH1cblxuICBzdGF0aWMgZ2V0RGVyaXZlZFN0YXRlRnJvbUVycm9yKGVycm9yOiBFcnJvcik6IFN0YXRlIHtcbiAgICByZXR1cm4geyBlcnJvciB9XG4gIH1cblxuICByZXNldCA9ICgpID0+IHRoaXMuc2V0U3RhdGUoeyBlcnJvcjogbnVsbCB9KVxuXG4gIHJlbmRlcigpIHtcbiAgICBpZiAodGhpcy5zdGF0ZS5lcnJvcilcbiAgICAgIHJldHVybiB0aGlzLnByb3BzLmZhbGxiYWNrKHRoaXMuc3RhdGUuZXJyb3IsIHRoaXMucmVzZXQpXG4gICAgcmV0dXJuIHRoaXMucHJvcHMuY2hpbGRyZW5cbiAgfVxufVxuIl19